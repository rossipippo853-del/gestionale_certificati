# 🖥️ Guida: provare il progetto a casa e poi portarlo al lavoro

Questa guida è pensata per **Windows** (i passaggi valgono igualmente su Mac/Linux,
le differenze sono segnalate). Il progetto è una **web application**: per usarla
devono girare insieme 3 cose sul PC:

1. **Node.js** → fa girare il server dell'applicazione
2. **MariaDB/MySQL** → il database
3. il **browser** → dove usi l'app su `http://localhost:3000`

Non serve installare nulla di Html/PHP: solo Node e il database.

---

## A. Installazione software a casa (una sola volta, ~15 minuti)

### 1) Node.js
- Vai su **https://nodejs.org** → scarica la versione **LTS** per Windows (file `.msi`)
- Installa con "Avanti" a tutte le schermate (lascia tutto di default)
- Verifica: apri il **Prompt dei comandi** (tasto Windows → digita `cmd`) e scrivi:
  ```
  node -v
  ```
  deve rispondere con un numero tipo `v22.14.0`.

### 2) Database — scegli UNA delle tre opzioni

**Opzione 1 — XAMPP (consigliata per la prova a casa, la più semplice)**
- Scarica XAMPP da **https://www.apachefriends.org** e installalo (basta il modulo MySQL/MariaDB)
- Apri **XAMPP Control Panel** → sulla riga **MySQL** premi **Start**
- Il database gira: l'utility `mysql` si trova in `C:\xampp\mysql\bin\mysql.exe`

**Opzione 2 — MySQL Community Server (più "da produzione")**
- Scarica da **https://dev.mysql.com/downloads/installer/** → installa con configurazione default
- Segna la password di `root` che scegli durante l'installazione
- Il client `mysql` viene aggiunto al PATH (comando `mysql` diretto)

**Opzione 3 — Docker (se hai già Docker Desktop)**
```
docker run -d --name mysql-certificati -e MARIADB_ROOT_PASSWORD=root -p 3306:3306 mariadb:11
```
(il client diventa: `docker exec -it mysql-certificati mariadb -u root -proot`)

---

## B. Preparare la cartella del progetto

1. Scarica **`certificati-comune.zip`** dall'area file di questa chat
2. Estrai lo ZIP in una cartella a piacere, ad esempio `Documenti\certificati-comune`
3. Apri una finestra di **Prompt dei comandi DENTRO quella cartella**:
   trucco veloce → apri la cartella in Esplora risorse, clicca sulla barra degli
   indirizzi, scrivi `cmd` e premi Invio.

> ⚠️ Usa il **Prompt dei comandi (cmd)**, non PowerShell: nei comandi sotto c'è il
> simbolo `<` che PowerShell non supporta. (Su Mac/Linux usa il Terminale normale.)

---

## C. Comandi da eseguire (in ordine)

### 1) Installa le dipendenze (scarica le librerie, ~1 minuto)
```
npm install
```

### 2) Crea il database e le tabelle

**Con XAMPP:**
```
"C:\xampp\mysql\bin\mysql.exe" -u root < db\schema.sql
```

**Con MySQL ufficiale** (ti chiede la password di root):
```
mysql -u root -p < db\schema.sql
```

**Alternativa grafica:** apri phpMyAdmin (XAMPP: http://localhost/phpmyadmin)
→ scheda **Importa** → seleziona il file `db\schema.sql` → Esegui.

> Questo script crea: database `certificati_comune`, le 2 tabelle e l'utente
> applicativo `cert_app` con password `CambiaQuestaPassword!`.
> **Per la prova a casa va benissimo lasciare questa password demo.**

### 3) Configura il file `.env`
- Copia `.env.example` e rinominala in `.env` (in cmd: `copy .env.example .env`)
- Aprilo col Blocco note e controlla/imposta queste righe:

| Riga | Valore per la prova a casa |
|---|---|
| `DB_HOST=localhost` | lascia così |
| `DB_PORT=3306` | lascia così |
| `DB_USER=cert_app` | lascia così |
| `DB_PASSWORD=` | **`CambiaQuestaPassword!`** (quella messa da schema.sql) |
| `JWT_SECRET=` | scrivi una stringa lunga e inventata, es. `casa-test-9t84hgs984hg9w4gh84h` |

### 4) Crea gli utenti iniziali
```
node db\seed.js
```
- Con `node db\seed.js --dipendenti=250` crea anche 250 dipendenti finti per provare
  ricerca, filtri e paginazione **(consigliato per la prova a casa)**
- Con `node db\seed.js --dipendenti=0` crea **solo l'account amministratore**
  (quello che userai al lavoro per iniziare con i dati veri)

### 5) Avvia l'applicazione
```
npm start
```
Devi leggere:
```
[OK] Connessione al database stabilita.
[OK] Server avviato su http://0.0.0.0:3000
```
Apri il browser su **http://localhost:3000** 🎉

Credenziali create dal seed:

| Ruolo | Matricola | Password |
|---|---|---|
| Amministratore | `admin` | `Admin@2026` |
| Dipendenti demo | `10001`…`10250` | `Benvenuto@2026` |

**Per fermare l'app:** `CTRL+C` nella finestra del prompt.
**I prossimi giorni:** avvia MySQL da XAMPP Control Panel, poi `npm start` nella cartella. I dati restano salvati.

---

### C-bis. Aggiornamento di un'installazione ESISTENTE (v2.2.5)

Se il database era già stato creato con una versione precedente, dopo aver
sostituito i file del progetto applica questa migrazione (una riga, non tocca
i dati: i certificati esistenti restano intatti):

```
sudo mysql certificati_comune < db/migrazione-v2.2.5.sql
```

(Windows/XAMPP: `"C:\xampp\mysql\bin\mysql.exe" -u root certificati_comune < db\migrazione-v2.2.5.sql`)

Le installazioni NUOVE non ne hanno bisogno: `db\schema.sql` è già aggiornato.

## D. (Facoltativo) Provarla anche dal telefono/altro PC di casa

1. Trova l'IP del tuo PC: in cmd scrivi `ipconfig` → guarda **IPv4 Address** (es. `192.168.1.50`)
2. Alla prima esecuzione Windows chiederà di consentire Node.js nel firewall → **Consenti**
3. Dal telefono (stessa Wi-Fi) apri `http://192.168.1.50:3000`

---

## E. Problemi comuni e soluzioni

| Problema | Soluzione |
|---|---|
| `'node' non è riconosciuto` | reinstalla Node.js e **riapri** il prompt dei comandi |
| `'mysql' non è riconosciuto` | usa il percorso completo XAMPP: `"C:\xampp\mysql\bin\mysql.exe" ...` |
| `<` dà errore strano | stai usando PowerShell: apri **cmd** invece |
| `ER_ACCESS_DENIED_ERROR` | password in `.env` diversa da quella dell'utente del database |
| `ECONNREFUSED 127.0.0.1:3306` | il database non è avviato (XAMPP → Start su MySQL) |
| `EADDRINUSE :::3000` | porta occupata: in `.env` imposta `PORT=3001` e usa http://localhost:3001 |
| XAMPP MySQL non parte | probabilmente hai già un servizio MySQL attivo: fermalo da `services.msc` |
| Login sempre rifiutato con seed fatto | hai scritto la password demo sbagliata: admin=`Admin@2026` (maiuscole!) |

---

## F. Portare il progetto al lavoro

### Cosa copiare (e cosa no)
Dal PC di casa porta al lavoro **lo stesso ZIP scaricato qui** (è già pulito):
contiene il codice ma **NON** contiene `node_modules` (si riscarica con `npm install`),
`uploads/` (si ricrea da sola) né `.env` (si ricrea da `.env.example`).

> ❌ **Non** copiare da casa `node_modules`, `uploads` con dati veri o il tuo `.env`:
> al lavoro useranno password e segreti nuovi.

### Al lavoro — passi
1. Installa Node.js e MariaDB/MySQL sul **server** che userete (o fai installare all'IT)
2. Copia la cartella del progetto sul server
3. **Prima di importare lo schema**: apri `db\schema.sql` col Blocco note e cambia la
   password alla riga `IDENTIFIED BY '...'` con una password vera
4. Ripeti i comandi del punto C con:
   - `.env` con la nuova `DB_PASSWORD` e un `JWT_SECRET` casuale nuovo
     (generalo con: `openssl rand -hex 32` su Linux, oppure inventa 64 caratteri)
   - `node db\seed.js --dipendenti=0` → crea **solo l'admin**, senza dati finti
5. Appena entri: **cambia subito la password dell'admin** (sezione Profilo)
6. Crea i dipendenti veri dal pannello admin (o import massivo da implementare in seguito)

### Come lo usano i ~250 colleghi
- L'app deve restare **accesa sul server**: su Linux usa il servizio systemd incluso
  (`deploy/certificati.service`) o PM2; su Windows Server usa PM2 (`npm i -g pm2`) o
  Operazioni pianificate per l'avvio automatico
- I colleghi non installano nulla: navigano su `http://IP-DEL-SERVER:3000`
  (l'app è pensata per l'**intranet comunale**: non esporla direttamente su Internet;
  se serve accesso esterno, l'IT deve mettere un reverse proxy con HTTPS e impostare
  `COOKIE_SECURE=true` nel `.env` — dettagli nel README, sezione nginx)

### Checklist sicurezza prima dell'uso reale
- [ ] Password di `cert_app` cambiata in `schema.sql` e in `.env`
- [ ] `JWT_SECRET` nuovo e casuale
- [ ] Password admin cambiata dal profilo
- [ ] Nessun account demo presente (seed con `--dipendenti=0`)
- [ ] Backup pianificato: `mysqldump` del database + copia della cartella `uploads`

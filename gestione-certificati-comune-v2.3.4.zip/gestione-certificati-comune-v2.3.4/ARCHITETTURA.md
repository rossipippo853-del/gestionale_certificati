# Architettura dell'applicazione

## Panoramica

```
                        ┌───────────────────────────────────────────────┐
                        │              SERVER LOCALE (intranet)         │
  Browser dipendenti    │                                               │
  ┌──────────────┐      │  ┌──────────────────────┐                     │
  │ index.html   │──────┼─▶│  Node.js + Express   │                     │
  │ (login)      │      │  │                      │                     │
  ├──────────────┤      │  │  /api/auth/*         │──┐                  │
  │ dipendente.  │──────┼─▶│  /api/certificati/*  │  │ query            │
  │ html         │      │  │  /api/admin/*        │  ▼ parametriche    │
  ├──────────────┤      │  │  static: public/     │ ┌───────────────┐  │
  │ admin.html   │──────┼─▶│                      │ │ MySQL/MariaDB │  │
  └──────────────┘      │  └──────────┬───────────┘ │ certificati_  │  │
                        │             │ Multer      │ comune        │  │
  ~250 utenti           │             ▼             └───────────────┘  │
  (browser qualsiasi)   │  uploads/certificati/                        │
                        │   ├── 10001/1709xxxx_sicurezza.pdf           │
                        │   ├── 10002/1710xxxx_gdpr.pdf                │
                        │   └── …/{matricola}/{file univoco}.pdf       │
                        └───────────────────────────────────────────────┘
```

## Scelte tecnologiche

| Scelta | Motivazione |
|---|---|
| **Node.js + Express** | singolo runtime, nessun build step, diploi con `npm install && npm start`; perfetto per un server locale gestito dall'IT comunale |
| **mysql2 (pool)** | query 100% parametriche, pool di 10 connessioni ampiamente sufficiente per ~250 utenti concorrenti in intranet |
| **JWT in cookie httpOnly** | senza stato server-side (nessuna tabella di sessione da gestire), non leggibile da JavaScript (anti-XSS), scadenza 8 h = giornata lavorativa |
| **bcryptjs** | algoritmo bcrypt (standard), implementazione JS pura → nessuna compilazione nativa, installazione sempre pulita |
| **Multer** | standard de facto per upload su disco con naming custom e limiti di dimensione |
| **Frontend vanilla** | zero CDN (funziona anche senza Internet), zero build, manutenibile da personale IT non frontend |

## Livelli del backend

```
server.js
 └── middleware globali  (json, cookie, security headers)
      ├── public/        → frontend statico
      ├── /api/auth      → autenticazione (login, me, password)
      ├── /api           → certificati.dipendente  [middleware: autenticazione]
      └── /api/admin     → amministrazione         [middleware: autenticazione + soloAdmin]
```

Ogni richiesta autenticata passa per `src/middleware/auth.js` che:
1. verifica la firma e la scadenza del JWT nel cookie `token`;
2. **ricarica l'utente dal database**: se l'account è stato disabilitato o eliminato
   la sessione viene invalidata all'istante (nessuna finestra residua fino a scadenza token);
3. espone `req.utente` (id, matricola, nome, ruolo) ai controller.

## Modello dati

```
┌────────────────────┐                 ┌────────────────────────────┐
│ dipendenti         │                 │ certificati                │
├────────────────────┤                 ├────────────────────────────┤
│ id (PK)            │◀──1:many──N─FK──│ dipendente_id              │
│ matricola  UNIQUE  │                 │ nome_corso                 │
│ nome / cognome     │                 │ ente_erogatore             │
│ email              │                 │ data_conseguimento (DATE)  │
│ password_hash(bcrypt)              │ nome_file_originale        │
│ ruolo ENUM         │◀──FK approvato──│ percorso_file (RELATIVO)   │
│ attivo             │      _da        │ dimensione_file            │
│ must_change_password                │ stato ENUM(IN_ATTESA/      │
└────────────────────┘                 │      APPROVATO/RIFIUTATO)  │
                                       │ note_admin / approvato_il  │
                                       └────────────────────────────┘
```

Ciclo di vita del certificato: `IN_ATTESA` → `APPROVATO` | `RIFIUTATO` (+ nota motivazione).

## Flussi principali

**Upload (dipendente)** — POST `/api/certificati`
1. middleware autenticazione → `req.utente`;
2. Multer: filtro estensione `.pdf` + MIME `application/pdf`, limite 5 MB,
   destinazione `uploads/certificati/{matricola}/` (**creata al primo upload**),
   nome `{timestamp}_{sanificato}.pdf` (**niente sovrascritture**);
3. verifica **magic bytes** `%PDF-` (i file rinominati vengono rifiutati e cancellati);
4. INSERT nel DB del solo **percorso relativo** + metadati, stato `IN_ATTESA`.

**Download/visualizzazione** — GET `/api/certificati/:id/file`
1. autenticazione; 2. lettura record; 3. controllo **proprietà** (o ruolo admin);
4. risoluzione anti-path-traversal; 5. `sendFile` (inline) o `download` (allegato).

**Approvazione admin** — PUT `/api/admin/certificati/:id/stato`
`stato = APPROVATO|RIFIUTATO`, `note_admin` opzionale, audit su `approvato_da`/`approvato_il`.

**Export CSV** — GET `/api/admin/certificati/export`
stessi filtri dell'elenco, BOM UTF-8 + separatore `;` → apertura diretta in Excel.

## Performance

- Indici su `matricola` (UNIQUE), `cognome`, `stato`, `data_conseguimento`, `dipendente_id`.
- Elenco utenti/certificati **paginati** (25/riga pagina) con `COUNT(*)` dedicato.
- Pool di connessioni MySQL riutilizzate (nessun connect per richiesta).
- File statici serviti da Express; in produzione nginx può agire da proxy/cache.
- Volume stimato: 250 utenti × ~10 certificati = ~2.500 righe/5 MB PDF/anno → trascurabile.

## Estensioni previste facilmente

- notifiche email su nuovo caricamento/approvazione;
- scadenze di certificati obbligatori (colonna `data_scadenza` + vista "in scadenza");
- import anagrafica massiva da CSV/AD;
- firma digitale/verifica hash del PDF (colonna `sha256`).

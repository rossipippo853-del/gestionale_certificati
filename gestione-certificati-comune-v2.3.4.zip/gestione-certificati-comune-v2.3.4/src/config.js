/**
 * ============================================================================
 *  src/config.js — CONFIGURAZIONE CENTRALE (12-factor: tutto da ambiente)
 * ============================================================================
 *  Unico punto in cui si leggono le variabili del file .env: i moduli del
 *  progetto importano `config` e non toccano mai process.env direttamente.
 *  Vantaggi: valori verificabili in un solo posto, override facile nei test
 *  (che impostano le env PRIMA di importare questo modulo).
 * ============================================================================
 */
require('dotenv').config();
const path = require('path');

/* Radice del progetto (certificati-comune/): usata per risolvere i percorsi
 * relativi in modo INDEPENDENTE dalla directory di avvio. [FIX QA-B1] */
const RADICE_PROGETTO = path.resolve(__dirname, '..');

const config = {
  /** Porta HTTP del server (default 3000; nei test 3100). */
  port: parseInt(process.env.PORT || '3000', 10),

  /** Interfaccia di ascolto [v1.5 — parametrizzata per il deployment]:
   *  '0.0.0.0' = tutte le schede di rete → i client della intranet
   *  raggiungono il server con http://IP-DEL-SERVER:3000.
   *  Restringere (es. 127.0.0.1) solo per installazioni locali/behind-proxy. */
  host: process.env.HOST || '0.0.0.0',

  /** Parametri di connessione al database — alimentano il pool in db.js. */
  db: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306', 10),
    user: process.env.DB_USER || 'cert_app',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'certificati_comune',
    connectionLimit: 10,   // ampiamente sufficiente per ~250 utenti intranet
    // DATE/TIMESTAMP come stringhe 'YYYY-MM-DD' / 'YYYY-MM-DD HH:MM:SS':
    // evita ogni conversione di fuso orario del driver e semplifica il JSON.
    dateStrings: true,
  },

  /** Segreto HMAC dei JWT: chi lo conosce può firmare token validi.
   *  In produzione DEVE essere casuale e riservato (openssl rand -hex 32). */
  jwtSecret: process.env.JWT_SECRET || '',
  jwtScadenza: process.env.JWT_SCADENZA || '8h', // una giornata lavorativa

  /** Attributi del cookie di sessione:
   *  secure=true SOLO dietro HTTPS (se attivato troppo presto i cookie
   *  su http://intranet verrebbero rifiutati dal browser). */
  cookieSecure: process.env.COOKIE_SECURE === 'true',
  cookieMaxAgeMs: 8 * 60 * 60 * 1000, // 8 ore, allineata alla scadenza JWT

  /** Radice dello storage PDF (v2.0): uploads/certificati/{codice_fiscale}/{file}.pdf
   *  Risolta contro la radice del PROGETTO (non la cwd). */
  uploadRoot: path.resolve(RADICE_PROGETTO, process.env.UPLOAD_DIR || 'uploads'),

  /** Limite dimensione upload: 5 MB in byte (valutato da Multer). */
  maxFileBytes: 5 * 1024 * 1024,
};

/* Guardia di configurazione: avvisa (senza bloccare) se il segreto JWT è
 * assente o lasciato al valore d'esempio — indica un ambiente non configurato. */
if (!config.jwtSecret || config.jwtSecret.includes('SOSTITUISCI')) {
  console.warn('[ATTENZIONE] JWT_SECRET non impostata o predefinita: imposta un segreto casuale in .env prima dell\'uso in produzione.');
}

module.exports = config;

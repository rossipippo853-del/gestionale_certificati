/**
 * ============================================================================
 *  src/app.js — CONFIGURAZIONE DELL'APPLICAZIONE EXPRESS
 * ============================================================================
 *  L'app è separata dall'avvio (server.js): questo modulo ESPORTA l'app senza
 *  mettersi in ascolto, così la suite di test può montarla su una porta
 *  dedicata con ambiente isolato (DB e upload di test).
 *
 *  Ordine di registrazione (Importante in Express: conta l'ordine!):
 *    1. middleware globali (parsing, cookie, header di sicurezza)
 *    2. rotte pubbliche (/api/salute) + static frontend
 *    3. router API protetti (auth → certificati → admin)
 *    4. 404 API + gestore errori centrale (sempre per ultimo)
 * ============================================================================
 */
require('dotenv').config(); // carica .env nelle process.env (una sola volta)

const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');

const authRoutes = require('./routes/auth.routes');
const certificatiRoutes = require('./routes/certificati.routes');
const adminRoutes = require('./routes/admin.routes');
const { gestoreErrori } = require('./middleware/errori');

const app = express();

/* ---------------------- Hardening e parsing ---------------------- */

app.disable('x-powered-by');      // non pubblicare la tecnologia usata
app.set('trust proxy', 1);        // dietro nginx: fida del primo hop per X-Forwarded-*
app.use(express.json({ limit: '1mb' }));  // body JSON (limite prudente anti DoS)
app.use(cookieParser());          // rende req.cookies disponibile ai middleware

/* Header di sicurezza applicati a OGNI risposta:
 *   X-Content-Type-Options → vieta il MIME-sniffing del browser
 *   X-Frame-Options        → la pagina non è incorniciabile da altri siti (anti clickjacking)
 *   Referrer-Policy        → non filtrare URL interni verso l'esterno
 *   Content-Security-Policy → niente script esterni/inline (script-src 'self'):
 *                             riduce drasticamente l'impatto di eventuali XSS
 *   Cache-Control no-store sulle API → nessuna risposta autenticata resta in cache */
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; " +
    "script-src 'self'; frame-ancestors 'self'; form-action 'self'; base-uri 'self'"
  );
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control', 'no-store');
  next();
});

/* ---------------------- Frontend statico ----------------------
 * public/ è servito così com'è (nessun build step): index.html (login),
 * dipendente.html, admin.html, css/ e js/. extensions:['html'] permette
 * URL puliti (/dipendente invece di /dipendente.html).
 *
 * [FIX QA-C1] Alias /login → /: la pagina di accesso è index.html servita
 * sulla radice; un eventuale link o segnalibro a "/login" non deve produrre
 * un 404 inglese ma ricadere sulla pagina di login. */
app.get('/login', (req, res) => res.redirect('/'));
app.use(express.static(path.join(__dirname, '..', 'public'), {
  index: 'index.html',
  extensions: ['html'],
  maxAge: 0, // in intranet si privilegia la sempre-freschezza dei file
}));

/* ---------------------- API REST ----------------------
 * Rotte pubbliche PRIMA dei router protetti. Nota storica (FIX QA-B10): il
 * router dei certificati è montato sul SUO prefisso (/api/certificati) e non
 * su /api, così il suo middleware di autenticazione non intercetta rotte
 * altrui (come accadeva per /api/salute, che rispondeva 401). */
app.get('/api/salute', (req, res) => res.json({ stato: 'ok', ora: new Date().toISOString() }));

app.use('/api/auth', authRoutes);               // login/logout/me/password
app.use('/api/certificati', certificatiRoutes); // area dipendente (autenticazione)
app.use('/api/admin', adminRoutes);             // area admin (autenticazione + ruolo)

/* 404 strutturato per qualunque endpoint API non riconosciuto: il frontend
 * riceve sempre JSON, mai pagine HTML di errore. */
app.use('/api', (req, res) => res.status(404).json({ errore: 'Endpoint non trovato.' }));

/* Gestore errori centrale: SEMPRE l'ultimo middleware registrato.
 * Converte MulterError, JSON malformati ed errori imprevisti in risposte
 * coerenti (4xx con messaggio utile, 500 senza dettagli interni). */
app.use(gestoreErrori);

module.exports = { app };

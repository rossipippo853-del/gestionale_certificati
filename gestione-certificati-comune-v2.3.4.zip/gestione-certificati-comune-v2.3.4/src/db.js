/**
 * ============================================================================
 *  src/db.js — ACCESSO AL DATABASE (pool mysql2/promise)
 * ============================================================================
 *  PERCHÉ UN POOL: aprire una connessione MySQL per ogni richiesta costa
 *  svariate decine di ms; il pool ne tiene 10 pronte e le "presta" ai
 *  controller, riciclandole. Con ~250 utenti in intranet è più che sufficiente.
 *
 *  REGOLA D'ORO DEL PROGETTO: ogni query usa SEGNAPosti "?" con valori
 *  separati (prepared statements del driver). Nessuna stringa SQL viene
 *  mai costruita concatenando input dell'utente → SQL injection resa
 *  strutturalmente impossibile.
 *
 *  dateStrings: il driver restituisce DATE e TIMESTAMP come stringhe
 *  'YYYY-MM-DD' e 'YYYY-MM-DD HH:MM:SS' invece di oggetti Date: il frontend
 *  li formatta senza ambiguità di fuso orario.
 * ============================================================================
 */
const mysql = require('mysql2/promise');
const config = require('./config');

const pool = mysql.createPool(config.db);

/** Ping di controllo usato all'avvio del server (fail-fast se il DB è giù). */
async function testConnection() {
  const conn = await pool.getConnection();
  await conn.ping();
  conn.release(); // la connessione torna al pool, non viene chiusa
}

module.exports = { pool, testConnection };

/**
 * ============================================================================
 *  middleware/errori.js — GESTORE ERRORI CENTRALE (middleware Express 4 argomenti)
 * ============================================================================
 *  Express riconduce TUTTI gli errori (next(err), throw nei middleware sync,
 *  MulterError, errori di parsing del body) a questo gestore, che deve restare
 *  l'ULTIMO middleware registrato in app.js.
 *
 *  Contratto verso il client:
 *    - errori noti → 4xx con messaggio in italiano comprensibile all'utente;
 *    - errori imprevisti → 500 generico (NESSUN dettaglio interno: stack,
 *      query o percorsi non devono trapelare); il dettaglio resta nel log.
 * ============================================================================
 */
const multer = require('multer');

function gestoreErrori(err, req, res, next) {
  // Se gli header sono già stati inviati non si può più rispondere: delega
  // al default handler di Express (chiude la connessione).
  if (res.headersSent) return next(err);

  /* 1) Errori di Multer (upload):
   *    LIMIT_FILE_SIZE          → superato il limite di 5 MB
   *    LIMIT_FILE_COUNT/UNEXPECTED → più di un file o campo diverso da "file" */
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ errore: 'File troppo grande: il limite massimo è 5 MB.' });
    }
    if (err.code === 'LIMIT_FILE_COUNT' || err.code === 'LIMIT_UNEXPECTED_FILE') {
      return res.status(400).json({ errore: 'È possibile caricare un solo file PDF nel campo "file".' });
    }
    return res.status(400).json({ errore: 'Errore durante il caricamento del file.' });
  }

  /* 2) Errori del fileFilter di Multer: li emettiamo come Error con messaggio
   *    esplicito che contiene "pdf" → 400 con il messaggio stesso. */
  if (err && typeof err.message === 'string' && err.message.toLowerCase().includes('pdf')) {
    return res.status(400).json({ errore: err.message });
  }

  /* 3) Body JSON malformato o troppo grande (express.json). */
  if (err && (err.type === 'entity.too.large' || err.status === 400 && err.type === 'entity.parse.failed')) {
    return res.status(400).json({ errore: 'Corpo della richiesta non valido.' });
  }

  /* 4) Tutto il resto: log completo lato server, risposta generica al client. */
  console.error('[ERRORE]', req.method, req.originalUrl, '\n', err);
  res.status(500).json({ errore: 'Errore interno del server.' });
}

module.exports = { gestoreErrori };

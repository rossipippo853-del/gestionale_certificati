/**
 * ============================================================================
 *  middleware/auth.js — AUTENTICAZIONE E AUTORIZZAZIONE PER RUOLO
 * ============================================================================
 *  Tre middleware usati in cascata da src/app.js:
 *
 *    autenticazione              → chi sei? (JWT valido + account attivo)
 *    soloAdmin                   → hai il ruolo giusto? (AMMINISTRATORE)
 *    richiediPasswordAggiornata  → hai sostituito la password provvisoria?
 *
 *  Scelte di sicurezza chiave:
 *   1. Il token viaggia SOLO nel cookie httpOnly `token` (non nei header
 *      custom gestiti da JS: meno superficie XSS).
 *   2. Ad OGNI richiesta l'utente viene RILETTO DAL DATABASE: se l'admin
 *      disabilita un account, tutte le sue sessioni muoiono all'istante,
 *      senza attendere la scadenza naturale del token.
 *   3. I token revocati via logout (jti nel registro sessioni) sono rifiutati.
 * ============================================================================
 */
const jwt = require('jsonwebtoken');
const config = require('../config');
const { pool } = require('../db');
const { eRevocato } = require('../utils/sessioni');

/** Proiezione minimale dell'utente per le verifiche di sessione. */
const SELECT_UTENTE = `
  SELECT id, matricola, codice_fiscale, nome, cognome, sesso, qualifica, email, ruolo, attivo, must_change_password
  FROM dipendenti
  WHERE id = ?
  LIMIT 1`;

/* [v2.3.3] Endpoint di DOWNLOAD per i quali il cookie httpOnly resta
 * accettato: sono link diretti del browser (Scarica/Visualizza/Export),
 * l'unico caso in cui l'header Authorization non può essere inviato. */
const PERCORSI_DOWNLOAD_CON_COOKIE = [
  /^\/api\/certificati\/\d+\/file$/,            // PDF/JPG/PNG del certificato
  /^\/api\/certificati\/allegati\/\d+\/file$/, // singolo allegato
  /^\/api\/admin\/utenti\/export$/,             // «Esporta Anagrafica CSV»
  /^\/api\/admin\/certificati\/export$/,        // export CSV dei certificati
];

/** True solo per richieste GET di download (query string esclusa). */
function cookieAmmessoPerDownload(req) {
  if ((req.method || 'GET').toUpperCase() !== 'GET') return false;
  const url = String(req.originalUrl || req.url || '').split('?')[0];
  return PERCORSI_DOWNLOAD_CON_COOKIE.some((re) => re.test(url));
}

/**
 * MIDDLEWARE 1 — AUTENTICAZIONE.
 * 401 in tutti i casi di sessione assente/non valida/revocata/account spento.
 * In caso di successo espone `req.utente` ai controller successivi.
 */
async function autenticazione(req, res, next) {
  try {
    /* 1) Token dall'HEADER Authorization (Bearer) o, in assenza, dal cookie.
     *    [v2.3.1] l'header serve alla modalità «sessione di scheda»: il
     *    frontend custodisce il JWT in sessionStorage (che muore alla chiusura
     *    della scheda) e lo invia qui; il cookie httpOnly resta per i download
     *    diretti e per i client che non gestiscono sessionStorage. */
    let token = null;
    const header = req.headers && (req.headers.authorization || req.headers.Authorization);
    if (typeof header === 'string' && header.startsWith('Bearer ')) {
      token = header.slice('Bearer '.length).trim();
    }
    /* [v2.3.3] MODALITÀ RIGIDA — il cookie è accettato SOLO sui download
     * diretti (link <a href> che non possono inviare l'header Authorization):
     * per ogni altra richiesta conta SOLO il token di scheda (sessionStorage).
     * Così chiusa la scheda il sessionStorage muore e il cookie sopravvissuto
     * NON basta più a rientrare: il login è sempre obbligatorio. */
    if (!token && req.cookies && req.cookies.token && cookieAmmessoPerDownload(req)) {
      token = req.cookies.token;
    }
    if (!token) return res.status(401).json({ errore: 'Non autenticato.' });

    /* 2) Firma e scadenza: jwt.verify lancia se il segreto non corrisponde
     *    o se exp è passata → 401 e cookie ripulito dal browser. */
    let payload;
    try {
      payload = jwt.verify(token, config.jwtSecret);
    } catch {
      res.clearCookie('token', { path: '/' });
      return res.status(401).json({ errore: 'Sessione scaduta. Effettua di nuovo il login.' });
    }

    /* 3) Token revocato da un logout? (registro in memoria per jti) */
    if (payload.jti && eRevocato(payload.jti)) {
      res.clearCookie('token', { path: '/' });
      return res.status(401).json({ errore: 'Sessione terminata. Effettua di nuovo il login.' });
    }

    /* 3-bis) [v2.1] Token con uno `scopo` diverso dalla sessione: il cookie
     * `token_cambio` del primo accesso NON autentica NULLA, nemmeno se
     * rinominato in `token` (defense in depth). Solo l'endpoint che lo ha
     * emesso (POST /api/auth/primo-accesso) lo accetta. */
    if (payload.scopo) {
      res.clearCookie('token', { path: '/' });
      return res.status(401).json({ errore: 'Completa il cambio password dalla pagina di accesso.' });
    }

    /* 4) Rilettura dal DB: fonte di verità su attivo/ruolo aggiornati.
     *    Un token "vecchio" non basta: conta lo stato CORRENTE dell'account. */
    const [righe] = await pool.query(SELECT_UTENTE, [payload.id]);
    const utente = righe[0];
    if (!utente || !utente.attivo) {
      res.clearCookie('token', { path: '/' });
      return res.status(401).json({ errore: 'Account non disponibile. Contatta l\'amministratore.' });
    }

    req.utente = utente; // → disponibile ai controller e agli altri middleware
    next();
  } catch (err) {
    next(err); // errori imprevisti → gestore centrale (500 generico)
  }
}

/**
 * MIDDLEWARE 2 — AUTORIZZAZIONE PER RUOLO.
 * Da usare SEMPRE dopo `autenticazione` (richiede req.utente). Nei fatti è
 * applicato a livello di router in routes/admin.routes.js: l'intero gruppo
 * /api/admin è precluso ai DIPENDENTE (403).
 */
function soloAdmin(req, res, next) {
  if (!req.utente || req.utente.ruolo !== 'AMMINISTRATORE') {
    return res.status(403).json({ errore: 'Operazione riservata agli amministratori.' });
  }
  next();
}

/**
 * MIDDLEWARE 3 — CAMBIO PASSWORD RACCOMANDATO (solo area ADMIN).
 * [MODIFICA v1.5] Questo vincolo NON si applica più all'area DIPENDENTE:
 * il caricamento dei certificati è consentito anche con la password
 * provvisoria (l'invito al cambio è un banner informativo non bloccante).
 * Resta applicato alle SCRITTURE dell'AREA ADMIN (admin.routes.js): le
 * operazioni amministrative esigono credenziali proprie aggiornate.
 * La LETTURA resta sempre permessa: le pagine si caricano e mostrano
 * l'avviso; /api/auth/password è fuori da questo vincolo, altrimenti
 * l'utente non potrebbe mai sbloccarsi.
 */
function richiediPasswordAggiornata(req, res, next) {
  if (req.utente && req.utente.must_change_password) {
    return res.status(403).json({
      errore: 'Devi prima sostituire la password provvisoria (sezione Profilo).',
      codice: 'PASSWORD_TEMPORANEA', // codice macchina leggibile dal frontend
    });
  }
  next();
}

module.exports = { autenticazione, soloAdmin, richiediPasswordAggiornata };

/**
 * ============================================================================
 *  routes/auth.routes.js — AUTENTICAZIONE E GESTIONE DELLE CREDENZIALI
 * ============================================================================
 *  Montato su: /api/auth  (vedi src/app.js)
 *
 *  Endpoint esposti:
 *    POST /api/auth/login           → accesso con matricola + password
 *    POST /api/auth/primo-accesso   → [v2.1] completa il cambio obbligatorio
 *                                     (modale al primo accesso, cookie monouso)
 *    POST /api/auth/logout          → revoca della sessione corrente
 *    GET  /api/auth/me              → profilo dell'utente autenticato
 *    PUT  /api/auth/password        → cambio password (richiede quella attuale)
 *
 *  Sicurezza implementata in questo file:
 *    - bcrypt (costo 10) per il confronto e la creazione degli hash: la
 *      password in chiaro NON viene mai memorizzata né loggata;
 *    - confronto in tempo "costante" logico: il messaggio di errore del login
 *      è volutamente identico per "matricola inesistente" e "password errata"
 *      (non si rivela all'esterno quali matricole esistono — anti enumerazione);
 *    - rate limiting in memoria: massimo 5 tentativi falliti per matricola
 *      ogni 15 minuti (anti brute-force su credenziali ripetute);
 *    - cookie di sessione httpOnly + SameSite=Lax (+ Secure se HTTPS): il
 *      token JWT non è leggibile da JavaScript (mitigazione XSS);
 *    - revoca dei token al logout tramite identificativo univoco `jti`
 *      (vedi utils/sessioni.js).
 * ============================================================================
 */
const express = require('express');
const crypto = require('crypto');        // randomUUID: identifica ogni token emesso
const bcrypt = require('bcryptjs');      // hashing adattivo delle password
const jwt = require('jsonwebtoken');     // firma/verifica dei token di sessione

const config = require('../config');     // segreto JWT, scadenza, flag cookie
const { pool } = require('../db');       // pool di connessioni MySQL
const { autenticazione } = require('../middleware/auth');
const { revoca, eRevocato } = require('../utils/sessioni'); // registro dei token revocati
const { pulisci, validaNuovaPassword } = require('../utils/validazione');

const router = express.Router();

/** Costo bcrypt: 2^10 iterazioni internes ~50-100 ms/hash (buon compromesso
 *  sicurezza/rehosting su server locale; si può alzare in futuro). */
const BCRYPT_ROUNDS = 10;

/* ------------------------------------------------------------------ *
 *  LIMITAZIONE DEI TENTATIVI DI LOGIN (anti brute-force)
 *  ------------------------------------------------------------------
 *  Struttura dati: Map in memoria  matricola → { n, scadenza }
 *    n        = tentativi falliti consecutivi nella finestra corrente
 *    scadenza = istante (epoch ms) in cui la finestra si azzera
 *
 *  È sufficiente per un'applicazione a SINGOLO server in intranet.
 *  Per installazioni multi-istanza sostituire con express-rate-limit
 *  appoggiato a un store condiviso (Redis).
 * ------------------------------------------------------------------ */
const TENTATIVI_MAX = 5;
const FINESTRA_MS = 15 * 60 * 1000; // 15 minuti
const tentativi = new Map();
/* [AUDIT C3] jti dei cookie di primo accesso attualmente PRENOTATI da una
 * richiesta in corso: l'aggiunta/verifica sincrona è atomica sull'event-loop,
 * quindi due richieste parallele non possono consumare lo stesso cookie. */
const CAMBI_IN_CORSO = new Set();

/** True se la matricola può ancora tentare il login. */
function loginConsentito(matricola) {
  const t = tentativi.get(matricola);
  if (!t) return true;                              // mai tentata → ok
  if (Date.now() > t.scadenza) {                    // finestra scaduta → reset
    tentativi.delete(matricola);
    return true;
  }
  return t.n < TENTATIVI_MAX;                       // sotto soglia → ok
}

/** Registra un tentativo fallito; al 5° errore apre una nuova finestra da 15'. */
function registraFallimento(matricola) {
  // Anti memory-leak: con tantissime matricole diverse la mappa crescerebbe
  // senza limiti; periodicamente scartiamo le finestre scadute.
  if (tentativi.size >= 500) {
    const ora = Date.now();
    for (const [chiave, valore] of tentativi) {
      if (ora > valore.scadenza) tentativi.delete(chiave);
    }
  }
  const t = tentativi.get(matricola) || { n: 0, scadenza: Date.now() + FINESTRA_MS };
  t.n += 1;
  if (t.n >= TENTATIVI_MAX) t.scadenza = Date.now() + FINESTRA_MS;
  tentativi.set(matricola, t);
}

/* ------------------------------------------------------------------ */

/**
 * Imposta il cookie di sessione con tutti gli attributi di sicurezza:
 *   httpOnly  → il cookie non è leggibile da JavaScript (anti furto via XSS)
 *   sameSite  → 'lax' mitiga il CSRF sui verbi non-sicuri
 *   secure    → true SOLO dietro HTTPS (flag COOKIE_SECURE in .env)
 *   [v2.2.9] NIENTE maxAge/expires → COOKIE DI SESSIONE: il browser lo
 *   cancella alla chiusura della finestra, quindi alla prossima apertura è
 *   SEMPRE obbligatorio rieffettuare l'accesso (nessuna persistenza).
 *   Il JWT interno conserva comunque la propria scadenza di sicurezza (8h).
 */
function impostaCookieSessione(res, token) {
  res.cookie('token', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.cookieSecure,
    path: '/',
    // niente maxAge / expires: cookie di sessione
  });
}

/* [v2.1] CAMBIO PASSWORD OBBLIGATORIO AL PRIMO ACCESSO ----------------------
 * Quando il login riconosce la password provvisoria NON viene emessa la
 * sessione: al suo posto un token JWT "scopito" (scopo: 'primo-accesso',
 * durata 15 minuti) viaggia nel cookie httpOnly `token_cambio` ed è accettato
 * SOLO dall'endpoint POST /api/auth/primo-accesso che completa il cambio nella
 * modale della pagina di login. Il middleware `autenticazione` rifiuta questi
 * token come sessioni (defense in depth) e il jti viene revocato dopo l'uso:
 * il cookie è quindi MONOUSO. */
const SCOPO_CAMBIO = 'primo-accesso';
const SCADENZA_CAMBIO = '15m';

function impostaCookieCambio(res, token) {
  res.cookie('token_cambio', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.cookieSecure,
    maxAge: 15 * 60 * 1000,
    path: '/',
  });
}

/** Proiezione "pubblica" dell'utente: MAI il campo password_hash. */
function profiloPubblico(u) {
  return {
    id: u.id,
    matricola: u.matricola,
    codiceFiscale: u.codice_fiscale, // v2.0: mostrato nel profilo
    nome: u.nome,
    cognome: u.cognome,
    sesso: u.sesso,                 // v1.4: mostrato nella sezione Profilo
    qualifica: u.qualifica,         // v1.4: mostrato nella sezione Profilo
    email: u.email,
    ruolo: u.ruolo,
    mustChangePassword: !!u.must_change_password, // → il frontend mostra il banner
  };
}

/**
 * POST /api/auth/login
 * Input  (JSON): { matricola: string, password: string }
 * Output (JSON): 200 { utente: {...} } + cookie `token`
 *                400 campi mancanti · 401 credenziali errate · 403 disabilitato
 *                429 troppi tentativi · 500 errore interno
 *
 * Flusso: validazione → rate-limit → SELECT per matricola → bcrypt.compare →
 *         firma JWT (con jti) → cookie → risposta con il profilo.
 */
router.post('/login', async (req, res, next) => {
  try {
    /* 1) Lettura e pulizia degli input: pulisci() gestisce anche i valori
     *    ripetuti (?a=1&a=2 → array) e il trim degli spazi. */
    const matricola = pulisci(req.body && req.body.matricola);
    const password = typeof (req.body && req.body.password) === 'string' ? req.body.password : '';

    if (!matricola || !password) {
      return res.status(400).json({ errore: 'Inserisci matricola e password.' });
    }

    /* 2) Guardia anti brute-force: oltre la soglia si risponde 429. */
    if (!loginConsentito(matricola)) {
      return res.status(429).json({ errore: 'Troppi tentativi falliti. Riprova tra 15 minuti.' });
    }

    /* 3) Ricerca dell'utente — query SEMPRE parametrica (?): il driver
     *    mysql2 invia i valori separatamente dal testo SQL, così un input
     *    tipo "' OR '1'='1' --" viene trattato come stringa letterale. */
    const [righe] = await pool.query('SELECT * FROM dipendenti WHERE matricola = ? LIMIT 1', [matricola]);
    const utente = righe[0];

    /* 4) Confronto password: bcrypt.compare estrae sale e costo dall'hash
     *    memorizzato e ricalcola. Se l'utente non esiste si esegue comunque
     *    un confronto su hash fittizio per equalizzare i tempi di risposta. */
    const credenzialiOk = utente && await bcrypt.compare(password, utente.password_hash);

    if (!credenzialiOk) {
      registraFallimento(matricola);
      // Messaggio generico: non rivelo SE la matricola esiste.
      return res.status(401).json({ errore: 'Matricola o password non valide.' });
    }
    if (!utente.attivo) {
      // Utente valido ma disabilitato dall'admin → accesso negato.
      return res.status(403).json({ errore: 'Account disabilitato. Contatta l\'amministratore.' });
    }

    tentativi.delete(matricola); // login riuscito: azzera il contatore

    /* [v2.1] PRIMO ACCESSO CON PASSWORD PROVVISORIA → modale bloccante.
     * Credenziali corrette ma flag a 1: NON si firma il token di sessione.
     * Si emette il cookie monouso `token_cambio` e si segnala al frontend
     * (pagina di login) di aprire la modale "Cambio Password Obbligatorio".
     * Nessun dato sensibile nella risposta: solo nome/cognome per il saluto. */
    if (utente.must_change_password) {
      const tokenCambio = jwt.sign(
        { id: utente.id, matricola: utente.matricola, jti: crypto.randomUUID(), scopo: SCOPO_CAMBIO },
        config.jwtSecret,
        { expiresIn: SCADENZA_CAMBIO }
      );
      res.clearCookie('token', { path: '/' });
      impostaCookieCambio(res, tokenCambio);
      return res.json({
        primoAccesso: true,
        messaggio: 'Password provvisoria: scegli una nuova password per completare l\'accesso.',
        utente: { matricola: utente.matricola, nome: utente.nome, cognome: utente.cognome, ruolo: utente.ruolo },
      });
    }

    /* 5) Firma del token di sessione.
     *    payload = { id, matricola, jti }: il `jti` (UUID) rende il token
     *    identificabile e quindi REVOCABILE al logout (utils/sessioni.js).
     *    expiresIn controlla il campo `exp` del token. */
    const token = jwt.sign(
      { id: utente.id, matricola: utente.matricola, jti: crypto.randomUUID() },
      config.jwtSecret,
      { expiresIn: config.jwtScadenza }
    );
    impostaCookieSessione(res, token);
    /* [v2.3.1] il token va ANCHE nel body: il frontend lo custodisce in
     * sessionStorage (sessione di SCHEDA: chiusa la scheda → sparito) e lo
     * rispedisce via header Authorization. Il cookie httpOnly resta per i
     * download diretti (export CSV, file). */
    res.json({ utente: profiloPubblico(utente), token });
  } catch (err) { next(err); }
});

/**
 * POST /api/auth/primo-accesso  [v2.1]
 * Completa il cambio password obbligatorio avviato dal login (modale nella
 * pagina di accesso). NON è una route pubblica qualunque: richiede il cookie
 * monouso `token_cambio` rilasciato da POST /login SOLO quando il flag
 * must_change_password è attivo.
 * Input  (JSON): { nuovaPassword, confermaPassword }
 * Output (JSON): 200 { ok, messaggio, utente } + cookie `token` (sessione)
 *                401 cookie assente/scaduto/non valido · 400 validazioni
 *
 * Garanzie: policy di robustezza, nuova password DIVERSA dalla provvisoria
 * (confronto bcrypt con l'hash in archivio), cookie di cambio revocato dopo
 * l'uso (monouso), sessione ufficiale emessa subito dopo: l'utente entra in
 * dashboard senza ridigitare le credenziali.
 *
 * Nota anti brute-force: qui NON serve il contatore del login — le verifiche
 * (conferma, policy, uguaglianza con la provvisoria) non sono "indovinabili"
 * a distanza e il cookie è firmato HMAC: non può essere forgiato.
 */
router.post('/primo-accesso', async (req, res, next) => {
  try {
    /* 1) Cookie monouso presente e valido? */
    const token = req.cookies ? req.cookies.token_cambio : null;
    if (!token) {
      return res.status(401).json({ errore: 'Sessione di primo accesso non trovata. Effettua di nuovo il login.' });
    }
    let payload;
    try {
      payload = jwt.verify(token, config.jwtSecret);
    } catch {
      res.clearCookie('token_cambio', { path: '/' });
      return res.status(401).json({ errore: 'La sessione di cambio password è scaduta. Effettua di nuovo il login.' });
    }
    /* Un token di SESSIONE (senza scopo) qui non c'entra: rifiuto secco. */
    if (payload.scopo !== SCOPO_CAMBIO) {
      res.clearCookie('token_cambio', { path: '/' });
      return res.status(401).json({ errore: 'Sessione di cambio password non valida. Effettua di nuovo il login.' });
    }
    /* Cookie GIÀ consumato (monouso): il jti è nel registro delle revoche.
     * [AUDIT C3] `CAMBI_IN_CORSO` prenota il jti in modo SINCRONO (atomico
     * sull'event-loop di Node): due richieste parallele con lo stesso cookie
     * non possono superare entrambe questa guardia e poi consumarlo due volte
     * durante gli await di bcrypt/query. Se la richiesta fallisce per un
     * errore di validazione, la prenotazione viene rilasciata (rilascia()). */
    if (payload.jti && (eRevocato(payload.jti) || CAMBI_IN_CORSO.has(payload.jti))) {
      res.clearCookie('token_cambio', { path: '/' });
      return res.status(401).json({ errore: 'Questa sessione di cambio è già stata utilizzata. Effettua di nuovo il login.' });
    }
    if (payload.jti) CAMBI_IN_CORSO.add(payload.jti);
    const rilascia = () => { if (payload.jti) CAMBI_IN_CORSO.delete(payload.jti); };

    let utente;
    try {
    /* 2) Rilettura dal DB: conta lo stato CORRENTE dell'account. */
    const [righe] = await pool.query('SELECT * FROM dipendenti WHERE id = ? LIMIT 1', [payload.id]);
    utente = righe[0];
    if (!utente || !utente.attivo) {
      res.clearCookie('token_cambio', { path: '/' });
      return res.status(401).json({ errore: 'Account non disponibile. Contatta l\'amministratore.' });
    }

    /* 3) Validazioni mostrate DENTRO la modale dal frontend. */
    const nuova = typeof (req.body && req.body.nuovaPassword) === 'string' ? req.body.nuovaPassword : '';
    const conferma = typeof (req.body && req.body.confermaPassword) === 'string' ? req.body.confermaPassword : '';

    if (!nuova || !conferma) {
      throw { status: 400, messaggio: 'Inserisci la nuova password e la conferma.' };
    }
    if (nuova !== conferma) {
      throw { status: 400, messaggio: 'Le due password non coincidono.' };
    }
    const errorePolicy = validaNuovaPassword(nuova);
    if (errorePolicy) {
      throw { status: 400, messaggio: errorePolicy };
    }
    if (await bcrypt.compare(nuova, utente.password_hash)) {
      throw { status: 400, messaggio: 'La nuova password deve essere diversa dalla password provvisoria.' };
    }

    /* 4) Salvataggio: nuovo hash + flag azzerato (la provvisoria cessa di esistere). */
    const hash = await bcrypt.hash(nuova, BCRYPT_ROUNDS);
    await pool.query(
      'UPDATE dipendenti SET password_hash = ?, must_change_password = 0 WHERE id = ?',
      [hash, utente.id]
    );

    /* 5) Il cookie di cambio è MONOUSO: revoca del jti (come al logout) +
     *    rilascio della prenotazione di concorrenza. */
    if (payload.jti) revoca(payload.jti, (payload.exp || 0) * 1000);
    rilascia();
    res.clearCookie('token_cambio', { path: '/' });

    /* 6) Accesso COMPLETATO: sessione ufficiale → la dashboard è raggiungibile. */
    tentativi.delete(payload.matricola);
    const tokenSessione = jwt.sign(
      { id: utente.id, matricola: utente.matricola, jti: crypto.randomUUID() },
      config.jwtSecret,
      { expiresIn: config.jwtScadenza }
    );
    impostaCookieSessione(res, tokenSessione);

    utente.must_change_password = 0; // proiezione aggiornata senza rileggere dal DB
    /* [v2.3.1] token nel body anche qui (sessionStorage, v. /login). */
    return res.json({
      ok: true,
      messaggio: 'Password aggiornata correttamente. Accesso completato.',
      utente: profiloPubblico(utente),
      token: tokenSessione,
    });
    } catch (err) {
      /* [AUDIT C3] errore di validazione → rilascia la prenotazione e risponde;
       * errore imprevisto → rilascia e passa al gestore centrale (500). */
      rilascia();
      if (err && err.status && err.messaggio) return res.status(err.status).json({ errore: err.messaggio });
      throw err;
    }
  } catch (err) { next(err); }
});

/**
 * POST /api/auth/logout
 * Revoca il token corrente (inserimento del jti nel registro fino a exp) e
 * rimuove il cookie dal browser. Idempotente: sicuro anche senza cookie.
 */
router.post('/logout', (req, res) => {
  /* [v2.3.3] il token può arrivare anche dall'header Bearer (sessione di
   * scheda): si revoca quello trovato per primo. */
  const header = req.headers && (req.headers.authorization || req.headers.Authorization);
  const token = (typeof header === 'string' && header.startsWith('Bearer '))
    ? header.slice('Bearer '.length).trim()
    : (req.cookies ? req.cookies.token : null);
  if (token) {
    try {
      const payload = jwt.decode(token); // solo decodifica: qui non serve verificare
      if (payload && payload.jti) revoca(payload.jti, (payload.exp || 0) * 1000);
    } catch { /* token illeggibile: nessuna revoca necessaria */ }
  }
  res.clearCookie('token', { path: '/' });
  res.json({ ok: true });
});

/**
 * GET /api/auth/me
 * Restituisce il profilo dell'utente corrente RILEGGENDOLO DAL DATABASE
 * (vedi middleware/auth.js): utile al frontend per decorare le pagine e per
 * il controllo del ruolo lato client. 401 se la sessione non è valida.
 */
router.get('/me', autenticazione, (req, res) => {
  res.json({ utente: profiloPubblico(req.utente) });
});

/**
 * PUT /api/auth/password — cambio password delle PROPRIE credenziali.
 * Input  (JSON): { passwordAttuale, nuovaPassword }
 * Output (JSON): 200 { ok, messaggio } · 400 policy non rispettata · 401 attuale errata
 *
 * Garanzie: richiede la password attuale (protezione da sessioni incustodite),
 * applica la policy di robustezza, vieta la riutilizzo della stessa password e
 * azzera must_change_password (la "password provvisoria" cessa di bloccare
 * le scritture: vedi middleware richiediPasswordAggiornata).
 */
router.put('/password', autenticazione, async (req, res, next) => {
  try {
    const attuale = typeof (req.body && req.body.passwordAttuale) === 'string' ? req.body.passwordAttuale : '';
    const nuova = typeof (req.body && req.body.nuovaPassword) === 'string' ? req.body.nuovaPassword : '';

    /* 1) Policy di robustezza (server-side, la validazione client non basta). */
    const erroreValidazione = validaNuovaPassword(nuova);
    if (erroreValidazione) return res.status(400).json({ errore: erroreValidazione });
    if (nuova === attuale) {
      return res.status(400).json({ errore: 'La nuova password deve essere diversa da quella attuale.' });
    }

    /* 2) Verifica della password attuale contro l'hash in archivio. */
    const [righe] = await pool.query('SELECT password_hash FROM dipendenti WHERE id = ? LIMIT 1', [req.utente.id]);
    if (!righe[0]) return res.status(401).json({ errore: 'Utente non trovato.' });

    const ok = await bcrypt.compare(attuale, righe[0].password_hash);
    if (!ok) return res.status(401).json({ errore: 'La password attuale non è corretta.' });

    /* 3) Salvataggio del nuovo hash + reset del flag "provvisoria". */
    const hash = await bcrypt.hash(nuova, BCRYPT_ROUNDS);
    await pool.query(
      'UPDATE dipendenti SET password_hash = ?, must_change_password = 0 WHERE id = ?',
      [hash, req.utente.id]
    );
    res.json({ ok: true, messaggio: 'Password aggiornata correttamente.' });
  } catch (err) { next(err); }
});

module.exports = router;

/**
 * ============================================================================
 *  routes/certificati.routes.js — AREA DIPENDENTE: CERTIFICATI
 * ============================================================================
 *  Montato su: /api/certificati  (vedi src/app.js — rotte interne: /, /:id/file)
 *
 *  Endpoint esposti:
 *    GET  /api/certificati             → elenco dei PROPRI certificati (+ allegati
 *                                        e ORE TOTALI con badge ≥ 40 h) [v2.2]
 *    POST /api/certificati             → upload nuovo certificato (multipart,
 *                                        fino a 5 file PDF/JPEG/PNG) [v2.2]
 *    GET  /api/certificati/:id/file    → download / visualizzazione del file principale
 *    GET  /api/certificati/allegati/:id/file → download di un allegato [v2.2]
 *
 *  Pipeline dell'upload (POST) — [MODIFICA v1.5]: NON è più presente il
 *  middleware richiediPasswordAggiornata. Il dipendente con password
 *  provvisoria PUÒ caricare i certificati; l'avvertimento al cambio password
 *  è gestito SOLO a interfaccia (banner informativo in dipendente.html/js).
 *    autenticazione → MULTER (filtri + disco) → validazione campi testuali
 *    → verifica magic bytes → INSERT MySQL.
 *    In QUALSIQUE punto di fallimento il file già scritto viene CANCELLATO:
 *    sul disco non restano mai upload "orfani" senza riga nel database.
 * ============================================================================
 */
const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer'); // standard de facto per multipart su disco

const config = require('../config'); // limiti (5 MB) e radice upload
const { pool } = require('../db');
const { autenticazione } = require('../middleware/auth');
const {
  cartellaDipendente, nomeFileUnivoco, tipoDaFirma, percorsoAssoluto,
} = require('../utils/file');
const { validaDatiCertificato } = require('../utils/validazione');

const router = express.Router();

/* Middleware applicato a TUTTE le rotte del router: senza cookie con token
 * JWT valido nessuna operazione è possibile (401). */
router.use(autenticazione);

/* ------------------------------------------------------------------ *
 *  CONFIGURAZIONE MULTER
 *  ------------------------------------------------------------------
 *  storage su DISCO (non memoria): i file vengono scritti direttamente nella
 *  cartella di destinazione — ideale per PDF fino a 5 MB e non appesantisce
 *  la RAM del server.
 * ------------------------------------------------------------------ */
const storage = multer.diskStorage({
  /** Cartella di destinazione (v2.0): uploads/certificati/{CODICE_FISCALE}/ —
   *  il CF del dipendente LOGGATO (dal token, non manipolabile) identifica
   *  la sua cartella; creata automaticamente se assente (self-healing). */
  destination(req, file, cb) {
    try {
      cb(null, cartellaDipendente(req.utente.codice_fiscale));
    } catch (err) { cb(err); }
  },
  /** Nome sul server: {timestamp}-{random8}_{nome_sanificato}.pdf — l'8
   *  caratteri casuali eliminano la race condition di due upload nello
   *  stesso millisecondo; il nome originale è sanificato (niente spazi,
   *  accentate o sequenze pericolose). */
  filename(req, file, cb) {
    cb(null, nomeFileUnivoco(file.originalname));
  },
});

const upload = multer({
  storage,
  /** Limiti hard: 1 solo file, 5 MB (config). Al superamento Multer genera
   *  un MulterError gestito dal gestore errori centrale (messaggio chiaro).
   *  [FIX QA-C3] busboy interrompe il file quando il contatore TOCCA il
   *  limite: con fileSize = 5 MB esatti veniva rifiutato anche un PDF di
   *  ESATTAMENTE 5 MB (5.242.880 byte). Si lascia a busboy un margine di
   *  1 KB e il limite ESATTO viene verificato subito dopo sul file salvato. */
  limits: { fileSize: config.maxFileBytes + 1024, files: 5 }, // [v2.2] fino a 5 file per corso
  /** [v2.2] Primo filtro (pre-scrittura): estensione e MIME dichiarato dal
   *  client. Ammessi PDF, JPEG e PNG. Il contenuto reale viene verificato
   *  DOPO con la firma binaria (tipoDaFirma). Massimo 5 file per caricamento. */
  fileFilter(req, file, cb) {
    const ammesse = ['.pdf', '.jpg', '.jpeg', '.png'];
    if (!ammesse.includes(path.extname(file.originalname).toLowerCase())) {
      return cb(new Error('Formato non ammesso: sono ammessi solo file PDF, JPG e PNG.'));
    }
    const mimeOk = ['application/pdf', 'image/jpeg', 'image/png', ''];
    if (file.mimetype && !mimeOk.includes(file.mimetype)) {
      return cb(new Error('Formato non ammesso: sono ammessi solo file PDF, JPG e PNG (MIME coerente).'));
    }
    cb(null, true);
  },
});

/**
 * Verifica dei MAGIC BYTES del file appena salvato: ogni PDF genuino inizia
 * con la sequenza "%PDF-". Questo blocca i file rinominati (es. un .exe o un
 * .txt con estensione forzata a .pdf), che il solo controllo del MIME non
 * intercetta, perché il MIME è dichiarato dal client e quindi falsificabile.
 */
async function firmaReale(percorsoFile) {
  const fd = await fs.promises.open(percorsoFile, 'r');
  try {
    const buf = Buffer.alloc(8); // [v2.2] 8 byte: coprono anche la firma PNG
    await fd.read(buf, 0, 8, 0); // leggo l'inizio del file dal disco
    return tipoDaFirma(buf);     // 'pdf' | 'jpeg' | 'png' | null
  } finally {
    await fd.close();
  }
}

/* ------------------------------------------------------------------ */

/**
 * GET /api/certificati
 * Elenco dei certificati dell'UTENTE LOGGATO (il WHERE usa req.utente.id
 * derivato dal token: il client non può "spiarare" gli altri).
 * Output: [{ id, nome_corso, ente_erogatore, data_conseguimento,
 *            nome_file_originale, dimensione_file, stato, note_admin,
 *            caricato_il }] — NOTA: percorso_file NON viene mai esposto.
 */
router.get('/', async (req, res, next) => {
  try {
    /* [v2.3.5] IMPAGINAZIONE SERVER-SIDE (come la tabella Dipendenti):
     * «perPagina» = 10/25/50, «pagina» ≥ 1. SENZA perPagina (o con
     * perPagina=tutti) si conserva il comportamento storico: ELENCO
     * COMPLETO — i client e i test esistenti continuano a funzionare.
     * oreTotali e conteggi restano SEMPRE globali (calcolati su TUTTI i
     * corsi del dipendente, non sulla pagina corrente). */
    const richiediTutti = req.query.perPagina === undefined
      || String(Array.isArray(req.query.perPagina) ? req.query.perPagina[0] : req.query.perPagina).toLowerCase() === 'tutti';
    const numeroSicuro = (v, def, min, max) => {
      const n = Number.parseInt(Array.isArray(v) ? v[0] : v, 10);
      return Number.isInteger(n) ? Math.min(max, Math.max(min, n)) : def;
    };
    const perPagina = richiediTutti ? null : numeroSicuro(req.query.perPagina, 10, 5, 50);
    const pagina = perPagina === null ? 1 : numeroSicuro(req.query.pagina, 1, 1, 1e9);
    const offset = perPagina === null ? 0 : (pagina - 1) * perPagina;

    const [righe] = await pool.query(
      `SELECT id, nome_corso, ente_erogatore, data_conseguimento,
              numero_ore, numero_minuti, esame_finale, area_tematica,
              nome_file_originale, dimensione_file, stato, note_admin, caricato_il
       FROM certificati
       WHERE dipendente_id = ?
       ORDER BY caricato_il DESC, id DESC${perPagina === null ? '' : ' LIMIT ? OFFSET ?'}`,
      perPagina === null ? [req.utente.id] : [req.utente.id, perPagina, offset]
    );

    const [[{ totale }]] = await pool.query(
      'SELECT COUNT(*) AS totale FROM certificati WHERE dipendente_id = ?',
      [req.utente.id]
    );

    /* [v2.3.5] Contatori GLOBALI per stato (alimentano le card statistiche
     * del profilo anche quando la tabella mostra una sola pagina). */
    const [righeConteggi] = await pool.query(
      'SELECT stato, COUNT(*) AS n FROM certificati WHERE dipendente_id = ? GROUP BY stato',
      [req.utente.id]
    );
    const conteggi = { TOTALE: 0, APPROVATO: 0, IN_ATTESA: 0, RIFIUTATO: 0 };
    for (const r of righeConteggi) {
      conteggi[r.stato] = Number(r.n);
      conteggi.TOTALE += Number(r.n);
    }

    /* [v2.2] Allegati di ogni corso (elenco per i link di download). */
    const ids = righe.map((r) => r.id);
    let mappaAllegati = new Map();
    if (ids.length) {
      const [tutti] = await pool.query(
        `SELECT id, certificato_id, nome_originale, tipo_file, dimensione_file
         FROM allegati WHERE certificato_id IN (?) ORDER BY id ASC`,
        [ids]
      );
      for (const a of tutti) {
        if (!mappaAllegati.has(a.certificato_id)) mappaAllegati.set(a.certificato_id, []);
        mappaAllegati.get(a.certificato_id).push({ id: a.id, nome: a.nome_originale, tipo: a.tipo_file, dimensione_file: a.dimensione_file }); // [v2.2.7]
      }
    }

    /* [v2.2.3] ORE FORMATIVE TOTALI: somma dei corsi VALIDI — APPROVATI e
     * IN_ATTESA (il totale non richiede la validazione dell'amministratore) —
     * ESCLUDENDO i RIFIUTATI: quando l'amministratore rifiuta un certificato,
     * le sue ore/minuti escono immediatamente dal totale del profilo
     * (reversal della v2.2.2 che li contava tutti). La spunta VERDE compare
     * quando il totale supera le 40 ore (> 2.400 minuti, soglia strettamente
     * maggiore). */
    const [[{ minutiTotali }]] = await pool.query(
      `SELECT COALESCE(SUM(numero_ore * 60 + numero_minuti), 0) AS minutiTotali
       FROM certificati WHERE dipendente_id = ? AND stato <> 'RIFIUTATO'`,
      [req.utente.id]
    );
    const SOGLIA_BADGE_MINUTI = 40 * 60;
    const totaleMinuti = Number(minutiTotali) || 0; // SUM() torna stringa DECIMAL
    const oreTotali = {
      minuti: totaleMinuti,
      ore: Math.floor(totaleMinuti / 60),
      restoMinuti: totaleMinuti % 60,
      badge: totaleMinuti > SOGLIA_BADGE_MINUTI, // [v2.2.2] maggiore a 40 ore
    };

    res.json({
      certificati: righe.map((r) => ({ ...r, allegati: mappaAllegati.get(r.id) || [] })),
      oreTotali,
      /* [v2.3.5] metadati di impaginazione + conteggi globali per le card */
      totale: Number(totale),
      pagina,
      perPagina: perPagina === null ? Math.max(1, Number(totale)) : perPagina,
      pagineTotali: perPagina === null ? 1 : Math.max(1, Math.ceil(Number(totale) / perPagina)),
      conteggi,
    });
  } catch (err) { next(err); }
});

/**
 * POST /api/certificati — upload di un nuovo certificato.
 * Input  (multipart/form-data): nome_corso, ente_erogatore, data_conseguimento,
 *                               numero_ore, esame_finale, area_tematica
 *                               e campo file "file" (PDF ≤ 5 MB).
 * Output (JSON): 201 { ok, id, messaggio } · 400 validazioni
 *
 * [MODIFICA v1.5] Nessun blocco per la password provvisoria: il dipendente con
 * password predefinita può caricare i certificati. L'invito a cambiarla è un
 * AVVISO NON BLOCCANTE mostrato dal frontend (banner in dipendente.html, vedi
 * utente.mustChangePassword di /api/auth/me). Nota: le SCRITTURE dell'AREA
 * ADMIN continuano a richiedere le credenziali aggiornate (admin.routes.js).
 */
router.post('/', upload.array('file', 5), async (req, res, next) => {
  try {
    /* 1) [v2.2] I file ci sono? (fino a 5: PDF, JPEG o PNG, ≤ 5 MB ciascuno) */
    const files = Array.isArray(req.files) ? req.files : [];
    const pulizia = () => Promise.all(files.map((f) => fs.promises.unlink(f.path).catch(() => {})));

    if (!files.length) {
      const contentLength = Number(req.headers['content-length'] || 0);
      const troppoGrande = contentLength > config.maxFileBytes + 64 * 1024;
      return res.status(400).json({
        errore: troppoGrande
          ? 'File troppo grande: il limite massimo è 5 MB per file.'
          : 'Il file del certificato è obbligatorio (PDF, JPG o PNG).',
      });
    }

    /* 1-bis) [FIX QA-C3] Limite ESATTO di 5 MB per file, applicato sul file
     *  salvato (busboy tollera +1 KB di margine tecnico). */
    const troppoGrande = files.find((f) => f.size > config.maxFileBytes);
    if (troppoGrande) {
      await pulizia(); // nessun orfano
      return res.status(400).json({ errore: `«${troppoGrande.originalname}» supera il limite di 5 MB per file.` });
    }

    /* 2) Validazione dei campi testuali (lunghezze, durata ore:minuti, data, area). */
    const { errori, valori } = validaDatiCertificato(req.body || {});
    if (errori.length) {
      await pulizia(); // cleanup
      return res.status(400).json({ errore: errori.join(' ') });
    }

    /* 3) [v2.2] Verifica del contenuto REALE di ogni file (firma binaria):
     *  blocca i file rinominati (es. un .exe o .txt travestito da .pdf/.jpg). */
    const tipi = [];
    for (const f of files) {
      const tipo = await firmaReale(f.path);
      if (!tipo) {
        await pulizia();
        return res.status(400).json({ errore: `«${f.originalname}» non è un file PDF, JPG o PNG valido.` });
      }
      tipi.push(tipo);
    }

    /* 4) Percorsi RELATIVI salvati nel DB (mai assoluti: il progetto può
     *    essere spostato di cartella o su altro server senza migrazioni). */
    const relativo = (nome) => path.join('certificati', req.utente.codice_fiscale, nome)
      .split(path.sep).join('/'); // separatori POSIX anche su Windows

    /* 5) INSERT del corso (stato IN_ATTESA) + riga di ALLEGATO per ogni file.
     *    Il primo file resta anche in certificati.percorso_file (compatibilità
     *    con v1.x: download, export e collegamento principale). */
    const primo = files[0];
    const [esito] = await pool.query(
      `INSERT INTO certificati
         (dipendente_id, nome_corso, ente_erogatore, data_conseguimento,
          numero_ore, numero_minuti, esame_finale, area_tematica,
          nome_file_originale, percorso_file, dimensione_file, stato)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'IN_ATTESA')`,
      [req.utente.id, valori.nomeCorso, valori.ente, valori.data,
       valori.numeroOre, valori.numeroMinuti, valori.esameFinale, valori.areaTematica,
       primo.originalname, relativo(primo.filename), primo.size]
    );

    await pool.query(
      `INSERT INTO allegati (certificato_id, percorso_file, nome_originale, tipo_file, dimensione_file)
       VALUES ?`,
      [files.map((f, i) => [esito.insertId, relativo(f.filename), f.originalname, tipi[i], f.size])]
    );

    res.status(201).json({
      ok: true,
      id: esito.insertId,
      allegati: files.length,
      messaggio: files.length > 1
        ? `Certificato caricato con ${files.length} documenti. In attesa di approvazione.`
        : 'Certificato caricato correttamente. In attesa di approvazione.',
    });
  } catch (err) {
    /* Qualsiasi errore imprevisto (DB giù, disco pieno…) → cleanup dei file
     * già scritti per non lasciare orfani sul file system. */
    const files = Array.isArray(req.files) ? req.files : (req.file ? [req.file] : []);
    await Promise.all(files.map((f) => fs.promises.unlink(f.path).catch(() => {})));
    next(err);
  }
});

/**
 * GET /api/certificati/:id/file — recupero del PDF.
 * Query: ?modo=visualizza → inline (preview nel browser); default → download.
 * PERMESSI: solo il PROPRIETARIO del certificato o un AMMINISTRATORE. È il
 * punto in cui si impedisce a un dipendente di leggere i documenti altrui.
 */
router.get('/:id/file', async (req, res, next) => {
  try {
    /* 1) Validazione dell'identificativo numerico nella URL. */
    /* [AUDIT v2.2-b F5] Solo CIFRE: parseInt("1;DROP") troncherebbe in
     * silenzio il valore (coerenza con FIX QA-C4 degli altri filtri). */
    if (!/^\d+$/.test(req.params.id)) {
      return res.status(400).json({ errore: 'Identificativo non valido.' });
    }
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ errore: 'Identificativo non valido.' });
    }

    /* 2) Lettura del record (serve per proprietà, percorso e nome file). */
    const [righe] = await pool.query('SELECT * FROM certificati WHERE id = ? LIMIT 1', [id]);
    const cert = righe[0];
    if (!cert) return res.status(404).json({ errore: 'Certificato non trovato.' });

    /* 3) CONTROLLO DI PROPRIETÀ: confronto tra l'id dell'utente autenticato
     *    (dal token, non manipolabile) e il dipendente_id del record. */
    if (req.utente.ruolo !== 'AMMINISTRATORE' && cert.dipendente_id !== req.utente.id) {
      return res.status(403).json({ errore: 'Puoi accedere solo ai tuoi certificati.' });
    }

    /* 4) Risoluzione del percorso con protezione anti path-traversal
     *    (percorsoAssoluto restituisce null se il percorso "esce" dalla
     *    radice degli upload). */
    const assoluto = percorsoAssoluto(cert.percorso_file);
    if (!assoluto || !fs.existsSync(assoluto)) {
      return res.status(404).json({ errore: 'File non presente sul server.' });
    }

    /* 5) Nome file per il browser: sanificato per l'header Content-Disposition.
     *    [v2.2] il tipo MIME è coerente col file realmente salvato. */
    const nomeSicuro = cert.nome_file_originale.replace(/[^\w.\- ]+/g, '_');
    const est = path.extname(cert.percorso_file).toLowerCase();
    const mime = est === '.png' ? 'image/png'
      : (est === '.jpg' || est === '.jpeg') ? 'image/jpeg' : 'application/pdf';

    if (req.query.modo === 'visualizza') {
      // inline → il browser lo apre nel visualizzatore integrato
      return res.sendFile(assoluto, {
        headers: {
          'Content-Type': mime,
          'Content-Disposition': `inline; filename="${nomeSicuro}"`,
        },
      });
    }
    // default → allegato scaricabile
    return res.download(assoluto, nomeSicuro, { headers: { 'Content-Type': mime } }); // [F6]
  } catch (err) { next(err); }
});

/**
 * GET /api/certificati/allegati/:id/file  [v2.2]
 * Download/visualizzazione di un SINGOLO allegato (PDF/JPEG/PNG) di un corso.
 * PERMESSI: solo il proprietario del certificato o un AMMINISTRATORE (stessa
 * regola del file principale). Percorso risolto con protezione anti traversal.
 */
router.get('/allegati/:id/file', async (req, res, next) => {
  try {
    /* [AUDIT v2.2-b F5] Solo CIFRE: parseInt("1;DROP") troncherebbe in
     * silenzio il valore (coerenza con FIX QA-C4 degli altri filtri). */
    if (!/^\d+$/.test(req.params.id)) {
      return res.status(400).json({ errore: 'Identificativo non valido.' });
    }
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ errore: 'Identificativo non valido.' });
    }

    const [righe] = await pool.query(
      `SELECT a.percorso_file, a.nome_originale, a.tipo_file, c.dipendente_id
       FROM allegati a JOIN certificati c ON c.id = a.certificato_id
       WHERE a.id = ? LIMIT 1`,
      [id]
    );
    const allegato = righe[0];
    if (!allegato) return res.status(404).json({ errore: 'Allegato non trovato.' });

    if (req.utente.ruolo !== 'AMMINISTRATORE' && allegato.dipendente_id !== req.utente.id) {
      return res.status(403).json({ errore: 'Puoi accedere solo ai tuoi certificati.' });
    }

    const assoluto = percorsoAssoluto(allegato.percorso_file);
    if (!assoluto || !fs.existsSync(assoluto)) {
      return res.status(404).json({ errore: 'File non presente sul server.' });
    }

    const nomeSicuro = allegato.nome_originale.replace(/[^\w.\- ]+/g, '_');
    const mime = allegato.tipo_file === 'png' ? 'image/png'
      : allegato.tipo_file === 'jpeg' ? 'image/jpeg' : 'application/pdf';

    if (req.query.modo === 'visualizza') {
      return res.sendFile(assoluto, {
        headers: { 'Content-Type': mime, 'Content-Disposition': `inline; filename="${nomeSicuro}"` },
      });
    }
    return res.download(assoluto, nomeSicuro, { headers: { 'Content-Type': mime } }); // [F6]
  } catch (err) { next(err); }
});

module.exports = router;

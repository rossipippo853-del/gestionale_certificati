/**
 * ============================================================================
 *  routes/admin.routes.js — AREA AMMINISTRATORE
 * ============================================================================
 *  Montato su: /api/admin — TUTTE le rotte richiedono ruolo AMMINISTRATORE:
 *  router.use(autenticazione, soloAdmin) è applicato a livello di router,
 *  quindi è impossibile "dimenticare" la protezione su una nuova rotta.
 *
 *  Endpoint:
 *    GET    /stats                        contatori della dashboard
 *    GET    /utenti                       ricerca + paginazione dipendenti
 *    GET    /utenti/options               elenco compatto (menu a tendina)
 *    POST   /utenti                       creazione dipendente (+ cartella FS)
 *    POST   /utenti/import                importazione massiva da CSV (v1.3)
 *    PUT    /utenti/:id/password          reset password
 *    PUT    /utenti/:id/stato             abilita / disabilita account
 *    GET    /certificati                  vista globale con filtri (area v1.4)
 *    GET    /certificati/export           export CSV (stessi filtri)
 *    PUT    /certificati/:id/stato        approva / rifiuta (+ nota)
 *    DELETE /certificati/:id              elimina record + file fisico
 * ============================================================================
 */
const express = require('express');
const crypto = require('crypto');   // randomInt: password provvisorie sicure
const fs = require('fs');           // rmdir della cartella su duplicato
const path = require('path');       // estensione del file CSV caricato
const bcrypt = require('bcryptjs');
const multer = require('multer');   // ricezione del file CSV (in memoria)

const { pool } = require('../db');
const { autenticazione, soloAdmin, richiediPasswordAggiornata } = require('../middleware/auth');
const config = require('../config');
const { eliminaFileAttesa, cartellaDipendente, nomeFileUnivoco, ePdf, tipoDaFirma, formattaDurata } = require('../utils/file');
const { pulisci, validaNuovaPassword, validaDatiDipendente, validaDatiCertificato, AREE_AMMESSE } = require('../utils/validazione');
const { generaPasswordProvvisoria } = require('../utils/password');
const { analizzaCsv, eseguiImport } = require('../utils/importazione'); // motore condiviso con la CLI

const router = express.Router();

/* --- Protezione per ruolo dell'INTERO router --- */
router.use(autenticazione, soloAdmin);

/* --- Cambio password obbligatorio per le SCRITTURE dell'admin stesso
 *     (le GET restano libere: l'interfaccia deve potersi caricare e mostrare
 *     il banner con l'invito a cambiare la password provvisoria). --- */
router.use((req, res, next) => {
  if (req.method === 'GET') return next();
  return richiediPasswordAggiornata(req, res, next);
});

const BCRYPT_ROUNDS = 10;
const STATI_VALIDI = ['IN_ATTESA', 'APPROVATO', 'RIFIUTATO'];

/* ============================ UTILITÀ ============================ */

/** Normalizza pagina/perPagina dai querystring con limiti prudenti
 *  (min 5, max 100 righe per pagina: impedisce richieste da 250.000 righe). */
function parametriPagina(req) {
  const pagina = Math.max(1, Number.parseInt(req.query.pagina, 10) || 1);
  const perPagina = Math.min(100, Math.max(5, Number.parseInt(req.query.perPagina, 10) || 25));
  return { pagina, perPagina, offset: (pagina - 1) * perPagina };
}

/** Escape dei metacaratteri LIKE (% _ \): la ricerca tratta l'input come
 *  testo LETTERALE (cercare "100%" non restituisce "100" + qualsiasi cosa).
 *  Necessita LIKE ESCAPE '\\' (default del driver mysql2). */
function likeSicuro(testo) {
  return `%${String(testo).replace(/[\\%_]/g, (m) => '\\' + m)}%`;
}

/**
 * Password provvisoria: la generazione vive ora in utils/password.js
 * (modulo condiviso con il motore di importazione massiva, v1.3).
 */

/**
 * Serializzazione di un campo CSV:
 *  1. anti formula-injection → se il valore inizia con = + - @ TAB o CR viene
 *     anteposto un apice, così Excel NON lo interpreta come formula;
 *  2. quoting → se contiene " ; o ritorni a capo, il valore viene racchiuso
 *     tra virgolette raddoppiando le virgolette interne (RFC 4180 adattato).
 */
function csvCampo(valore) {
  if (valore === null || valore === undefined) return '';
  let s = String(valore);
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/* ========================== STATISTICHE ========================== */

/** GET /stats — una sola query con 6 sub-select scalari: sul volume atteso
 *  (poche migliaia di righe) è la soluzione più semplice ed efficiente. */
/** [v2.2.9] AUDIT LOG: registra le modifiche amministrative ai certificati.
 *  [v2.3.4] AZIONI SPECIFICHE: ogni evento ha un codice puntuale
 *  (MODIFICA_TITOLO_CORSO, MODIFICA_ENTE_EROGATORE, MODIFICA_DATA_CONSEGUIMENTO,
 *  MODIFICA_DURATA, MODIFICA_ESAME_FINALE, MODIFICA_AREA_TEMATICA,
 *  ELIMINAZIONE_<CAMPO>, APPROVAZIONE_CERTIFICATO, RIFIUTO_CERTIFICATO,
 *  ELIMINAZIONE_CERTIFICATO) e nei dettagli i valori prima → dopo.
 *  Non blocca mai l'operazione principale: un eventuale errore viene solo loggato. */
async function scriviAudit(adminId, azione, certificatoId, dettagli) {
  try {
    await pool.query(
      'INSERT INTO audit_log (admin_id, azione, certificato_id, dettagli) VALUES (?, ?, ?, ?)',
      [adminId, azione, certificatoId, dettagli ? String(dettagli).slice(0, 500) : null]
    );
  } catch (err) { console.error('[AUDIT LOG] scrittura fallita:', err.message); }
}

router.get('/stats', async (req, res, next) => {
  try {
    const [righe] = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM dipendenti)                          AS totaleDipendenti,
        (SELECT COUNT(*) FROM dipendenti WHERE attivo = 1)         AS dipendentiAttivi,
        (SELECT COUNT(*) FROM certificati)                         AS totaleCertificati,
        (SELECT COUNT(*) FROM certificati WHERE stato = 'IN_ATTESA') AS certificatiInAttesa,
        (SELECT COUNT(*) FROM certificati WHERE stato = 'APPROVATO') AS certificatiApprovati,
        (SELECT COUNT(*) FROM certificati WHERE stato = 'RIFIUTATO') AS certificatiRifiutati
    `);
    /* [v2.2.9] Analytics: ore formative APPROVATE per area tematica
     * (tutto il personale) per la dashboard sintetica a barre. */
    const [aree] = await pool.query(`
      SELECT area_tematica AS area,
             COALESCE(SUM(numero_ore * 60 + numero_minuti), 0) AS minuti,
             COUNT(*) AS corsi
      FROM certificati
      WHERE stato = 'APPROVATO'
      GROUP BY area_tematica
      ORDER BY minuti DESC
    `);
    res.json({ stats: righe[0], orePerArea: aree.map((a) => ({ ...a, minuti: Number(a.minuti) })) });
  } catch (err) { next(err); }
});

/* ======================== GESTIONE UTENTI ======================== */

/** GET /utenti — ricerca testuale (matricola/nome/cognome/nome completo),
 *  filtro stato e paginazione. Restituisce pagina dati + metadati (totale,
 *  pagineTotali) per il controllo di paginazione del frontend. */
router.get('/utenti', async (req, res, next) => {
  try {
    const q = pulisci(req.query.q);
    const attivo = req.query.attivo === '0' || req.query.attivo === '1' ? req.query.attivo : null;
    const { pagina, perPagina, offset } = parametriPagina(req);

    /* WHERE costruito dinamicamente ma SOLO con segnaposto parametrici:
     * i valori arrivano dall'utente, le parole chiave no → zero SQLi. */
    const condizioni = [];
    const parametri = [];
    if (q) {
      condizioni.push('(matricola LIKE ? OR codice_fiscale LIKE ? OR nome LIKE ? OR cognome LIKE ? OR CONCAT(nome, " ", cognome) LIKE ?)');
      const like = likeSicuro(q);
      parametri.push(like, like, like, like, like);
    }
    if (attivo !== null) { condizioni.push('attivo = ?'); parametri.push(Number(attivo)); }
    const where = condizioni.length ? `WHERE ${condizioni.join(' AND ')}` : '';

    /* Due query: COUNT(*) per il totale (servono le pagine) + SELECT di pagina. */
    const [[{ totale }]] = await pool.query(`SELECT COUNT(*) AS totale FROM dipendenti ${where}`, parametri);
    const [utenti] = await pool.query(
      `SELECT id, matricola, codice_fiscale, nome, cognome, sesso, qualifica, email, ruolo, attivo, must_change_password, created_at
       FROM dipendenti ${where}
       ORDER BY cognome ASC, nome ASC
       LIMIT ? OFFSET ?`,
      [...parametri, perPagina, offset]
    );

    res.json({ utenti, totale, pagina, perPagina, pagineTotali: Math.max(1, Math.ceil(totale / perPagina)) });
  } catch (err) { next(err); }
});

/** GET /utenti/options — versione compatta (id/matricola/nome) per i menu
 *  a tendina dei filtri: poche righe, nessun dato sensibile. */
router.get('/utenti/options', async (req, res, next) => {
  try {
    const [utenti] = await pool.query(
      `SELECT id, matricola, codice_fiscale, nome, cognome FROM dipendenti
       WHERE attivo = 1 ORDER BY cognome ASC, nome ASC`
    );
    res.json({ opzioni: utenti });
  } catch (err) { next(err); }
});

/**
 * POST /utenti — creazione di un nuovo dipendente.
 * body: { matricola, nome, cognome, email?, ruolo, password? }
 *
 * Protocollo in 3 passi (vede anche il file system):
 *   (1) pre-check duplicato → 409 immediato senza toccare il disco;
 *   (2) creazione cartella uploads/certificati/{codice_fiscale}/ (recursive =
 *       idempotente; se fallisce → 500 e la registrazione si ferma);
 *   (3) INSERT con vincolo UNIQUE come "backstop": in caso di ER_DUP_ENTRY
 *       (create concorrenti) la cartella viene rimossa SOLO se la matricola
 *       davvero non è stata registrata → non si cancella mai la cartella
 *       del "vincitore". rmdirSync NON ricorsivo = solo cartelle vuote.
 */
router.post('/utenti', async (req, res, next) => {
  try {
    /* 1) Validazione completa dei dati anagrafici + policy password. */
    const { errori, valori } = validaDatiDipendente(req.body || {});

    const passwordInserita = typeof (req.body && req.body.password) === 'string' ? req.body.password.trim() : '';
    const passwordProvvisoria = passwordInserita || generaPasswordProvvisoria();
    const errPassword = validaNuovaPassword(passwordProvvisoria);

    const tuttiGliErrori = [...errori, ...(errPassword ? [errPassword] : [])];
    if (tuttiGliErrori.length) return res.status(400).json({ errore: tuttiGliErrori.join(' ') });

    /* 2) Hash bcrypt della password provvisoria. */
    const hash = await bcrypt.hash(passwordProvvisoria, BCRYPT_ROUNDS);

    /* (1) pre-check duplicato (fast path). */
    const [dup] = await pool.query('SELECT id FROM dipendenti WHERE matricola = ? LIMIT 1', [valori.matricola]);
    if (dup.length) return res.status(409).json({ errore: 'Matricola già esistente.' });

    /* (2) creazione immediata della cartella della matricola. */
    let dirDipendente;
    try {
      dirDipendente = cartellaDipendente(valori.codiceFiscale); // v2.0: cartella nominata col CF
    } catch (errFs) {
      console.error('[FATALE] Impossibile creare la cartella upload per la matricola', valori.matricola, errFs);
      return res.status(500).json({ errore: 'Errore nella creazione della cartella sul server: registrazione annullata.' });
    }

    try {
      /* (3) INSERT (v2.0: anagrafica completa con Codice Fiscale).
       *     must_change_password=1 obbliga il cambio al primo accesso. */
      const [esito] = await pool.query(
        `INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, sesso, qualifica, email, password_hash, ruolo, attivo, must_change_password)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1)`,
        [valori.matricola, valori.codiceFiscale, valori.nome, valori.cognome, valori.sesso, valori.qualifica,
         valori.email || null, hash, valori.ruolo]
      );
      res.status(201).json({
        ok: true,
        id: esito.insertId,
        passwordProvvisoria: passwordInserita ? undefined : passwordProvvisoria,
        messaggio: `Dipendente ${valori.matricola} creato.`,
      });
    } catch (err) {
      if (err && err.code === 'ER_DUP_ENTRY') {
        /* Race: un'altra richiesta ha registrato la stessa matricola o lo stesso
         * CF nel frattempo. Rimuoviamo la cartella SOLO se la matricola non
         * esiste a DB (cioè se siamo davvero noi il "perdente" della corsa).
         * v2.0: il messaggio distingue il vincolo violato (matricola o CF). */
        /* [AUDIT F2] La cartella del "perdente" della corsa viene rimossa SE
         * VUOTA (rmdirSync fallisce in modo innocuo se contiene file, es. la
         * cartella di un CF già di un altro utente con documenti): così non
         * restano cartelle orfane e non si cancella MAI un documento esistente. */
        try { fs.rmdirSync(dirDipendente); } catch { /* non vuota: ignoriamo */ }
        const cfDuplicato = String(err.message || '').includes('uq_dipendenti_cf');
        return res.status(409).json({ errore: cfDuplicato
          ? 'Codice Fiscale già registrato per un altro dipendente.'
          : 'Matricola già esistente.' });
      }
      throw err;
    }
  } catch (err) { next(err); }
});

/* ------------------------------------------------------------------ *
 *  IMPORTAZIONE MASSIVA DA CSV  (v1.3)
 *  ------------------------------------------------------------------
 *  Il file viene ricevuto IN MEMORIA (multer memoryStorage: 2 MB sono
 *  trascurabili) e passato al motore condiviso utils/importazione.js —
 *  lo stesso usato dallo script CLI db/import-dipendenti.js.
 *  opzioni (multipart fields): duplicati = ignora|aggiorna · dry_run = '1'
 * ------------------------------------------------------------------ */
const uploadCsv = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 2 * 1024 * 1024, files: 1 }, // 2 MB: oltre 2000 righe di testo
  fileFilter(req, file, cb) {
    if (!['.csv', '.txt'].includes(path.extname(file.originalname).toLowerCase())) {
      return cb(new Error('Formato non ammesso: caricare un file CSV (.csv o .txt). Da Excel usare "Salva con nome → CSV UTF-8".'));
    }
    cb(null, true);
  },
});

/**
 * POST /utenti/import — importazione massiva dei dipendenti da file CSV.
 * Input  (multipart/form-data): file (CSV ≤ 2 MB, ≤ 2000 righe),
 *        duplicati ('ignora'|'aggiorna'), dry_run ('1' = sola verifica).
 * Output (JSON): { duplicati, dryRun, esito: { elaborati, creati[], aggiornati[],
 *        saltati[], errori[], righeVuoteIgnorate } }
 *
 * Garanzie (implementate nel motore): password SEMPRE cifrate con bcrypt,
 * cartella uploads/certificati/{matricola} creata per ogni nuovo utente,
 * duplicati gestiti secondo l'opzione scelta, report riga per riga.
 */
router.post('/utenti/import', (req, res, next) => {
  // Multer invocato "a mano" per tradurre QUI i suoi errori in messaggi
  // precisi sul CSV (il gestore centrale è specializzato sugli upload PDF).
  uploadCsv.single('file')(req, res, (errUpload) => {
    if (errUpload) {
      if (errUpload instanceof multer.MulterError && errUpload.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ errore: 'File CSV troppo grande: il limite è 2 MB.' });
      }
      if (errUpload instanceof multer.MulterError) {
        return res.status(400).json({ errore: 'Errore nel caricamento del file CSV.' });
      }
      return res.status(400).json({ errore: errUpload.message }); // messaggio del fileFilter
    }

    (async () => {
      try {
        if (!req.file) return res.status(400).json({ errore: 'Seleziona il file CSV da importare.' });

        const analisi = analizzaCsv(req.file.buffer.toString('utf8'));
        if (!analisi.ok) return res.status(400).json({ errore: analisi.errore });

        const duplicati = req.body.duplicati === 'aggiorna' ? 'aggiorna' : 'ignora';
        const dryRun = req.body.dry_run === '1' || req.body.dry_run === 'true';

        const esito = await eseguiImport(analisi, { duplicati, dryRun });
        res.json({ duplicati, dryRun, esito });
      } catch (err) { next(err); }
    })();
  });
});

/** PUT /utenti/:id/password — reset da parte dell'admin.
 * Se `nuovaPassword` è vuota ne genera una provvisoria sicura. Impone
 * must_change_password=1: al primo accesso l'utente dovrà cambiarla. */
/** [v2.3.0] Soglia di formazione obbligatoria: 40 ore = 2400 minuti. */
const TARGET_FORMAZIONE_MINUTI = 40 * 60;

/** GET /monitoraggio — [v2.3.2] aggregated analytics della tab «Monitoraggio»:
 *  1) Target 40h: quante persone hanno raggiunto le 40 ore considerando TUTTI
 *     i certificati caricati (APPROVATI + IN ATTESA; i rifiuti restano fuori);
 *  2) aree tematiche: numero di certificati per area (ogni caricamento conta);
 *  3) KPI: media ore conteggiate per dipendente, totale certificati in attesa,
 *     top 3 aree più frequentate. */
router.get('/monitoraggio', async (req, res, next) => {
  try {
    /* Ore CONTEGGIATE per ogni dipendente (una sola query, LEFT JOIN: anche
     * chi non ha caricato nulla compare con 0 minuti). */
    const [righeDip] = await pool.query(
      `SELECT d.id,
              COALESCE(SUM(IF(c.stato IN ('APPROVATO', 'IN_ATTESA'),
                              c.numero_ore * 60 + c.numero_minuti, 0)), 0) AS minuti
       FROM dipendenti d
       LEFT JOIN certificati c ON c.dipendente_id = d.id
       GROUP BY d.id`
    );

    const totaleDipendenti = righeDip.length;
    const sommaMinuti = righeDip.reduce((acc, r) => acc + Number(r.minuti), 0);
    const raggiunti = righeDip.filter((r) => Number(r.minuti) >= TARGET_FORMAZIONE_MINUTI).length;
    const nonRaggiunti = totaleDipendenti - raggiunti;
    const percentuale = totaleDipendenti
      ? Math.round((raggiunti / totaleDipendenti) * 100)
      : 0;
    const mediaOreMinuti = totaleDipendenti
      ? Math.round(sommaMinuti / totaleDipendenti)
      : 0;

    /* Aree tematiche: TUTTI i certificati caricati (la scelta dell'area avviene
     * al caricamento, indipendentemente dalla decisione dell'amministratore). */
    const [aree] = await pool.query(
      `SELECT area_tematica AS area, COUNT(*) AS certificati
       FROM certificati
       GROUP BY area_tematica
       ORDER BY certificati DESC, area ASC`
    );

    const [[{ inAttesa }]] = await pool.query(
      "SELECT COUNT(*) AS inAttesa FROM certificati WHERE stato = 'IN_ATTESA'"
    );

    res.json({
      target: { totaleDipendenti, raggiunti, nonRaggiunti, percentuale },
      mediaOreMinuti,
      certificatiInAttesa: Number(inAttesa),
      aree: aree.map((a) => ({ area: a.area, certificati: Number(a.certificati) })),
      topAree: aree.slice(0, 3).map((a) => ({ area: a.area, certificati: Number(a.certificati) })),
    });
  } catch (err) { next(err); }
});

/** GET /audit — [v2.2.9] ultime 100 modifiche amministrative ai certificati
 *  (storico per il pannello admin). */
router.get('/audit', async (req, res, next) => {
  try {
    const [righe] = await pool.query(
      `SELECT a.id, a.azione, a.certificato_id, a.dettagli, a.creato_il,
              d.matricola AS admin_matricola, d.nome AS admin_nome, d.cognome AS admin_cognome
       FROM audit_log a JOIN dipendenti d ON d.id = a.admin_id
       ORDER BY a.id DESC LIMIT 100`
    );
    res.json({ righe });
  } catch (err) { next(err); }
});

/** GET /utenti/export — [v2.2.9] «Esporta Anagrafica CSV»: elenco completo
 *  degli account con anagrafica (formato friendly Excel: BOM + ';'). */
router.get('/utenti/export', async (req, res, next) => {
  try {
    const [righe] = await pool.query(
      `SELECT nome, cognome, matricola, codice_fiscale, sesso, qualifica, attivo
       FROM dipendenti ORDER BY cognome ASC, nome ASC`
    );
    const righeCsv = [
      'Nome;Cognome;Matricola;Codice Fiscale;Sesso;Qualifica;Stato',
      ...righe.map((u) => [
        u.nome, u.cognome, u.matricola, u.codice_fiscale, u.sesso,
        u.qualifica, u.attivo ? 'Attivo' : 'Disabilitato',
      ].join(';')),
    ];
    const csv = '\uFEFF' + righeCsv.join('\r\n') + '\r\n';
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="anagrafica-dipendenti.csv"');
    res.send(csv);
  } catch (err) { next(err); }
});

/** GET /utenti/:id/formazione — [v2.3.0] dashboard di formazione del singolo
 *  dipendente: contatori per stato, ore approvate, ore mancanti al TARGET di
 *  40 ore obbligatorie e ripartizione per area tematica (solo APPROVATI).
 *  Consumata dalla card «Dashboard formazione per dipendente» di admin.html. */

router.get('/utenti/:id/formazione', async (req, res, next) => {
  try {
    /* [AUDIT v2.2-b F5] solo cifre: niente parseInt tolleranti su input esterni. */
    if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ errore: 'Identificativo non valido.' });
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ errore: 'Identificativo non valido.' });

    const [righe] = await pool.query(
      `SELECT id, matricola, codice_fiscale, nome, cognome, qualifica, attivo
       FROM dipendenti WHERE id = ?`, [id]);
    if (!righe.length) return res.status(404).json({ errore: 'Dipendente non trovato.' });
    const dipendente = righe[0];

    /* Contatori per stato + ore DISTINCTE (una sola riga di aggregazione).
     * [v2.3.1] le ore si dividono in APPROVATE e IN ATTESA: il TARGET considera
     * le CONTEGGIATE = approvate + in attesa (i rifiuti restano sempre fuori). */
    const [[conteggi]] = await pool.query(
      `SELECT COUNT(*) AS totale,
              COALESCE(SUM(stato = 'APPROVATO'), 0) AS approvati,
              COALESCE(SUM(stato = 'IN_ATTESA'), 0) AS inAttesa,
              COALESCE(SUM(stato = 'RIFIUTATO'), 0) AS rifiutati,
              COALESCE(SUM(IF(stato = 'APPROVATO', numero_ore * 60 + numero_minuti, 0)), 0) AS oreApprovate,
              COALESCE(SUM(IF(stato = 'IN_ATTESA',  numero_ore * 60 + numero_minuti, 0)), 0) AS oreAttesa
       FROM certificati WHERE dipendente_id = ?`, [id]);

    /* Ripartizione per area dei corsi NON rifiutati (approvati + in attesa):
     * la somma dei minuti coincide con le ore CONTEGGIATE per il target.
     * Per ogni area si indica anche quanto è ancora in attesa di approvazione. */
    const [aree] = await pool.query(
      `SELECT area_tematica AS area, COUNT(*) AS certificati,
              COALESCE(SUM(numero_ore * 60 + numero_minuti), 0) AS minuti,
              COALESCE(SUM(IF(stato = 'IN_ATTESA', numero_ore * 60 + numero_minuti, 0)), 0) AS minutiAttesa
       FROM certificati
       WHERE dipendente_id = ? AND stato IN ('APPROVATO', 'IN_ATTESA')
       GROUP BY area_tematica
       ORDER BY minuti DESC, area ASC`, [id]);

    const oreApprovateMinuti = Number(conteggi.oreApprovate);
    const oreInAttesaMinuti = Number(conteggi.oreAttesa);
    const oreConteggiateMinuti = oreApprovateMinuti + oreInAttesaMinuti;
    /* [v2.3.1] mancanti e avanzamento sul CONTEGGIO completo: se un domani
     * l'admin rifiuta un certificato, le ore escono dal conteggio e la barra
     * si riduce da sola (i rifiuti non contano mai). */
    const oreMancantiMinuti = Math.max(0, TARGET_FORMAZIONE_MINUTI - oreConteggiateMinuti);
    const percentuale = Math.min(100, Math.round((oreConteggiateMinuti / TARGET_FORMAZIONE_MINUTI) * 100));
    const stato = oreConteggiateMinuti >= TARGET_FORMAZIONE_MINUTI ? 'IN_REGOLA'
      : (oreConteggiateMinuti > 0 ? 'IN_CORSO' : 'SOTTO_SOGLIA');

    res.json({
      dipendente,
      certificati: {
        totale: Number(conteggi.totale),
        approvati: Number(conteggi.approvati),
        inAttesa: Number(conteggi.inAttesa),
        rifiutati: Number(conteggi.rifiutati),
      },
      targetMinuti: TARGET_FORMAZIONE_MINUTI,
      oreApprovateMinuti,
      oreInAttesaMinuti,
      oreConteggiateMinuti,
      oreMancantiMinuti,
      percentuale,
      stato,
      perArea: aree.map((a) => ({
        area: a.area,
        certificati: Number(a.certificati),
        minuti: Number(a.minuti),
        minutiAttesa: Number(a.minutiAttesa),
      })),
    });
  } catch (err) { next(err); }
});

/** PUT /utenti/:id — [v2.2.8] modifica anagrafica e dati lavorativi del
 *  dipendente: nome, cognome, matricola, codice fiscale, sesso, qualifica
 *  professionale ed email. Stesse regole di validazione della creazione;
 *  unicità di matricola/CF/email rispetto agli ALTRI dipendenti (409).
 *  Ruolo, stato account e password NON si toccano qui: hanno rotte/policy
 *  dedicate (stato, reset password). */
router.put('/utenti/:id', async (req, res, next) => {
  try {
    /* [AUDIT v2.2-b F5] Solo CIFRE: niente parseInt tolleranti su input esterni. */
    if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ errore: 'Identificativo non valido.' });
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ errore: 'Identificativo non valido.' });

    const [esistente] = await pool.query('SELECT id FROM dipendenti WHERE id = ?', [id]);
    if (!esistente.length) return res.status(404).json({ errore: 'Utente non trovato.' });

    /* Validazione completa (stesse regole della creazione: matricola, CF in
     * formato italiano maiuscolo, nome/cognome/qualifica, sesso, email). */
    const { errori, valori } = validaDatiDipendente(req.body || {});
    if (errori.length) return res.status(400).json({ errore: errori.join(' ') });

    /* Unicità rispetto a un ALTRO account: il confronto esclude se stesso
     * (ri-salvare i propri dati non deve dare conflitto). */
    const conflitti = [];
    const [dupMatricola] = await pool.query(
      'SELECT id FROM dipendenti WHERE matricola = ? AND id <> ? LIMIT 1', [valori.matricola, id]);
    if (dupMatricola.length) conflitti.push('Matricola già assegnata a un altro dipendente.');
    const [dupCF] = await pool.query(
      'SELECT id FROM dipendenti WHERE codice_fiscale = ? AND id <> ? LIMIT 1', [valori.codiceFiscale, id]);
    if (dupCF.length) conflitti.push('Codice Fiscale già assegnato a un altro dipendente.');
    if (valori.email) {
      const [dupEmail] = await pool.query(
        'SELECT id FROM dipendenti WHERE email = ? AND id <> ? LIMIT 1', [valori.email, id]);
      if (dupEmail.length) conflitti.push('Email già assegnata a un altro dipendente.');
    }
    if (conflitti.length) return res.status(409).json({ errore: conflitti.join(' ') });

    try {
      /* UPDATE solo dei campi anagrafici/lavorativi richiesti. */
      const [esito] = await pool.query(
        `UPDATE dipendenti
         SET matricola = ?, codice_fiscale = ?, nome = ?, cognome = ?,
             sesso = ?, qualifica = ?, email = ?
         WHERE id = ?`,
        [valori.matricola, valori.codiceFiscale, valori.nome, valori.cognome,
         valori.sesso, valori.qualifica, valori.email || null, id]
      );
      if (!esito.affectedRows) return res.status(404).json({ errore: 'Utente non trovato.' });
      res.json({ ok: true, messaggio: `Dati di ${valori.cognome} ${valori.nome} aggiornati.` });
    } catch (err) {
      /* Race su UNIQUE (matricola/CF): il pre-check ha già filtrato i casi
       * normali; qui catturiamo le concorrenze vere. */
      if (err && err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ errore: 'Matricola o Codice Fiscale già in uso da un altro dipendente.' });
      }
      throw err;
    }
  } catch (err) { next(err); }
});

router.put('/utenti/:id/password', async (req, res, next) => {
  try {
    /* [AUDIT v2.2-b F5] Solo CIFRE: niente parseInt tolleranti su input esterni. */
    if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ errore: 'Identificativo non valido.' });
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ errore: 'Identificativo non valido.' });

    const richiesta = typeof (req.body && req.body.nuovaPassword) === 'string' ? req.body.nuovaPassword.trim() : '';
    const passwordProvvisoria = richiesta || generaPasswordProvvisoria();
    const errPassword = validaNuovaPassword(passwordProvvisoria);
    if (errPassword) return res.status(400).json({ errore: errPassword });

    const hash = await bcrypt.hash(passwordProvvisoria, BCRYPT_ROUNDS);
    const [esito] = await pool.query(
      'UPDATE dipendenti SET password_hash = ?, must_change_password = 1 WHERE id = ?',
      [hash, id]
    );
    if (!esito.affectedRows) return res.status(404).json({ errore: 'Utente non trovato.' });

    res.json({
      ok: true,
      passwordProvvisoria,
      messaggio: 'Password reimpostata. Comunicala al dipendente (modifica obbligatoria al primo accesso).',
    });
  } catch (err) { next(err); }
});

/** PUT /utenti/:id/stato — abilita/disabilita un account.
 * `attivo` deve essere un boolean RIGOROSO (true/false JSON). L'admin non può
 * disabilitare se stesso (garanzia anti lock-out dell'ultimo amministratore
 * attivo in sessione). La sessione dell'utente disabilitato muove all'istante
 * grazie alla rilettura dal DB nel middleware di autenticazione. */
router.put('/utenti/:id/stato', async (req, res, next) => {
  try {
    /* [AUDIT v2.2-b F5] Solo CIFRE: niente parseInt tolleranti su input esterni. */
    if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ errore: 'Identificativo non valido.' });
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ errore: 'Identificativo non valido.' });

    const attivo = req.body && req.body.attivo;
    if (typeof attivo !== 'boolean') return res.status(400).json({ errore: 'Campo "attivo" (true/false) obbligatorio.' });

    if (!attivo && id === req.utente.id) {
      return res.status(400).json({ errore: 'Non puoi disabilitare il tuo stesso account.' });
    }

    const [esito] = await pool.query('UPDATE dipendenti SET attivo = ? WHERE id = ?', [attivo ? 1 : 0, id]);
    if (!esito.affectedRows) return res.status(404).json({ errore: 'Utente non trovato.' });

    res.json({ ok: true, messaggio: attivo ? 'Account abilitato.' : 'Account disabilitato.' });
  } catch (err) { next(err); }
});

/* ====================== GESTIONE CERTIFICATI ====================== */

/* ------------------------------------------------------------------ *
 *  [v2.0] CARICAMENTO CERTIFICATO PER CONTO DI UN DIPENDENTE
 *  ------------------------------------------------------------------
 *  L'amministratore seleziona il dipendente (dipendenteId) e compila il
 *  modulo completo con il PDF: il file viene salvato nella cartella
 *  uploads/certificati/{CODICE_FISCALE_DEL_DIPENDENTE}/ e il record è
 *  associato al dipendente scelto, come se lo avesse caricato lui stesso.
 *
 *  Perché storage in MEMORIA (max 5 MB, trascurabili): il campo testuale
 *  "dipendenteId" può arrivare DOPO il file nel corpo multipart, quindi
 *  non è affidabile decidere la cartella dentro lo storage di Multer.
 *  Con la memoria il file viene scritto manualmente SOLO dopo la
 *  validazione completa → nessun file orfano in caso di rifiuto.
 * ------------------------------------------------------------------ */
const uploadPdfAdmin = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.maxFileBytes + 1024, files: 5 }, // [v2.2] fino a 5 file
  fileFilter(req, file, cb) {
    const ammesse = ['.pdf', '.jpg', '.jpeg', '.png']; // [v2.2] anche immagini
    if (!ammesse.includes(path.extname(file.originalname).toLowerCase())) {
      return cb(new Error('Formato non ammesso: sono ammessi solo file PDF, JPG e PNG.'));
    }
    const mimeOk = ['application/pdf', 'image/jpeg', 'image/png', ''];
    if (file.mimetype && !mimeOk.includes(file.mimetype)) {
      return cb(new Error('Formato non ammesso: sono ammessi solo file PDF, JPG e PNG (MIME coerente).'));
    }
    cb(null, true);
  },
});

/** POST /api/admin/certificati — multipart/form-data:
 *  dipendenteId + nome_corso, ente_erogatore, data_conseguimento,
 *  numero_ore, esame_finale, area_tematica + file (PDF ≤ 5 MB). */
router.post('/certificati', uploadPdfAdmin.array('file', 5), async (req, res, next) => {
  try {
    /* 1) Dipendente di destinazione: identificativo numerico + lettura a DB
     *    (serve il codice_fiscale per la cartella e l'id per l'associazione). */
    /* [AUDIT v2.2-b F5] solo cifre anche per il campo del form. */
    const testoDip = String((req.body && req.body.dipendenteId) ?? '');
    const dipendenteId = /^\d+$/.test(testoDip) ? Number.parseInt(testoDip, 10) : NaN;
    if (!Number.isInteger(dipendenteId) || dipendenteId <= 0) {
      return res.status(400).json({ errore: 'Seleziona il dipendente per cui caricare il certificato.' });
    }
    const [righeDip] = await pool.query(
      'SELECT id, matricola, codice_fiscale, nome, cognome FROM dipendenti WHERE id = ? LIMIT 1',
      [dipendenteId]
    );
    const dipendente = righeDip[0];
    if (!dipendente) return res.status(404).json({ errore: 'Dipendente non trovato.' });

    /* 2) [v2.2] I file: da 1 a 5 (PDF/JPEG/PNG), entro il limite ESATTO e con
     *    firma binaria genuina (anti file rinominato). */
    const files = Array.isArray(req.files) ? req.files : [];
    if (!files.length) {
      const contentLength = Number(req.headers['content-length'] || 0);
      const troppoGrande = contentLength > config.maxFileBytes + 64 * 1024;
      return res.status(400).json({
        errore: troppoGrande ? 'File troppo grande: il limite massimo è 5 MB per file.'
          : 'Il file del certificato è obbligatorio (PDF, JPG o PNG).',
      });
    }
    const eccessivo = files.find((f) => f.size > config.maxFileBytes);
    if (eccessivo) {
      return res.status(400).json({ errore: `«${eccessivo.originalname}» supera il limite di 5 MB per file.` });
    }
    const tipi = [];
    for (const f of files) {
      const tipo = tipoDaFirma(f.buffer);
      if (!tipo) {
        return res.status(400).json({ errore: `«${f.originalname}» non è un file PDF, JPG o PNG valido.` });
      }
      tipi.push(tipo);
    }

    /* 3) Validazione dei campi del certificato (stesse regole del dipendente). */
    const { errori, valori } = validaDatiCertificato(req.body || {});
    if (errori.length) return res.status(400).json({ errore: errori.join(' ') });

    /* 4) Scrittura dei file nella cartella del DIPENDENTE SCELTO (v2.0:
     *    la cartella è nominata col SUO codice fiscale) con nomi univoci. */
    const dirDestinazione = cartellaDipendente(dipendente.codice_fiscale);
    const relativo = (nome) => path.join('certificati', dipendente.codice_fiscale, nome)
      .split(path.sep).join('/');
    const salvati = [];
    for (const f of files) {
      const nomeSuServer = nomeFileUnivoco(f.originalname);
      await fs.promises.writeFile(path.join(dirDestinazione, nomeSuServer), f.buffer);
      salvati.push({ nomeSuServer, originale: f.originalname, size: f.size });
    }

    /* 5) Registrazione a nome del dipendente (stato IN_ATTESA) + un allegato
     *    per ogni file: il primo resta anche in percorso_file (compat. v1.x). */
    const [esito] = await pool.query(
      `INSERT INTO certificati
         (dipendente_id, nome_corso, ente_erogatore, data_conseguimento,
          numero_ore, numero_minuti, esame_finale, area_tematica,
          nome_file_originale, percorso_file, dimensione_file, stato)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'IN_ATTESA')`,
      [dipendente.id, valori.nomeCorso, valori.ente, valori.data,
       valori.numeroOre, valori.numeroMinuti, valori.esameFinale, valori.areaTematica,
       salvati[0].originale, relativo(salvati[0].nomeSuServer), salvati[0].size]
    );

    await pool.query(
      `INSERT INTO allegati (certificato_id, percorso_file, nome_originale, tipo_file, dimensione_file)
       VALUES ?`,
      [salvati.map((f, i) => [esito.insertId, relativo(f.nomeSuServer), f.originale, tipi[i], f.size])]
    );

    res.status(201).json({
      ok: true,
      id: esito.insertId,
      allegati: salvati.length,
      messaggio: `Certificato caricato per ${dipendente.cognome} ${dipendente.nome} (matricola ${dipendente.matricola}). In attesa di approvazione.`,
    });
  } catch (err) { next(err); }
});

/** [FIX QA-C2] Filtro con valore non valido: non va IGNORATO silenziosamente
 *  (l'utente crederebbe che il filtro sia attivo mentre vede tutto l'archivio)
 *  ma rifiutato con 400 e un messaggio chiaro. */
class ErroreFiltro extends Error {}

/** Costruttore condiviso del WHERE per vista globale ed export CSV.
 *  Filtri accettati: q (testo libero), stato, dipendenteId, dal, al (date ISO)
 *  e area tematica (v1.4). Ogni filtro è additivo (AND) e parametrico.
 *  [FIX QA-C2] un filtro PRESENTE ma non valido solleva ErroreFiltro → 400. */
function filtriCertificati(query) {
  const condizioni = [];
  const parametri = [];

  const q = pulisci(query.q);
  if (q) {
    condizioni.push('(c.nome_corso LIKE ? OR c.ente_erogatore LIKE ? OR d.matricola LIKE ? OR d.nome LIKE ? OR d.cognome LIKE ?)');
    const like = likeSicuro(q);
    parametri.push(like, like, like, like, like);
  }
  const stato = pulisci(query.stato);
  if (stato && !STATI_VALIDI.includes(stato)) {
    throw new ErroreFiltro('Filtro «stato» non valido: usare IN_ATTESA, APPROVATO o RIFIUTATO.');
  }
  if (stato) { condizioni.push('c.stato = ?'); parametri.push(stato); }

  const dipendenteIdTesto = pulisci(query.dipendenteId);
  if (dipendenteIdTesto !== '') {
    /* [FIX QA-C4] Solo CIFRE: parseInt("1;DROP") restituirebbe 1 e applicherebbe
     *  un filtro "silenzioso" a un id non richiesto. Qui il valore parziale
     *  viene rifiutato con 400. */
    if (!/^\d+$/.test(dipendenteIdTesto)) {
      throw new ErroreFiltro('Filtro «dipendente» non valido: identificativo numerico atteso.');
    }
    const dipendenteId = Number.parseInt(dipendenteIdTesto, 10);
    if (!Number.isInteger(dipendenteId) || dipendenteId <= 0) {
      throw new ErroreFiltro('Filtro «dipendente» non valido: identificativo numerico atteso.');
    }
    condizioni.push('c.dipendente_id = ?');
    parametri.push(dipendenteId);
  }

  const RE_DATA_FILTRO = /^\d{4}-\d{2}-\d{2}$/;
  const dal = pulisci(query.dal);
  if (dal && (!RE_DATA_FILTRO.test(dal) || Number.isNaN(Date.parse(dal)))) {
    throw new ErroreFiltro('Filtro «dal» non valido: usare una data nel formato AAAA-MM-GG.');
  }
  if (dal) { condizioni.push('c.data_conseguimento >= ?'); parametri.push(dal); }

  const al = pulisci(query.al);
  if (al && (!RE_DATA_FILTRO.test(al) || Number.isNaN(Date.parse(al)))) {
    throw new ErroreFiltro('Filtro «al» non valido: usare una data nel formato AAAA-MM-GG.');
  }
  if (al) { condizioni.push('c.data_conseguimento <= ?'); parametri.push(al); }

  /* v1.4: filtro per AREA TEMATICA (corrispondenza esatta).
   * [v2.2.5] ammesse le 17 aree nuove e le 6 storiche (archivio preesistente). */
  const area = pulisci(query.area);
  if (area && !AREE_AMMESSE.includes(area)) {
    throw new ErroreFiltro('Filtro «area tematica» non valido: scegliere una voce dell\'elenco.');
  }
  if (area) { condizioni.push('c.area_tematica = ?'); parametri.push(area); }

  /* [v2.2.7] filtro DURATA: durataMin/durataMax in MINUTI interi, sulla durata
   * totale (numero_ore * 60 + numero_minuti) così anche i corsi sotto l'ora
   * (es. 0:45 → 45) restano correttamente filtrabili. */
  for (const [chiave, operatore, etichetta] of [
    ['durataMin', '>=', 'durata minima'], ['durataMax', '<=', 'durata massima'],
  ]) {
    const v = pulisci(query[chiave]);
    if (v === '') continue;
    if (!/^\d{1,6}$/.test(v)) {
      throw new ErroreFiltro(`Filtro «${etichetta}» non valido: inserire i minuti come numero intero.`);
    }
    condizioni.push(`(c.numero_ore * 60 + c.numero_minuti) ${operatore} ?`);
    parametri.push(Number.parseInt(v, 10));
  }

  /* [v2.2] filtro ESAME FINALE a tendina: ?esame=si | ?esame=no. */
  const esame = pulisci(query.esame).toLowerCase();
  if (esame && !['si', 'no'].includes(esame)) {
    throw new ErroreFiltro('Filtro «esame finale» non valido: usare Si oppure No.');
  }
  if (esame) { condizioni.push('c.esame_finale = ?'); parametri.push(esame === 'si' ? 1 : 0); }

  return { where: condizioni.length ? `WHERE ${condizioni.join(' AND ')}` : '', parametri };
}

/** Wrapper dei due endpoint con filtri: traduce ErroreFiltro in 400. */
function filtriSicuri(req, res) {
  try {
    return filtriCertificati(req.query);
  } catch (err) {
    if (err instanceof ErroreFiltro) {
      res.status(400).json({ errore: err.message });
      return null;
    }
    throw err;
  }
}

/** Proiezione con JOIN sull'anagrafica: ogni riga porta matricola/nome/cognome. */
const SELECT_CERTIFICATI = `
  SELECT c.id, c.dipendente_id, c.nome_corso, c.ente_erogatore, c.data_conseguimento,
         c.numero_ore, c.numero_minuti, c.esame_finale, c.area_tematica,
         c.nome_file_originale, c.dimensione_file, c.stato, c.note_admin, c.caricato_il,
         d.matricola, d.codice_fiscale, d.nome, d.cognome, d.qualifica, d.sesso
  FROM certificati c
  JOIN dipendenti d ON d.id = c.dipendente_id`;

/** GET /certificati — vista globale (tutti i dipendenti).
 *  [v2.2.3] con perPagina=tutti restituisce l'ELENCO COMPLETO (nessun limite
 *  di righe: la tabella di riepilogo admin non ha più tagli da paginazione);
 *  senza, resta la paginazione classica (min 5 / max 100 righe per pagina). */
router.get('/certificati', async (req, res, next) => {
  try {
    const filtri = filtriSicuri(req, res);
    if (!filtri) return; // risposta 400 già inviata (filtro non valido)
    const { where, parametri } = filtri;
    const [[{ totale }]] = await pool.query(
      `SELECT COUNT(*) AS totale FROM certificati c JOIN dipendenti d ON d.id = c.dipendente_id ${where}`,
      parametri
    );

    /* [v2.2.3] perPagina=tutti → NESSUN taglio: si restituiscono tutte le
     * righe che rispettano i filtri (l'admin consulta l'elenco completo). */
    const elencoCompleto = String(req.query.perPagina || '').toLowerCase() === 'tutti';
    const { pagina, perPagina, offset } = elencoCompleto
      ? { pagina: 1, perPagina: Math.max(1, totale), offset: 0 }
      : parametriPagina(req);
    const [certificati] = await pool.query(
      `${SELECT_CERTIFICATI} ${where} ORDER BY c.caricato_il DESC, c.id DESC${elencoCompleto ? '' : ' LIMIT ? OFFSET ?'}`,
      elencoCompleto ? parametri : [...parametri, perPagina, offset]
    );

    /* [v2.2] Allegati di ogni corso mostrato nella pagina corrente. */
    const ids = certificati.map((c) => c.id);
    const mappaAllegati = new Map();
    if (ids.length) {
      const [tutti] = await pool.query(
        `SELECT id, certificato_id, nome_originale, tipo_file, dimensione_file
         FROM allegati WHERE certificato_id IN (?) ORDER BY id ASC`,
        [ids]
      );
      for (const a of tutti) {
        if (!mappaAllegati.has(a.certificato_id)) mappaAllegati.set(a.certificato_id, []);
        mappaAllegati.get(a.certificato_id).push({ id: a.id, nome: a.nome_originale, tipo: a.tipo_file, dimensione_file: a.dimensione_file }); // [v2.2.7]
      }
    }
    const conAllegati = certificati.map((c) => ({ ...c, allegati: mappaAllegati.get(c.id) || [] }));

    res.json({ certificati: conAllegati, totale, pagina, perPagina,
      pagineTotali: elencoCompleto ? 1 : Math.max(1, Math.ceil(totale / perPagina)) });
  } catch (err) { next(err); }
});

/** GET /certificati/export — CSV dei certificati (stessi filtri, NO paginazione).
 *  Formato "friendly Excel italiano": BOM UTF-8 + separatore ';'. */
router.get('/certificati/export', async (req, res, next) => {
  try {
    const filtri = filtriSicuri(req, res);
    if (!filtri) return; // risposta 400 già inviata (filtro non valido)
    const { where, parametri } = filtri;
    const [righe] = await pool.query(
      `${SELECT_CERTIFICATI} ${where}
       ORDER BY d.cognome ASC, d.nome ASC, c.data_conseguimento DESC`,
      parametri
    );

    /* v1.4: report COMPLETO — anagrafica (con sesso e qualifica) + dettagli
     * del certificato (ore, esame, area) + riferimenti al file (stato e link
     * relativo, scaricabile dopo il login come amministratore). */
    const intestazione = ['ID', 'Matricola', 'Codice Fiscale', 'Cognome', 'Nome', 'Sesso', 'Qualifica',
      'Corso', 'Ente erogatore', 'Data conseguimento', 'Numero ore', 'Esame finale',
      'Area tematica', 'Stato certificato', 'Caricato il', 'File originale',
      'Link PDF', 'Dimensione (KB)', 'Note'];
    const righeCsv = righe.map(r => [
      r.id, r.matricola, r.codice_fiscale, r.cognome, r.nome, r.sesso, r.qualifica,
      r.nome_corso, r.ente_erogatore, r.data_conseguimento,
      formattaDurata(r.numero_ore, r.numero_minuti), // [v2.2] "8" oppure "8:30"
      r.esame_finale ? 'Si' : 'No', r.area_tematica, r.stato, r.caricato_il,
      r.nome_file_originale, `/api/certificati/${r.id}/file`,
      (r.dimensione_file / 1024).toFixed(1), r.note_admin || '',
    ].map(csvCampo).join(';'));

    const csv = '\uFEFF' + [intestazione.join(';'), ...righeCsv].join('\r\n');

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="certificati_${new Date().toISOString().slice(0, 10)}.csv"`);
    res.send(csv);
  } catch (err) { next(err); }
});

/** PUT /certificati/:id/stato — decisione di verifica: APPROVATO | RIFIUTATO.
 *  La nota (max 500 caratteri) è facoltativa e visibile al dipendente.
 *  Audit trail: chi (approvato_da) e quando (approvato_il). */
/** PUT /certificati/:id — [v2.2.9] l'amministratore corregge i METADATI di
 *  un certificato già caricato (titolo, ente, data, durata, esame, area).
 *  Stesse validazioni dell'upload; l'operazione finisce nell'audit log.
 *  Lo stato e i file allegati NON si toccano (hanno gestioni dedicate). */
router.put('/certificati/:id', async (req, res, next) => {
  try {
    /* [AUDIT v2.2-b F5] Solo CIFRE: niente parseInt tolleranti su input esterni. */
    if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ errore: 'Identificativo non valido.' });
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ errore: 'Identificativo non valido.' });

    /* [v2.3.4] lettura COMPLETA dei metadati attuali: serve al confronto
     * campo per campo che alimenta lo storico specifico. */
    const [presente] = await pool.query(
      `SELECT nome_corso, ente_erogatore, data_conseguimento,
              numero_ore, numero_minuti, esame_finale, area_tematica
       FROM certificati WHERE id = ?`, [id]);
    if (!presente.length) return res.status(404).json({ errore: 'Certificato non trovato.' });

    const { errori, valori } = validaDatiCertificato(req.body || {});
    if (errori.length) return res.status(400).json({ errore: errori.join(' ') });

    const [esito] = await pool.query(
      `UPDATE certificati
       SET nome_corso = ?, ente_erogatore = ?, data_conseguimento = ?,
           numero_ore = ?, numero_minuti = ?, esame_finale = ?, area_tematica = ?
       WHERE id = ?`,
      [valori.nomeCorso, valori.ente, valori.data, valori.numeroOre,
       valori.numeroMinuti, valori.esameFinale, valori.areaTematica, id]
    );
    if (!esito.affectedRows) return res.status(404).json({ errore: 'Certificato non trovato.' });

    /* [v2.3.4] Storico SPECIFICO (richiesta 5.1 evoluta): una riga di audit
     * per OGNI campo realmente modificato, con codice puntuale (es.
     * MODIFICA_TITOLO_CORSO) e valori prima → dopo nei dettagli. Se nessun
     * campo è cambiato non si scrive nessuna riga. */
    const prima = presente[0];
    const eventi = [
      ['TITOLO_CORSO',       prima.nome_corso, valori.nomeCorso],
      ['ENTE_EROGATORE',     prima.ente_erogatore, valori.ente],
      ['DATA_CONSEGUIMENTO', prima.data_conseguimento, valori.data],
      ['DURATA',             formattaDurata(prima.numero_ore, prima.numero_minuti),
                             formattaDurata(valori.numeroOre, valori.numeroMinuti)],
      ['ESAME_FINALE',       prima.esame_finale ? 'Sì' : 'No', valori.esameFinale ? 'Sì' : 'No'],
      ['AREA_TEMATICA',      prima.area_tematica, valori.areaTematica],
    ];
    for (const [campo, vecchio, nuovo] of eventi) {
      if (String(vecchio) === String(nuovo)) continue;
      /* Codice azione puntuale: MODIFICA_<CAMPO>; ELIMINAZIONE_<CAMPO> se il
       * nuovo valore è vuoto (difensivo: oggi la validazione li rende tutti
       * obbligatori, il codice è pronto per l'evoluzione del form). */
      const codice = (nuovo === '' ? 'ELIMINAZIONE_' : 'MODIFICA_') + campo;
      await scriviAudit(req.utente.id, codice, id, `«${vecchio}» → «${nuovo}»`);
    }

    res.json({ ok: true, messaggio: 'Certificato aggiornato.' });
  } catch (err) { next(err); }
});

router.put('/certificati/:id/stato', async (req, res, next) => {
  try {
    /* [AUDIT v2.2-b F5] Solo CIFRE: niente parseInt tolleranti su input esterni. */
    if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ errore: 'Identificativo non valido.' });
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ errore: 'Identificativo non valido.' });

    const stato = pulisci(req.body && req.body.stato);
    if (!['APPROVATO', 'RIFIUTATO'].includes(stato)) {
      return res.status(400).json({ errore: 'Stato non valido: usa APPROVATO o RIFIUTATO.' });
    }
    const note = typeof (req.body && req.body.note) === 'string' ? req.body.note.trim().slice(0, 500) : null;

    /* [v2.3.4] stato PRECEDENTE: entra nei dettagli dello storico
     * («Stato: IN_ATTESA → APPROVATO») per rendere il cambio immediato. */
    const [presente] = await pool.query('SELECT stato FROM certificati WHERE id = ?', [id]);
    if (!presente.length) return res.status(404).json({ errore: 'Certificato non trovato.' });

    /* COALESCE(?, note_admin): se la nota non è fornita si conserva la precedente. */
    const [esito] = await pool.query(
      `UPDATE certificati
       SET stato = ?, note_admin = COALESCE(?, note_admin), approvato_da = ?, approvato_il = NOW()
       WHERE id = ?`,
      [stato, note, req.utente.id, id]
    );
    if (!esito.affectedRows) return res.status(404).json({ errore: 'Certificato non trovato.' });

    /* [v2.3.4] storico con azione SPECIFICA: APPROVAZIONE_CERTIFICATO o
     * RIFIUTO_CERTIFICATO (prima: APPROVAZIONE/RIFIUTO generici). */
    await scriviAudit(req.utente.id, stato === 'APPROVATO' ? 'APPROVAZIONE_CERTIFICATO' : 'RIFIUTO_CERTIFICATO', id,
      `Stato: ${presente[0].stato} → ${stato}${note ? ` · Nota: ${note}` : ''}`);

    res.json({ ok: true, messaggio: `Certificato ${stato === 'APPROVATO' ? 'approvato' : 'rifiutato'}.` });
  } catch (err) { next(err); }
});

/** DELETE /certificati/:id — eliminazione COMPLETA: riga MySQL + file PDF
 *  sul disco. Prima si legge il percorso (serve dopo), poi si cancella la
 *  riga e SI ATTENDE la rimozione fisica del file [FIX QA]: la risposta 200
 *  garantisce che record e file non esistano più (nessuna corsa con la
 *  cancellazione asincrona). */
router.delete('/certificati/:id', async (req, res, next) => {
  try {
    /* [AUDIT v2.2-b F5] Solo CIFRE: niente parseInt tolleranti su input esterni. */
    if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ errore: 'Identificativo non valido.' });
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ errore: 'Identificativo non valido.' });

    const [righe] = await pool.query(
      `SELECT c.percorso_file, c.nome_corso, d.matricola
       FROM certificati c JOIN dipendenti d ON d.id = c.dipendente_id
       WHERE c.id = ? LIMIT 1`, [id]);
    if (!righe[0]) return res.status(404).json({ errore: 'Certificato non trovato.' });

    /* [v2.2] tutti i percorsi da rimuovere: file principale + allegati
     * (le righe di allegati spariscono da sole per FK ON DELETE CASCADE). */
    const [allegati] = await pool.query('SELECT percorso_file FROM allegati WHERE certificato_id = ?', [id]);
    const percorsi = [righe[0].percorso_file, ...allegati.map((a) => a.percorso_file)];

    await pool.query('DELETE FROM certificati WHERE id = ?', [id]);
    for (const percorso of percorsi) await eliminaFileAttesa(percorso); // attesa: nessun residuo

    /* [v2.3.4] anche l'eliminazione entra nello storico con azione specifica.
     * certificato_id resta NULL (la riga non esiste più: FK ON DELETE SET
     * NULL) e i dettagli conservano corso e matricola del titolare. */
    await scriviAudit(req.utente.id, 'ELIMINAZIONE_CERTIFICATO', null,
      `Corso «${righe[0].nome_corso}» · dipendente ${righe[0].matricola}`);

    res.json({ ok: true, messaggio: 'Certificato eliminato.' });
  } catch (err) { next(err); }
});

module.exports = router;

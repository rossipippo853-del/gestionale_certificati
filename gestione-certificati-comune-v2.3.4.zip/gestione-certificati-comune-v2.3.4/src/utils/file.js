/**
 * ============================================================================
 *  utils/file.js — STORAGE DEI PDF SUL FILE SYSTEM DEL SERVER
 * ============================================================================
 *  Struttura fisica (v2.0): {UPLOAD_DIR}/certificati/{CODICE_FISCALE}/{timestamp}-{random8}_{nome}.pdf
 *  La cartella di ogni dipendente è nominata con il CODICE FISCALE (non più la
 *  matricola): nasce alla registrazione/importazione e accoglie i suoi PDF.
 *  Nel database:      SOLO il percorso relativo (colonna percorso_file).
 *
 *  Perché il file system e non i BLOB MySQL:
 *   - il DB resta piccolo, i backup sono rapidi e indipendenti dai documenti;
 *   - i file sono serviti da Node con sendFile (streaming efficiente);
 *   - spostare lo storage (altro disco/NAS) = cambiare una variabile .env.
 * ============================================================================
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const config = require('../config');

const DIR_CERTIFICATI = path.join(config.uploadRoot, 'certificati');

/**
 * Restituisce (creandola se assente) la cartella upload del dipendente.
 * [v2.0] La chiave della cartella è il CODICE FISCALE del dipendente:
 *   - il codice è ripulito (solo [A-Za-z0-9_-]): nessun path traversal è
 *     possibile anche in caso di dati ostili;
 *   - mkdirSync recursive è IDEMPOTENTE: crea l'intero percorso se manca e
 *     non fallisce se esiste già → base del "self-healing" (se la cartella
 *     viene cancellata, il primo upload la ricrea al volo).
 * @param {string} chiaveCartella il Codice Fiscale del dipendente (v2.0)
 */
function cartellaDipendente(chiaveCartella) {
  const sicura = String(chiaveCartella || '').replace(/[^A-Za-z0-9_-]/g, '_');
  /* [AUDIT F1] Una chiave vuota verrebbe risolta sulla RADICE dei certificati:
   * si rifiuta esplicitamente (i chiamanti passano sempre un CF validato). */
  if (!sicura) throw new Error('Chiave della cartella mancante: operazione annullata.');
  const dir = path.join(DIR_CERTIFICATI, sicura);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

/**
 * Nome file univoco su disco: {timestamp ms}-{8 hex casuali}_{nome_sanificato}.pdf
 *   - il timestamp cronologizza i file;
 *   - il suffisso CASUALE elimina la race condition di due upload con lo
 *     stesso nome nello stesso millisecondo [FIX QA-B3];
 *   - il nome originale è ridotto ai caratteri sicuri e limitato a 80
 *     caratteri finali (si conserva l'estensione).
 */
function nomeFileUnivoco(nomeOriginale) {
  const base = path.basename(String(nomeOriginale))
    .replace(/[^A-Za-z0-9._-]/g, '_')
    .replace(/_{2,}/g, '_')
    .slice(-80);
  const casuale = crypto.randomBytes(4).toString('hex');
  return `${Date.now()}-${casuale}_${base}`;
}

/** Verifica dei magic bytes: un PDF reale inizia con "%PDF-". */
function ePdf(buffer) {
  return Buffer.isBuffer(buffer) && buffer.length >= 5 && buffer.subarray(0, 5).toString('latin1') === '%PDF-';
}

/**
 * [v2.2] Riconosce il TIPO REALE di un file dalla sua firma binaria:
 *   'pdf'  → "%PDF-"                              (5 byte)
 *   'jpeg' → FF D8 FF                             (immagine JPEG/JFIF/EXIF)
 *   'png'  → 89 50 4E 47 0D 0A 1A 0A              (immagine PNG)
 * Restituisce null per qualunque altro contenuto: è la base della verifica
 * "il contenuto corrisponde all'estensione dichiarata?" (anti file travestito).
 */
function tipoDaFirma(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 8) return null;
  if (ePdf(buffer)) return 'pdf';
  if (buffer[0] === 0xFF && buffer[1] === 0xD8 && buffer[2] === 0xFF) return 'jpeg';
  const PNG = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
  if (PNG.every((byte, i) => buffer[i] === byte)) return 'png';
  return null;
}

/** [v2.2] Formatta la durata in "ore" o "ore:minuti" (es. 8 → "8", 8h30 → "8:30"). */
function formattaDurata(ore, minuti) {
  const o = Number.parseInt(ore, 10) || 0;
  const m = Number.parseInt(minuti, 10) || 0;
  return m > 0 ? `${o}:${String(m).padStart(2, '0')}` : `${o}`;
}

/**
 * Converte il percorso relativo (dal DB) in percorso assoluto sul disco,
 * CON protezione anti path traversal:
 *   1. rifiuta percorsi contenenti '..';
 *   2. risolve contro la radice degli upload;
 *   3. accetta solo ciò che resta DENTRO certificati/.
 * Restituisce null in caso di tentativo di evasione → il chiamante risponde 404.
 */
function percorsoAssoluto(percorsoRelativo) {
  if (typeof percorsoRelativo !== 'string' || percorsoRelativo.includes('..')) return null;
  const radice = path.resolve(DIR_CERTIFICATI);
  const abs = path.resolve(config.uploadRoot, percorsoRelativo);
  return abs.startsWith(radice + path.sep) ? abs : null;
}

/** Elimina un file dallo storage (best effort: un fallimento non deve mai
 *  impedire l'operazione logica che lo ha richiesto, es. DELETE del record). */
function eliminaFile(percorsoRelativo) {
  const abs = percorsoAssoluto(percorsoRelativo);
  if (!abs) return;
  fs.promises.unlink(abs).catch(() => {});
}

/**
 * Come eliminaFile, ma ATTENDE il completamento della cancellazione.
 * [FIX QA] Usata dal DELETE dei certificati: garantisce che quando il server
 * risponde "eliminato", il file sia davvero già rimosso dal disco (prima la
 * cancellazione era fire-and-forget e poteva completarsi DOPO la risposta).
 */
async function eliminaFileAttesa(percorsoRelativo) {
  const abs = percorsoAssoluto(percorsoRelativo);
  if (!abs) return;
  await fs.promises.unlink(abs).catch(() => {});
}

module.exports = { DIR_CERTIFICATI, cartellaDipendente, nomeFileUnivoco, ePdf, tipoDaFirma, formattaDurata, percorsoAssoluto, eliminaFile, eliminaFileAttesa };

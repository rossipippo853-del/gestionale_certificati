/**
 * utils/sessioni.js — Registro di revoca dei token di sessione (in memoria).
 *
 * [FIX QA-B9] Il logout, con JWT "stateless", non invalidava davvero il token:
 * chi ne avesse una copia avrebbe potuto continuare a usarlo fino alla scadenza
 * (8 ore). Ora ogni token ha un identificativo univoco (jti); il logout lo
 * inserisce in questa lista fino alla sua scadenza naturale, e il middleware
 * di autenticazione rifiuta i token revocati.
 *
 * Nota operativa: la lista vive in memoria (adeguata per un server singolo in
 * intranet; al riavvio del servizio le sessioni revocate vengono dimenticate,
 * ma tutte le sessioni utente vengono comunque riacquistate ri-effettuando il
 * login). Per installazioni multi-istanza usare Redis o tabella dedicata.
 */
'use strict';

const revocati = new Map(); // jti → scadenza in ms epoch
const LIMITE = 10000;

function ripulisci() {
  const ora = Date.now();
  for (const [jti, scadenza] of revocati) {
    if (ora > scadenza) revocati.delete(jti);
  }
}

/** Revoca un token fino alla sua scadenza naturale (ms epoch). */
function revoca(jti, scadenzaMs) {
  if (!jti) return;
  if (revocati.size >= LIMITE) ripulisci();
  revocati.set(jti, scadenzaMs || Date.now() + 24 * 3600 * 1000);
}

/** True se il token identificato da jti è stato revocato (logout). */
function eRevocato(jti) {
  if (!jti) return false;
  if (revocati.size > 0 && revocati.size % 100 === 0) ripulisci();
  return revocati.has(jti);
}

module.exports = { revoca, eRevocato };

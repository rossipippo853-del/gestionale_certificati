/**
 * ============================================================================
 *  utils/importazione.js — MOTORE DI IMPORTAZIONE MASSIVA DIPENDENTI DA CSV
 * ============================================================================
 *  v1.3 — Un solo motore, due interfacce:
 *    • POST /api/admin/utenti/import  (pannello web, routes/admin.routes.js)
 *    • node db/import-dipendenti.js file.csv   (riga di comando / automazioni)
 *  → le due vie si comportano allo stesso modo perché condividono QUESTO codice.
 *
 *  Garanzie del motore:
 *    1. PARSING robusto senza librerie esterne (intranet senza Internet):
 *       riconosce BOM UTF-8, fine riga CRLF/LF, campi tra virgolette con
 *       separatori e virgolette raddoppiate ("") dentro, e rileva da solo il
 *       separatore (; , TAB) dalla riga di intestazione.
 *    2. VALIDAZIONE riga per riga con report: le righe difettose NON bloccano
 *       le altre; ogni problema è riportato con il numero di riga del file.
 *    3. SICUREZZA: ogni password (indicata nel file o generata) è cifrata con
 *       bcrypt prima dell'INSERT; nel DB non arriva mai una password in chiaro.
 *    4. FILE SYSTEM: per ogni nuovo utente è creata la cartella
 *       uploads/certificati/{codice_fiscale}/ PRIMA dell'INSERT (v2.0) (se fallisce, la
 *       riga va in errore senza lasciare utenti "senza cartella"; in ogni
 *       caso l'upload ricreerebbe la cartella al bisogno — self-healing).
 *    5. DUPLICATI: matricola già a DB → "ignora" (default) o "aggiorna"
 *       (nome, cognome, email, ruolo — MAI la password, MAI il Codice Fiscale,
 *       che se diverso rende la riga errata); tutto nel report.
 *
 *  Limiti prudenziali: 2 MB per file, 2000 righe per importazione.
 * ============================================================================
 */
'use strict';

const bcrypt = require('bcryptjs');
const { pool } = require('../db');
const { cartellaDipendente } = require('./file');
const { pulisci, RE_MATRICOLA, RE_CODICE_FISCALE, RE_EMAIL, validaNuovaPassword, SESSI } = require('./validazione');

const MAX_RIGHE_IMPORT = 2000;
const MAX_BYTE_FILE = 2 * 1024 * 1024; // 2 MB
const BCRYPT_ROUNDS = 10;
const RUOLI_VALIDI = ['DIPENDENTE', 'AMMINISTRATORE'];

/** v1.4 — password predefinita usata dall'import CSV quando la colonna
 *  "password_temporanea" è vuota (richiesta dirigenziale: valore noto e
 *  comunicabile a tutti; il cambio al primo accesso resta comunque obbligatorio). */
const PASSWORD_PREDEFINITA_CSV = 'Benvenuto@2026';

/* ------------------------------------------------------------------ *
 *  PARSER CSV
 * ------------------------------------------------------------------ */

/** Normalizza il nome di una colonna: minuscole, spazi → underscore. */
function normalizzaIntestazione(t) {
  return pulisci(t).toLowerCase().replace(/\s+/g, '_');
}

/** Alias ammessi per le colonne (il primo è il nome canonico del modello). */
const ALIAS_COLONNE = {
  matricola: ['matricola'],
  codice_fiscale: ['codice_fiscale', 'cf'],   // v2.0: obbligatorio, chiave delle cartelle PDF
  nome: ['nome'],
  cognome: ['cognome'],
  sesso: ['sesso'],                                   // v1.4: obbligatorio (M/F/ALTRO)
  qualifica: ['qualifica_professionale', 'qualifica'], // v1.4: obbligatoria
  email: ['email', 'e-mail', 'mail'],                 // facoltativa (retrocompatibilità)
  ruolo: ['ruolo', 'profilo'],                        // facoltativo (retrocompatibilità)
  password_temporanea: ['password_temporanea', 'password_provvisoria', 'password'],
};

/**
 * Parser CSV completo (gestione virgolette RFC-4180-like) senza dipendenze.
 * Restituisce una matrice di righe (array di campi stringa); le righe
 * completamente vuote vengono scartate.
 */
function parseCsv(testo) {
  // BOM UTF-8 (file salvati da Excel) + unificazione delle fine riga
  const t = testo.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');

  // Rilevamento del separatore dalla PRIMA riga, contando i candidati
  // fuori dalle virgolette (un campo "\"a;b\";c" non deve ingannare).
  const finePrima = t.indexOf('\n') === -1 ? t.length : t.indexOf('\n');
  const prima = t.slice(0, finePrima);
  const candidati = [';', '\t', ','];
  const conteggi = { ';': 0, '\t': 0, ',': 0 };
  let inQ = false;
  for (const ch of prima) {
    if (ch === '"') inQ = !inQ;
    else if (!inQ && ch in conteggi) conteggi[ch] += 1;
  }
  let separatore = candidati.sort((a, b) => conteggi[b] - conteggi[a])[0];
  if (conteggi[separatore] === 0) separatore = ';'; // file a colonna singola

  // Macchina a stati: virgolette aperte, campo corrente, riga corrente
  const righe = [];
  let riga = [];
  let campo = '';
  inQ = false;
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (inQ) {
      if (c === '"') {
        if (t[i + 1] === '"') { campo += '"'; i++; } // "" → virgolette letterali
        else inQ = false;
      } else campo += c;
    } else if (c === '"') {
      inQ = true;
    } else if (c === separatore) {
      riga.push(campo); campo = '';
    } else if (c === '\n') {
      riga.push(campo); righe.push(riga); riga = []; campo = '';
    } else {
      campo += c;
    }
  }
  riga.push(campo); righe.push(riga); // ultima riga senza \n finale

  // Scarta le righe interamente vuote (o ridotte a un campo vuoto)
  return righe.filter((r) => !(r.length === 1 && pulisci(r[0]) === ''));
}

/**
 * Analizza il contenuto di un file CSV dei dipendenti.
 * Output: { ok:true, totaleRighe, righeVuoteIgnorate, record:[{numeroRiga,
 *          dati:{matricola,nome,cognome,email,ruolo,password}, errori[]}] }
 * oppure  { ok:false, errore } per problemi strutturali (file vuoto,
 * colonne obbligatorie mancanti, tropppe righe).
 *
 * Le righe con errori NON vengono scartate qui: arrivano a eseguiImport con
 * errori[] popolato e lì finiscono nel report senza essere salvate.
 */
function analizzaCsv(testo) {
  const righe = parseCsv(testo);
  if (!righe.length) return { ok: false, errore: 'Il file è vuoto o non contiene righe leggibili.' };

  // Mappa colonne canoniche → indice (gestione alias nell'intestazione)
  const intestazione = righe[0].map(normalizzaIntestazione);
  const indice = {};
  for (const campo of Object.keys(ALIAS_COLONNE)) {
    indice[campo] = intestazione.findIndex((h) => ALIAS_COLONNE[campo].includes(h));
  }

  const mancanti = ['matricola', 'codice_fiscale', 'nome', 'cognome', 'sesso', 'qualifica'].filter((c) => indice[c] === -1);
  if (mancanti.length) {
    return { ok: false, errore: `Colonne obbligatorie mancanti nell'intestazione: ${mancanti.join(', ')}.` };
  }
  if (righe.length - 1 > MAX_RIGHE_IMPORT) {
    return { ok: false, errore: `Il file contiene troppe righe (massimo ${MAX_RIGHE_IMPORT}).` };
  }

  const viste = new Set();    // per individuare matricole ripetute DENTRO il file
  const visteCF = new Set();  // v2.0: idem per i codici fiscali
  const record = [];
  let righeVuoteIgnorate = 0;

  righe.slice(1).forEach((campi, i) => {
    const numeroRiga = i + 2; // la riga 1 è l'intestazione
    const prendi = (campo) =>
      indice[campo] >= 0 && indice[campo] < campi.length ? pulisci(campi[indice[campo]]) : '';

    const dati = {
      matricola: prendi('matricola'),
      codice_fiscale: prendi('codice_fiscale').toUpperCase(), // v2.0: sempre maiuscolo
      nome: prendi('nome'),
      cognome: prendi('cognome'),
      sesso: prendi('sesso').toUpperCase(),
      qualifica: prendi('qualifica'),
      email: prendi('email'),
      ruolo: (prendi('ruolo') || 'DIPENDENTE').toUpperCase(),
      password: prendi('password_temporanea'),
    };

    // Riga completamente vuota → ignorata e conteggiata a parte
    if (!dati.matricola && !dati.nome && !dati.cognome && !dati.sesso
        && !dati.qualifica && !dati.email && !dati.password) {
      righeVuoteIgnorate += 1;
      return;
    }

    const errori = [];
    if (!RE_MATRICOLA.test(dati.matricola)) errori.push('matricola non valida (2-20 caratteri alfanumerici)');
    if (!RE_CODICE_FISCALE.test(dati.codice_fiscale)) errori.push('codice_fiscale non valido (16 caratteri nel formato italiano, es. RSSMRA80A01H501U)');
    if (dati.nome.length < 2 || dati.nome.length > 100) errori.push('nome non valido (2-100 caratteri)');
    if (dati.cognome.length < 2 || dati.cognome.length > 100) errori.push('cognome non valido (2-100 caratteri)');
    if (!SESSI.includes(dati.sesso)) errori.push('sesso non valido (usare M, F o ALTRO)');
    if (dati.qualifica.length < 2 || dati.qualifica.length > 120) errori.push('qualifica_professionale non valida (2-120 caratteri)');
    if (dati.email && (dati.email.length > 150 || !RE_EMAIL.test(dati.email))) errori.push('email non valida');
    if (!RUOLI_VALIDI.includes(dati.ruolo)) errori.push('ruolo non valido (usare DIPENDENTE o AMMINISTRATORE)');
    if (dati.password) {
      const errPw = validaNuovaPassword(dati.password);
      if (errPw) errori.push(`password_temporanea: ${errPw.toLowerCase()}`);
    }
    if (viste.has(dati.matricola.toUpperCase())) errori.push('matricola duplicata nel file');
    if (dati.matricola) viste.add(dati.matricola.toUpperCase());
    if (visteCF.has(dati.codice_fiscale)) errori.push('codice_fiscale duplicato nel file');
    if (dati.codice_fiscale) visteCF.add(dati.codice_fiscale);

    record.push({ numeroRiga, dati, errori });
  });

  return { ok: true, totaleRighe: record.length, righeVuoteIgnorate, record };
}

/* ------------------------------------------------------------------ *
 *  ESECUZIONE DELL'IMPORTAZIONE
 * ------------------------------------------------------------------ */

/**
 * Applica al database le righe validate da analizzaCsv.
 * opzioni: { duplicati: 'ignora'|'aggiorna', dryRun: boolean }
 *
 * Restituisce il report:
 *   { dryRun, elaborati, creati:[{matricola,nome,password,generata}],
 *     aggiornati:[{matricola}], saltati:[{matricola,motivo}],
 *     errori:[{riga,matricola,errore}], righeVuoteIgnorate }
 *
 * In dryRun nessuna scrittura viene eseguita (né DB né cartelle): il report
 * mostra ciò che accadrebbe. Le password generate vengono comunque simulate
 * (campo password = null in dryRun, per non suggerire valori mai utilizzati).
 */
async function eseguiImport(analisi, opzioni = {}) {
  const duplicati = opzioni.duplicati === 'aggiorna' ? 'aggiorna' : 'ignora';
  const dryRun = !!opzioni.dryRun;

  const esito = {
    dryRun,
    elaborati: 0,
    creati: [],
    aggiornati: [],
    saltati: [],
    errori: [],
    righeVuoteIgnorate: analisi.righeVuoteIgnorate || 0,
  };

  for (const r of analisi.record) {
    esito.elaborati += 1;

    /* 1) Riga non valida → nel report e si prosegue con le altre. */
    if (r.errori.length) {
      esito.errori.push({
        riga: r.numeroRiga,
        matricola: r.dati.matricola || '(vuota)',
        errore: r.errori.join('; '),
      });
      continue;
    }

    /* v2.0: anagrafica completa — matricola, CODICE FISCALE, nome, cognome,
     * sesso, qualifica. Il CF identifica la cartella PDF del dipendente. */
    const { matricola, codice_fiscale, nome, cognome, sesso, qualifica, email, ruolo, password } = r.dati;

    try {
      /* 2) La matricola esiste già nel database? */
      const [presenti] = await pool.query('SELECT id, codice_fiscale FROM dipendenti WHERE matricola = ? LIMIT 1', [matricola]);

      if (presenti.length) {
        if (duplicati === 'aggiorna') {
          /* v2.0: il Codice Fiscale è un'identità univoca NON aggiornabile
           * dall'import. Se il file riporta un CF diverso da quello a DB la
           * riga va in errore (richiede intervento dell'amministratore) e le
           * altre proseguono. */
          if (presenti[0].codice_fiscale !== codice_fiscale) {
            esito.errori.push({
              riga: r.numeroRiga,
              matricola,
              errore: `codice_fiscale non corrispondente: a database risulta ${presenti[0].codice_fiscale} (il CF non viene modificato dall'import)`,
            });
            continue;
          }
          /* AGGIORNA: solo i dati anagrafici (v1.4: incluse sesso e qualifica) —
           * la password, lo stato (attivo) e must_change_password restano invariati. */
          if (!dryRun) {
            await pool.query(
              'UPDATE dipendenti SET nome = ?, cognome = ?, email = ?, ruolo = ?, sesso = ?, qualifica = ? WHERE id = ?',
              [nome, cognome, email || null, ruolo, sesso, qualifica, presenti[0].id]
            );
            cartellaDipendente(codice_fiscale); // v2.0: cartella nominata col CF, idempotente
          }
          esito.aggiornati.push({ matricola });
        } else {
          esito.saltati.push({ matricola, motivo: 'matricola già esistente nel database' });
        }
        continue;
      }

      /* v2.0: il CF del nuovo utente deve essere libero (vincolo UNIQUE a DB:
       * qui un pre-controllo chiaro evita che la race arrivi come errore SQL). */
      const [cfPresenti] = await pool.query('SELECT id, matricola FROM dipendenti WHERE codice_fiscale = ? LIMIT 1', [codice_fiscale]);
      if (cfPresenti.length) {
        esito.errori.push({
          riga: r.numeroRiga,
          matricola,
          errore: `codice_fiscale già registrato per la matricola ${cfPresenti[0].matricola}`,
        });
        continue;
      }

      /* 3) Nuovo utente: password indicata nel file, oppure PREDEFINITA
       *    ('Benvenuto@2026', v1.4) se la colonna era vuota. La generazione
       *    casuale resta disponibile per la creazione singola dal pannello. */
      const passwordFinale = password || PASSWORD_PREDEFINITA_CSV;
      const predefinita = !password;

      if (dryRun) {
        esito.creati.push({ matricola, codice_fiscale, nome: `${cognome} ${nome}`, password: null, generata: false, predefinita });
        continue;
      }

      /* 4) Cartella del CODICE FISCALE PRIMA dell'INSERT (v2.0): se il disco
       *    fallisce la riga va in errore senza creare un utente "senza cartella". */
      try {
        cartellaDipendente(codice_fiscale);
      } catch (errFs) {
        esito.errori.push({ riga: r.numeroRiga, matricola, errore: 'impossibile creare la cartella sul server' });
        continue;
      }

      /* 5) Cifratura bcrypt e inserimento (v2.0: anagrafica completa col CF).
       *    Nasce con must_change_password=1: anche chi riceve la password
       *    predefinita dovrà sostituirla al primo accesso. */
      const hash = await bcrypt.hash(passwordFinale, BCRYPT_ROUNDS);
      await pool.query(
        `INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, sesso, qualifica, email, password_hash, ruolo, attivo, must_change_password)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1)`,
        [matricola, codice_fiscale, nome, cognome, sesso, qualifica, email || null, hash, ruolo]
      );
      esito.creati.push({ matricola, codice_fiscale, nome: `${cognome} ${nome}`, password: passwordFinale, generata: false, predefinita });
    } catch (err) {
      /* 6) ER_DUP_ENTRY = un'altra richiesta ha registrato la matricola nel
       *    frattempo (race): si tratta come duplicato; altri errori DB → report. */
      if (err && err.code === 'ER_DUP_ENTRY') {
        if (duplicati === 'aggiorna') esito.aggiornati.push({ matricola });
        else esito.saltati.push({ matricola, motivo: 'matricola già esistente (registrata durante l\u2019importazione)' });
      } else {
        console.error('[IMPORT] errore DB sulla riga', r.numeroRiga, err.message);
        esito.errori.push({ riga: r.numeroRiga, matricola, errore: 'errore del database durante il salvataggio' });
      }
    }
  }

  return esito;
}

module.exports = { parseCsv, analizzaCsv, eseguiImport, MAX_RIGHE_IMPORT, MAX_BYTE_FILE };

/**
 * ============================================================================
 *  utils/password.js — GENERAZIONE DI PASSWORD PROVVISORIE SICURE
 * ============================================================================
 *  Funzione estratta in modulo condiviso (v1.3): è usata sia dalla creazione
 *  singola di un dipendente (routes/admin.routes.js) sia dall'importazione
 *  massiva (utils/importazione.js) → comportamento garantito identico.
 *
 *  Formato: 10 caratteri = 8 lettere (senza caratteri ambigui O/0/I/l) + 2
 *  cifre, mescolati con Fisher-Yates. La generazione usa crypto.randomInt
 *  (CSPRNG): adatto a credenziali, a differenza di Math.random.
 * ============================================================================
 */
'use strict';

const crypto = require('crypto');

function generaPasswordProvvisoria() {
  const lettere = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz';
  const cifre = '0123456789';
  let chars = [];
  for (let i = 0; i < 8; i++) chars.push(lettere[crypto.randomInt(lettere.length)]);
  for (let i = 0; i < 2; i++) chars.push(cifre[crypto.randomInt(cifre.length)]);
  for (let i = chars.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join('');
}

module.exports = { generaPasswordProvvisoria };

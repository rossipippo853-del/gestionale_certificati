/**
 * ============================================================================
 *  utils/validazione.js — REGOLE DI VALIDAZIONE LATO SERVER
 * ============================================================================
 *  Principio: la validazione lato client (required/maxlength nei form) è solo
 *  ergonomica; la fonte di verità è SEMPRE questa, perché il server non può
 *  fidarsi di ciò che arriva dal browser (basta curl per aggirare l'HTML).
 *
 *  v1.4 — nuovi campi obbligatori:
 *    · DIPENDENTI  → sesso (M/F/ALTRO) e qualifica professionale
 *    · CERTIFICATI → numero_ore (intero ≥ 1), esame_finale (booleano),
 *                    area_tematica (una delle 6 aree ammesse)
 * ============================================================================
 */

/** Matricola: 3-20 caratteri alfanumerici (+ _ -). È anche il nome della
 *  cartella upload: il pattern esclude di fatto sequenze di path traversal. */
const RE_MATRICOLA = /^[A-Za-z0-9_-]{2,20}$/; // [v2.3.1] lunghezza minima 2 (richiesta utente)

/** Data ISO 'AAAA-MM-GG' (formato nativo di <input type="date">). */
const RE_DATA_ISO = /^\d{4}-\d{2}-\d{2}$/;

/** Email semplice: presenza di testo@testo.tld (verifica reale facoltativa). */
const RE_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/** v2.0 — Codice Fiscale italiano: 16 caratteri nel formato canonico
 *  (6 lettere, 2 cifre, lettera, 2 cifre, lettera, 3 cifre, lettera),
 *  es. RSSMRA80A01H501U. È anche il nome della cartella PDF del dipendente. */
const RE_CODICE_FISCALE = /^[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]$/;

/** Valori ammessi per il sesso (v1.4). */
const SESSI = ['M', 'F', 'ALTRO'];

/** [v2.2.9] Aree tematiche ammesse per i certificati — elenco chiuso a 18 voci. */
const AREE_TEMATICHE = [
  'Conoscenza dello specifico contesto lavorativo',
  'Gestione Economico-Finanziaria Enti Locali',
  'Innovazione Digitale e Transizione Digitale',
  'Lingue straniere',
  'Corsi obbligatori(Salute e sicurezza sul lavoro)',
  'Privacy,anticorruzione,antiriciclaggio,trasparenza',
  'Salvaguardia/Impatto ambientale',
  'Ambiente',
  'Risorse umane',
  'Codice appalti e e-procurement',
  'Servizi sociali',
  'Edilizia e urbanistica',
  'GDPR e trattamento dei dati personali',
  'Attività Produttive e Sviluppo Economico',
  'Polizia Locale e Sicurezza Urbana',
  'Affari Generali, Demografici e Statistica',
  'Procedimenti amministrativi', // [v2.2.9] richiesta Comune di Milazzo
  'Altro',
];

/** [v2.2.5] Aree STORICHE (v1.4 → v2.2.4): non più proposte nei form ma ancora
 *  ammesse in validazione e nei filtri, così i certificati già in archivio con
 *  la vecchia classificazione restano validi e filtrabili. */
const AREE_STORICHE = [
  'Competenze linguistiche',
  'Leadership e soft skills',
  'Principi e valori della PA',
  'Transizione digitale',
  'Transizione ecologica',
  'Transizione amministrativa',
];

/** Unione usata da validazione e filtri: nuove + storiche (23 voci). */
const AREE_AMMESSE = [...AREE_TEMATICHE, ...AREE_STORICHE];

/** Limiti del campo "numero ore" (v1.4). */
const ORE_MIN = 1;
const ORE_MAX = 9999;

/**
 * Normalizzatore di input: trim delle stringhe.
 * [FIX QA-B5] se il client invia parametri ripetuti (?q=a&q=b) Express
 * fornisce un ARRAY: si considera il primo valore.
 */
function pulisci(v) {
  if (Array.isArray(v)) v = v[0];
  return typeof v === 'string' ? v.trim() : '';
}

/**
 * Validazione dei campi del form di caricamento certificato (v1.4).
 * Input : req.body (nome_corso, ente_erogatore, data_conseguimento,
 *         numero_ore, esame_finale, area_tematica)
 * Output: { errori[], valori: {nomeCorso, ente, data, numeroOre, esameFinale, areaTematica} }
 *
 * Note: i campi multipart arrivano come STRINGHE → numero_ore viene
 * convertito con parseInt e deve essere un intero in [ORE_MIN, ORE_MAX];
 * esame_finale accetta '1'/'true'/'on' (spuntato) e qualunque altro valore
 * come non spuntato (il checkbox trasmette sempre un valore esplicito qui).
 */
function validaDatiCertificato(body) {
  const errori = [];
  const nomeCorso = pulisci(body.nome_corso);
  const ente = pulisci(body.ente_erogatore);
  const data = pulisci(body.data_conseguimento);
  const areaTematica = pulisci(body.area_tematica);

  /* [v2.2] DURATA Ore:Minuti. "numero_ore" (ore intere, 0 ammesso SOLO se
   * i minuti sono ≥ 1) + "numero_minuti" (0-59, facoltativo). La durata
   * complessiva deve restare ≥ 1 minuto: corsi anche brevissimi (45')
   * restano registrabili, "0 ore e 0 minuti" no.
   * [AUDIT v2.2-b F4] i client JSON possono inviare NUMERI veri (multipart
   * manda sempre stringhe): vengono accettati e convertiti; booleans,
   * array e oggetti restano rifiutati. */
  const comeTesto = (v) => (typeof v === 'number' && Number.isFinite(v) ? String(v) : pulisci(v));
  const oreRaw = comeTesto(body.numero_ore);
  const numeroOre = /^\d+$/.test(oreRaw) ? Number.parseInt(oreRaw, 10) : NaN;
  const minutiRaw = comeTesto(body.numero_minuti);
  const numeroMinuti = minutiRaw === '' ? 0 : (/^\d+$/.test(minutiRaw) ? Number.parseInt(minutiRaw, 10) : NaN);
  if (!Number.isInteger(numeroOre) || numeroOre < 0 || numeroOre > ORE_MAX) {
    errori.push(`Le ore devono essere un numero intero tra 0 e ${ORE_MAX}.`);
  }
  if (!Number.isInteger(numeroMinuti) || numeroMinuti < 0 || numeroMinuti > 59) {
    errori.push('I minuti devono essere un numero intero tra 0 e 59.');
  }
  if (!errori.some((e) => /ore|minuti/i.test(e)) && numeroOre * 60 + numeroMinuti < 1) {
    errori.push('La durata del corso deve essere di almeno 1 minuto (ore oppure minuti).');
  }

  /* Esame finale: campo booleano (checkbox). */
  const esameFinale = ['1', 'true', 'on', 'si', 'sì'].includes(String(body.esame_finale || '').toLowerCase()) ? 1 : 0;

  /* [v2.2.5] Area tematica: una delle 17 aree nuove (o storica, per l'archivio). */
  if (!AREE_AMMESSE.includes(areaTematica)) {
    errori.push('Seleziona un\u2019area tematica valida dall\u2019elenco.');
  }

  if (nomeCorso.length < 3 || nomeCorso.length > 200) {
    errori.push('Il nome del corso deve essere lungo da 3 a 200 caratteri.');
  }
  if (ente.length < 2 || ente.length > 150) {
    errori.push('L\'ente erogatore deve essere lungo da 2 a 150 caratteri.');
  }
  if (!RE_DATA_ISO.test(data) || Number.isNaN(Date.parse(data))) {
    errori.push('La data di conseguimento non è valida.');
  } else {
    /* [AUDIT F3] Verifica del CALENDARIO REALE: il parser permissivo di JS
     * accetta '2026-02-30' arrotolandola al 2 marzo (e MySQL la rifiuterebbe).
     * Ricostruiamo la data per componenti: se non coincide con l'input, la
     * data non esiste nel calendario → rifiuto esplicito. */
    const [anno, mese, giorno] = data.split('-').map(Number);
    const reale = new Date(anno, mese - 1, giorno);
    if (reale.getFullYear() !== anno || reale.getMonth() !== mese - 1 || reale.getDate() !== giorno) {
      errori.push('La data di conseguimento non è valida.');
    } else {
      const oggi = new Date();
      oggi.setHours(23, 59, 59, 999); // tollera "oggi" fino a fine giornata
      if (new Date(`${data}T00:00:00`) > oggi) {
        errori.push('La data di conseguimento non può essere nel futuro.');
      }
    }
  }

  return { errori, valori: { nomeCorso, ente, data, numeroOre, numeroMinuti: Number.isInteger(numeroMinuti) ? numeroMinuti : 0, esameFinale, areaTematica } };
}

/**
 * Policy password: min 8 e max 72 caratteri (72 = limite operativo di bcrypt),
 * almeno una lettera e almeno un numero. Restituisce null se valida,
 * altrimenti il messaggio d'errore da mostrare.
 */
function validaNuovaPassword(p) {
  if (typeof p !== 'string' || p.length < 8 || p.length > 72) {
    return 'La nuova password deve essere lunga almeno 8 caratteri (max 72).';
  }
  if (!/[A-Za-z]/.test(p) || !/\d/.test(p)) {
    return 'La nuova password deve contenere almeno una lettera e almeno un numero.';
  }
  return null;
}

/**
 * Validazione anagrafica di un dipendente (creazione singola e import CSV).
 * v1.4: sesso e qualifica professionale sono OBBLIGATORI.
 * Output: { errori, valori } normalizzati (sesso in maiuscolo).
 */
function validaDatiDipendente(body) {
  const errori = [];
  const valori = {
    matricola: pulisci(body.matricola),
    codiceFiscale: pulisci(body.codice_fiscale).toUpperCase(), // v2.0: sempre maiuscolo
    nome: pulisci(body.nome),
    cognome: pulisci(body.cognome),
    sesso: pulisci(body.sesso).toUpperCase(),
    qualifica: pulisci(body.qualifica),
    email: pulisci(body.email),
    ruolo: pulisci(body.ruolo) || 'DIPENDENTE',
  };

  if (!RE_MATRICOLA.test(valori.matricola)) errori.push('Matricola non valida (2-20 caratteri alfanumerici).');
  if (!RE_CODICE_FISCALE.test(valori.codiceFiscale)) errori.push('Codice Fiscale non valido: inserire 16 caratteri nel formato italiano (es. RSSMRA80A01H501U).');
  if (valori.nome.length < 2 || valori.nome.length > 100) errori.push('Nome non valido (2-100 caratteri).');
  if (valori.cognome.length < 2 || valori.cognome.length > 100) errori.push('Cognome non valido (2-100 caratteri).');
  if (!SESSI.includes(valori.sesso)) errori.push('Sesso non valido: usare M, F o ALTRO.');
  if (valori.qualifica.length < 2 || valori.qualifica.length > 120) errori.push('Qualifica professionale non valida (2-120 caratteri).');
  if (valori.email && (valori.email.length > 150 || !RE_EMAIL.test(valori.email))) errori.push('Email non valida.');
  if (!['DIPENDENTE', 'AMMINISTRATORE'].includes(valori.ruolo)) errori.push('Ruolo non valido.');

  return { errori, valori };
}

module.exports = {
  pulisci,
  validaDatiCertificato,
  validaNuovaPassword,
  validaDatiDipendente,
  RE_MATRICOLA,
  RE_CODICE_FISCALE,
  RE_EMAIL,
  SESSI,
  AREE_TEMATICHE,
  AREE_STORICHE,
  AREE_AMMESSE,
  ORE_MIN,
  ORE_MAX,
};

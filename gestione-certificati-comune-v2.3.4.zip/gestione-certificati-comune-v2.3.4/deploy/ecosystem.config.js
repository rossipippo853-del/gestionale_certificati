/**
 * deploy/ecosystem.config.js — Avvio con PM2 (Linux e Windows).
 *
 * Uso:
 *   pm2 start deploy/ecosystem.config.js     # avvio
 *   pm2 save && pm2 startup                  # Linux: riparto automatico al boot
 *   pm2 save && pm2-startup install          # Windows (pm2-windows-startup)
 *   pm2 logs certificati                     # log in tempo reale
 *   pm2 restart certificati                  # riavvio (es. dopo modifica .env)
 *
 * Il parametro HOST=0.0.0.0 è già il default dell'app (vedi src/config.js):
 * le variabili qui sotto fanno da ridondanza esplicita per l'operatore.
 */
module.exports = {
  apps: [
    {
      name: 'certificati',
      script: 'server.js',
      cwd: __dirname + '/..',
      instances: 1,               // una sola istanza: le sessioni (jti) vivono in memoria
      exec_mode: 'fork',
      watch: false,               // niente riavvii a caldo su modifica file in produzione
      autorestart: true,
      max_restarts: 20,
      restart_delay: 5000,        // 5 s tra un tentativo e l'altro
      env: {
        NODE_ENV: 'production',
        HOST: '0.0.0.0',          // ascolto su tutte le schede (intranet, IP fisso)
        PORT: 3000,
      },
      out_file: './logs/pm2-out.log',
      error_file: './logs/pm2-err.log',
      merge_logs: true,
      time: true,
    },
  ],
};

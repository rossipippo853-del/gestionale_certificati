# Redirect Vercel — «insegna al neon» verso il portale interno

Istruzioni complete in `docs/COME-ACCEDERE-SENZA-DNS-v2.2.9.md` (Opzione B).

## Prima di pubblicare

Sostituisci `192.168.1.50` con l'IP REALE del PC server in **entrambi** i file:

- `vercel.json` → campo `"destination"`
- `index.html` → `url=…` del meta refresh e `href` del link

## Pubblicazione (2 modi)

**Con il terminale** (una volta sola):

```bash
npm install -g vercel
vercel login            # account gratuito (email)
vercel --prod           # lanciato da QUESTA cartella
```

Alla domanda «project name» rispondere es. `portale-milazzo` → il nome
pubblico per i dipendenti diventa: **https://portale-milazzo.vercel.app**

**Senza terminale**: vercel.com → login → «Add New…» → Project → trascinare
questa cartella → Deploy.

## Verifica

Da un PC dipendente: apri `https://portale-milazzo.vercel.app` → dopo un
istanto deve apparire la pagina di login del portale. Se il proxy aziendale
blocca `vercel.app` (raro ma possibile), l'opzione non è praticabile: resta
l'Opzione A (link/segnalibio/QR).

## Nota

Su Vercel non transita alcun dato: la pagina contiene solo l'istruzione
«vai a http://IP-DEL-SERVER». Il portale e tutti i certificati restano sul
PC server interno.

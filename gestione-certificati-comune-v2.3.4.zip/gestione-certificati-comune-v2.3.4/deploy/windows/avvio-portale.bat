@echo off
REM ============================================================
REM  Avvio del Portale Formazione e Certificati (app Node.js)
REM  Usato dall'attivita pianificata "Portale - App" (ONSTART).
REM  Adattare il percorso se il progetto non e' in C:\certificati-comune
REM ============================================================
cd /d C:\certificati-comune
node server.js

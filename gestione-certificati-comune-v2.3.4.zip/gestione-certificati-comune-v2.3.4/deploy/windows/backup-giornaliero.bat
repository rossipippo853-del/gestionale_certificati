@echo off
REM ============================================================
REM  Backup giornaliero del Portale: database + allegati
REM  Usato dall'attivita pianificata "Portale - Backup" (DAILY 20:30).
REM
REM  PREPARAZIONE (una volta sola):
REM   1) crea il file C:\certificati-comune\deploy\windows\backup.cnf
REM      con DUE righe:
REM        [client]
REM        password="PASSWORD-ROOT-MARIADB"
REM      (cosi la password non compare in questo script)
REM   2) verifica il percorso di mysqldump.exe (dipende dalla versione)
REM  I backup piu vecchi di 30 giorni vengono eliminati automaticamente.
REM ============================================================
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd"') do set DATA=%%i
set DEST=C:\Backup\Portale\%DATA%
mkdir "%DEST%" 2>nul

"C:\Program Files\MariaDB 11.8\bin\mysqldump.exe" --defaults-extra-file=C:\certificati-comune\deploy\windows\backup.cnf certificati_comune > "%DEST%\database.sql"

robocopy "C:\certificati-comune\uploads" "%DEST%\uploads" /E /NFL /NDL /NJH /NJS

REM pulizia: conserva gli ultimi 30 giorni
forfiles /p C:\Backup\Portale /d -30 /c "cmd /c if exist @path rmdir /s /q @path" 2>nul

echo Backup completato in %DEST%

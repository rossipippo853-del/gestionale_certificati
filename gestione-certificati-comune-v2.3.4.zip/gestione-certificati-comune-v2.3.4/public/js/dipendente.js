/**
 * dipendente.js — logica dell'area dipendente:
 * statistiche, upload certificato, elenco, cambio password.
 *
 * [MODIFICA v1.5] Onboarding senza blocchi: chi ha ancora la password
 * provvisoria assegnata dall'admin PUÒ caricare i certificati normalmente.
 * Il ricordo di cambiare la password è un AVVISO NON BLOCCANTE (banner in
 * alto, mostrato quando utente.mustChangePassword = true), che scompare
 * appena la password viene sostituita.
 */
'use strict';

let utente = null;
let certificati = [];
let ultimoCaricamento = null; // [v2.2] ultima risposta API (oreTotali per profilo/badge)
let impaginazione = { pagina: 1, perPagina: 10 }; // [v2.3.5] righe per pagina (server-side)

document.addEventListener('DOMContentLoaded', init);

/**
 * Inizializzazione della pagina (DOMContentLoaded):
 *  1. proteggiPagina('DIPENDENTE') → 404 logico: un admin viene reindirizzato
 *     a /admin, un anonimo al login;
 *  2. decorazione di topbar/profilo con i dati dell'utente;
 *  3. banner password provvisoria se richiesto;
 *  4. caricamento certificati + binding dei form (upload e cambio password).
 */
async function init() {
  utente = await proteggiPagina('DIPENDENTE');
  if (!utente) return;

  document.getElementById('nome-utente').textContent = `${utente.cognome} ${utente.nome}`;
  document.getElementById('matricola-utente').textContent = `Matricola ${utente.matricola}`;

  document.getElementById('pr-matricola').textContent = utente.matricola;
  document.getElementById('pr-codice-fiscale').textContent = utente.codiceFiscale || '—'; // v2.0
  document.getElementById('pr-nome').textContent = `${utente.cognome} ${utente.nome}`;
  document.getElementById('pr-sesso').textContent = { M: 'Maschile (M)', F: 'Femminile (F)', ALTRO: 'Altro' }[utente.sesso] || utente.sesso;
  document.getElementById('pr-qualifica').textContent = utente.qualifica || '—';
  document.getElementById('pr-email').textContent = utente.email || '—';
  document.getElementById('pr-ruolo').innerHTML =
    utente.ruolo === 'AMMINISTRATORE'
      ? '<span class="badge blu">AMMINISTRATORE</span>'
      : '<span class="badge grigio">DIPENDENTE</span>';

  /* [v2.3.11] card «Siti di formazione» nella scheda Profilo */
  renderSitiFormazione('siti-formazione');

  /* [v1.5] Avviso NON bloccante: solo informativo, la navigazione e
   * l'upload restano pienamente disponibili. */
  if (utente.mustChangePassword) {
    document.getElementById('banner-password').classList.remove('nascosto');
  }

  await caricaCertificati();

  /* ------------ upload certificato ------------ */
  const input = document.getElementById('up-file');
  const hint = document.getElementById('file-hint');

  input.addEventListener('change', () => {
    const files = Array.from(input.files || []);
    if (!files.length) { hint.textContent = 'PDF, JPG o PNG · max 5 MB ciascuno · fino a 5 file.'; return; }
    const ammesse = ['.pdf', '.jpg', '.jpeg', '.png'];
    const sbagliato = files.find((f) => !ammesse.some((est) => f.name.toLowerCase().endsWith(est)));
    if (sbagliato) {
      hint.textContent = `⚠️ «${sbagliato.name}»: formato non ammesso (solo PDF, JPG o PNG).`;
      return;
    }
    const grande = files.find((f) => f.size > 5 * 1024 * 1024);
    if (grande) {
      hint.textContent = `⚠️ «${grande.name}» troppo grande (${dimensioneUmana(grande.size)}): il limite è 5 MB per file.`;
      return;
    }
    if (files.length > 5) { hint.textContent = '⚠️ Massimo 5 file per un solo corso.'; return; }
    hint.textContent = files.length === 1
      ? `✅ ${files[0].name} (${dimensioneUmana(files[0].size)}) pronto per il caricamento.`
      : `✅ ${files.length} documenti pronti per il caricamento.`;
  });

  document.getElementById('form-upload').addEventListener('submit', carica);

  /* ------------ cambio password ------------ */
  document.getElementById('form-password').addEventListener('submit', cambiaPassword);

  /* [v2.3.5] impaginazione elenco certificati: righe per pagina (server-side) */
  document.getElementById('dp-perPagina').addEventListener('change', () => {
    impaginazione.perPagina = Number.parseInt(document.getElementById('dp-perPagina').value, 10) || 10;
    impaginazione.pagina = 1;
    caricaCertificati();
  });
}

/* ---------------------------------------------------------- */

/** GET /api/certificati → salva l'elenco (PAGINA corrente, v2.3.5) in memoria
 *  e ridisegna stats+tabella. oreTotali e conteggi restano globali (server). */
async function caricaCertificati() {
  try {
    const dati = await api(`/api/certificati?${costruisciQuery({ pagina: impaginazione.pagina, perPagina: impaginazione.perPagina })}`);
    let infoPager;

    if (Number.isFinite(dati.pagineTotali)) {
      /* [v2.3.5] backend AGGIORNATO: la pagina è già tagliata dal server. */
      if (impaginazione.pagina > dati.pagineTotali) {
        impaginazione.pagina = dati.pagineTotali;
        return caricaCertificati();
      }
      certificati = dati.certificati || []; // solo la pagina corrente (tabella)
      ultimoCaricamento = dati;   // [v2.2] oreTotali + [v2.3.5] conteggi globali
      infoPager = dati;
    } else {
      /* [v2.3.10] backend NON aggiornato (risposta senza metadati = ELENCO
       * COMPLETO): impaginazione LOCALE di compatibilità — la lista viene
       * tagliata nel browser e le frecce del pager restano operative.
       * Le statistiche restano corrette: i conteggi sono calcolati sulla
       * lista completa, non sulla pagina visibile. */
      const listaCompleta = dati.certificati || [];
      const pagineTotali = Math.max(1, Math.ceil(listaCompleta.length / impaginazione.perPagina));
      if (impaginazione.pagina > pagineTotali) impaginazione.pagina = pagineTotali;
      const inizio = (impaginazione.pagina - 1) * impaginazione.perPagina;
      certificati = listaCompleta.slice(inizio, inizio + impaginazione.perPagina);
      ultimoCaricamento = { ...dati, conteggi: conteggiDaLista(listaCompleta) };
      infoPager = { pagina: impaginazione.pagina, pagineTotali, totale: listaCompleta.length };
    }

    renderStatistiche();
    renderTabella();
    renderPaginazione('paginazione-miei', infoPager, (p) => { impaginazione.pagina = p; caricaCertificati(); });
  } catch (err) {
    toast(`Impossibile caricare i certificati: ${err.message}`, 'errore');
  }

}

/** [v2.3.10] Conteggi per stato calcolati nel browser — usati SOLO nel
 *  fallback con backend vecchio (quello aggiornato fornisce già «conteggi»). */
function conteggiDaLista(lista) {
  const c = { TOTALE: lista.length, APPROVATO: 0, IN_ATTESA: 0, RIFIUTATO: 0 };
  for (const x of lista) if (c[x.stato] !== undefined) c[x.stato] += 1;
  return c;
}

/** Contatori della dashboard (totale/approvati/attesa/rifiutati).
 *  [v2.3.5] i numeri sono GLOBALI (tutti i corsi del dipendente, non solo
 *  la pagina mostrata): arrivano dal server nel campo «conteggi»; se assente
 *  (risposta storica) si ricade sul conteggio locale dell'elenco ricevuto. */
function renderStatistiche() {
  const c = ultimoCaricamento && ultimoCaricamento.conteggi;
  const conta = (s) => certificati.filter((x) => x.stato === s).length;
  document.getElementById('stat-totale').textContent = c ? c.TOTALE : certificati.length;
  document.getElementById('stat-approvati').textContent = c ? c.APPROVATO : conta('APPROVATO');
  document.getElementById('stat-attesa').textContent = c ? c.IN_ATTESA : conta('IN_ATTESA');
  document.getElementById('stat-rifiutati').textContent = c ? c.RIFIUTATO : conta('RIFIUTATO');

  /* [v2.2] Ore formative totali (certificati APPROVATI) + spunta blu ≥ 40 ore. */
  const totale = ultimoCaricamento && ultimoCaricamento.oreTotali;
  if (totale) {
    const etichetta = totale.minuti > 0 && totale.minuti % 60 !== 0
      ? `${totale.ore}h ${totale.restoMinuti}m`
      : `${totale.ore}h`;
    document.getElementById('pr-ore').textContent = etichetta;
    document.getElementById('pr-badge').classList.toggle('nascosto', !totale.badge);
  }
}

/** Costruzione righe della tabella con escapeHtml() su OGNI valore proveniente
 *  dal database (mitigazione XSS difesa-in-profondità, oltre alla CSP). */
function renderTabella() {
  const tbody = document.querySelector('#tabella-certificati tbody');
  tbody.innerHTML = '';

  if (!certificati.length) {
    tbody.innerHTML = '<tr><td colspan="10" class="vuoto">Nessun certificato caricato: usa il form qui sopra.</td></tr>';
    return;
  }

  for (const c of certificati) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><div class="cella-principale">${escapeHtml(c.nome_corso)}</div>
          <div class="cella-secondaria">Caricato il ${dataOraIt(c.caricato_il)}</div></td>
      <td>${escapeHtml(c.ente_erogatore)}</td>
      <td>${dataIt(c.data_conseguimento)}</td>
      <td>${formattaDurata(c.numero_ore, c.numero_minuti)}</td>
      <td>${c.esame_finale ? '<span class="badge verde">Sì</span>' : '<span class="badge grigio">No</span>'}</td>
      <td>${escapeHtml(c.area_tematica)}</td>
      <!-- [v2.2.4] colonna FILE: pulsante «Scarica» per ogni allegato (numerato
           se più di uno; il nome completo resta nel suggerimento). Per i corsi
           con file unico restano nome+dimensione: il download è già nei pulsanti
           «Visualizza / Scarica» della colonna Azioni. -->
      <td>
        ${(c.allegati && c.allegati.length)
          ? `<div class="cello-allegati">${c.allegati.map((a, i) => `<a class="btn piccolo secondario btn-scarica" href="/api/certificati/allegati/${a.id}/file"
              title="Scarica ${escapeHtml(a.nome)}">${iconaTipo(a.tipo)} Scarica${c.allegati.length > 1 ? ' ' + (i + 1) : ''}</a>`).join('')}</div>`
          : `<div>${escapeHtml(c.nome_file_originale)}</div>
             <div class="cella-secondaria">${dimensioneUmana(c.dimensione_file)}</div>`}
      </td>
      <td>${badgeStato(c.stato)}</td>
      <td>${c.note_admin ? escapeHtml(c.note_admin) : '—'}</td>
      <td class="azioni-cell">
        <div class="azioni">
          <!-- [v2.3.0] azioni compatte a icona con tooltip: la colonna occupa
               pochissimo e la tabella resta interamente visibile senza scroll. -->
          <a class="btn piccolo secondario btn-icona" target="_blank" rel="noopener"
             title="Visualizza il documento" aria-label="Visualizza il documento"
             href="/api/certificati/${c.id}/file?modo=visualizza">👁</a>
          <a class="btn piccolo secondario btn-icona" title="⬇ Scarica il documento"
             aria-label="Scarica il documento" href="/api/certificati/${c.id}/file">⬇</a>
        </div>
      </td>`;
    tbody.appendChild(tr);
  }
}

/** Submit del form di upload:
 *  1. pre-controlli client (file presente, .pdf, ≤ 5 MB) per feedback immediato;
 *  2. FormData con i campi del corso + il file → POST /api/certificati;
 *  3. [v1.5] NESSUN blocco per la password provvisoria: qualunque errore del
 *     server viene mostrato inline, senza interferire con l'onboarding. */
async function carica(e) {
  e.preventDefault();
  const erroreEl = document.getElementById('upload-errore');
  const bottone = document.getElementById('btn-upload');
  erroreEl.classList.add('nascosto');

  /* [v2.2] da 1 a 5 documenti per lo stesso corso (PDF, JPG o PNG). */
  const files = Array.from(document.getElementById('up-file').files || []);
  if (!files.length) { mostraErroreUpload('Seleziona almeno un documento del certificato.'); return; }
  if (files.length > 5) { mostraErroreUpload('Massimo 5 file per un solo corso.'); return; }
  const ammesse = ['.pdf', '.jpg', '.jpeg', '.png'];
  for (const f of files) {
    if (!ammesse.some((est) => f.name.toLowerCase().endsWith(est))) {
      mostraErroreUpload(`«${f.name}»: formato non ammesso (solo PDF, JPG o PNG).`);
      return;
    }
    if (f.size > 5 * 1024 * 1024) { mostraErroreUpload(`«${f.name}» supera il limite di 5 MB.`); return; }
  }

  /* [v2.2.2] durata in un'unica cella hh:mm (parser condiviso in common.js). */
  const durata = parserDurata(document.getElementById('up-durata').value);
  if (!durata) {
    mostraErroreUpload('Durata non valida: usa il formato ore:minuti (es. 8:30, 0:45 oppure 8).');
    return;
  }
  const ore = durata.ore;
  const minuti = durata.minuti;

  const formData = new FormData();
  formData.append('nome_corso', document.getElementById('up-corso').value.trim());
  formData.append('ente_erogatore', document.getElementById('up-ente').value.trim());
  formData.append('data_conseguimento', document.getElementById('up-data').value);
  formData.append('numero_ore', String(ore));
  formData.append('numero_minuti', String(minuti));
  formData.append('esame_finale', document.getElementById('up-esame').value); // [v2.2.2] tendina Sì/No
  formData.append('area_tematica', document.getElementById('up-area').value);
  for (const f of files) formData.append('file', f);

  bottone.disabled = true;
  bottone.textContent = 'Caricamento…';
  try {
    const dati = await api('/api/certificati', { method: 'POST', formData });
    toast(dati.messaggio || 'Certificato caricato.', 'successo');
    document.getElementById('form-upload').reset();
    document.getElementById('file-hint').textContent = 'PDF, JPG o PNG · max 5 MB ciascuno · puoi selezionare più file insieme (anche scan + attestato).';
    await caricaCertificati();
  } catch (err) {
    /* [v1.5] Niente più caso PASSWORD_TEMPORANEA: l'upload non è mai bloccato.
     * Il banner informativo in alto (già visibile con la provvisoria) NON viene
     * usato per segnalare errori: qui si mostra solo il messaggio del server. */
    mostraErroreUpload(err.message);
  } finally {
    bottone.disabled = false;
    bottone.textContent = '💾 Salva'; // [v2.2.9] testo del pulsante rinominato
  }
}

/** Mostra l'errore del form upload nell'apposito alert inline. */
function mostraErroreUpload(msg) {
  const erroreEl = document.getElementById('upload-errore');
  erroreEl.textContent = msg;
  erroreEl.classList.remove('nascosto');
}

/** Submit cambio password: verifica preliminare che nuova == conferma,
 *  poi PUT /api/auth/password {passwordAttuale, nuovaPassword}. Al successo
 *  nasconde il banner della password provvisoria. */
async function cambiaPassword(e) {
  e.preventDefault();
  const erroreEl = document.getElementById('pw-errore');
  erroreEl.classList.add('nascosto');

  const attuale = document.getElementById('pw-attuale').value;
  const nuova = document.getElementById('pw-nuova').value;
  const conferma = document.getElementById('pw-conferma').value;

  if (nuova !== conferma) {
    erroreEl.textContent = 'La nuova password e la conferma non coincidono.';
    erroreEl.classList.remove('nascosto');
    return;
  }

  const bottone = document.getElementById('btn-password');
  bottone.disabled = true;
  try {
    const dati = await api('/api/auth/password', {
      method: 'PUT',
      body: { passwordAttuale: attuale, nuovaPassword: nuova },
    });
    toast(dati.messaggio || 'Password aggiornata.', 'successo');
    document.getElementById('form-password').reset();
    document.getElementById('banner-password').classList.add('nascosto');
  } catch (err) {
    erroreEl.textContent = err.message;
    erroreEl.classList.remove('nascosto');
  } finally {
    bottone.disabled = false;
  }
}

/**
 * common.js — utilità condivise dalle pagine frontend.
 * Nessuna dipendenza esterna (funziona offline / intranet).
 *
 * v1.1 — BUGFIX:
 *  [FIX #1] api(): il redirect su 401 non viene più eseguito quando ci si trova
 *           sulla pagina di login (era la causa del loop di ricaricamento infinito:
 *           /api/auth/me rispondeva 401 → location.href='/' → reload → 401 → …).
 *  [FIX #2] conferma(): i bottoni del dialog sono stati spostati dentro un
 *           <form method="dialog">. Prima si trovavano in un semplice <div>:
 *           senza un form owner il click NON chiudeva il dialog né impostava
 *           returnValue, quindi la Promise non si risolveva mai e l'interfaccia
 *           restava bloccata sul modale (abilita/disabilita utente, eliminazioni).
 */

'use strict';

/* -------------------- client API -------------------- */

/**
 * Wrapper di fetch: JSON automatico, gestione 401 (redirect al login),
 * errori già pronti per toast/alert.
 */
/* ---------- [v2.3.1] Sessione di SCHEDA (sessionStorage) ----------
 * Il JWT vive in sessionStorage: chiuse la scheda o il browser SPARISCE e
 * l'utente deve rifare il login. Viaggiava già solo in un cookie di sessione
 * (senza scadenza, v2.2.9) — ma il cookie sopravvive alla chiusura della
 * sola scheda e al «ripristino sessione» di alcuni browser: con il token in
 * sessionStorage la riapertura richiede SEMPRE le credenziali. Il cookie
 * httpOnly resta per i download diretti (export CSV, file). */
const CHIAVE_TOKEN = 'token_portale';

function salvaToken(t) { try { sessionStorage.setItem(CHIAVE_TOKEN, t); } catch { /* modalità privata */ } }
function leggiToken() { try { return sessionStorage.getItem(CHIAVE_TOKEN); } catch { return null; } }
function rimuoviToken() { try { sessionStorage.removeItem(CHIAVE_TOKEN); } catch { /* noop */ } }

async function api(url, { method = 'GET', body = null, formData = null } = {}) {
  const opzioni = { method, credentials: 'same-origin', headers: {} };
  /* [v2.3.1] se c'è un token di scheda lo si invia nell'header (il middleware
   * lo preferisce al cookie): nuovo login = nuova scheda = nuovo token. */
  const t = leggiToken();
  if (t) opzioni.headers['Authorization'] = `Bearer ${t}`;
  if (body !== null) {
    opzioni.headers['Content-Type'] = 'application/json';
    opzioni.body = JSON.stringify(body);
  }
  if (formData !== null) opzioni.body = formData;

  const risposta = await fetch(url, opzioni);

  // [FIX #1] Su 401 reindirizziamo al login SOLO se non siamo già nella pagina
  // pubblica di login ("/"). In quel caso l'errore va lasciato gestire al
  // chiamante (es. il controllo "hai già una sessione?" di index.html),
  // altrimenti si genera un loop di ricaricamento infinito.
  const sullaPaginaLogin = location.pathname === '/' || location.pathname.endsWith('/index.html');
  if (risposta.status === 401 && !url.includes('/auth/login') && !sullaPaginaLogin) {
    location.href = '/';
    throw new Error('Sessione scaduta.');
  }

  const dati = await risposta.json().catch(() => ({}));
  if (!risposta.ok) {
    // [QA] l'errore porta con sé stato HTTP ed eventuale codice applicativo
    // (es. PASSWORD_TEMPORANEA) così le pagine possono reagire di conseguenza.
    const err = new Error(dati.errore || `Errore ${risposta.status}`);
    err.status = risposta.status;
    err.codice = dati.codice;
    throw err;
  }
  return dati;
}

/** Verifica la sessione e il ruolo richiesto; reindirizza se non conforme. */
async function proteggiPagina(ruoloAtteso) {
  try {
    const { utente } = await api('/api/auth/me');
    if (ruoloAtteso && utente.ruolo !== ruoloAtteso) {
      location.href = utente.ruolo === 'AMMINISTRATORE' ? '/admin' : '/dipendente';
      return null;
    }
    return utente;
  } catch {
    return null; // api() reindirizza già al login in caso di 401 (fuori dal login)
  }
}

function esci() {
  rimuoviToken(); // [v2.3.1] la sessione di scheda muore subito, oltre al logout server
  api('/api/auth/logout', { method: 'POST' }).finally(() => { location.href = '/'; });
}

/* -------------------- formattazione -------------------- */

function escapeHtml(s) {
  return String(s ?? '')
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}

/** 'YYYY-MM-DD' → 'GG/MM/AAAA' (senza passare da Date: niente problemi di fuso). */
function dataIt(iso) {
  if (!iso) return '';
  const parti = String(iso).slice(0, 10).split('-');
  return parti.length === 3 ? `${parti[2]}/${parti[1]}/${parti[0]}` : String(iso);
}

/** 'YYYY-MM-DD HH:MM:SS' → 'GG/MM/AAAA HH:MM' */
function dataOraIt(dt) {
  if (!dt) return '';
  const [data, ora] = String(dt).split(' ');
  return ora ? `${dataIt(data)} ${ora.slice(0, 5)}` : dataIt(data);
}

function dimensioneUmana(byte) {
  if (byte == null) return '';
  if (byte < 1024) return `${byte} B`;
  if (byte < 1024 * 1024) return `${(byte / 1024).toFixed(0)} KB`;
  return `${(byte / 1024 / 1024).toFixed(1)} MB`;
}

const BADGE_STATO = {
  APPROVATO: '<span class="badge verde">✔ Approvato</span>',
  IN_ATTESA: '<span class="badge ambra">⏳ In attesa</span>',
  RIFIUTATO: '<span class="badge rosso">✖ Rifiutato</span>',
};
function badgeStato(stato) {
  return BADGE_STATO[stato] || `<span class="badge grigio">${escapeHtml(stato)}</span>`;
}

/* -------------------- UI: toast, dialog, paginazione -------------------- */

function toast(messaggio, tipo = 'info') {
  let box = document.getElementById('toast-box');
  if (!box) {
    box = document.createElement('div');
    box.id = 'toast-box';
    document.body.appendChild(box);
  }
  const t = document.createElement('div');
  t.className = `toast ${tipo}`;
  t.textContent = messaggio;
  box.appendChild(t);
  requestAnimationFrame(() => t.classList.add('visibile'));
  setTimeout(() => {
    t.classList.remove('visibile');
    setTimeout(() => t.remove(), 300);
  }, 4200);
}

/**
 * Finestra di conferma riutilizzabile (elemento <dialog id="dlg-conferma">).
 * Restituisce una Promise<boolean>.
 *
 * [FIX #2] I bottoni stanno dentro <form method="dialog">: la submission del
 * form chiude il dialog e imposta returnValue al value del bottone premuto
 * ("si"/"no"). Prima, bottoni in un semplice <div> non chiudevano il dialog:
 * la Promise restava sospesa e l'UI appariva bloccata sul modale.
 * Prima di ogni apertura azzeriamo returnValue per distinguere anche la
 * chiusura con il tasto ESC (→ false, mai un "si" residuo della volta prima).
 */
function conferma(testo, { titolo = 'Conferma', etichetta = 'Conferma', pericoloso = true } = {}) {
  return new Promise((risolvi) => {
    let dlg = document.getElementById('dlg-conferma');
    if (!dlg) {
      dlg = document.createElement('dialog');
      dlg.id = 'dlg-conferma';
      dlg.innerHTML = `
        <h3 id="conf-titolo"></h3>
        <p id="conf-testo"></p>
        <form method="dialog" class="azioni">
          <button class="btn secondario" value="no">Annulla</button>
          <button class="btn pericolo" id="conf-btn" value="si"></button>
        </form>`;
      document.body.appendChild(dlg);
    }
    const btnSi = dlg.querySelector('#conf-btn');
    dlg.querySelector('#conf-titolo').textContent = titolo;
    dlg.querySelector('#conf-testo').textContent = testo;
    btnSi.textContent = etichetta;
    btnSi.className = `btn ${pericoloso ? 'pericolo' : 'primario'}`;

    dlg.returnValue = ''; // reset: ESC/Annulla devono risolvere sempre a false
    dlg.onclose = () => risolvi(dlg.returnValue === 'si');
    dlg.showModal();
  });
}

/** Render della paginazione (Precedente / Pagina X di Y / Successiva). */
function renderPaginazione(contenitore, info, onCambia) {
  const el = typeof contenitore === 'string' ? document.getElementById(contenitore) : contenitore;
  if (!el) return;
  if (info.pagineTotali <= 1) { el.innerHTML = ''; return; }
  el.innerHTML = '';
  el.className = 'paginazione';

  const btnPrev = document.createElement('button');
  btnPrev.className = 'btn piccolo secondario';
  btnPrev.textContent = '← Precedente';
  btnPrev.disabled = info.pagina <= 1;
  btnPrev.onclick = () => onCambia(info.pagina - 1);

  const testo = document.createElement('span');
  testo.textContent = `Pagina ${info.pagina} di ${info.pagineTotali} — ${info.totale} risultati`;

  const btnNext = document.createElement('button');
  btnNext.className = 'btn piccolo secondario';
  btnNext.textContent = 'Successiva →';
  btnNext.disabled = info.pagina >= info.pagineTotali;
  btnNext.onclick = () => onCambia(info.pagina + 1);

  el.append(btnPrev, testo, btnNext);
}

/** [v2.3.11] SITI DI FORMAZIONE — scheda «Profilo» (dipendente e admin).
 *  PERSONALIZZAZIONE: per aggiungere/togliere piattaforme basta modificare
 *  QUESTA lista (nome, url, descrizione, icona emoji): le card «Siti di
 *  formazione» delle due pagine si aggiornano automaticamente. I link si
 *  aprono sempre in una NUOVA scheda (target=_blank + noopener). */
const SITI_FORMAZIONE = [
  { nome: 'Syllabus', url: 'https://www.syllabus.gov.it/portale/web/syllabus/',
    descrizione: 'Piattaforma e-learning per la formazione del personale della PA', icona: '🎓' },
  { nome: 'ASMEL', url: 'https://asmel.eu/formazione',
    descrizione: 'Piattaforma e-learning per la formazione del personale della PA', icona: '🎓' },
  { nome: 'IFEL', url: 'https://www.fondazioneifel.it/scuolaifel',
    descrizione: 'Piattaforma e-learning per la formazione del personale della PA', icona: '🎓' },
];

/** Rende l'elenco dei siti di formazione nel contenitore indicato
 *  (usato dalle card «Siti di formazione» di dipendente.html e admin.html). */
function renderSitiFormazione(idContenitore) {
  const el = document.getElementById(idContenitore);
  if (!el) return;
  el.innerHTML = '';
  for (const sito of SITI_FORMAZIONE) {
    const a = document.createElement('a');
    a.className = 'sito-formazione';
    a.href = sito.url;
    a.target = '_blank';            // apertura in NUOVA scheda, come richiesto
    a.rel = 'noopener noreferrer';  // sicurezza sui link esterni
    a.innerHTML = `
      <span class="sito-icona" aria-hidden="true">${escapeHtml(sito.icona || '🔗')}</span>
      <span class="sito-testo">
        <span class="sito-nome">${escapeHtml(sito.nome)}</span>
        <span class="sito-descrizione">${escapeHtml(sito.descrizione || '')}</span>
      </span>
      <span class="btn piccolo secondario sito-apri">Apri ↗</span>`;
    el.appendChild(a);
  }
}

/** Query string da oggetto (salta valori vuoti). */
function costruisciQuery(parametri) {
  const q = new URLSearchParams();
  Object.entries(parametri).forEach(([chiave, valore]) => {
    if (valore !== '' && valore !== null && valore !== undefined) q.set(chiave, valore);
  });
  return q.toString();
}

function debounce(fn, ms = 300) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}

/* -------------------- binding comuni -------------------- */

document.addEventListener('DOMContentLoaded', () => {
  // Pulsanti di logout
  document.querySelectorAll('[data-logout]').forEach((b) => b.addEventListener('click', esci));

  // Navigazione a tab: <button class="tab" data-tab="nome"> ↔ <section id="sezione-nome">
  document.querySelectorAll('.tab[data-tab]').forEach((tab) => {
    tab.addEventListener('click', () => attivaTab(tab.dataset.tab));
  });
  // Link interni che puntano a una tab (es. banner "cambia password")
  document.querySelectorAll('[data-apri-tab]').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      attivaTab(link.dataset.apriTab);
    });
  });
});

function attivaTab(nome) {
  document.querySelectorAll('.tab[data-tab]').forEach((t) =>
    t.classList.toggle('attiva', t.dataset.tab === nome));
  document.querySelectorAll('.sezione').forEach((s) =>
    s.classList.toggle('visibile', s.id === `sezione-${nome}`));
  window.scrollTo({ top: 0 });
}

/* [v2.2] Durata in ore o ore:minuti: 8h30 → "8:30", 8h → "8", 45 min → "0:45". */
function formattaDurata(ore, minuti) {
  const o = Number.parseInt(ore, 10) || 0;
  const m = Number.parseInt(minuti, 10) || 0;
  return m > 0 ? `${o}:${String(m).padStart(2, '0')}` : `${o}`;
}

/* [v2.2] Icona per il tipo di allegato (PDF o immagine). */
function iconaTipo(tipo) {
  return tipo === 'png' || tipo === 'jpeg' ? '\u{1F5BC}' : '\u{1F4C4}';
}

/* [v2.2.2] Analizza la durata scritta in un'unica cella "hh:mm" (oppure solo
 * "h"): restituisce {ore, minuti} oppure null se il formato non è valido.
 * Accetta: "8" · "8:30" · "08:05" · spazi intorno. Rifiuta: "", "8:5", "1:75",
 * "-3", "8.30", testo. */
function parserDurata(testo) {
  const t = String(testo ?? '').trim();
  const m = t.match(/^(\d{1,4})(?::([0-5]\d))?$/);
  if (!m) return null;
  const ore = Number.parseInt(m[1], 10);
  const minuti = m[2] !== undefined ? Number.parseInt(m[2], 10) : 0;
  if (ore * 60 + minuti < 1) return null; // la durata deve esistere
  return { ore, minuti };
}

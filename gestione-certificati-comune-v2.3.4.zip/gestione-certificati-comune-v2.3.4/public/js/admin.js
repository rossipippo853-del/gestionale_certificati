/**
 * admin.js — logica dell'area amministratore:
 * statistiche, gestione utenti, gestione certificati, export CSV.
 */
'use strict';

let utente = null;
const filtriUtenti = { pagina: 1, q: '', attivo: '', perPagina: 25 }; // [v2.2.9] righe per pagina
const filtriCert = { pagina: 1, perPagina: 25, q: '', stato: '', dipendenteId: '', dal: '', al: '', area: '', esame: '', durataMin: '', durataMax: '' }; // [v2.2.7] durata in MINUTI · [v2.3.5] impaginazione server-side
let resetTarget = null;   // { id, nome } per il dialog reset password
let modificaId = null;    // [v2.2.8] id del dipendente nel dialog di modifica
let ultimiUtenti = [];    // [v2.2.8] cache dell'ultimo elenco (precompilazione)
let opzioniDipendenti = []; // [v2.2.9] elenco per la ricerca autocompletante
let ultimiCertificati = []; // [v2.2.9] cache per il dialog di modifica certificato
let modificaCertId = null;  // [v2.2.9] id del certificato in correzione
let rifiutaTarget = null; // id certificato per il dialog rifiuta

document.addEventListener('DOMContentLoaded', init);

/**
 * Inizializzazione dell'area admin (DOMContentLoaded):
 *  1. proteggiPagina('AMMINISTRATORE') — un dipendente viene riportato alla
 *     sua area, un anonimo al login;
 *  2. caricamento parallelo di: statistiche, tabella dipendenti, tabella
 *     certificati, opzioni del filtro dipendente;
 *  3. binding di TUTTI gli eventi (ricerche con debounce, dialog, tabelle con
 *     event delegation: un solo listener per <tbody> gestisce le righe future).
 */
async function init() {
  utente = await proteggiPagina('AMMINISTRATORE');
  if (!utente) return;

  document.getElementById('nome-utente').textContent = `${utente.cognome} ${utente.nome}`;

  // Sezione Profilo [FIX QA-B8: prima l'admin non aveva modo di cambiare la propria password]
  document.getElementById('pr-matricola').textContent = utente.matricola;
  document.getElementById('pr-codice-fiscale').textContent = utente.codiceFiscale || '—'; // v2.0
  document.getElementById('pr-nome').textContent = `${utente.cognome} ${utente.nome}`;
  document.getElementById('pr-sesso').textContent = { M: 'Maschile (M)', F: 'Femminile (F)', ALTRO: 'Altro' }[utente.sesso] || utente.sesso;
  document.getElementById('pr-qualifica').textContent = utente.qualifica || '—';

  /* [v2.3.11] card «Siti di formazione» nella scheda Profilo */
  renderSitiFormazione('siti-formazione');
  document.getElementById('pr-email').textContent = utente.email || '—';
  if (utente.mustChangePassword) mostraBannerPassword();

  await Promise.all([caricaStatistiche(), caricaDipendenti(), caricaCertificati(), caricaOpzioniDipendenti(), caricaMonitoraggio()]);
  /* [v2.3.2] la tab Monitoraggio si aggiorna a ogni apertura. */
  document.querySelector('.tab[data-tab="monitoraggio"]').addEventListener('click', caricaMonitoraggio);

  /* ---------------- eventi: dipendenti ---------------- */
  document.getElementById('ut-q').addEventListener('input', debounce(() => {
    filtriUtenti.q = document.getElementById('ut-q').value.trim();
    filtriUtenti.pagina = 1;
    caricaDipendenti();
  }, 350));
  document.getElementById('ut-attivo').addEventListener('change', () => {
    filtriUtenti.attivo = document.getElementById('ut-attivo').value;
    filtriUtenti.pagina = 1;
    caricaDipendenti();
  });

  /* [v2.2.9] impaginazione utenti: righe per pagina (server-side) */
  document.getElementById('ut-perPagina').addEventListener('change', () => {
    filtriUtenti.perPagina = Number.parseInt(document.getElementById('ut-perPagina').value, 10) || 25;
    filtriUtenti.pagina = 1;
    caricaDipendenti();
  });
  /* [v2.2.9] esportazione anagrafica CSV */
  document.getElementById('btn-export-utenti').addEventListener('click', () => {
    window.location.assign('/api/admin/utenti/export');
  });
  /* [v2.2.9] storico modifiche (audit log) */
  document.getElementById('btn-audit').addEventListener('click', caricaAudit);
  document.getElementById('audit-annulla').addEventListener('click', () => chiudi('dlg-audit'));
  /* [v2.2.9] dialog di modifica certificato */
  document.getElementById('mc-annulla').addEventListener('click', () => chiudi('dlg-modifica-cert'));
  document.getElementById('form-modifica-cert').addEventListener('submit', eseguiModificaCert);
  inizializzaComboDipendenti();
  /* [v2.3.0] ricerca della dashboard formazione per dipendente */
  inizializzaRicercaDashboard();
  /* [v2.3.1] pulsante «✕ Chiudi scheda» della dashboard */
  document.getElementById('fd-chiudi').addEventListener('click', chiudiDashboardFormazione);
  document.getElementById('btn-nuovo-utente').addEventListener('click', apriNuovoUtente);
  document.getElementById('btn-importa').addEventListener('click', apriImporta);
  document.getElementById('imp-annulla').addEventListener('click', () => chiudi('dlg-importa'));
  document.getElementById('imp-modello').addEventListener('click', scaricaModelloCsv);
  document.getElementById('form-importa').addEventListener('submit', eseguiImporta);
  document.getElementById('nu-annulla').addEventListener('click', () => chiudi('dlg-nuovo-utente'));
  document.getElementById('form-nuovo-utente').addEventListener('submit', salvaNuovoUtente);

  document.getElementById('rp-annulla').addEventListener('click', () => chiudi('dlg-reset-password'));
  document.getElementById('form-reset-password').addEventListener('submit', eseguiResetPassword);
  /* [v2.2.8] dialog di modifica anagrafica del dipendente */
  document.getElementById('mu-annulla').addEventListener('click', () => chiudi('dlg-modifica-utente'));
  document.getElementById('form-modifica-utente').addEventListener('submit', eseguiModificaUtente);

  // Azioni sulla tabella utenti (event delegation)
  document.querySelector('#tabella-utenti tbody').addEventListener('click', azioneUtente);

  /* ---------------- eventi: certificati ---------------- */
  ['ce-q', 'ce-stato', 'ce-esame', 'ce-area', 'ce-dipendente', 'ce-dal', 'ce-al',
   'ce-durata-min', 'ce-durata-max'].forEach((id) => { // [v2.2.7] durata min/max
    const el = document.getElementById(id);
    el.addEventListener(id === 'ce-q' ? 'input' : 'change', debounce(() => {
      filtriCert.q = document.getElementById('ce-q').value.trim();
      filtriCert.stato = document.getElementById('ce-stato').value;
      filtriCert.area = document.getElementById('ce-area').value;
      filtriCert.esame = document.getElementById('ce-esame').value; // [v2.2]
      filtriCert.dipendenteId = document.getElementById('ce-dipendente').value;
      filtriCert.dal = document.getElementById('ce-dal').value;
      filtriCert.al = document.getElementById('ce-al').value;
      /* [v2.2.7] durata: testo «h» o «h:mm» → MINUTI (parser comune); un
       * valore non valido non filtra e segnala il campo in rosso. */
      filtriCert.durataMin = leggiDurataFiltro('ce-durata-min');
      filtriCert.durataMax = leggiDurataFiltro('ce-durata-max');
      filtriCert.pagina = 1;
      caricaCertificati();
    }, id === 'ce-q' ? 350 : 0));
  });

  document.getElementById('btn-azzera-filtri').addEventListener('click', azzeraFiltri);
  document.getElementById('btn-export').addEventListener('click', esportaCsv);

  /* [v2.3.5] impaginazione certificati: righe per pagina (server-side,
   * come la tabella Dipendenti) — il cambio riporta alla prima pagina. */
  document.getElementById('ce-perPagina').addEventListener('change', () => {
    filtriCert.perPagina = Number.parseInt(document.getElementById('ce-perPagina').value, 10) || 25;
    filtriCert.pagina = 1;
    caricaCertificati();
  });

  /* [v2.0] caricamento certificato per conto di un dipendente */
  document.getElementById('btn-carica-per').addEventListener('click', apriCaricaPer);
  document.getElementById('cc-annulla').addEventListener('click', () => chiudi('dlg-carica-cert'));
  document.getElementById('form-carica-cert').addEventListener('submit', eseguiCaricaPer);

  document.querySelector('#tabella-certificati tbody').addEventListener('click', azioneCertificato);

  document.getElementById('ri-annulla').addEventListener('click', () => chiudi('dlg-rifiuta'));
  document.getElementById('form-rifiuta').addEventListener('submit', eseguiRifiuta);

  /* ---------------- eventi: profilo ---------------- */
  document.getElementById('form-password').addEventListener('submit', cambiaPassword);
}

/** [FIX QA-B2] avvisa e sblocca indicando l'operatore della situazione. */
function mostraBannerPassword() {
  document.getElementById('banner-password').classList.remove('nascosto');
}

/** Ritorna true se l'errore è "password provvisoria da cambiare" (e mostra il banner). */
function errorePasswordProvvisoria(err) {
  if (err && err.codice === 'PASSWORD_TEMPORANEA') {
    mostraBannerPassword();
    return true;
  }
  return false;
}

async function cambiaPassword(e) {
  e.preventDefault();
  const erroreEl = document.getElementById('pw-errore');
  erroreEl.classList.add('nascosto');

  const attuale = document.getElementById('pw-attuale').value;
  const nuova = document.getElementById('pw-nuova').value;
  const conferma = document.getElementById('pw-conferma').value;

  if (nuova !== conferma) {
    erroreEl.textContent = 'La nuova password e la conferma non coincidono.';
    erroreEl.classList.remove('nascosto');
    return;
  }

  const bottone = document.getElementById('btn-password');
  bottone.disabled = true;
  try {
    const dati = await api('/api/auth/password', {
      method: 'PUT',
      body: { passwordAttuale: attuale, nuovaPassword: nuova },
    });
    toast(dati.messaggio || 'Password aggiornata.', 'successo');
    document.getElementById('form-password').reset();
    document.getElementById('banner-password').classList.add('nascosto');
  } catch (err) {
    erroreEl.textContent = err.message;
    erroreEl.classList.remove('nascosto');
  } finally {
    bottone.disabled = false;
  }
}

function chiudi(id) { document.getElementById(id).close(); }

/* ============================================================
   STATISTICHE
   ============================================================ */

/** GET /api/admin/stats → aggiorna i 6 KPI della dashboard. */
async function caricaStatistiche() {
  try {
    const { stats } = await api('/api/admin/stats');
    document.getElementById('s-dip-attivi').textContent = stats.dipendentiAttivi;
    document.getElementById('s-dip-tot').textContent = stats.totaleDipendenti;
    document.getElementById('s-cert-tot').textContent = stats.totaleCertificati;
    document.getElementById('s-cert-attesa').textContent = stats.certificatiInAttesa;
    document.getElementById('s-cert-approvati').textContent = stats.certificatiApprovati;
    document.getElementById('s-cert-rifiutati').textContent = stats.certificatiRifiutati;
  } catch (err) {
    toast(`Statistiche non disponibili: ${err.message}`, 'errore');
  }
}

/* ============================================================
   DIPENDENTI
   ============================================================ */

/** GET /api/admin/utenti con filtri/paginatura correnti → ridisegna la tabella.
 *  Per ogni utente: badge ruolo/stato, bottone reset password e abilita/
 *  disabilita (renderizzato secondo lo stato attuale). */
async function caricaDipendenti() {
  const tbody = document.querySelector('#tabella-utenti tbody');
  try {
    const qs = costruisciQuery({ q: filtriUtenti.q, attivo: filtriUtenti.attivo, pagina: filtriUtenti.pagina, perPagina: filtriUtenti.perPagina });
    const dati = await api(`/api/admin/utenti?${qs}`);
    ultimiUtenti = dati.utenti; // [v2.2.8] serve alla precompilazione del dialog

    tbody.innerHTML = '';
    if (!dati.utenti.length) {
      tbody.innerHTML = '<tr><td colspan="10" class="vuoto">Nessun dipendente trovato.</td></tr>';
    }

    for (const u of dati.utenti) {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="cella-principale">${escapeHtml(u.matricola)}</td>
        <td class="mono">${escapeHtml(u.codice_fiscale || '—')}</td>
        <td>${escapeHtml(u.cognome)} ${escapeHtml(u.nome)}</td>
        <td>${escapeHtml(u.sesso)}</td>
        <td>${escapeHtml(u.qualifica || '—')}</td>
        <td>${u.email ? escapeHtml(u.email) : '—'}</td>
        <td>${u.ruolo === 'AMMINISTRATORE' ? '<span class="badge blu">ADMIN</span>' : '<span class="badge grigio">DIPENDENTE</span>'}</td>
        <td>${u.attivo
          ? '<span class="badge verde">Attivo</span>'
          : '<span class="badge rosso">Disabilitato</span>'}</td>
        <td>${u.must_change_password ? '<span class="badge ambra">Cambia pwd</span>' : '—'}</td>
        <td class="azioni-cell">
          <div class="azioni">
            <button class="btn piccolo secondario" data-azione="modifica" data-id="${u.id}"
              data-nome="${escapeHtml(u.cognome)} ${escapeHtml(u.nome)}" title="Modifica anagrafica e dati lavorativi">✏️</button>
            <button class="btn piccolo secondario" data-azione="reset" data-id="${u.id}"
              data-nome="${escapeHtml(u.cognome)} ${escapeHtml(u.nome)}" title="Reimposta password">🔑</button>
            ${u.attivo
              ? `<button class="btn piccolo pericolo" data-azione="disabilita" data-id="${u.id}"
                   data-nome="${escapeHtml(u.cognome)} ${escapeHtml(u.nome)}" title="Disabilita account">⏸</button>`
              : `<button class="btn piccolo successo" data-azione="abilita" data-id="${u.id}" title="Riabilita account">▶</button>`}
          </div>
        </td>`;
      tbody.appendChild(tr);
    }

    renderPaginazione('paginazione-utenti', dati, (p) => { filtriUtenti.pagina = p; caricaDipendenti(); });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="10" class="vuoto">Errore: ${escapeHtml(err.message)}</td></tr>`;
  }
}

/* ---------- [v2.2.9] Ricerca autocompletante dipendente (combobox) ---------- */

/** Filtra la cache dei dipendenti attivi su nome, cognome, matricola e CF. */
function filtraDipendenti(testo) {
  const q = testo.trim().toLowerCase();
  if (!q) return [];
  return opzioniDipendenti.filter((o) =>
    o.nome.toLowerCase().includes(q) ||
    o.cognome.toLowerCase().includes(q) ||
    o.matricola.toLowerCase().includes(q) ||
    (o.codice_fiscale || '').toLowerCase().includes(q)
  ).slice(0, 12);
}

/** Rende i risultati nel pannello a discesa della combobox. */
function mostraListaDipendenti(risultati) {
  const lista = document.getElementById('cc-dipendente-lista');
  const input = document.getElementById('cc-dipendente-cerca');
  lista.innerHTML = '';
  if (!risultati.length) { lista.classList.add('nascosto'); input.setAttribute('aria-expanded', 'false'); return; }
  for (const o of risultati) {
    const voce = document.createElement('button');
    voce.type = 'button';
    voce.setAttribute('role', 'option');
    voce.innerHTML = `<strong>${escapeHtml(o.cognome)} ${escapeHtml(o.nome)}</strong>
      <span class="cella-secondaria">${escapeHtml(o.matricola)} · CF ${escapeHtml(o.codice_fiscale || '—')}</span>`;
    voce.addEventListener('click', () => scegliDipendente(o));
    lista.appendChild(voce);
  }
  lista.classList.remove('nascosto');
  input.setAttribute('aria-expanded', 'true');
}

/** Selezione: l'id va nel campo nascosto (che parla con l'API), il testo
 *  leggibile nell'input. */
function scegliDipendente(o) {
  document.getElementById('cc-dipendente').value = o.id;
  document.getElementById('cc-dipendente-cerca').value = `${o.cognome} ${o.nome} (${o.matricola})`;
  const lista = document.getElementById('cc-dipendente-lista');
  lista.classList.add('nascosto');
  document.getElementById('cc-dipendente-cerca').setAttribute('aria-expanded', 'false');
}

function inizializzaComboDipendenti() {
  const input = document.getElementById('cc-dipendente-cerca');
  const lista = document.getElementById('cc-dipendente-lista');
  if (!input) return;
  input.addEventListener('input', () => {
    document.getElementById('cc-dipendente').value = ''; // la selezione è valida finché non si ricambia
    mostraListaDipendenti(filtraDipendenti(input.value));
  });
  input.addEventListener('keydown', (e) => {
    const voci = Array.from(lista.querySelectorAll('button'));
    if (!voci.length) return;
    const attiva = voci.findIndex((v) => v.classList.contains('attiva'));
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const nuova = e.key === 'ArrowDown' ? Math.min(attiva + 1, voci.length - 1) : Math.max(attiva - 1, 0);
      voci.forEach((v) => v.classList.remove('attiva'));
      voci[nuova].classList.add('attiva');
      voci[nuova].scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'Enter' && attiva >= 0) {
      e.preventDefault(); voci[attiva].click();
    } else if (e.key === 'Escape') {
      lista.classList.add('nascosto');
      input.setAttribute('aria-expanded', 'false');
    }
  });
  input.addEventListener('blur', () => setTimeout(() => lista.classList.add('nascosto'), 180));
}

/* ---------- [v2.2.9] Modifica metadati certificato (admin) ---------- */

/** Precompila il dialog con i valori ATTUALI del certificato (durata in h:mm). */
function apriModificaCert(id) {
  const c = ultimiCertificati.find((x) => x.id === id);
  if (!c) { toast('Certificato non trovato: ricarica la pagina.', 'errore'); return; }
  modificaCertId = id;
  document.getElementById('mc-id').value = id;
  document.getElementById('mc-corso').value = c.nome_corso || '';
  document.getElementById('mc-ente').value = c.ente_erogatore || '';
  document.getElementById('mc-data').value = (c.data_conseguimento || '').slice(0, 10);
  document.getElementById('mc-durata').value =
    `${c.numero_ore}:${String(c.numero_minuti).padStart(2, '0')}`;
  document.getElementById('mc-esame').value = c.esame_finale ? '1' : '0';
  document.getElementById('mc-area').value = c.area_tematica || 'Altro';
  document.getElementById('mc-errore').classList.add('nascosto');
  document.getElementById('dlg-modifica-cert').showModal();
}

/** Submit: validazione durata (parser comune) → PUT → refresh. */
async function eseguiModificaCert(e) {
  e.preventDefault();
  const erroreEl = document.getElementById('mc-errore');
  erroreEl.classList.add('nascosto');
  const durata = parserDurata(document.getElementById('mc-durata').value);
  if (!durata) {
    erroreEl.textContent = 'Durata non valida: usa il formato ore:minuti (es. 8:30, 0:45 oppure 8).';
    erroreEl.classList.remove('nascosto');
    return;
  }
  try {
    const dati = await api(`/api/admin/certificati/${modificaCertId}`, {
      method: 'PUT',
      body: {
        nome_corso: document.getElementById('mc-corso').value.trim(),
        ente_erogatore: document.getElementById('mc-ente').value.trim(),
        data_conseguimento: document.getElementById('mc-data').value,
        numero_ore: String(durata.ore),
        numero_minuti: String(durata.minuti),
        esame_finale: document.getElementById('mc-esame').value,
        area_tematica: document.getElementById('mc-area').value,
      },
    });
    chiudi('dlg-modifica-cert');
    toast(dati.messaggio || 'Certificato aggiornato.', 'successo');
    await Promise.all([caricaCertificati(), caricaStatistiche()]);
  } catch (err) {
    errorePasswordProvvisoria(err);
    erroreEl.textContent = err.message;
    erroreEl.classList.remove('nascosto');
  }
}

/* ---------- [v2.2.9] Storico modifiche (audit log) ---------- */

/* [v2.3.4] ETICHETTE DINAMICHE: il codice azione del log (es.
 * MODIFICA_ENTE_EROGATORE) viene tradotto nell'operazione ESATTA eseguita
 * dall'amministratore («Modifica Ente Erogatore») con badge colorato per
 * famiglia: blu = modifiche, verde = approvazioni, rosso = rifiuti ed
 * eliminazioni, ambra = cambiamenti di stato/metadati rimossi.
 * CAMPI_AUDIT alimenta la traduzione anche per codici futuri. */
const CAMPI_AUDIT = {
  TITOLO_CORSO: 'Titolo Corso',
  ENTE_EROGATORE: 'Ente Erogatore',
  DATA_CONSEGUIMENTO: 'Data Conseguimento',
  DURATA: 'Durata',
  ESAME_FINALE: 'Esame Finale',
  AREA_TEMATICA: 'Area Tematica',
  METADATO: 'Metadato',
  STATO: 'Stato',
  CERTIFICATO: 'Certificato',
};

/* Codici con etichetta FISSA: righe storiche pre-v2.3.4 e casi particolari. */
const ETICHETTE_AUDIT = {
  MODIFICA_CERTIFICATO: ['Modifica metadati (storico)', 'blu'],
  APPROVAZIONE: ['Approvazione (storico)', 'verde'],
  RIFIUTO: ['Rifiuto (storico)', 'rosso'],
  ELIMINAZIONE: ['Eliminazione (storico)', 'grigio'],
  CAMBIO_STATO: ['Cambio Stato', 'ambra'],
};

/** Traduce un codice azione in [etichetta, colore del badge].
 *  Regole per prefisso (dinamico) + mappa fissa + fallback neutro. */
function etichettaAzione(azione) {
  if (ETICHETTE_AUDIT[azione]) return ETICHETTE_AUDIT[azione];
  const m = /^(MODIFICA|ELIMINAZIONE|APPROVAZIONE|RIFIUTO|CAMBIO)_(.+)$/.exec(azione || '');
  if (m) {
    const campo = CAMPI_AUDIT[m[2]] || m[2].toLowerCase().replace(/_/g, ' ');
    if (m[1] === 'MODIFICA') return [`Modifica ${campo}`, 'blu'];
    if (m[1] === 'CAMBIO') return [`Cambio ${campo}`, 'ambra'];
    if (m[1] === 'APPROVAZIONE') return [`Approvazione ${campo}`, 'verde'];
    if (m[1] === 'RIFIUTO') return [`Rifiuto ${campo}`, 'rosso'];
    /* ELIMINAZIONE: rossa se l'oggetto è l'intero certificato, ambra se è un singolo metadato. */
    return [`Eliminazione ${campo}`, m[2] === 'CERTIFICATO' ? 'rosso' : 'ambra'];
  }
  return [azione || '—', 'grigio'];
}

async function caricaAudit() {
  const tbody = document.getElementById('audit-tbody');
  try {
    const { righe } = await api('/api/admin/audit');
    tbody.innerHTML = righe.length ? '' : '<tr><td colspan="4" class="vuoto">Nessuna modifica registrata.</td></tr>';
    for (const r of righe) {
      const [etichetta, colore] = etichettaAzione(r.azione);
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${dataOraIt(r.creato_il)}</td>
        <td><span class="cella-principale">${escapeHtml(r.admin_matricola)}</span>
            <div class="cella-secondaria">${escapeHtml(r.admin_cognome)} ${escapeHtml(r.admin_nome)}</div></td>
        <td><span class="badge ${colore}">${escapeHtml(etichetta)}</span></td>
        <td>${escapeHtml(r.dettagli || '—')}${r.certificato_id ? ` <span class="cella-secondaria">(certificato #${r.certificato_id})</span>` : ''}</td>`;
      tbody.appendChild(tr);
    }
    document.getElementById('dlg-audit').showModal();
  } catch (err) { toast(`Storico non disponibile: ${err.message}`, 'errore'); }
}

/* ---------- [v2.3.0] Dashboard formazione del singolo dipendente ---------- */

const STATI_FORMAZIONE = {
  IN_REGOLA: ['In regola con il target 40h', 'verde'],
  IN_CORSO: ['In corso', 'ambra'],
  SOTTO_SOGLIA: ['Sotto la soglia', 'rosso'],
};

/** Ore in formato h:mm a partire da dei minuti. */
function minutiInHhMm(minuti) {
  return formattaDurata(Math.floor(minuti / 60), minuti % 60);
}

/** Chiama l'API metriche e disegna le schede KPI scure della dashboard. */
async function caricaDashboardFormazione(id) {
  const dash = document.getElementById('fd-dash');
  const vuoto = document.getElementById('fd-vuoto');
  try {
    const d = await api(`/api/admin/utenti/${id}/formazione`);

    vuoto.classList.add('nascosto');
    dash.classList.remove('nascosto');

    document.getElementById('fd-nome').textContent = `${d.dipendente.cognome} ${d.dipendente.nome}`;
    document.getElementById('fd-sotto').textContent =
      `Matricola ${d.dipendente.matricola} · CF ${d.dipendente.codice_fiscale || '—'} · ${d.dipendente.qualifica || 'qualifica non indicata'}${d.dipendente.attivo ? '' : ' · ACCOUNT DISABILITATO'}`;

    const [testoStato, coloreStato] = STATI_FORMAZIONE[d.stato] || [d.stato, 'grigio'];
    const badge = document.getElementById('fd-stato');
    badge.textContent = testoStato;
    badge.className = `badge ${coloreStato}`;

    document.getElementById('fd-cert-tot').textContent = d.certificati.totale;
    document.getElementById('fd-approvati').textContent = d.certificati.approvati;
    document.getElementById('fd-attesa').textContent = d.certificati.inAttesa;
    document.getElementById('fd-rifiutati').textContent = d.certificati.rifiutati;

    /* [v2.3.1] ore DISTINCTE: approvate vs totali inviate (con quelle in
     * attesa); il target considera il CONTEGGIO completo (approvate+attesa). */
    document.getElementById('fd-ore-approvate').textContent = minutiInHhMm(d.oreApprovateMinuti);
    document.getElementById('fd-ore-inviate').textContent = minutiInHhMm(d.oreConteggiateMinuti);
    document.getElementById('fd-ore-attesa').textContent = minutiInHhMm(d.oreInAttesaMinuti);
    document.getElementById('fd-mancanti').textContent = minutiInHhMm(d.oreMancantiMinuti);

    document.getElementById('fd-percentuale').textContent = `${d.percentuale}%`;
    const barra = document.getElementById('fd-barra');
    barra.style.width = `${d.percentuale}%`;
    barra.parentElement.setAttribute('aria-valuenow', String(d.percentuale));

    const aree = document.getElementById('fd-aree');
    aree.innerHTML = d.perArea.length
      ? d.perArea.map((a) => {
          const inAttesa = a.minutiAttesa > 0 ? ` <span class="chip-attesa">(⏳ ${minutiInHhMm(a.minutiAttesa)} in attesa)</span>` : '';
          return `<span class="chip-area"><strong>${escapeHtml(a.area)}</strong>
            <span>${minutiInHhMm(a.minuti)} · ${a.certificati} ${a.certificati === 1 ? 'certificato' : 'certificati'}${inAttesa}</span></span>`;
        }).join('')
      : '<span class="hint">Nessuna formazione caricata: le aree compariranno al primo certificato.</span>';
  } catch (err) {
    dash.classList.add('nascosto');
    vuoto.classList.remove('nascosto');
    vuoto.textContent = `Dashboard non disponibile: ${err.message}`;
  }
}

/** Selezione dalla ricerca: l'id va nel campo nascosto e si carica la dashboard. */
function selezionaDipendenteDashboard(o) {
  document.getElementById('fd-dipendente').value = o.id;
  document.getElementById('fd-dipendente-cerca').value = `${o.cognome} ${o.nome} (${o.matricola})`;
  const lista = document.getElementById('fd-dipendente-lista');
  lista.classList.add('nascosto');
  document.getElementById('fd-dipendente-cerca').setAttribute('aria-expanded', 'false');
  caricaDashboardFormazione(o.id);
}

/** [v2.3.1] «✕ Chiudi scheda»: nasconde i KPI del dipendente e azzera la
 *  vista (campo di ricerca svuotato, nessuna selezione attiva). */
function chiudiDashboardFormazione() {
  document.getElementById('fd-dash').classList.add('nascosto');
  document.getElementById('fd-vuoto').classList.remove('nascosto');
  document.getElementById('fd-vuoto').textContent =
    'Nessun dipendente selezionato: la dashboard comparirà qui dopo la ricerca.';
  document.getElementById('fd-dipendente').value = '';
  document.getElementById('fd-dipendente-cerca').value = '';
  document.getElementById('fd-dipendente-lista').classList.add('nascosto');
  document.getElementById('fd-dipendente-cerca').setAttribute('aria-expanded', 'false');
  document.getElementById('fd-dipendente-cerca').focus();
}

/** Rende i risultati della ricerca nel pannello a discesa della dashboard. */
function mostraListaDashboard(risultati) {
  const lista = document.getElementById('fd-dipendente-lista');
  const input = document.getElementById('fd-dipendente-cerca');
  lista.innerHTML = '';
  if (!risultati.length) {
    lista.classList.add('nascosto');
    input.setAttribute('aria-expanded', 'false');
    return;
  }
  for (const o of risultati) {
    const voce = document.createElement('button');
    voce.type = 'button';
    voce.setAttribute('role', 'option');
    voce.innerHTML = `<strong>${escapeHtml(o.cognome)} ${escapeHtml(o.nome)}</strong>
      <span class="cella-secondaria">${escapeHtml(o.matricola)} · CF ${escapeHtml(o.codice_fiscale || '—')}</span>`;
    voce.addEventListener('click', () => selezionaDipendenteDashboard(o));
    lista.appendChild(voce);
  }
  lista.classList.remove('nascosto');
  input.setAttribute('aria-expanded', 'true');
}

/** Stessa logica di filtro della combobox di caricamento (nome/cognome/
 *  matricola/CF), ma al servizio della dashboard. */
function inizializzaRicercaDashboard() {
  const input = document.getElementById('fd-dipendente-cerca');
  const lista = document.getElementById('fd-dipendente-lista');
  if (!input) return;
  input.addEventListener('input', () => {
    document.getElementById('fd-dipendente').value = '';
    mostraListaDashboard(filtraDipendenti(input.value));
  });
  input.addEventListener('keydown', (e) => {
    const voci = Array.from(lista.querySelectorAll('button'));
    if (!voci.length) return;
    const attiva = voci.findIndex((v) => v.classList.contains('attiva'));
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const nuova = e.key === 'ArrowDown' ? Math.min(attiva + 1, voci.length - 1) : Math.max(attiva - 1, 0);
      voci.forEach((v) => v.classList.remove('attiva'));
      voci[nuova].classList.add('attiva');
      voci[nuova].scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'Enter' && attiva >= 0) {
      e.preventDefault(); voci[attiva].click();
    } else if (e.key === 'Escape') {
      lista.classList.add('nascosto');
      input.setAttribute('aria-expanded', 'false');
    }
  });
  input.addEventListener('blur', () => setTimeout(() => lista.classList.add('nascosto'), 180));
}

/* ---------- [v2.3.2] Tab «Monitoraggio»: analytics aggregate ---------- */

/** Disegna la ciambella del target 40h (SVG con stroke-dasharray). */
function renderDonutTarget(t) {
  const raggio = 56;
  const circonferenza = 2 * Math.PI * raggio;
  const arco = document.getElementById('donut-arco');
  arco.setAttribute('stroke-dasharray', `${(circonferenza * t.percentuale) / 100} ${circonferenza}`);

  document.getElementById('donut-percento').textContent = `${t.percentuale}%`;
  document.getElementById('donut-sotto').textContent = `${t.raggiunti} su ${t.totaleDipendenti}`;
  document.getElementById('tg-raggiunti').textContent = t.raggiunti;
  document.getElementById('tg-non').textContent = t.nonRaggiunti;
  document.getElementById('tg-tot').textContent = t.totaleDipendenti;
}

/** Disegna le barre percentuali per area tematica (tutti i caricamenti). */
function renderBarreAree(aree) {
  const contenitore = document.getElementById('barre-aree');
  const totale = aree.reduce((somma, a) => somma + a.certificati, 0);
  contenitore.innerHTML = aree.length
    ? aree.map((a) => {
        const pct = totale ? Math.round((a.certificati / totale) * 100) : 0;
        return `<div class="area-riga">
          <div class="area-testo"><span title="${escapeHtml(a.area)}">${escapeHtml(a.area)}</span>
            <span class="cella-secondaria">${a.certificati} ${a.certificati === 1 ? 'certificato' : 'certificati'} · ${pct}%</span></div>
          <div class="area-traccia"><div class="area-riempimento" style="width:${pct}%"></div></div>
        </div>`;
      }).join('')
    : '<p class="hint">Nessun certificato caricato: la distribuzione comparirà al primo caricamento.</p>';
}

/** Pannello KPI: media ore, certificati in attesa, top 3 aree. */
function renderKpiExtra(d) {
  document.getElementById('kpi-media-ore').textContent = minutiInHhMm(d.mediaOreMinuti);
  document.getElementById('kpi-in-attesa').textContent = d.certificatiInAttesa;
  const top = document.getElementById('kpi-top-aree');
  top.innerHTML = d.topAree.length
    ? d.topAree.map((a, i) =>
        `<li><span class="posizione">${i + 1}.</span> ${escapeHtml(a.area)} <span class="cella-secondaria">(${a.certificati})</span></li>`).join('')
    : '<li class="cella-secondaria">Nessun dato disponibile</li>';
}

/** Aggiorna l'intera tab Monitoraggio (chiamata all'avvio e all'apertura). */
async function caricaMonitoraggio() {
  try {
    const d = await api('/api/admin/monitoraggio');
    renderDonutTarget(d.target);
    renderBarreAree(d.aree);
    renderKpiExtra(d);
  } catch (err) { toast(`Monitoraggio non disponibile: ${err.message}`, 'errore'); }
}

/* -------------------- [v2.2.8] Modifica dipendente -------------------- */

/** Precompila il dialog di modifica con i valori ATTUALI del dipendente
 *  (dalla cache dell'ultimo elenco caricato). */
function apriModificaUtente(id) {
  const u = ultimiUtenti.find((x) => x.id === id);
  if (!u) { toast('Dipendente non trovato: ricarica la pagina.', 'errore'); return; }
  modificaId = id;
  document.getElementById('mu-matricola').value = u.matricola || '';
  document.getElementById('mu-codice-fiscale').value = u.codice_fiscale || '';
  document.getElementById('mu-nome').value = u.nome || '';
  document.getElementById('mu-cognome').value = u.cognome || '';
  document.getElementById('mu-sesso').value = u.sesso || 'M';
  document.getElementById('mu-qualifica').value = u.qualifica || '';
  document.getElementById('mu-email').value = u.email || '';
  document.getElementById('mu-errore').classList.add('nascosto');
  document.getElementById('dlg-modifica-utente').showModal();
}

/** Validazione lato CLIENT, specchio delle regole del server
 *  (src/utils/validazione.js): stessi formati, stessi messaggi. */
function validaAnagraficaClient(v) {
  const errori = [];
  if (!/^[A-Za-z0-9_-]{2,20}$/.test(v.matricola)) errori.push('Matricola non valida (2-20 caratteri alfanumerici).'); // [v2.3.1] minimo 2
  if (!/^[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]$/.test(v.codice_fiscale)) errori.push('Codice Fiscale non valido: inserire 16 caratteri nel formato italiano (es. RSSMRA80A01H501U).');
  if (v.nome.length < 2 || v.nome.length > 100) errori.push('Nome non valido (2-100 caratteri).');
  if (v.cognome.length < 2 || v.cognome.length > 100) errori.push('Cognome non valido (2-100 caratteri).');
  if (!['M', 'F', 'ALTRO'].includes(v.sesso)) errori.push('Sesso non valido: usare M, F o ALTRO.');
  if (v.qualifica.length < 2 || v.qualifica.length > 120) errori.push('Qualifica professionale non valida (2-120 caratteri).');
  if (v.email && (v.email.length > 150 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email))) errori.push('Email non valida.');
  return errori;
}

/** Submit del dialog: validazione client → PUT → toast + refresh. */
async function eseguiModificaUtente(e) {
  e.preventDefault();
  const erroreEl = document.getElementById('mu-errore');
  erroreEl.classList.add('nascosto');

  const payload = {
    matricola: document.getElementById('mu-matricola').value.trim(),
    codice_fiscale: document.getElementById('mu-codice-fiscale').value.trim().toUpperCase(),
    nome: document.getElementById('mu-nome').value.trim(),
    cognome: document.getElementById('mu-cognome').value.trim(),
    sesso: document.getElementById('mu-sesso').value,
    qualifica: document.getElementById('mu-qualifica').value.trim(),
    email: document.getElementById('mu-email').value.trim(),
  };
  const errori = validaAnagraficaClient(payload);
  if (errori.length) {
    erroreEl.textContent = errori.join(' ');
    erroreEl.classList.remove('nascosto');
    return;
  }

  try {
    const dati = await api(`/api/admin/utenti/${modificaId}`, { method: 'PUT', body: payload });
    chiudi('dlg-modifica-utente');
    toast(dati.messaggio || 'Dati aggiornati.', 'successo');
    await Promise.all([caricaDipendenti(), caricaStatistiche()]);
  } catch (err) {
    erroreEl.textContent = err.message;   // es. 409 «Matricola già assegnata…»
    erroreEl.classList.remove('nascosto');
  }
}

/** Event delegation sui bottoni della tabella dipendenti:
 *  reset → apre il dialog password; disabilita → dialog di conferma
 *  (Promise da common.js); abilita → chiamata diretta. Ogni esito aggiorna
 *  tabella e statistiche. */
async function azioneUtente(e) {
  const btn = e.target.closest('button[data-azione]');
  if (!btn) return;
  const id = Number(btn.dataset.id);

  /* [v2.2.8] modifica anagrafica: apre il dialog precompilato. */
  if (btn.dataset.azione === 'modifica') {
    apriModificaUtente(id);
    return;
  }

  if (btn.dataset.azione === 'reset') {
    resetTarget = { id, nome: btn.dataset.nome };
    document.getElementById('rp-testo').textContent =
      `Reimposta la password di ${resetTarget.nome}.`;
    document.getElementById('rp-password').value = '';
    document.getElementById('rp-errore').classList.add('nascosto');
    document.getElementById('dlg-reset-password').showModal();
    return;
  }

  if (btn.dataset.azione === 'disabilita') {
    const ok = await conferma(
      `Disabilitare l'account di ${btn.dataset.nome}? Il dipendente non potrà più accedere.`,
      { titolo: 'Disabilita account', etichetta: 'Disabilita' }
    );
    if (!ok) return;
    try {
      const dati = await api(`/api/admin/utenti/${id}/stato`, { method: 'PUT', body: { attivo: false } });
      toast(dati.messaggio, 'successo');
      await Promise.all([caricaDipendenti(), caricaStatistiche()]);
    } catch (err) { if (!errorePasswordProvvisoria(err)) toast(err.message, 'errore'); }
    return;
  }

  if (btn.dataset.azione === 'abilita') {
    try {
      const dati = await api(`/api/admin/utenti/${id}/stato`, { method: 'PUT', body: { attivo: true } });
      toast(dati.messaggio, 'successo');
      await Promise.all([caricaDipendenti(), caricaStatistiche()]);
    } catch (err) { if (!errorePasswordProvvisoria(err)) toast(err.message, 'errore'); }
  }
}

/** Apre il dialog di creazione con il form azzerato. */
function apriNuovoUtente() {
  document.getElementById('form-nuovo-utente').reset();
  document.getElementById('nu-errore').classList.add('nascosto');
  document.getElementById('dlg-nuovo-utente').showModal();
}

/** POST /api/admin/utenti: crea il dipendente; se il server ha generato una
 *  password provvisoria la mostra nel dialog credenziale (unica occasione). */
async function salvaNuovoUtente(e) {
  e.preventDefault();
  const erroreEl = document.getElementById('nu-errore');
  erroreEl.classList.add('nascosto');
  try {
    const dati = await api('/api/admin/utenti', {
      method: 'POST',
      body: {
        matricola: document.getElementById('nu-matricola').value.trim(),
        codice_fiscale: document.getElementById('nu-codice-fiscale').value.trim().toUpperCase(), // v2.0
        nome: document.getElementById('nu-nome').value.trim(),
        cognome: document.getElementById('nu-cognome').value.trim(),
        sesso: document.getElementById('nu-sesso').value,
        qualifica: document.getElementById('nu-qualifica').value.trim(),
        email: document.getElementById('nu-email').value.trim(),
        ruolo: document.getElementById('nu-ruolo').value,
        password: document.getElementById('nu-password').value.trim(),
      },
    });
    chiudi('dlg-nuovo-utente');
    toast(dati.messaggio || 'Dipendente creato.', 'successo');
    if (dati.passwordProvvisoria) {
      await mostraCredenziale(
        'Dipendente creato — password provvisoria',
        document.getElementById('nu-matricola').value.trim(),
        dati.passwordProvvisoria
      );
    }
    await Promise.all([caricaDipendenti(), caricaStatistiche()]);
  } catch (err) {
    errorePasswordProvvisoria(err);
    erroreEl.textContent = err.message;
    erroreEl.classList.remove('nascosto');
  }
}

/** PUT /api/admin/utenti/:id/password: applica il reset e mostra la
 *  provvisoria generata (o confermata) dall'amministratore. */
async function eseguiResetPassword(e) {
  e.preventDefault();
  const erroreEl = document.getElementById('rp-errore');
  erroreEl.classList.add('nascosto');
  try {
    const dati = await api(`/api/admin/utenti/${resetTarget.id}/password`, {
      method: 'PUT',
      body: { nuovaPassword: document.getElementById('rp-password').value.trim() },
    });
    chiudi('dlg-reset-password');
    toast('Password reimpostata.', 'successo');
    await mostraCredenziale(`Password provvisoria per ${resetTarget.nome}`, null, dati.passwordProvvisoria);
    await Promise.all([caricaDipendenti(), caricaStatistiche()]);
  } catch (err) {
    erroreEl.textContent = err.message;
    erroreEl.classList.remove('nascosto');
  }
}

/** Dialog con la password provvisoria generata dal server. */
function mostraCredenziale(titolo, matricola, password) {
  return new Promise((risolvi) => {
    let dlg = document.getElementById('dlg-credenziale');
    if (!dlg) {
      dlg = document.createElement('dialog');
      dlg.id = 'dlg-credenziale';
      dlg.innerHTML = `
        <h3 id="cr-titolo"></h3>
        <p>Comunicala al dipendente: sarà obbligato a cambiarla al primo accesso.</p>
        ${matricola ? '<p>Matricola: <b id="cr-matricola"></b></p>' : ''}
        <div class="credenziale" id="cr-password"></div>
        <div class="azioni"><button class="btn primario" id="cr-ok">Ho preso nota</button></div>`;
      document.body.appendChild(dlg);
      // [FIX QA-B6] niente attributi onclick inline (bloccati dalla CSP)
      dlg.querySelector('#cr-ok').addEventListener('click', () => dlg.close());
    }
    dlg.querySelector('#cr-titolo').textContent = titolo;
    dlg.querySelector('#cr-password').textContent = password;
    if (matricola) {
      dlg.querySelector('#cr-matricola').textContent = matricola;
    }
    dlg.onclose = () => risolvi();
    dlg.showModal();
  });
}

/* ============================================================
   CERTIFICATI
   ============================================================ */

/** [v2.0] Apre il dialog "Carica certificato per dipendente": popola il menu
 *  con l'elenco aggiornato dei dipendenti attivi (matricola, cognome/nome, CF). */
async function apriCaricaPer() {
  const select = document.getElementById('cc-dipendente');
  select.innerHTML = '<option value="">— seleziona —</option>';
  try {
    const { opzioni } = await api('/api/admin/utenti/options');
    for (const o of opzioni) {
      const opt = document.createElement('option');
      opt.value = o.id;
      opt.textContent = `${o.matricola} — ${o.cognome} ${o.nome} · CF ${o.codice_fiscale}`;
      select.appendChild(opt);
    }
  } catch (err) { toast(`Impossibile caricare l'elenco dipendenti: ${err.message}`, 'errore'); return; }

  document.getElementById('form-carica-cert').reset();
  document.getElementById('cc-errore').classList.add('nascosto');
  document.getElementById('dlg-carica-cert').showModal();
}

/** [v2.0] Submit: multipart con dipendenteId + campi del corso + PDF.
 *  Il server scrive il file nella cartella {codice_fiscale} del dipendente. */
async function eseguiCaricaPer(e) {
  e.preventDefault();
  const erroreEl = document.getElementById('cc-errore');
  const bottone = document.getElementById('cc-btn');
  erroreEl.classList.add('nascosto');

  /* [v2.2.9] con la ricerca autocompletante il dipendente va scelto dall'elenco. */
  const dipendenteId = document.getElementById('cc-dipendente').value;
  if (!dipendenteId) {
    erroreEl.textContent = 'Seleziona un dipendente dalla ricerca (nome, cognome, matricola o CF).';
    erroreEl.classList.remove('nascosto');
    return;
  }

  /* [v2.2] da 1 a 5 documenti (PDF, JPG o PNG) per lo stesso corso. */
  const files = Array.from(document.getElementById('cc-file').files || []);
  if (!files.length) { erroreEl.textContent = 'Seleziona almeno un documento del certificato.'; erroreEl.classList.remove('nascosto'); return; }
  if (files.length > 5) { erroreEl.textContent = 'Massimo 5 file per un solo corso.'; erroreEl.classList.remove('nascosto'); return; }
  const ammesse = ['.pdf', '.jpg', '.jpeg', '.png'];
  for (const f of files) {
    if (!ammesse.some((est) => f.name.toLowerCase().endsWith(est))) {
      erroreEl.textContent = `«${f.name}»: formato non ammesso (solo PDF, JPG o PNG).`;
      erroreEl.classList.remove('nascosto');
      return;
    }
    if (f.size > 5 * 1024 * 1024) {
      erroreEl.textContent = `«${f.name}» supera il limite di 5 MB per file.`;
      erroreEl.classList.remove('nascosto');
      return;
    }
  }

  /* [v2.2.2] durata in un'unica cella hh:mm. */
  const durata = parserDurata(document.getElementById('cc-durata').value);
  if (!durata) {
    erroreEl.textContent = 'Durata non valida: usa il formato ore:minuti (es. 8:30, 0:45 oppure 8).';
    erroreEl.classList.remove('nascosto');
    return;
  }
  const ore = durata.ore;
  const minuti = durata.minuti;

  const formData = new FormData();
  formData.append('dipendenteId', dipendenteId);
  formData.append('nome_corso', document.getElementById('cc-corso').value.trim());
  formData.append('ente_erogatore', document.getElementById('cc-ente').value.trim());
  formData.append('data_conseguimento', document.getElementById('cc-data').value);
  formData.append('numero_ore', String(ore));
  formData.append('numero_minuti', String(minuti));
  formData.append('esame_finale', document.getElementById('cc-esame').value);
  formData.append('area_tematica', document.getElementById('cc-area').value);
  for (const f of files) formData.append('file', f);

  bottone.disabled = true;
  bottone.textContent = 'Caricamento…';
  try {
    const dati = await api('/api/admin/certificati', { method: 'POST', formData });
    chiudi('dlg-carica-cert');
    toast(dati.messaggio || 'Certificato caricato.', 'successo');
    await Promise.all([caricaCertificati(), caricaStatistiche()]);
  } catch (err) {
    errorePasswordProvvisoria(err);
    erroreEl.textContent = err.message;
    erroreEl.classList.remove('nascosto');
  } finally {
    bottone.disabled = false;
    bottone.textContent = 'Carica certificato';
  }
}

/** Popola il menu filtro "Dipendente" (GET /api/admin/utenti/options). */
async function caricaOpzioniDipendenti() {
  const select = document.getElementById('ce-dipendente');
  try {
    const { opzioni } = await api('/api/admin/utenti/options');
    opzioniDipendenti = opzioni; // [v2.2.9] cache per l'autocompletamento
    for (const o of opzioni) {
      const opt = document.createElement('option');
      opt.value = o.id;
      opt.textContent = `${o.matricola} — ${o.cognome} ${o.nome} · CF ${o.codice_fiscale}`; // v2.0
      select.appendChild(opt);
    }
  } catch { /* il filtro resta senza opzioni; non blocca la pagina */ }
}

/** GET /api/admin/certificati con i filtri correnti → vista globale COMPLETA.
 *  [v2.2.3] perPagina=tutti: la tabella mostra TUTTI i certificati che
 *  rispettano i filtri, senza paginazione né tagli visivi.
 *  Le azioni conditional (approva/rifiuta) compaiono solo per gli IN_ATTESA;
 *  l'eliminazione è sempre disponibile con conferma. */
async function caricaCertificati() {
  const tbody = document.querySelector('#tabella-certificati tbody');
  try {
    const qs = costruisciQuery({ ...filtriCert }); // [v2.3.5] impaginazione server-side (prima: perPagina='tutti')
    const dati = await api(`/api/admin/certificati?${qs}`);

    /* [v2.3.5] la pagina corrente non esiste più (es. ultima riga dell'ultima
     * pagina eliminata) → si ricade sull'ultima pagina disponibile. */
    if (dati.pagineTotali && filtriCert.pagina > dati.pagineTotali) {
      filtriCert.pagina = dati.pagineTotali;
      return caricaCertificati();
    }

    ultimiCertificati = dati.certificati; // [v2.2.9] per il dialog di modifica (pagina corrente)

    tbody.innerHTML = '';
    if (!dati.certificati.length) {
      tbody.innerHTML = '<tr><td colspan="7" class="vuoto">Nessun certificato trovato con questi filtri.</td></tr>';
    }

    for (const c of dati.certificati) {
      /* [v2.2.6] RIGA PRINCIPALE — 7 colonne, tutto visibile a 1024px+.
       * Le informazioni secondarie (caricamento, esame, documenti, note)
       * vanno nella riga di dettaglio espandibile, subito sotto. */
      /* [v2.2.7] pulsante di download nella colonna AZIONI: scarica subito il
       * documento (file unico o allegato singolo); con più allegati apre la
       * riga di dettaglio dove sono elencati tutti con nome e dimensione. */
      const fileSingolo = (c.allegati && c.allegati.length === 1)
        ? { href: `/api/certificati/allegati/${c.allegati[0].id}/file`, nome: c.allegati[0].nome }
        : (!c.allegati || !c.allegati.length)
          ? { href: `/api/certificati/${c.id}/file`, nome: c.nome_file_originale }
          : null;
      const bottoneAzioniFile = fileSingolo
        ? `<a class="btn piccolo secondario" href="${fileSingolo.href}"
             title="Scarica ${escapeHtml(fileSingolo.nome)}" aria-label="Scarica il documento">⬇</a>`
        : `<button class="btn piccolo secondario" data-azione="dettaglio" data-id="${c.id}"
             title="${c.allegati.length} documenti: apri i dettagli per scaricarli"
             aria-label="Apri i dettagli e scarica">⬇ ${c.allegati.length}</button>`;

      /* [v2.2.7] DETTAGLIO DOCUMENTI: nome originale, dimensione e pulsante
       * di download dedicato per ogni file. */
      const documentiDettaglio = (c.allegati && c.allegati.length)
        ? c.allegati.map((a) => `<div class="riga-documento">
            <span aria-hidden="true">${iconaTipo(a.tipo)}</span>
            <span class="tronca" title="${escapeHtml(a.nome)}">${escapeHtml(a.nome)}</span>
            <span class="cella-secondaria">${dimensioneUmana(a.dimensione_file)}</span>
            <a class="btn piccolo secondario btn-scarica" href="/api/certificati/allegati/${a.id}/file"
               title="Scarica ${escapeHtml(a.nome)}">⬇ Scarica</a></div>`).join('')
        : `<div class="riga-documento"><span aria-hidden="true">📄</span>
            <span class="tronca" title="${escapeHtml(c.nome_file_originale)}">${escapeHtml(c.nome_file_originale)}</span>
            <span class="cella-secondaria">${dimensioneUmana(c.dimensione_file)}</span>
            <a class="btn piccolo secondario btn-scarica" href="/api/certificati/${c.id}/file"
               title="Scarica ${escapeHtml(c.nome_file_originale)}">⬇ Scarica</a></div>`;

      const tr = document.createElement('tr');
      tr.className = 'riga-principale';
      tr.tabIndex = 0;
      tr.setAttribute('aria-expanded', 'false');
      tr.innerHTML = `
        <td><div class="cella-principale"><span class="freccia-espandi" aria-hidden="true"
              title="Apri/chiudi i dettagli">▸</span> ${escapeHtml(c.matricola)}</div>
            <div class="cella-secondaria">${escapeHtml(c.cognome)} ${escapeHtml(c.nome)}</div>
            <div class="cella-secondaria tronca" title="${escapeHtml(c.qualifica || '')}">${escapeHtml(c.qualifica || '—')}</div></td>
        <td><div class="tronca" title="${escapeHtml(c.nome_corso)}">${escapeHtml(c.nome_corso)}</div>
            <div class="cella-secondaria tronca" title="${escapeHtml(c.ente_erogatore)}">${escapeHtml(c.ente_erogatore)}</div></td>
        <td>${dataIt(c.data_conseguimento)}</td>
        <td>${formattaDurata(c.numero_ore, c.numero_minuti)}
            ${c.esame_finale ? '<span class="badge mini verde" title="Corso con esame finale">Esame ✓</span>' : ''}</td>
        <td class="tronca" title="${escapeHtml(c.area_tematica)}">${escapeHtml(c.area_tematica)}</td>
        <td>${badgeStato(c.stato)}</td>
        <td class="azioni-cell">
          <div class="azioni">
            ${bottoneAzioniFile}
            <button class="btn piccolo secondario" data-azione="modifica-cert" data-id="${c.id}"
              title="Modifica i metadati del certificato">✏️</button>
            ${c.stato === 'IN_ATTESA' ? `
              <button class="btn piccolo successo" data-azione="approva" data-id="${c.id}"
                data-nome="${escapeHtml(c.cognome)} ${escapeHtml(c.nome)}" title="Approva">✔</button>
              <button class="btn piccolo pericolo" data-azione="rifiuta" data-id="${c.id}"
                data-nome="${escapeHtml(c.cognome)} ${escapeHtml(c.nome)}" title="Rifiuta">✖</button>` : ''}
            <button class="btn piccolo pericolo" data-azione="elimina" data-id="${c.id}"
              data-corso="${escapeHtml(c.nome_corso)}" title="Elimina definitivamente">🗑</button>
          </div>
        </td>`;
      tbody.appendChild(tr);

      /* RIGA DI DETTAGLIO (nascosta): ciò che non serve «a colpo d'occhio»:
       * data/peso di caricamento, esame, documenti (pulsanti «Scarica» v2.2.4
       * con il nome completo nel suggerimento) e note dell'amministratore. */
      const det = document.createElement('tr');
      det.className = 'riga-dettaglio nascosto';
      det.dataset.dettaglio = c.id;
      det.innerHTML = `
        <td colspan="7">
          <div class="griglia-dettaglio">
            <div><div class="dettaglio-titolo">Caricato il</div>
                 <div>${dataOraIt(c.caricato_il)}</div>
                 <div class="cella-secondaria">${dimensioneUmana(c.dimensione_file)}</div></div>
            <div><div class="dettaglio-titolo">Esame finale</div>
                 <div>${c.esame_finale ? 'Sì' : 'No'}</div></div>
            <div><div class="dettaglio-titolo">Documenti</div>
                 <div class="elenco-documenti">${documentiDettaglio}</div></div>
            <div><div class="dettaglio-titolo">Note</div>
                 <div>${c.note_admin ? escapeHtml(c.note_admin) : '—'}</div></div>
          </div>
        </td>`;
      tbody.appendChild(det);
    }

    /* [v2.3.5] impaginazione della tabella certificati (server-side).
     * [v2.3.10] con un backend che non fornisce i metadati il pager si
     * nasconde (mai «Pagina undefined»); la tabella mostra l'elenco ricevuto. */
    if (Number.isFinite(dati.pagineTotali)) {
      renderPaginazione('paginazione-certificati', dati, (p) => { filtriCert.pagina = p; caricaCertificati(); });
    }
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="vuoto">Errore: ${escapeHtml(err.message)}</td></tr>`;
  }
}

/** [v2.2.6] Apre/chiude la riga di dettaglio di una riga principale. */
function toggleDettaglio(riga) {
  const dettaglio = riga.nextElementSibling;
  if (!dettaglio || !dettaglio.classList.contains('riga-dettaglio')) return;
  const oraChiuso = dettaglio.classList.toggle('nascosto');
  riga.classList.toggle('aperta', !oraChiuso);
  riga.setAttribute('aria-expanded', oraChiuso ? 'false' : 'true');
}

/** [v2.2.6] Espansione riga (master-detail): un click sulla riga principale
 *  apre/chiude la riga di dettaglio sottostante. I click su pulsanti e link
 *  (approva/rifiuta/elimina/scarica) NON attivano l'espansione. */
function espandiDettaglio(e) {
  if (e.target.closest('button, a')) return;
  const riga = e.target.closest('tr.riga-principale');
  if (!riga) return;
  toggleDettaglio(riga);
}

/** Event delegation sulla tabella certificati: approva (diretto), rifiuta
 *  (dialog con motivazione), elimina (dialog di conferma). */
async function azioneCertificato(e) {
  const btn = e.target.closest('button[data-azione]');
  if (!btn) return;
  const id = Number(btn.dataset.id);

  /* [v2.2.9] modifica metadati del certificato. */
  if (btn.dataset.azione === 'modifica-cert') {
    apriModificaCert(id);
    return;
  }

  /* [v2.2.7] «⬇ n» nella colonna Azioni (corso con più allegati): apre la
   * riga di dettaglio, dove ogni documento ha nome, dimensione e download. */
  if (btn.dataset.azione === 'dettaglio') {
    const riga = btn.closest('tr.riga-principale');
    if (riga) toggleDettaglio(riga);
    return;
  }

  if (btn.dataset.azione === 'approva') {
    try {
      const dati = await api(`/api/admin/certificati/${id}/stato`, {
        method: 'PUT', body: { stato: 'APPROVATO' },
      });
      toast(dati.messaggio, 'successo');
      await Promise.all([caricaCertificati(), caricaStatistiche()]);
    } catch (err) { if (!errorePasswordProvvisoria(err)) toast(err.message, 'errore'); }
    return;
  }

  if (btn.dataset.azione === 'rifiuta') {
    rifiutaTarget = id;
    document.getElementById('ri-testo').textContent =
      `Rifiutare il certificato di ${btn.dataset.nome}? Puoi indicare una motivazione.`;
    document.getElementById('ri-note').value = '';
    document.getElementById('dlg-rifiuta').showModal();
    return;
  }

  if (btn.dataset.azione === 'elimina') {
    const ok = await conferma(
      `Eliminare definitivamente il certificato "${btn.dataset.corso}"? Anche il file PDF sarà rimosso dal server.`,
      { titolo: 'Elimina certificato', etichetta: 'Elimina' }
    );
    if (!ok) return;
    try {
      const dati = await api(`/api/admin/certificati/${id}`, { method: 'DELETE' });
      toast(dati.messaggio, 'successo');
      await Promise.all([caricaCertificati(), caricaStatistiche()]);
    } catch (err) { if (!errorePasswordProvvisoria(err)) toast(err.message, 'errore'); }
  }
}

/** Conferma del rifiuto: PUT /:id/stato con stato=RIFIUTATO + nota. */
async function eseguiRifiuta(e) {
  e.preventDefault();
  try {
    const dati = await api(`/api/admin/certificati/${rifiutaTarget}/stato`, {
      method: 'PUT',
      body: { stato: 'RIFIUTATO', note: document.getElementById('ri-note').value.trim() },
    });
    chiudi('dlg-rifiuta');
    toast(dati.messaggio, 'successo');
    await Promise.all([caricaCertificati(), caricaStatistiche()]);
  } catch (err) { if (!errorePasswordProvvisoria(err)) toast(err.message, 'errore'); }
}

/** [v2.2.7] Legge un campo durata del filtro («8», «1:30»…, vuoto = senza
 *  limite) e lo converte in MINUTI; il valore non valido non filtra e il
 *  campo resta evidenziato in rosso finché non viene corretto. */
function leggiDurataFiltro(id) {
  const el = document.getElementById(id);
  const testo = el.value.trim();
  if (testo === '') { el.classList.remove('input-nonvalido'); return ''; }
  const d = parserDurata(testo);
  if (!d) { el.classList.add('input-nonvalido'); return ''; }
  el.classList.remove('input-nonvalido');
  return String(d.ore * 60 + d.minuti);
}

/** Ripristina tutti i filtri certificati ai valori di default e ricarica. */
function azzeraFiltri() {
  document.getElementById('ce-q').value = '';
  document.getElementById('ce-stato').value = '';
  document.getElementById('ce-area').value = '';
  document.getElementById('ce-esame').value = '';
  document.getElementById('ce-dipendente').value = '';
  document.getElementById('ce-dal').value = '';
  document.getElementById('ce-al').value = '';
  document.getElementById('ce-durata-min').value = '';
  document.getElementById('ce-durata-max').value = '';
  document.querySelectorAll('.durata-filtri .input-nonvalido').forEach((el) => el.classList.remove('input-nonvalido'));
  Object.assign(filtriCert, { pagina: 1, q: '', stato: '', dipendenteId: '', dal: '', al: '', area: '', esame: '', durataMin: '', durataMax: '' });
  caricaCertificati();
}

function esportaCsv() {
  // Rispetta i filtri correnti; il download usa il cookie di sessione.
  // (Prima si usava window.open('_blank'), che lasciava aperta una tab vuota
  //  ed era esposto al blocco popup del browser: ora usiamo un link temporaneo
  //  con l'attributo download → file scaricato, nessuna tab aggiuntiva.)
  const qs = costruisciQuery({ ...filtriCert });
  const link = document.createElement('a');
  link.href = `/api/admin/certificati/export${qs ? `?${qs}` : ''}`;
  link.setAttribute('download', '');
  document.body.appendChild(link);
  link.click();
  link.remove();
  toast('Esportazione CSV avviata.', 'info');
}

/* ============================================================
   IMPORTAZIONE MASSIVA DA CSV  (v1.3)
   Pannello: dialog con file + opzioni → report con contatori,
   password generate, errori riga per riga. Il motore (validazione,
   bcrypt, cartelle, duplicati) vive sul server in utils/importazione.js
   ed è lo stesso dello script CLI db/import-dipendenti.js.
   ============================================================ */

/** Contenuto del modello CSV scaricabile dall'operatore. */
function contenutoModelloCsv() {
  return [
    'nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale;email;ruolo;password_temporanea',
    'Maria;Carta;30011;CRTMRA80A01H501U;F;Istruttore direttivo;maria.carta@comune.it;DIPENDENTE;Benvenuto2026',
    'Luigi;Spano;30012;SPNLUJ85M20D963T;M;Agente di polizia locale;;DIPENDENTE;',
    'Sara;Melis;30013;MLSSRA90C45G822W;F;Assistente amministrativo;sara.melis@comune.it;DIPENDENTE;',
  ].join('\r\n');
}

/** Download client-side del modello (Blob: nessuna chiamata al server). */
function scaricaModelloCsv(e) {
  e.preventDefault();
  const blob = new Blob(['\uFEFF' + contenutoModelloCsv()], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'modello_dipendenti.csv';
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

/** Apre il dialog nella vista "modulo" (azzerato). */
function apriImporta() {
  document.getElementById('form-importa').reset();
  document.getElementById('imp-errore').classList.add('nascosto');
  document.getElementById('imp-view-form').classList.remove('nascosto');
  const risultato = document.getElementById('imp-view-risultato');
  risultato.classList.add('nascosto');
  risultato.innerHTML = '';
  document.getElementById('dlg-importa').showModal();
}

/** Submit del dialog: invia file + opzioni al backend e mostra il report. */
async function eseguiImporta(e) {
  e.preventDefault();
  const erroreEl = document.getElementById('imp-errore');
  const bottone = document.getElementById('imp-btn');
  erroreEl.classList.add('nascosto');

  const file = document.getElementById('imp-file').files[0];
  if (!file) { mostraErroreImporta('Seleziona il file CSV da importare.'); return; }

  const formData = new FormData();
  formData.append('file', file);
  formData.append('duplicati', document.getElementById('imp-duplicati').value);
  formData.append('dry_run', document.getElementById('imp-dryrun').checked ? '1' : '0');

  bottone.disabled = true;
  bottone.textContent = 'Elaborazione in corso…';
  try {
    const dati = await api('/api/admin/utenti/import', { method: 'POST', formData });
    renderRisultatoImporta(dati);
    // Solo se l'import è reale: tabella e statistiche possono essere cambiate
    if (!dati.dryRun) await Promise.all([caricaDipendenti(), caricaStatistiche()]);
  } catch (err) {
    errorePasswordProvvisoria(err);
    mostraErroreImporta(err.message);
  } finally {
    bottone.disabled = false;
    bottone.textContent = 'Verifica e importa';
  }
}

function mostraErroreImporta(msg) {
  const erroreEl = document.getElementById('imp-errore');
  erroreEl.textContent = msg;
  erroreEl.classList.remove('nascosto');
}

/** Copia negli appunti con fallback (su http di intranet l'API async
 *  navigator.clipboard può non essere disponibile). */
async function copiaNegliAppunti(testo) {
  try {
    await navigator.clipboard.writeText(testo);
    toast('Elenco copiato negli appunti.', 'successo');
  } catch {
    const ta = document.createElement('textarea');
    ta.value = testo;
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); toast('Elenco copiato negli appunti.', 'successo'); }
    catch { toast('Copia non riuscita: seleziona il testo manualmente.', 'errore'); }
    ta.remove();
  }
}

/** Render del report importazione nella seconda vista del dialog. */
function renderRisultatoImporta(dati) {
  const e = dati.esito;
  const vista = document.getElementById('imp-view-risultato');
  document.getElementById('imp-view-form').classList.add('nascosto');
  vista.classList.remove('nascosto');

  const chip = (testo, classe = 'grigio') => `<span class="badge ${classe}">${escapeHtml(testo)}</span>`;

  let html = `
    <h3>Esito dell'importazione ${dati.dryRun ? '<span class="badge ambra">PROVA GENERALE — nessuna modifica salvata</span>' : ''}</h3>
    <div style="display:flex; flex-wrap:wrap; gap:.4rem; margin:.7rem 0 1rem">
      ${chip(`Righe elaborate: ${e.elaborati}`, 'blu')}
      ${chip(`Nuovi account: ${e.creati.length}`, 'verde')}
      ${chip(`Aggiornati: ${e.aggiornati.length}`, 'blu')}
      ${chip(`Saltati: ${e.saltati.length}`, 'ambra')}
      ${chip(`Errori: ${e.errori.length}`, e.errori.length ? 'rosso' : 'grigio')}
      ${e.righeVuoteIgnorate ? chip(`Righe vuote ignorate: ${e.righeVuoteIgnorate}`, 'grigio') : ''}
    </div>`;

  /* --- Nuovi account creati (+ password provvisorie generate) --- */
  if (e.creati.length) {
    html += `<h3>Nuovi account</h3>
      <div class="tabella-wrap" style="max-height:230px; overflow:auto">
        <table class="dati">
          <thead><tr><th>Matricola</th><th>Dipendente</th><th>Password provvisoria</th></tr></thead>
          <tbody>`;
    for (const c of e.creati) {
      const pw = dati.dryRun ? '— (verifica)'
        : (c.predefinita ? 'Benvenuto@2026 (predefinita)'
          : (c.generata ? c.password : '(quella indicata nel file)'));
      html += `<tr>
        <td class="cella-principale">${escapeHtml(c.matricola)}</td>
        <td>${escapeHtml(c.nome)}</td>
        <td>${escapeHtml(pw)}</td>
      </tr>`;
    }
    html += `</tbody></table></div>
      <p class="hint">Comunicare le password ai dipendenti: al primo accesso sarà
      obbligatorio sostituirle. Le password generate NON saranno più visibili.</p>`;

    const credenziali = e.creati.filter((c) => c.password).map((c) => `${c.matricola};${c.password}`).join('\n');
    if (credenziali && !dati.dryRun) {
      html += `<div class="azioni" style="margin-top:.5rem">
        <button class="btn piccolo secondario" id="imp-copia">📋 Copia matricole e password generate</button>
        <button class="btn piccolo secondario" id="imp-scarica">⬇ Scarica credenziali (CSV)</button>
      </div>`;
    }
  }

  /* --- Record saltati (matricole già presenti) --- */
  if (e.saltati.length) {
    html += `<h3 style="margin-top:1rem">Record saltati</h3>
      <div class="tabella-wrap" style="max-height:180px; overflow:auto">
        <table class="dati">
          <thead><tr><th>Matricola</th><th>Motivo</th></tr></thead>
          <tbody>${e.saltati.map((s) => `
            <tr><td class="cella-principale">${escapeHtml(s.matricola)}</td><td>${escapeHtml(s.motivo)}</td></tr>`).join('')}
          </tbody>
        </table>
      </div>`;
  }

  /* --- Aggiornati (opzione duplicati = aggiorna) --- */
  if (e.aggiornati.length) {
    html += `<h3 style="margin-top:1rem">Record aggiornati</h3>
      <p class="hint">${e.aggiornati.map((a) => escapeHtml(a.matricola)).join(', ')}</p>`;
  }

  /* --- Righe con errori --- */
  if (e.errori.length) {
    html += `<h3 style="margin-top:1rem">Righe con errori <span class="badge rosso">${e.errori.length}</span></h3>
      <div class="tabella-wrap" style="max-height:200px; overflow:auto">
        <table class="dati">
          <thead><tr><th>Riga file</th><th>Matricola</th><th>Errore</th></tr></thead>
          <tbody>${e.errori.map((er) => `
            <tr><td>${er.riga}</td><td class="cella-principale">${escapeHtml(er.matricola)}</td><td>${escapeHtml(er.errore)}</td></tr>`).join('')}
          </tbody>
        </table>
      </div>
      <p class="hint">Correggere queste righe nel file e rilanciare l'importazione:
      le righe corrette già importate verranno riconosciute come duplicati e saltate.</p>`;
  }

  html += `<div class="azioni" style="margin-top:1.1rem">
    <button class="btn primario" id="imp-chiudi">Chiudi</button>
  </div>`;
  vista.innerHTML = html;

  /* --- Binding dei pulsanti creati dinamicamente --- */
  document.getElementById('imp-chiudi').addEventListener('click', () => chiudi('dlg-importa'));
  const btnCopia = document.getElementById('imp-copia');
  const btnScarica = document.getElementById('imp-scarica');
  const credenzialiOut = (e.creati || []).filter((c) => c.password).map((c) => `${c.matricola};${c.password}`).join('\r\n');

  if (btnCopia) btnCopia.addEventListener('click', () => copiaNegliAppunti(credenzialiOut));
  if (btnScarica) {
    btnScarica.addEventListener('click', () => {
      const csv = '\uFEFF' + 'matricola;password_temporanea\r\n' + credenzialiOut;
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'credenziali_dipendenti.csv';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    });
  }
}

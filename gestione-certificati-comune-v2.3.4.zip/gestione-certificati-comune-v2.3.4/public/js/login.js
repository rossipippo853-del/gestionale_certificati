/**
 * login.js — logica della pagina di accesso.
 * [FIX QA-B6] spostato dal codice inline in index.html: la Content-Security-Policy
 * restrittiva (script-src 'self') vieta gli script inline.
 *
 * [v2.1] FLUSSO DI PRIMO ACCESSO CON PASSWORD PROVVISORIA
 *  1. l'utente invia matricola + password provvisoria;
 *  2. il backend verifica le credenziali e, se must_change_password = 1, NON
 *     emette la sessione: risponde { primoAccesso: true } e deposita un cookie
 *     monouso `token_cambio` (15 minuti, httpOnly);
 *  3. questa pagina apre la MODALE BLOCCANTE "Primo Accesso — Cambio Password
 *     Obbligatorio": nessuna 'X', ESC annullato, nessuna chiusura cliccando
 *     fuori (i <dialog> nativi non chiudono al click esterno e qui non lo
 *     gestiamo) — l'utente NON può raggiungere la dashboard finché non cambia
 *     la password, perché nessun cookie di sessione esiste ancora;
 *  4. il form della modale invia { nuovaPassword, confermaPassword } a
 *     POST /api/auth/primo-accesso: a gesto compiuto il backend aggiorna
 *     l'hash bcrypt, azzera il flag, revoca il cookie di cambio ed EMETTE la
 *     sessione → redirect automatico alla dashboard in base al ruolo.
 */
'use strict';

(async () => {
  // Se c'è già una sessione valida, salta il login.
  // NOTA: su questa pagina api() NON reindirizza mai in caso di 401
  // (guardia "sullaPaginaLogin" in common.js) → nessun loop di ricaricamento.
  try {
    const { utente } = await api('/api/auth/me');
    location.href = utente.ruolo === 'AMMINISTRATORE' ? '/admin' : '/dipendente';
    return;
  } catch { /* nessuna sessione: restiamo sul login */ }

  const form = document.getElementById('form-login');
  const errore = document.getElementById('login-errore');
  const bottone = document.getElementById('login-bottone');

  /* ---------- [v2.1] Riferimenti alla modale di primo accesso ---------- */
  const dlg = document.getElementById('dlg-primo-accesso');
  const formCambio = document.getElementById('form-primo-accesso');
  const paNuova = document.getElementById('pa-nuova');
  const paConferma = document.getElementById('pa-conferma');
  const paErrore = document.getElementById('pa-errore');
  const paBottone = document.getElementById('pa-bottone');

  /** Modale BLOCCANTE: intercetta ESC ('cancel') e non prevede altri canali
   *  di chiusura. L'unico modo per proseguire è completare il cambio. */
  dlg.addEventListener('cancel', (e) => e.preventDefault());

  function apriCambioObbligatorio(utente) {
    document.getElementById('pa-nome-utente').textContent =
      `${utente.nome} ${utente.cognome} (matricola ${utente.matricola})`;
    // il form di login torna pronto per un eventuale nuovo tentativo
    bottone.disabled = false;
    bottone.textContent = 'Accedi';
    errore.classList.add('nascosto');
    paNuova.value = '';
    paConferma.value = '';
    paErrore.classList.add('nascosto');
    dlg.showModal();
    paNuova.focus();
  }

  /** Validazioni CLIENT della modale (quelle reali restano server-side). */
  function validaClient(nuova, conferma) {
    if (!nuova) return { campo: paNuova, messaggio: 'Inserisci la nuova password.' };
    if (nuova.length < 8 || nuova.length > 72 || !/[A-Za-z]/.test(nuova) || !/\d/.test(nuova)) {
      return { campo: paNuova, messaggio: 'La password deve essere lunga almeno 8 caratteri e contenere lettere e numeri (max 72).' };
    }
    if (!conferma) return { campo: paConferma, messaggio: 'Conferma la nuova password.' };
    if (nuova !== conferma) return { campo: paConferma, messaggio: 'Le due password non coincidono.' };
    return null;
  }

  formCambio.addEventListener('submit', async (e) => {
    e.preventDefault();
    paErrore.classList.add('nascosto');

    const nuova = paNuova.value;
    const conferma = paConferma.value;
    const difetto = validaClient(nuova, conferma);
    if (difetto) {
      paErrore.textContent = difetto.messaggio;
      paErrore.classList.remove('nascosto');
      difetto.campo.focus();
      return;
    }

    paBottone.disabled = true;
    paBottone.textContent = 'Salvataggio…';
    try {
      const risposta = await api('/api/auth/primo-accesso', {
        method: 'POST',
        body: { nuovaPassword: nuova, confermaPassword: conferma },
      });
      /* [v2.3.1] sessione di scheda anche qui (v. /login). */
      salvaToken(risposta.token);
      // Sessione emessa: si entra direttamente nella propria dashboard.
      location.href = risposta.utente.ruolo === 'AMMINISTRATORE' ? '/admin' : '/dipendente';
    } catch (err) {
      // Errori mostrati DENTRO la modale (che resta aperta e bloccante).
      paErrore.textContent = err.status === 401
        ? 'Sessione di cambio scaduta: effettua di nuovo il login.'
        : err.message;
      paErrore.classList.remove('nascosto');
      paBottone.disabled = false;
      paBottone.textContent = 'Conferma e Salva Nuova Password';
    }
  });

  /* ------------------------------ LOGIN ------------------------------ */
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errore.classList.add('nascosto');
    bottone.disabled = true;
    bottone.textContent = 'Accesso in corso…';
    try {
      const risposta = await api('/api/auth/login', {
        method: 'POST',
        body: {
          matricola: document.getElementById('login-matricola').value.trim(),
          password: document.getElementById('login-password').value,
        },
      });
      if (risposta.primoAccesso) {          // [v2.1] password provvisoria:
        apriCambioObbligatorio(risposta.utente); // modale bloccante, niente sessione
        return;
      }
      /* [v2.3.1] sessione di SCHEDA: il token va in sessionStorage (muore
       * alla chiusura della scheda; le pagine lo rimandano via header). */
      salvaToken(risposta.token);
      location.href = risposta.utente.ruolo === 'AMMINISTRATORE' ? '/admin' : '/dipendente';
    } catch (err) {
      errore.textContent = err.message;
      errore.classList.remove('nascosto');
      bottone.disabled = false;
      bottone.textContent = 'Accedi';
    }
  });
})();

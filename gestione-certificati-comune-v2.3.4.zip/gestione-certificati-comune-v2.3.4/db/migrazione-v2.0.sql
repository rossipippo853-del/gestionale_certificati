-- ============================================================================
--  MIGRAZIONE v1.x → v2.0 — Introduzione del CODICE FISCALE (chiave cartelle PDF)
--  Eseguire UNA SOLA VOLTA su un database esistente:  mysql -u root -p < db/migrazione-v2.0.sql
--
--  Note:
--   · i record pre-esistenti NON hanno un Codice Fiscale reale: la migrazione
--     assegna un segnaposto UNIVOCO «X» + id a 15 cifre (es. X000000000000007),
--     riconoscibile al volo, che l'amministratore sostituirà dal pannello o
--     via SQL con il valore anagrafico corretto;
--   · le cartelle PDF dei dipendenti storici restano nominate con la MATRICOLA
--     (i percorsi sono registrati nel DB e continuano a funzionare); le NUOVE
--     cartelle nascono con il Codice Fiscale. Per uniformare i vecchi archivi:
--     1) aggiornare il codice_fiscale di ogni dipendente,
--     2) rinominare le cartelle (uploads/certificati/{matricola} → {cf}) e
--     3) aggiornare i percorsi:
--        UPDATE certificati c JOIN dipendenti d ON d.id = c.dipendente_id
--        SET c.percorso_file = REPLACE(c.percorso_file, CONCAT('certificati/', d.matricola, '/'), CONCAT('certificati/', d.codice_fiscale, '/'));
-- ============================================================================
USE certificati_comune;

-- 1) colonna (NULL temporaneamente per popolarla senza collisioni)
ALTER TABLE dipendenti
  ADD COLUMN codice_fiscale VARCHAR(16) NULL AFTER matricola;

-- 2) segnaposto univoco deterministico per le anagrafiche esistenti
UPDATE dipendenti
  SET codice_fiscale = CONCAT('X', LPAD(id, 15, '0'))
  WHERE codice_fiscale IS NULL;

-- 3) vincoli definitivi: NOT NULL + UNIVOCO (usato anche come nome cartella)
ALTER TABLE dipendenti
  MODIFY codice_fiscale VARCHAR(16) NOT NULL,
  ADD UNIQUE KEY uq_dipendenti_cf (codice_fiscale);

-- 4) verifica consigliata
--    SELECT id, matricola, codice_fiscale FROM dipendenti ORDER BY id LIMIT 10;

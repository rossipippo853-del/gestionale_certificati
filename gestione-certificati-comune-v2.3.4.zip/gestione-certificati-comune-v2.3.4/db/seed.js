/**
 * db/seed.js — Popolamento iniziale del database.
 *
 * Uso:  node db/seed.js [--dipendenti=250] [--skip-certificati]
 *
 * Crea:
 *  - 1 account AMMINISTRATORE  → matricola "admin"    / password "Admin@2026"
 *  - N dipendenti dimostrativi → matricola 10001...   / password "Benvenuto@2026"
 *  - un set di certificati di esempio con PDF reali minimali nello storage.
 *
 * Lo script è idempotente: se l'admin esiste già non fa nulla (nessuna sovrascrittura).
 */
require('dotenv').config();

const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { pool } = require('../src/db');
const { DIR_CERTIFICATI } = require('../src/utils/file');

const args = process.argv.slice(2);
const nDipendenti = Math.max(0,
  Number.parseInt((args.find(a => a.startsWith('--dipendenti=')) || '--dipendenti=12').split('=')[1], 10) || 12);
const skipCertificati = args.includes('--skip-certificati');

const ADMIN = { matricola: 'admin', nome: 'Ufficio', cognome: 'Sistema', password: 'Admin@2026' };
const PASSWORD_DIPENDENTI = 'Benvenuto@2026';

const NOMI = ['Mario', 'Luigi', 'Anna', 'Maria', 'Giuseppe', 'Rosa', 'Antonio', 'Chiara',
  'Francesco', 'Alessandra', 'Giovanni', 'Laura', 'Salvatore', 'Giulia', 'Vincenzo', 'Sara',
  'Calogero', 'Valentina', 'Rosario', 'Francesca', 'Ignazio', 'Simona', 'Girolamo', 'Paola'];
const COGNOMI = ['Rossi', 'Ferraro', 'Russo', 'Grasso', 'Messina', 'Greco', 'Bellomo', 'La Mantia',
  'Catalfamo', 'Amato', 'Pizzo', 'Lo Presti', 'Cascio', 'Di Liberto', 'Orlando', 'Marino',
  'Guadagnino', 'Bonsignore', 'Santoro', 'Rizzo', 'Vitale', 'Ciminata', 'Scaduto', 'Aliotta'];

/** v2.0: genera un Codice Fiscale DEMO con formato italiano valido e
 *  univoco (le cifre centrali derivano dall'indice). NON è un CF reale. */
function cfDemo(nome, cognome, indice) {
  const lettere = (s) => s.toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Z]/g, '').replace(/[AEIOU]/g, '').padEnd(3, 'X').slice(0, 3);
  const MESI = 'ABCDEHLMPRST';
  return `${lettere(cognome)}${lettere(nome)}` +
    `${String(55 + (indice % 45)).padStart(2, '0')}` +   // anno di nascita fittizio
    `${MESI[indice % MESI.length]}` +                     // mese (lettera)
    `${String(1 + (indice % 28)).padStart(2, '0')}` +     // giorno
    `A${String(100 + (indice % 900)).padStart(3, '0')}X`; // comune fittizio + CIN
}

/** v1.4: qualifiche professionali e aree tematiche per i dati dimostrativi. */
const QUALIFICHE = [
  'Istruttore direttivo', 'Funzionario amministrativo', 'Agente di polizia locale',
  'Assistente amministrativo', 'Dirigente', 'Collaboratore amministrativo',
];
/* [v2.2.5] aree tematiche aggiornate all'elenco a 17 voci */
const AREE = [
  'Conoscenza dello specifico contesto lavorativo',
  'Gestione Economico-Finanziaria Enti Locali',
  'Innovazione Digitale e Transizione Digitale',
  'Lingue straniere',
  'Corsi obbligatori(Salute e sicurezza sul lavoro)',
  'Privacy,anticorruzione,antiriciclaggio,trasparenza',
  'Salvaguardia/Impatto ambientale',
  'Ambiente',
  'Risorse umane',
  'Codice appalti e e-procurement',
  'Servizi sociali',
  'Edilizia e urbanistica',
  'GDPR e trattamento dei dati personali',
  'Attività Produttive e Sviluppo Economico',
  'Polizia Locale e Sicurezza Urbana',
  'Affari Generali, Demografici e Statistica',
  'Altro',
];

const CORSI = [
  ['Sicurezza sul lavoro - Formazione generale (D.Lgs. 81/08)', 'Ente Formazione Sicurezza Srl'],
  ['Sicurezza sul lavoro - Formazione specifica', 'Ente Formazione Sicurezza Srl'],
  ['Antincendio - Addetto di basso rischio', 'Centro Formazione Vigili del Fuoco'],
  ['Primo soccorso aziendale', 'Croce Rossa Italiana'],
  ['Privacy e protezione dei dati (GDPR)', 'Scuola Superiore della P.A.'],
  ['Cybersecurity di base per la PA', 'Istituto per l\'Informatica e Telematica'],
  ['Accessibilita digitale degli servizi online', 'Accademia Digitale Nazionale'],
  ['Excel per ufficio - livello avanzato', 'Centro Formazione Informatica'],
  ['Protocollo informatico e gestione documentale', 'Scuola Superiore della P.A.'],
  ['Contratti pubblici - aggiornamento annuale', 'Scuola Superiore della P.A.'],
];

/**
 * Genera un PDF minimale ma VALIDO (pagina singola, font Helvetica).
 * Costruisce "a mano" la struttura di un documento PDF 1.4: catalogo,
 * albero pagine, pagina, risorse font e stream di contenuto con il testo
 * delle righe; poi xref/trailer con gli offset calcolati. Utile per il seed:
 * i certificati demo sono apribili con qualunque lettore PDF.
 */
function generaPdf(righe) {
  const esc = (s) => s.replace(/[\\()]/g, (c) => '\\' + c);
  let stream = 'BT\n/F1 12 Tf\n16 TL\n60 780 Td\n';
  for (const r of righe) stream += `(${esc(r)}) Tj T*\n`;
  stream += 'ET';

  const oggetti = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
    `<< /Length ${Buffer.byteLength(stream, 'latin1')} >>\nstream\n${stream}\nendstream`,
  ];

  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  oggetti.forEach((o, i) => {
    offsets.push(Buffer.byteLength(pdf, 'latin1'));
    pdf += `${i + 1} 0 obj\n${o}\nendobj\n`;
  });
  const startxref = Buffer.byteLength(pdf, 'latin1');
  pdf += `xref\n0 ${oggetti.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= oggetti.length; i++) {
    pdf += String(offsets[i]).padStart(10, '0') + ' 00000 n \n';
  }
  pdf += `trailer\n<< /Size ${oggetti.length + 1} /Root 1 0 R >>\nstartxref\n${startxref}\n%%EOF\n`;
  return Buffer.from(pdf, 'latin1');
}

function slug(s) {
  return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 60);
}

async function main() {
  // Admin già presente? → nessuna operazione
  const [[{ esistenti }]] = await pool.query('SELECT COUNT(*) AS esistenti FROM dipendenti');
  if (esistenti > 0) {
    console.log('[SKIP] Il database contiene già utenti: seed annullato (script idempotente).');
    process.exit(0);
  }

  console.log(`[1/3] Creo l'account amministratore "${ADMIN.matricola}"...`);
  await pool.query(
    `INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, sesso, qualifica, email, password_hash, ruolo, attivo, must_change_password)
     VALUES (?, ?, ?, ?, 'M', 'Dirigente', ?, ?, 'AMMINISTRATORE', 1, 0)`,
    [ADMIN.matricola, cfDemo(ADMIN.nome, ADMIN.cognome, 0), ADMIN.nome, ADMIN.cognome, null,
     await bcrypt.hash(ADMIN.password, 10)]
  );

  console.log(`[2/3] Creo ${nDipendenti} dipendenti dimostrativi...`);
  const hashComune = await bcrypt.hash(PASSWORD_DIPENDENTI, 10);
  const creati = [];
  for (let i = 0; i < nDipendenti; i++) {
    const matricola = String(10001 + i);
    const nome = NOMI[i % NOMI.length];
    const cognome = COGNOMI[(i * 7 + 3) % COGNOMI.length];
    const sesso = ['F', 'M', 'F', 'F', 'M', 'F', 'M', 'F'][i % 8];
    const qualifica = QUALIFICHE[i % QUALIFICHE.length];
    const email = `${nome.toLowerCase()}.${cognome.toLowerCase().replace(/\s+/g, '')}.${matricola}@comune.demo`; // [v2.2.8] unica per dipendente
    const cf = cfDemo(nome, cognome, i + 1); // v2.0: CF demo univoco
    const [esito] = await pool.query(
      `INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, sesso, qualifica, email, password_hash, ruolo, attivo, must_change_password)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'DIPENDENTE', 1, 1)`,
      [matricola, cf, nome, cognome, sesso, qualifica, email, hashComune]
    );
    creati.push({ id: esito.insertId, matricola, codice_fiscale: cf, nome, cognome });
  }
  // Un paio di account disabilitati per provare la UI
  if (creati.length >= 5) {
    await pool.query('UPDATE dipendenti SET attivo = 0 WHERE matricola IN (?, ?)',
      [creati[3].matricola, creati[4].matricola]);
  }

  if (skipCertificati || !creati.length) {
    console.log('[3/3] Certificati di esempio: saltati.');
  } else {
    console.log('[3/3] Creo certificati di esempio (con PDF nello storage)...');
    fs.mkdirSync(DIR_CERTIFICATI, { recursive: true });
    const stati = ['APPROVATO', 'IN_ATTESA', 'APPROVATO', 'IN_ATTESA', 'RIFIUTATO'];
    const [[adminRow]] = await pool.query("SELECT id FROM dipendenti WHERE matricola = 'admin'");

    let n = 0;
    for (const [k, dip] of creati.slice(0, Math.min(40, creati.length)).entries()) {
      const quanti = 1 + (k % 3);
      for (let j = 0; j < quanti; j++) {
        n += 1;
        const [corso, ente] = CORSI[(k + j * 3) % CORSI.length];
        const anno = 2023 + ((k + j) % 3);
        const mese = String(1 + ((k * 5 + j) % 12)).padStart(2, '0');
        const giorno = String(1 + ((k * 11 + j * 7) % 27)).padStart(2, '0');
        const data = `${anno}-${mese}-${giorno}`;
        const stato = stati[(k + j) % stati.length];
        // v1.4: dettagli dimostrativi (ore, esame, area tematica)
        const numeroOre = 4 + ((k * 3 + j * 2) % 6) * 4;      // 4..24
        const esameFinale = (k + j) % 2;                       // 0/1
        const area = AREE[(k * 2 + j) % AREE.length];

        // PDF sul disco (v2.0): uploads/certificati/{codice_fiscale}/{timestamp}_{slug}.pdf
        const dir = path.join(DIR_CERTIFICATI, dip.codice_fiscale);
        fs.mkdirSync(dir, { recursive: true });
        const nomeFile = `${Date.now() - n * 1000}_${slug(corso)}.pdf`;
        fs.writeFileSync(path.join(dir, nomeFile), generaPdf([
          'CERTIFICATO DI PARTECIPAZIONE',
          '',
          `Corso: ${corso}`,
          `Ente: ${ente}`,
          `Data: ${giorno}/${mese}/${anno}`,
          `Partecipante: ${dip.cognome} ${dip.nome} (matr. ${dip.matricola})`,
        ]));

        const relativo = `certificati/${dip.codice_fiscale}/${nomeFile}`;
        const note = stato === 'RIFIUTATO' ? 'Scan illeggibile: ricaricare in migliore qualita.' : null;
        await pool.query(
          `INSERT INTO certificati (dipendente_id, nome_corso, ente_erogatore, data_conseguimento,
              numero_ore, numero_minuti, esame_finale, area_tematica,
              nome_file_originale, percorso_file, dimensione_file, stato, note_admin,
              approvato_da, approvato_il)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [dip.id, corso, ente, data, numeroOre, [0, 30, 45, 0][j % 4], esameFinale, area, // [FIX 2.2.2] era «indice» (non definito): crash al punto [3/3]
           `${slug(corso)}.pdf`, relativo,
           fs.statSync(path.join(dir, nomeFile)).size, stato, note,
           stato === 'IN_ATTESA' ? null : adminRow.id,
           stato === 'IN_ATTESA' ? null : `${anno}-${mese}-${giorno} 10:00:00`]
        );
      }
    }
    console.log(`       → inseriti ${n} certificati di esempio.`);
  }

  console.log('\n=== SEED COMPLETATO ===');
  console.log(`AMMINISTRATORE   → matricola: ${ADMIN.matricola}  password: ${ADMIN.password}`);
  if (nDipendenti > 0) {
    console.log(`DIPENDENTI DEMO  → matricola: ${creati[0].matricola} ... ${creati[creati.length - 1].matricola}`);
    console.log(`                   password comune: ${PASSWORD_DIPENDENTI} (cambio obbligatorio al primo accesso)`);
  }
  process.exit(0);
}

main().catch((err) => {
  console.error('[ERRORE SEED]', err);
  process.exit(1);
});

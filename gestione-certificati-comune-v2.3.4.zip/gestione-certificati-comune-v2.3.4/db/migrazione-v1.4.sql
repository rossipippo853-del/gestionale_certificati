-- ==============================================================================
--  MIGRAZIONE v1.3 → v1.4 — Gestione Certificati Dipendenti Comunali
-- ==============================================================================
--  Aggiunge le nuove colonne (profilo utente e dettagli certificato) a un
--  database GIÀ ESISTENTE, conservando tutti i dati presenti.
--
--  Esecuzione (UNA SOLA VOLTA):
--      mysql -u root -p < db/migrazione-v1.4.sql
--
--  ⚠ Non eseguire due volte: la seconda esecuzione restituirebbe
--    "Duplicate column name" (nessun danno, ma è un segnale che non serve).
--
--  Cosa fa:
--    dipendenti  → + sesso ENUM('M','F','ALTRO'), + qualifica VARCHAR(120)
--    certificati → + numero_ore, + esame_finale, + area_tematica (6 aree)
--
--  I record ESISTENTI ricevono i valori predefiniti indicati qui sotto
--  (sesso 'M', qualifica vuota, 0 ore, nessun esame, area di default):
--  le NUOVE registrazioni invece impongono sempre i campi obbligatori.
--  Per completare i dati storici a mano:
--      UPDATE dipendenti SET qualifica='Istruttore direttivo' WHERE matricola='10001';
--      UPDATE certificati SET numero_ore=8 WHERE id=1;
-- ==============================================================================

USE certificati_comune;

-- ---- DIPENDENTI: sesso e qualifica professionale -----------------------------
ALTER TABLE dipendenti
  ADD COLUMN sesso     ENUM('M','F','ALTRO') NOT NULL DEFAULT 'M' AFTER matricola,
  ADD COLUMN qualifica VARCHAR(120)          NOT NULL DEFAULT ''  AFTER sesso;

ALTER TABLE dipendenti
  ADD KEY idx_dipendenti_qualifica (qualifica);

-- ---- CERTIFICATI: ore, esame finale, area tematica ---------------------------
ALTER TABLE certificati
  ADD COLUMN numero_ore     INT UNSIGNED NOT NULL DEFAULT 0 AFTER data_conseguimento,
  ADD COLUMN esame_finale   TINYINT(1)   NOT NULL DEFAULT 0 AFTER numero_ore,
  ADD COLUMN area_tematica  ENUM('Competenze linguistiche',
                                 'Leadership e soft skills',
                                 'Principi e valori della PA',
                                 'Transizione digitale',
                                 'Transizione ecologica',
                                 'Transizione amministrativa')
                              NOT NULL DEFAULT 'Principi e valori della PA' AFTER esame_finale;

ALTER TABLE certificati
  ADD KEY idx_cert_area (area_tematica);

-- ---- Verifica rapida (opzionale) ---------------------------------------------
-- DESCRIBE dipendenti;
-- DESCRIBE certificati;

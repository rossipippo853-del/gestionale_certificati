-- ============================================================================
--  MIGRAZIONE v2.2 — Durata Ore:Minuti + allegati multipli (PDF/JPEG/PNG)
--  Per database creati con versione ≤ 2.1.x. Idempotente e CONSERVATIVA:
--  non modifica né cancella dati esistenti. Su un DB nuovo NON serve:
--  db/schema.sql è già aggiornato.
--  Uso:  mysql -u root -p certificati_comune < db/migrazione-v2.2.sql
-- ============================================================================

-- 1) Parte in MINUTI della durata del corso (0 = durate intere, come v1.x).
--    I corsi esistenti mantengono le loro ore: minuti restano a 0.
ALTER TABLE certificati
  ADD COLUMN IF NOT EXISTS numero_minuti INT UNSIGNED NOT NULL DEFAULT 0 AFTER numero_ore;

-- 2) Allegati multipli per corso (PDF, JPEG o PNG; max 5 MB ciascuno).
CREATE TABLE IF NOT EXISTS allegati (
  id                   INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  certificato_id       INT UNSIGNED     NOT NULL,
  percorso_file        VARCHAR(500)     NOT NULL,
  nome_originale       VARCHAR(255)     NOT NULL,
  tipo_file            ENUM('pdf','jpeg','png') NOT NULL DEFAULT 'pdf',
  dimensione_file      INT UNSIGNED     NOT NULL,
  caricato_il          TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_allegati_certificato (certificato_id),
  CONSTRAINT fk_allegati_certificato FOREIGN KEY (certificato_id)
    REFERENCES certificati (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3) (Opzionale, consigliato) Popola la tabella allegati con i file storici:
--    ogni certificato esistente diventa un allegato di tipo pdf.
--    Scommentare per eseguirla:
-- INSERT INTO allegati (certificato_id, percorso_file, nome_originale, tipo_file, dimensione_file, caricato_il)
--   SELECT id, percorso_file, nome_file_originale, 'pdf', dimensione_file, caricato_il
--   FROM certificati;

#!/usr/bin/env node
/**
 * ============================================================================
 *  db/import-dipendenti.js — IMPORTAZIONE MASSIVA DIPENDENTI DA RIGA DI COMANDO
 * ============================================================================
 *  Alternativa al pannello web per l'amministratore IT: usa lo STESSO motore
 *  di validazione/importazione dell'interfaccia (utils/importazione.js), quindi
 *  stesso formato file, stesse regole, stesso report.
 *
 *  USO:
 *    node db/import-dipendenti.js <file.csv> [opzioni]
 *
 *  Opzioni:
 *    --duplicati=ignora    se la matricola esiste già: salta (DEFAULT)
 *    --duplicati=aggiorna  se la matricola esiste già: aggiorna anagrafica
 *    --dry-run             sola verifica: nessuna scrittura su DB/cartelle
 *
 *  Esempi:
 *    node db/import-dipendenti.js dipendenti_comune.csv
 *    node db/import-dipendenti.js dipendenti_comune.csv --duplicati=aggiorna
 *    node db/import-dipendenti.js dipendenti_comune.csv --dry-run
 *    npm run importa -- dipendenti_comune.csv --dry-run
 *
 *  Requisiti: MySQL attivo e file .env configurato nella cartella del progetto
 *  (le credenziali del database sono lette dal .env, come per il server web).
 *
 *  Codici di uscita (utili in script/scheduler):
 *    0 = importazione completata senza errori
 *    1 = errore bloccante (file, argomenti, database)
 *    2 = importazione completata MA con righe in errore (vedi report)
 * ============================================================================
 */
require('dotenv').config();

const fs = require('fs');
const path = require('path');
const { analizzaCsv, eseguiImport, MAX_BYTE_FILE, MAX_RIGHE_IMPORT } = require('../src/utils/importazione');
const { pool } = require('../src/db');

/** Legge il valore di un'opzione --nome=valore (o il default). */
function opzione(nome, def) {
  const trovata = process.argv.find((a) => a.startsWith(`--${nome}=`));
  return trovata ? trovata.split('=').slice(1).join('=') : def;
}

function stampaUso() {
  console.log(`
Importazione massiva dipendenti — Gestione Certificati

USO:
  node db/import-dipendenti.js <file.csv> [--duplicati=ignora|aggiorna] [--dry-run]

FORMATO FILE (UTF-8, separatore ; , , o TAB — riconosciuto automaticamente):
  matricola;nome;cognome;email;ruolo;password_temporanea
  (obbligatorie: matricola, nome, cognome — le altre sono facoltative)
  Modello scaricabile: db/modello-dipendenti.csv
`);
}

async function main() {
  const fileArg = process.argv[2];
  const duplicati = opzione('duplicati', 'ignora');
  const dryRun = process.argv.includes('--dry-run');

  if (!fileArg || fileArg.startsWith('--') || process.argv.includes('--aiuto') || process.argv.includes('--help')) {
    stampaUso();
    process.exit(1);
  }
  if (!['ignora', 'aggiorna'].includes(duplicati)) {
    console.error(`[ERRORE] Opzione --duplicati non valida: "${duplicati}" (usare ignora oppure aggiorna).`);
    process.exit(1);
  }

  // --- Controlli sul file (prima di toccare il database) ---
  const assoluto = path.resolve(process.cwd(), fileArg);
  if (!fs.existsSync(assoluto)) {
    console.error(`[ERRORE] File non trovato: ${assoluto}`);
    process.exit(1);
  }
  if (!['.csv', '.txt'].includes(path.extname(assoluto).toLowerCase())) {
    console.error('[ERRORE] Formato non ammesso: serve un file CSV (.csv o .txt).');
    console.error('         Da Excel: "Salva con nome → CSV UTF-8 (delimitato dal punto e virgola)".');
    process.exit(1);
  }
  const dimensione = fs.statSync(assoluto).size;
  if (dimensione > MAX_BYTE_FILE) {
    console.error(`[ERRORE] File troppo grande (${(dimensione / 1024 / 1024).toFixed(1)} MB): il limite è 2 MB (${MAX_RIGHE_IMPORT} righe).`);
    process.exit(1);
  }

  // --- Analisi del contenuto ---
  const analisi = analizzaCsv(fs.readFileSync(assoluto, 'utf8'));
  if (!analisi.ok) {
    console.error(`[ERRORE] ${analisi.errore}`);
    process.exit(1);
  }

  console.log('════════════════════════════════════════════════════════════');
  console.log(' Importazione dipendenti — Gestione Certificati');
  console.log('════════════════════════════════════════════════════════════');
  console.log(` File:               ${assoluto}`);
  console.log(` Righe dati:         ${analisi.totaleRighe} (vuote ignorate: ${analisi.righeVuoteIgnorate})`);
  console.log(` Duplicati:          ${duplicati === 'aggiorna' ? 'AGGIORNA anagrafica' : 'IGNORA (salta)'}`);
  console.log(` Modalità:           ${dryRun ? 'PROVA GENERALE — nessuna modifica verrà salvata' : 'IMPORTAZIONE EFFETTIVA'}`);
  console.log('────────────────────────────────────────────────────────────');

  // --- Esecuzione (stesso motore del pannello web) ---
  const esito = await eseguiImport(analisi, { duplicati, dryRun });

  if (esito.creati.length) {
    console.log(`\n► NUOVI ACCOUNT (${esito.creati.length})`);
    for (const c of esito.creati) {
      const pw = dryRun ? '—' : (c.generata ? c.password : '(indicata nel file)');
      const nota = dryRun ? '' : (c.generata ? '(generata)' : '');
      console.log(`   ${c.matricola.padEnd(12)} ${c.nome.padEnd(30)} password: ${pw} ${nota}`);
    }
    if (!dryRun) {
      console.log('\n   ⚠ Conserva/comunica queste password: non saranno più visibili.');
      console.log('     Al primo accesso il dipendente dovrà sostituirle.');
    }
  }

  if (esito.aggiornati.length) {
    console.log(`\n► ACCOUNT AGGIORNATI (${esito.aggiornati.length})`);
    console.log(`   ${esito.aggiornati.map((a) => a.matricola).join(', ')}`);
    console.log('   (aggiornati nome, cognome, email, ruolo — password invariata)');
  }

  if (esito.saltati.length) {
    console.log(`\n► SALTATI — matricola già esistente (${esito.saltati.length})`);
    for (const s of esito.saltati) console.log(`   ${s.matricola.padEnd(12)} ${s.motivo}`);
  }

  if (esito.errori.length) {
    console.log(`\n► RIGHE CON ERRORI (${esito.errori.length}) — correggerle e rilanciare`);
    for (const er of esito.errori) {
      console.log(`   riga ${String(er.riga).padEnd(5)} ${er.matricola.padEnd(12)} ${er.errore}`);
    }
  }

  // --- Riepilogo finale ---
  console.log('\n────────────────────────────────────────────────────────────');
  console.log(` RIEPILOGO: elaborate ${esito.elaborati} · nuovi ${esito.creati.length} · aggiornati ${esito.aggiornati.length} · saltati ${esito.saltati.length} · errori ${esito.errori.length}`);
  if (dryRun) console.log(' (prova generale: NESSUNA modifica è stata salvata)');
  console.log('════════════════════════════════════════════════════════════');

  await pool.end();
  process.exit(esito.errori.length ? 2 : 0);
}

main().catch((err) => {
  console.error('\n[ERRORE FATALE]', err.message);
  console.error('Verificare che MySQL/MariaDB sia attivo e che il file .env sia corretto.');
  process.exit(1);
});

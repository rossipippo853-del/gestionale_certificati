-- ==============================================================================
--  Gestione Certificati Dipendenti Comunali
--  SCHEMA DEL DATABASE (v1.4.0) — MySQL 8.x / MariaDB 10.6+
--
--  Esecuzione:   mysql -u root -p < db/schema.sql
--  Idempotente:  CREATE ... IF NOT EXISTS → rieseguirlo non distrugge nulla.
--
--  ⚠ INSTALLAZIONE GIÀ ESISTENTE (v1.3 o precedente)? NON rieseguire questo
--    file: usa lo script di migrazione db/migrazione-v1.4.sql, che aggiunge
--    le nuove colonne con ALTER TABLE senza toccare i dati.
--
--  Nuove colonne in v1.4:
--    dipendenti.sesso                ENUM('M','F','ALTRO')   (obbligatorio)
--    dipendenti.qualifica            VARCHAR(120)            (obbligatorio)
--    certificati.numero_ore          INT UNSIGNED            (obbligatorio, ≥ 1)
--    certificati.esame_finale        TINYINT(1) 0/1          (obbligatorio)
--    certificati.area_tematica       VARCHAR(100), elenco in validazione.js (obbligatorio)
--
--  ⚠ Prima dell'uso in produzione: sostituire la password dell'utente
--    applicativo alla riga "IDENTIFIED BY" e riportarla nel file .env.
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS certificati_comune
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE certificati_comune;

-- ------------------------------------------------------------------------------
-- Utente applicativo con privilegi MINIMI (nessun DDL, solo dati).
-- ------------------------------------------------------------------------------
CREATE USER IF NOT EXISTS 'cert_app'@'localhost' IDENTIFIED BY 'CambiaQuestaPassword!';
GRANT SELECT, INSERT, UPDATE, DELETE ON certificati_comune.* TO 'cert_app'@'localhost';
FLUSH PRIVILEGES;

-- ------------------------------------------------------------------------------
-- Tabella DIPENDENTI = utenti dell'applicazione (~250 righe attese).
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dipendenti (
  id                   INT UNSIGNED     NOT NULL AUTO_INCREMENT,  -- PK tecnica, non cambia mai
  matricola            VARCHAR(20)      NOT NULL,                 -- USERNAME del sistema (UNIQUE)
  codice_fiscale       VARCHAR(16)      NOT NULL,                 -- v2.0: identita fiscale univoca; NOMINA LE CARTELLE PDF
  sesso                ENUM('M','F','ALTRO') NOT NULL DEFAULT 'M', -- v1.4: dati anagrafici obbligatori
  qualifica            VARCHAR(120)     NOT NULL DEFAULT '',      -- v1.4: qualifica professionale
  nome                 VARCHAR(100)     NOT NULL,
  cognome              VARCHAR(100)     NOT NULL,
  email                VARCHAR(150)     NULL,                     -- facoltativa, non usata per il login
  password_hash        VARCHAR(100)     NOT NULL,                 -- hash bcrypt (costo 10): MAI la password in chiaro
  ruolo                ENUM('DIPENDENTE','AMMINISTRATORE') NOT NULL DEFAULT 'DIPENDENTE',
  attivo               TINYINT(1)       NOT NULL DEFAULT 1,       -- 0 = disabilitato (login e sessioni bloccati)
  must_change_password TINYINT(1)       NOT NULL DEFAULT 0,       -- 1 = provvisoria: scritture bloccate finché non cambia
  created_at           TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_dipendenti_matricola (matricola),
  UNIQUE KEY uq_dipendenti_cf (codice_fiscale),
  KEY idx_dipendenti_cognome (cognome, nome),
  KEY idx_dipendenti_qualifica (qualifica)
) ENGINE = InnoDB;

-- ------------------------------------------------------------------------------
-- Tabella CERTIFICATI — metadati dei documenti.
-- I PDF vivono SOLO sul file system: {UPLOAD_DIR}/certificati/{matricola}/…
-- qui viene salvato unicamente il percorso RELATIVO (percorso_file).
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS certificati (
  id                   INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  dipendente_id        INT UNSIGNED     NOT NULL,                 -- proprietario del documento (FK)
  nome_corso           VARCHAR(200)     NOT NULL,                 -- titolo/denominazione della formazione
  ente_erogatore       VARCHAR(150)     NOT NULL,                 -- ente che ha rilasciato il certificato
  data_conseguimento   DATE             NOT NULL,
  numero_ore           INT UNSIGNED     NOT NULL DEFAULT 0,       -- v1.4: durata in ore (≥ 1 validato in applicazione)
  numero_minuti        INT UNSIGNED     NOT NULL DEFAULT 0,       -- v2.2: parte in MINUTI (0-59); durata totale = ore*60+minuti ≥ 1
  esame_finale         TINYINT(1)       NOT NULL DEFAULT 0,       -- v1.4: 1 = il corso prevedeva esame finale
  area_tematica        VARCHAR(100)     NOT NULL DEFAULT 'Altro', -- [v2.2.5] elenco governato dall'app (validazione.js): 17 aree nuove + 6 storiche
  nome_file_originale  VARCHAR(255)     NOT NULL,
  percorso_file        VARCHAR(500)     NOT NULL,                 -- percorso RELATIVO: certificati/{matricola}/{file}.pdf
  dimensione_file      INT UNSIGNED     NOT NULL,                 -- byte (max 5 MB validato in applicazione)
  stato                ENUM('IN_ATTESA','APPROVATO','RIFIUTATO') NOT NULL DEFAULT 'IN_ATTESA',
  note_admin           VARCHAR(500)     NULL,
  caricato_il          TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  approvato_da         INT UNSIGNED     NULL,
  approvato_il         TIMESTAMP        NULL,
  PRIMARY KEY (id),
  KEY idx_cert_dipendente  (dipendente_id),
  KEY idx_cert_stato       (stato),
  KEY idx_cert_data        (data_conseguimento),
  KEY idx_cert_area        (area_tematica),                      -- v1.4: filtro per area tematica
  CONSTRAINT fk_cert_dipendente  FOREIGN KEY (dipendente_id) REFERENCES dipendenti (id)  ON DELETE CASCADE,
  CONSTRAINT fk_cert_approvatore FOREIGN KEY (approvato_da)  REFERENCES dipendenti (id)  ON DELETE SET NULL
) ENGINE = InnoDB;
-- [v2.2] ALLEGATI del certificato: ogni corso può avere più documenti
--        (PDF, JPEG o PNG). Il primo file resta anche in certificati.percorso_file
--        per compatibilità con v1.x; l'elenco completo vive qui (FK a cascata:
--        cancellando il certificato spariscono anche i suoi allegati).
CREATE TABLE IF NOT EXISTS allegati (
  id                   INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  certificato_id       INT UNSIGNED     NOT NULL,                 -- corso di appartenenza (FK)
  percorso_file        VARCHAR(500)     NOT NULL,                 -- percorso RELATIVO: certificati/{CF}/{file}
  nome_originale       VARCHAR(255)     NOT NULL,                 -- nome scelto dall'utente
  tipo_file            ENUM('pdf','jpeg','png') NOT NULL DEFAULT 'pdf',
  dimensione_file      INT UNSIGNED     NOT NULL,                 -- byte (max 5 MB per file)
  caricato_il          TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_allegati_certificato (certificato_id),
  CONSTRAINT fk_allegati_certificato FOREIGN KEY (certificato_id)
    REFERENCES certificati (id) ON DELETE CASCADE
) ENGINE = InnoDB;

-- [v2.2.9] STORICO MODIFICHE ADMIN (audit log): ogni correzione/approvazione/
-- rifiuto/eliminazione di un certificato fatta dall'amministratore.
CREATE TABLE IF NOT EXISTS audit_log (
  id             INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  admin_id       INT UNSIGNED     NOT NULL,
  azione         VARCHAR(50)      NOT NULL,  -- [v2.3.4] azione SPECIFICA: MODIFICA_TITOLO_CORSO | MODIFICA_ENTE_EROGATORE | MODIFICA_DATA_CONSEGUIMENTO | MODIFICA_DURATA | MODIFICA_ESAME_FINALE | MODIFICA_AREA_TEMATICA | ELIMINAZIONE_<CAMPO> | APPROVAZIONE_CERTIFICATO | RIFIUTO_CERTIFICATO | ELIMINAZIONE_CERTIFICATO (storici pre-v2.3.4: MODIFICA_CERTIFICATO | APPROVAZIONE | RIFIUTO | ELIMINAZIONE)
  certificato_id INT UNSIGNED     NULL,      -- NULL se il certificato è stato eliminato
  dettagli       VARCHAR(500)     NULL,
  creato_il      TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_data (creato_il),
  CONSTRAINT fk_audit_admin FOREIGN KEY (admin_id) REFERENCES dipendenti(id) ON DELETE CASCADE,
  CONSTRAINT fk_audit_cert  FOREIGN KEY (certificato_id) REFERENCES certificati(id) ON DELETE SET NULL
) ENGINE = InnoDB;

-- ============================================================================
--  MIGRAZIONE v2.2.5 — Nuove aree tematiche (17 voci)
-- ============================================================================
--  La colonna area_tematica passa da ENUM (6 valori v1.4) a VARCHAR(100):
--  l'elenco delle aree ammesse è ora governato dall'applicazione
--  (src/utils/validazione.js) e non più dallo schema del database.
--  I certificati esistenti con le 6 aree storiche NON vengono toccati:
--  restano validi, visibili e filtrabili (elenco «Aree precedenti» nel
--  filtro admin). Da applicare con:
--      sudo mysql certificati_comune < db/migrazione-v2.2.5.sql
-- ============================================================================

USE certificati_comune;

ALTER TABLE certificati
  MODIFY area_tematica VARCHAR(100) NOT NULL DEFAULT 'Altro';

-- ============================================================================
--  MIGRAZIONE v2.2.9 — Audit log delle modifiche amministrative
--  Da applicare ai database esistenti (le installazioni nuove usano schema.sql):
--      sudo mysql certificati_comune < db/migrazione-v2.2.9.sql
-- ============================================================================
USE certificati_comune;

CREATE TABLE IF NOT EXISTS audit_log (
  id             INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  admin_id       INT UNSIGNED     NOT NULL,
  azione         VARCHAR(50)      NOT NULL,
  certificato_id INT UNSIGNED     NULL,
  dettagli       VARCHAR(500)     NULL,
  creato_il      TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_data (creato_il),
  CONSTRAINT fk_audit_admin FOREIGN KEY (admin_id) REFERENCES dipendenti(id) ON DELETE CASCADE,
  CONSTRAINT fk_audit_cert  FOREIGN KEY (certificato_id) REFERENCES certificati(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

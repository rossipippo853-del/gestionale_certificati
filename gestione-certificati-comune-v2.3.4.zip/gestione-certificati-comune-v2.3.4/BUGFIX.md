# 🔧 Note di revisione — v1.1.0

Analisi completa del codice con correzione dei 3 bug bloccanti segnalati
più una revisione globale. Tutti i fix sono stati verificati con test
funzionali sul sistema.

---

## BUG #1 — Loop di ricaricamento infinito nella pagina di login

**File:** `public/js/common.js` (funzione `api()`)

**Causa (analisi):**
La pagina di login, al caricamento, verifica se esiste già una sessione con
`GET /api/auth/me`. Quando non si è loggati il server risponde correttamente
**401**. Il wrapper `api()`, però, su *qualsiasi* 401 eseguiva:

```js
if (risposta.status === 401 && !url.includes('/auth/login')) {
  location.href = '/';   // ← reindirizza alla pagina di login…
  throw new Error('Sessione scaduta.');
}
```

Il redirect ri-caricava `/` (la pagina di login stessa), che rilanciava
`/api/auth/me`, che rispondeva di nuovo 401, che ri-reindirizzava a `/`…
**loop infinito di ricaricamento**. Il controllo `!url.includes('/auth/login')`
non bastava: a fallire non è `/auth/login`, è `/auth/me`.

**Correzione:**
`api()` ora non reindirizza mai quando ci si trova già sulla pagina pubblica
di login — in quel caso l'errore è lasciato al chiamante (che lo gestisce
con un semplice `catch`, restando sul login):

```js
const sullaPaginaLogin = location.pathname === '/' || location.pathname.endsWith('/index.html');
if (risposta.status === 401 && !url.includes('/auth/login') && !sullaPaginaLogin) {
  location.href = '/';
  throw new Error('Sessione scaduta.');
}
```

**Risultato:** la pagina si carica una volta sola ed è subito possibile
inserire le credenziali. Il redirect automatico su sessione scaduta continua
a funzionare nelle aree protette (`/dipendente`, `/admin`).

---

## BUG #2 — Blocco su abilita/disabilita utente (modale che non si chiude)

**File:** `public/js/common.js` (funzione `conferma()`)

**Causa (analisi):**
Il dialog di conferma generato dinamicamente inseriva i bottoni in un
semplice `<div>`:

```html
<div class="azioni">
  <button class="btn secondario" value="no">Annulla</button>
  <button class="btn pericolo" value="si">Disabilita</button>
</div>
```

Secondo la specifica HTML, un `<button>` **fuori da un `<form>`** non ha un
"form owner": il click non produce alcuna submission, quindi **non chiude il
`<dialog>` e non imposta `dialog.returnValue`**. Conseguenza a cascata:

1. `conferma()` restituisce una `Promise` che si risolve solo su `onclose`;
2. il dialog non si chiude mai → `onclose` non scatta mai → **la Promise resta
   sospesa per sempre**;
3. `azioneUtente()` resta bloccata su `await conferma(...)` → l'operazione
   non viene mai chiamata a database e l'interfaccia appare "congelata" sul
   modale. (Solo ESC chiudeva il dialog, risolvendo `false` = nessuna azione.)

**Correzione:** i bottoni ora stanno dentro `<form method="dialog">`: la
submission imposta `returnValue` al `value` del bottone premuto e chiude il
dialog (comportamento nativo del browser). In più, prima di ogni apertura
`returnValue` viene azzerato, così anche la chiusura con ESC risolve
deterministicamente `false` (mai un "si" residuo della sessione precedente):

```html
<form method="dialog" class="azioni">
  <button class="btn secondario" value="no">Annulla</button>
  <button class="btn pericolo" id="conf-btn" value="si"></button>
</form>
```

```js
dlg.returnValue = '';
dlg.onclose = () => risolvi(dlg.returnValue === 'si');
dlg.showModal();
```

**Risultato:** "Disabilita" → API `PUT /api/admin/utenti/:id/stato` eseguita →
toast di conferma → modale chiuso → tabella e statistiche ricaricate con il
nuovo stato. Il fix riguadagna anche il dialog di conferma **eliminazione
certificati**, che condivideva lo stesso codice.

---

## BUG #3 — Cartella `/uploads/certificati/{matricola}` non creata alla registrazione

**File:** `src/routes/admin.routes.js` (endpoint `POST /api/admin/utenti`)

**Causa (analisi):**
La creazione del dipendente eseguiva solo l'`INSERT` a database: la cartella
della matricola nasceva **solo lazy**, cioè al primo upload di un certificato
(gestita da Multer tramite `cartellaDipendente()`).

**Correzione (due livelli):**

1. **Creazione immediata alla registrazione** — prima dell'`INSERT` viene ora
   chiamata `cartellaDipendente(matricola)` che esegue
   `fs.mkdirSync(dir, { recursive: true })` (idempotente: crea l'intero
   percorso se manca, non fallisce se esiste). Ordine voluto:
   *cartella → INSERT*: se la creazione cartella fallisce (permessi/disco), la
   registrazione viene annullata con un 500 esplicito; se l'`INSERT` fallisce
   per **matricola duplicata**, la cartella appena creata viene rimossa con
   `fs.rmdirSync()` non-ricorsivo (rimuove solo se vuota → nessun rischio dati).
   Invariante garantito: *utente esistente ⇒ cartella esistente*.

2. **Upload autosufficiente** — la destinazione Multer chiama
   `cartellaDipendente()` a **ogni** caricamento: se la cartella viene
   cancellata/limitata per qualsiasi motivo (pulizia manuale, ripristino
   backup parziale, …), viene **ricreata automaticamente** al volo.

**Verifiche eseguite (sistema reale):**
- `POST /api/admin/utenti` matricola `10999` → cartella `uploads/certificati/10999/` creata ✅
- `POST` duplicato `10999` → 409 "Matricola già esistente." e cartella rimossa ✅
- `rm -rf uploads/certificati/10001/` → upload certificato → 201, cartella e file ricreati ✅

---

## Revisione globale — altri interventi

| # | Area | Problema rilevato | Correzione |
|---|---|---|---|
| 1 | Export CSV | **Formula injection**: un corso/note che inizia con `=` `+` `-` `@` veniva eseguito come formula da Excel all'apertura del report | `csvCampo()` antepone un apice ai prefissi pericolosi |
| 2 | Ricerche admin | I metacaratteri LIKE (`%`, `_`, `\`) nell'input di ricerca alteravano i risultati (es. `100%` restituiva tutto) | `likeSicuro()` li escape-a; la ricerca ora è letterale |
| 3 | Export CSV (frontend) | `window.open(..., '_blank')` lasciava una **tab vuota** aperta ed era soggetto al blocco popup | link temporaneo con attributo `download` |
| 4 | Rate-limit login | La mappa dei tentativi cresceva senza limiti con molte matricole diverse (memory leak) | pulizia periodica delle finestre scadute (>500 voci) |
| 5 | Codice | blocco `if` vuoto residuo in `POST /utenti` | rimosso + import non usato eliminato |

### Verificato OK (nessuna correzione necessaria)
- **Gestione errori**: gestore centrale con messaggi dedicati per Multer
  (5 MB, file multipli), JSON malformato e errori interni generici (500 senza
  dettagli verso il client).
- **Validazione**: server-side su tutti gli input (matricola, nome, email,
  date — incluso il rifiuto di date future —, policy password 8+ con lettere e
  numeri); client-side nei form HTML (`required`, `maxlength`, `accept=".pdf"`).
- **Protezione rotte**: `autenticazione` (JWT httpOnly + ricarica utente dal
  DB: account disabilitato = subito fuori) e `soloAdmin` su tutto `/api/admin`;
  download PDF consentito solo a proprietario/admin; anti path-traversal sul
  percorso file. Testati: 401 senza login, 403 dipendente→API admin, 403 PDF altrui.

**File modificati:** `public/js/common.js`, `public/js/admin.js`,
`src/routes/admin.routes.js`, `src/routes/auth.routes.js`, `package.json` (v1.1.0).
File non toccati: tutti gli altri (verificati, nessun intervento richiesto).

# 📘 GUIDA SEMPLICE — Portare l'app sul PC server della rete (10 passi)
## Versione "in parole povere" di `docs/GUIDA-SERVER-INTRANET.md` · v1.5.0

> **Obiettivo:** i dipendenti aprono il browser e digitano `http://192.168.1.50:3000`
> (indirizzo fisso del server) e trovano l'app.
>
> **Regola d'oro:** nei comandi qui sotto sostituisci sempre `192.168.1.50` con
> l'IP della VOSTRA rete e `C:\certificati-comune` con la cartella reale del progetto.

---

## Prima di iniziare: i 3 concetti da sapere

1. **IP fisso** = l'indirizzo del server che non cambia mai. Se cambia, i dipendenti non trovano più il sito.
2. **Porta 3000** = il "numero dello sportello" dell'app dentro il server.
3. **Firewall** = la "portineria" del PC: va avvisata di lasciare passare i colleghi sulla porta 3000.

---

## I 10 PASSI

### ✅ Passo 1 — Installa i programmi (una volta sola)
- **Node.js LTS** → https://nodejs.org → Avanti, Avanti, Fine
- **MariaDB** → https://mariadb.org/download → al wizard: imposta la password di root, lascia spuntato "avvio automatico"

Verifica (Prompt dei comandi):
```bat
node -v
```
deve rispondere con un numero (es. `v20.x.x`).

### ✅ Passo 2 — Scopri i numeri della tua rete
```bat
ipconfig
```
Annota **Indirizzo IPv4**, **Subnet mask**, **Gateway predefinito** della scheda Ethernet.

### ✅ Passo 3 — Blocca l'indirizzo del server (IP fisso)
Prompt dei comandi **come Amministratore** (usa i numeri trovati al passo 2,
cambiando solo l'ultimo numero dell'IP, es. `.77` → `.50`):

```bat
netsh interface ip set address name="Ethernet" static 192.168.1.50 255.255.255.0 192.168.1.1
```

*(Linux Ubuntu: file `/etc/netplan/01-ip-statico.yaml` — copia il modello dalla guida completa, §1.5.)*

Verifica dal PC di un collega: `ping 192.168.1.50` → deve rispondere.

### ✅ Passo 4 — Copia il progetto sul server e prepara il database
```bat
cd C:\certificati-comune
npm install
mysql -u root -p < db\schema.sql
node db\seed.js --dipendenti=0
```
Cosa fa: installa i moduli, crea database e tabelle, crea l'account amministratore.

### ✅ Passo 5 — Configura il file `.env` (LE RIGHE FONDAMENTALI)
Copia `.env.example` in `.env` (nella cartella del progetto) e imposta:

```ini
PORT=3000
HOST=0.0.0.0                 ← senza questa riga i dipendenti NON vedono il sito!
DB_HOST=127.0.0.1
DB_USER=cert_app
DB_PASSWORD=<la password che hai scelto per il database>
DB_NAME=certificati_comune
JWT_SECRET=<una stringa lunga e casuale, inventala a occhio>
COOKIE_SECURE=false          ← fondamentale su http (i browser rifiutano altrimenti il login)
UPLOAD_DIR=uploads
```

### ✅ Passo 6 — Primo avvio e prova sul server
```bat
npm start
```
Devi leggere: `[OK] Server avviato su http://0.0.0.0:3000`.
Sul server apri `http://localhost:3000` → deve apparire la pagina di login.
Chiudi con CTRL+C (lo start definitivo arriva al passo 9).

### ✅ Passo 7 — Apri la porta nel firewall (avvisa la "portineria")
Prompt dei comandi **come Amministratore**:

```bat
netsh advfirewall firewall add rule name="Certificati Comune 3000" dir=in action=allow protocol=TCP localport=3000
```

*(Linux: `sudo ufw allow 3000/tcp`)*

### ✅ Passo 8 — LA PROVA DECISIVA dal PC di un collega
Apri il browser e digita:
```
http://192.168.1.50:3000
```
→ pagina di login visibile = **il sistema è funzionante**. 🎉

### ✅ Passo 9 — Avvio automatico (riparte da solo dopo black-out/riavvii)

**Il database:**
```bat
sc config MariaDB start= auto
```

**L'applicazione (due modi):**

*Modo semplice — Utilità di pianificazione:*
1. Menu Start → "Utilità di pianificazione" → Crea attività base
2. Trigger: **"All'avvio del computer"**
3. Azione: avvia programma `node.exe` (si trova in `C:\Program Files\nodejs\`)
4. Argomenti: `server.js` — Percorso: `C:\certificati-comune`
5. Nelle proprietà dell'attività: ✓ "Esegui indipendentemente dalla connessione degli utenti"

*Modo professionale — PM2:*
```bat
npm install -g pm2 pm2-windows-startup
cd C:\certificati-comune
pm2 start deploy\ecosystem.config.js
pm2 save
pm2-startup install
```

**Linux:** due comandi totali:
```bash
sudo systemctl enable --now mariadb
sudo cp deploy/certificati.service /etc/systemd/system/ && sudo systemctl enable --now certificati
```

### ✅ Passo 10 — Riavvio di collaudo e carico dei dipendenti
1. Riavvia il PC server e verifica che il sito torni da solo (senza login manuale)
2. Entra come amministratore → **Importa da CSV** → carica i 250 dipendenti
   (modello pronto: `db/modello-dipendenti.csv`)
3. **Cambia la password dell'admin** e comunicala solo all'ufficio personale

---

## 🚨 SE QUALCOSA NON FUNZIONA

| Problema | Causa più probabile | Soluzione |
|---|---|---|
| Dal collega la pagina non si apre | Firewall chiuso o HOST sbagliato | Passo 7 fatto? Nel `.env` c'è `HOST=0.0.0.0`? Poi riavvia l'app |
| La pagina si apre ma il login "non fa niente" | `COOKIE_SECURE=true` | Metti `COOKIE_SECURE=false` nel `.env`, riavvia |
| Sul server funziona, fuori no | App ascolta solo in locale | `netstat -ano \| findstr :3000` deve dire `0.0.0.0:3000` (non `127.0.0.1`) |
| Dopo un riavvio non va più niente | Avvio automatico mancante | Passo 9: database e app in automatico |
| «Database non raggiungibile» all'avvio | MariaDB spento | Windows: `net start MariaDB` · Linux: `sudo systemctl start mariadb` |
| Un PDF non si scarica | Sessione scaduta o file rimosso | Rifai il login; se persiste, vedi guida completa §5.2-C |

## 🧯 Backup (pianificarlo il prima possibile)
Il database e i PDF sono DUE cose diverse da salvare:
```bat
mysqldump -u cert_app -p certificati_comune > backup_db.sql
```
più una copia della cartella `uploads\` (con l'Utilità di pianificazione, ogni notte).

---
*Approfondimenti e varianti Linux: `docs/GUIDA-SERVER-INTRANET.md` (guida completa).
Uso quotidiano dell'app: `docs/GUIDA-OPERATIVA.md`.*

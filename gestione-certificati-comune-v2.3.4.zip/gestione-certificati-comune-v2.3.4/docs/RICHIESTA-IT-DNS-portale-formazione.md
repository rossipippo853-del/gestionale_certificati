# Richiesta al tecnico IT esterno — Scenario A: accesso SOLO dalla rete interna del Comune

Testo pronto da inviare (email o PEC) al tecnico esterno che gestisce server,
rete e domini. Il portale sarà raggiungibile **esclusivamente dai PC collegati
alla rete interna del Comune**: nessuna esposizione su Internet.
Prima dell'invio compilare i campi tra parentesi quadre `[...]`.

---

## VERSIONE BREVE (per messaggistica rapida)

> Ciao [Nome], dobbiamo pubblicare il nuovo portale formazione del Comune
> (gestione certificati dei dipendenti) **solo in rete interna**.
> Ci servirebbero 3 cose:
>
> 1. record DNS di tipo **A** sul **DNS interno** di rete:
>    `portale-formazione.comune.milazzo.it` → **[IP LAN del PC-server, es. 192.168.1.50]**;
> 2. conferma che quel PC abbia **IP fisso** (statico o riservazione DHCP);
> 3. nulla altro su router/firewall: **nessuna porta aperta verso Internet**,
>    il servizio non deve risultare raggiungibile dall'esterno.
>
> Per l'HTTPS pensiamo a: certificato della **CA interna** se esiste (i PC di
> dominio lo vedono già valido), in alternativa Let's Encrypt via **DNS-01**.
> Ci confermi IP e disponibilità? Grazie!

---

## VERSIONE COMPLETA (email formale)

**Oggetto:** Richiesta configurazione DNS interno — nuovo servizio «portale-formazione» (certificati formazione dipendenti, accesso solo rete interna)

Buongiorno [Nome],

è stato completato lo sviluppo di una nuova applicazione web per la gestione
dei certificati di formazione dei dipendenti del Comune («Portale Certificati
— Formazione»). Il servizio sarà ospitato su un PC/server dell'ente e sarà
utilizzato **esclusivamente dalla rete interna**: chiediamo la Vostra
collaborazione per la configurazione descritta di seguito.

### 1. Precondizione — IP fisso del PC-server

Il PC-server (ubicazione: [es. «municipio, ufficio ___»]) deve avere un
indirizzo LAN **che non cambi nel tempo**:
- se riceve l'indirizzo in DHCP, chiediamo una **riservazione DHCP** (oppure configurazione statica);
- Vi chiediamo la **conferma scritta dell'IP assegnato** prima della creazione del record.

### 2. Richiesta principale — record sul DNS interno

| Campo | Valore |
|---|---|
| Nome host | `portale-formazione.comune.milazzo.it` |
| Tipo record | **A** |
| Valore | **[IP LAN fisso del PC-server — es. 192.168.1.50]** |
| TTL | default della zona interna |
| Dove | **DNS interno della rete** (es. Active Directory DNS) — **NON** sul DNS pubblico |

Note operative:
- se la zona `comune.milazzo.it` esiste in **vista divisa** (split-horizon, interna e pubblica diverse), il record va aggiunto **solo alla vista interna** usata dai PC dei dipendenti;
- il nome si risolverà quindi **solo** dai dispositivi collegati alla rete interna (o VPN, se presente): è il comportamento desiderato;
- **nessuna modifica al DNS pubblico**: esternamente il nome continuerà a non risolvere.

### 3. Firewall / router di perimetro — NESSUN intervento richiesto

| Porta | Servizio | Esposizione |
|---|---|---|
| 443/TCP | HTTPS del portale (reverse proxy sul PC-server) | **Solo LAN** |
| 80/TCP | redirect verso HTTPS / rinnovo certificato | **Solo LAN** |
| 3000/TCP | porta interna dell'applicazione Node.js | **Mai raggiungibile** (nemmeno da LAN, se possibile bloccarla a favore di 80/443) |
| Qualunque porta | da Internet | **Nessuna apertura** — il servizio non esiste per Internet |

Sul PC-server stesso terremo un firewall host con ammessi solo 80/443 dalla LAN.

### 4. Certificato TLS (HTTPS)

In ordine di preferenza, Vi chiediamo un parere sulla fattibilità:

1. **CA interna dell'ente** (es. Active Directory Certificate Services), se esiste: i PC in dominio vedrebbero il certificato come valido senza alcuna configurazione; era la soluzione preferita;
2. **Let's Encrypt con validazione DNS-01**: il record TXT `_acme-challenge.portale-formazione` verrebbe aggiunto (da Voi o tramite loro API) alla zona pubblica del dominio, mentre il record A resta solo interno — la validation **non richiede alcuna esposizione del server**; richiede però che il PC-server possa raggiungere Internet in uscita (443) o rinnovo manuale periodico;
3. certificato autofirmato: **sconsigliato** (avvisi di sicurezza per gli utenti).

Una volta attivo l'HTTPS attiveremo l'header **HSTS**.

### 5. Suggerimenti di sicurezza (se compatibili con le Vs. procedure)

- il PC-server non necessita di accesso da Internet: se può essere inserito in un segmento/VLAN interna senza uscita in ingresso, meglio;
- aggiornamenti automatici di sicurezza del SO; solo servizi necessari attivi;
- log/alert sulle modifiche alla zona DNS interna (buona pratica per un ente pubblico);
- credenziali amministrative del server gestite secondo le procedure dell'ente.

### 6. Verifiche che eseguiremo dopo l'intervento (da un PC in rete interna)

1. `nslookup portale-formazione.comune.milazzo.it` → deve restituire **[IP LAN]**;
2. `https://portale-formazione.comune.milazzo.it` → pagina di login del portale, senza avvisi di certificato;
3. la porta 3000 NON deve essere raggiungibile;
4. (verifica attesa) da una rete esterna il nome NON deve risolvere.

### 7. Riepilogo delle attività richieste

| # | Attività | Note |
|---|---|---|
| 1 | Conferma IP fisso (o riservazione DHCP) del PC-server | con conferma scritta dell'IP |
| 2 | Creazione record A su **DNS interno**: `portale-formazione` → IP | solo vista interna se split-horizon |
| 3 | Parere sul certificato TLS (CA interna vs DNS-01) | nessuna esposizione richiesta |
| 4 | Nessuna apertura porte su router/firewall di perimetro | accesso solo LAN |
| 5 | Conferma scritta con data/ora dell'intervento | per registro dei changes |

Restiamo a disposizione per un breve confronto tecnico (anche telefonico) per
confermare IP e modalità. Ringraziando per la consueta collaborazione, porgiamo
distinti saluti.

[Nome e cognome]
[Ruolo — es. responsabile del progetto / Ufficio ___ del Comune di ___]
[Recapiti]

---

## Checklist PRIMA di inviare

- [ ] IP LAN del PC-server noto o da far assegnare (punto 1)
- [ ] PC-server acceso, raggiungibile in LAN e con l'applicazione installata e in ascolto
- [ ] Concordanza col Comune sul nome esatto `portale-formazione` (punto 2)
- [ ] Chiarito con l'ufficio che gli utenti usano il portale **solo dagli uffici** (da remoto non funzionerà senza VPN)
- [ ] Allegare, se richiesto, la scheda tecnica dell'applicazione (README del progetto)

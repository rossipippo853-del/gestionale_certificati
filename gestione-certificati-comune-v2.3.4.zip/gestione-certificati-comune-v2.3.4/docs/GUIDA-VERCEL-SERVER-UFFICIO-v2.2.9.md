# 🌐 Opzione B — Redirect Vercel: installazione sul PC server dell'ufficio
## Città di Milazzo · v2.2.9 · tempo richiesto: ~45 min (server già installato)

**Idea della soluzione**: il dipendente digita un **nome pubblico**
(`https://portale-milazzo.vercel.app`) → Vercel (su Internet) risponde «vai a
`http://IP-DEL-SERVER`» → il browser apre il portale che resta **dentro la rete
dell'ufficio**, con tutti i dati sul suo disco. Su Vercel finiscono solo 3 file
di testo: **nessun dato del portale**.

```
[PC dipendente ufficio] ──1──▶ [DNS pubblico Internet]
                                    │ 2. «portale-milazzo.vercel.app» = Vercel
                                    ▼
                              [Vercel: solo cartello]
                                    │ 3. «vai a http://192.168.1.50/»
                                    ▼
[PC dipendente] ───────4──▶ [PC server ufficio: NGINX :80 → Portale :3000]
```

> **Prerequisito indispensabile**: il PC server dell'ufficio deve essere già
> funzionante con **NGINX attivo** (porta 80). Se non lo è ancora, segui prima
> `docs/GUIDA-INSTALLAZIONE-SERVER-v2.2.9.md` (11 passi) e poi torna qui.

---

## PARTE 1 — Verifica del server (5 min)

Dal server (e poi da un PC qualsiasi dell'ufficio):

```bat
curl http://127.0.0.1/          (oppure apri nel browser)
```

Deve comparire la pagina di login **senza** `:3000`. Se funziona solo con
`:3000`, NGINX non è attivo → PASSO 8 della guida di installazione. È NGINX che
permette al redirect di puntare all'IP «nudo», senza porta.

Annota l'**IP fisso** del server (es. `192.168.1.50`): è il valore che userai
in tutti i passaggi. Se l'IP non è ancora fisso, torna al PASSO 1 della guida:
con un IP che cambia, il redirect smetterebbe di funzionare al primo cambio.

## PARTE 2 — Prepara i 3 file del cartello (10 min)

Sul tuo PC (anche di casa): apri la cartella `deploy/reindirizzamento-vercel/`
dello zip e sostituisci l'IP di esempio `192.168.1.50` con l'IP **reale del
server ufficio**, in **entrambi** i file. **Senza** `:3000` (c'è NGINX).

**`vercel.json`**:
```json
{
  "redirects": [
    { "source": "/(.*)", "destination": "http://192.168.1.50/", "permanent": false }
  ]
}
```

**`index.html`** — due punti da allineare (meta refresh + link di riserva):
```html
<meta http-equiv="refresh" content="0; url=http://192.168.1.50/">
<a href="http://192.168.1.50/">clicca qui per accedere al portale</a>
```

Il terzo file (`README.md`) è solo documentazione: non si tocca.

## PARTE 3 — Pubblica su Vercel (15 min)

**Via browser (consigliata, nessuna riga di comando):**
1. https://vercel.com → **Sign Up** con un'email **di servizio** (es.
   `portale@comune.milazzo.it`; evitare email personali: il servizio non deve
   dipendere da una persona). Piano **Hobby** (gratuito).
2. Attiva la **verifica in due passaggi** sull'account (Settings → Two-Factor
   Authentication): costa 1 minuto e mette al sicuro il «cartello».
3. Dashboard → **Add New… → Project** → se chiede il repository: **Skip**.
4. Trascina la cartella `reindirizzamento-vercel` (con i file già corretti).
5. Project name: `portale-milazzo` → **Deploy** → in ~30 s: **Ready**.
6. Il nome pubblico è pronto: `https://portale-milazzo.vercel.app`

**Via terminale (alternativa):**
```bash
npm install -g vercel
vercel login
cd deploy/reindirizzamento-vercel
vercel --prod
```

> Se il deploy segnalasse un errore su `vercel.json` (alcune versioni sono
> rigide sul campo `destination` con IP privato): elimina `vercel.json` dalla
> cartella e ri-pubblica — `index.html` da solo fa lo stesso redirect.

## PARTE 4 — Test in ufficio (10 min, NON saltarli)

| # | Test | Come | Esito atteso |
|---|---|---|---|
| 1 | Dal **server** | apri `https://portale-milazzo.vercel.app` | login del portale |
| 2 | Da **2-3 PC dipendenti** (reparti diversi) | stesso indirizzo | login del portale |
| 3 | **Proxy aziendale** ⚠️ | ripeti il test 2; se la pagina Vercel non si apre MAI (timeout/blocco) | il proxy blocca `*.vercel.app` → l'opzione B non è praticabile: resta l'Opzione A (link+segnalibio+QR) |
| 4 | **Server spento** (prova controllata) | spegni il server, ripeti il test | il nome si apre ma il portale no → conferma che il «cartello» non contiene dati |
| 5 | Login completo | matricola + password su un PC | accesso funzionante |
| 6 | **Fuori sede** (opzionale) | dal telefono in 4G/5G (NON Wi-Fi ufficio) | il nome si apre ma il portale NON raggiungibile → è normale: l'IP `192.168.x.x` esiste solo dentro l'ufficio (il portale non è esposto su Internet: è una protezione, vedi pro/contro) |

## PARTE 5 — Mantenimento (qualche minuto l'anno)

| Evento | Cosa fare |
|---|---|
| IP del server cambia (non dovrebbe: è fisso) | aggiorna i 2 file con il nuovo IP → ri-deploy (trascina di nuovo la cartella su Vercel: stesso progetto = stesso nome) |
| Nuova versione del portale | nulla da fare su Vercel: il cartello non cambia |
| Persona lascia il servizio | l'account Vercel è di SERVIZIO (email istituzionale) + 2FA: si gira la chiave senza dipendere da nessuno |
| Vercel modifica le condizioni del piano gratuito | il servizio resta attivo nel frattempo; piano B già pronto: segnalibio con `http://IP-SERVER/` oppure (meglio) record DNS interno se l'IT acconsentirà |
| Si vuole dismettere Vercel (es. arriva il DNS interno) | Delete project su Vercel + diffondere il nuovo nome `portale.certificati` — nessun impatto sul portale |

---

# PRO E CONTRO dell'Opzione B (Redirect Vercel)

## ✅ Pro

| # | Pro | Perché conta |
|---|---|---|
| 1 | **Zero modifiche sui 300 PC** | il nome viene risolto dal DNS pubblico: nessun file hosts, nessuna configurazione sulle postazioni |
| 2 | **Zero richieste all'IT di rete** | nessun record DNS da attendere: si fa tutto in autonomia |
| 3 | **Nessun dato su cloud esterni** | su Vercel ci sono 3 file di testo; anagrafiche e certificati restano sul server interno (posizione GDPR-compatibile) |
| 4 | **Gratis e veloce** | piano Hobby gratuito, ~45 min di lavoro totale |
| 5 | **Il nome è in HTTPS** | `https://portale-milazzo.vercel.app` è cifrato; il traffico interno verso il portale resta http su rete locale |
| 6 | **Il portale resta invisibile da Internet** | nessuna porta aperta sul router: il server non è raggiungibile dall'esterno (vedi anche il «contro» 6) |
| 7 | **Facilmente disattivabile** | si cancella il progetto Vercel: zero impatti sul portale |

## ⚠️ Contro (e mitigazioni)

| # | Contro | Impatto | Mitigazione |
|---|---|---|---|
| 1 | **Richiede Internet nei PC** | se la rete ufficio perde la connessione a Internet, il nome smette di funzionare | i dipendenti con il **segnalibio** a `http://IP-SERVER/` continuano a lavorare lo stesso (distribuire comunque il segnalibio!) |
| 2 | **Dipendenza da un fornitore terzo** | Vercel potrebbe cambiare condizioni/limiti del piano gratuito | account di servizio +2FA; piano B pronto (segnalibio/DNS); il rischio reale è basso ma non zero |
| 3 | **Proxy aziendale può bloccarlo** | alcune reti filtrano `*.vercel.app` | test 3 della Parte 4 PRIMA di diffondere il nome; se bloccato → Opzione A |
| 4 | **Nome non «istituzionale»** | `portale-milazzo.vercel.app` non è `portale.comune.milazzo.it` | estetica/immagine: se un giorno servirà il nome ufficiale, la strada resta il DNS interno (opzione D) |
| 5 | **In barra degli indirizzi appare l'IP** | dopo il click l'indirizzo torna `http://192.168.x.x` (e «Non protetto») | innocuo: i dipendenti non riscrivono mai l'indirizzo, usano il segnalibio |
| 6 | **Non funziona fuori sede** | da casa/4G il nome si apre ma l'IP privato non è raggiungibile | per una PA è spesso un **vantaggio** (dati del personale non esposti); il telelavoro al portale non è previsto |
| 7 | **Manutenzione legata all'IP** | se l'IP cambia, si ri-depila il redirect | IP **fisso** al PASSO 1 della guida server: problema annullato alla radice |

## Verdetto

L'Opzione B è una **soluzione-ponte pragmatica**: risolve subito e bene il
bisogno «digitare un nome, senza toccare PC né IT», tenendo i dati dentro
l'ufficio. I contro sono tutti gestibili con le mitigazioni sopra. Nel medio
periodo però, se l'IT dovesse acconsentire, **il record DNS interno (Opzione D)
resta la soluzione definitivamente migliore** (funziona anche senza Internet,
nome istituzionale, zero terze parti): adottato quello, Vercel si dismette in
un minuto.

---

*Guida v2.2.9 — file del cartello: `deploy/reindirizzamento-vercel/`;
installazione completa del server: `docs/GUIDA-INSTALLAZIONE-SERVER-v2.2.9.md`;
confronto tra tutte le opzioni: `docs/COME-ACCEDERE-SENZA-DNS-v2.2.9.md`.*

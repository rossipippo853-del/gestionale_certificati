# 🧪 REPORT DI COLLAUDO — Gestione Certificati Comune
## Versione 1.4.1 · Collaudo di sistema pre-rilascio (Principal QA Engineer)

| | |
|---|---|
| **Data del collaudo** | 09/09/2026 |
| **Ambiente** | Node.js 20 · MariaDB 10.x · Ubuntu (sandbox di collaudo) |
| **Applicazione in esame** | Backend Express + frontend statico + MariaDB + file system locale |
| **Suite di collaudo** | `tests-qa/` — **116 test** (Jest 30 + Supertest 7, `--runInBand`, DB e upload isolati) |
| **Suite di regressione** | `tests/` — **74 test** (runner nativo `node --test`) |
| **Esito complessivo** | ✅ **190/190 PASS — RILASCIO APPROVATO** dopo la correzione dei 4 difetti QA-C1…C4 |

---

## 1. Sintesi esecutiva

Il collaudo ha coperto **tutti i componenti**: API Express (autenticazione, RBAC, upload,
import/export, filtri), database MariaDB (integrità, hash, flag), file system locale
(cartelle per matricola, self-healing, univocità, orfani) e i flussi frontend
(redirect login, modali admin, wiring dei gestori).

**4 difetti reali individuati e corretti** (QA-C1…C4, tutti con test di regressione
dedicati) + 7 aggiustamenti alla suite stessa emersi dal triage. Nessun difetto
bloccante residuo. Le osservazioni di sicurezza non bloccanti sono elencate al §7.

```
npm test  →  prepare-db + 74 test di regressione + 116 test di collaudo Jest  →  190 PASS
```

---

## 2. Metodologia e ambienti

- **Test di integrazione end-to-end via HTTP**: Supertest monta l'app Express su una
  porta effimera; nessun test tocca i dati reali (DB `certificati_comune_test`,
  upload in `uploads-qa/`, reset completo ad ogni caso).
- **Test strutturali frontend**: il codice di `public/js/*.js` e `public/*.html` è
  analizzato come sorgente (pattern già usato dalla suite di regressione) per
  verificare il wiring dei flussi UI (chiusura modale, refresh tabelle, CSP).
- **Magic-bytes, boundary e triage**: i casi limite (5 MB esatti, BOM, quoting CSV,
  date agli estremi) sono verificati con valori esatti e ricostruiti con riproduzioni
  minime standalone (`debug-5mb`), prima di scrivere il fix.

---

## 3. Copertura per fase del piano di collaudo

### FASE 1 — Autenticazione, sessioni, sicurezza · `01`, `02`, `03` (39 test)
| Area | Verifiche principali | Esito |
|---|---|---|
| Login/redirect | nessun loop su `/` con e senza sessione; 401 solo JSON; **QA-C1**: `/login` ora 302→`/` | ✅ |
| Cookie/token | httpOnly + SameSite=Lax; token manomesso/scaduto/revocato → 401 con messaggi coerenti; cookie ripulito | ✅ |
| Brute-force | 5 fallimenti → 429 anche con password corretta; limite per singola matricola | ✅ |
| Anti-enumerazione | messaggio identico per matricola inesistente e password errata; SQL injection → 401 | ✅ |
| RBAC | matrice di 12 endpoint admin per un DIPENDENTE → tutti 403; senza sessione → 401 | ✅ |
| Isolamento dati | elenco = solo propri certificati; PDF altrui → 403 (anche `modo=visualizza`); admin → 200 | ✅ |
| Path traversal | `percorso_file` manomesso a DB → 404, nessuna fuoriuscita dallo storage | ✅ |
| Upload hostile | `.js`, `.exe`, `.jpg`, `.html`, `.zip` → 400; `.exe` rinominato `.pdf` con MIME falso → 400 (magic bytes); PDF vero con estensione errata → 400 | ✅ |
| Limite 5 MB | >5 MB → 400; **QA-C3**: 5 MB esatti ora accettati; nessun file orfano dopo i rifiuti | ✅ |
| Hardening | CSP `script-src 'self'`, nosniff, X-Frame-Options, no `x-powered-by`, `Cache-Control: no-store` sulle API, 404 JSON | ✅ |

### FASE 2 — Gestione utenti e import CSV · `04`, `05` (29 test)
| Area | Verifiche principali | Esito |
|---|---|---|
| Import 250 utenti | 250 righe → 250 account a DB, **password cifrate bcrypt** (`Benvenuto@2026` per le colonne vuote, password dedicata altrove), **250 cartelle** `uploads/certificati/{matricola}`, cambio password obbligatorio | ✅ |
| Re-import duplicati | `duplicati=ignora` → 250 saltati, nessun blocco, DB invariato | ✅ |
| `duplicati=aggiorna` | anagrafica aggiornata, **password INVARIATA** (login ancora valido con la vecchia) | ✅ |
| Righe malformate | manca nome/matricola/qualifica/sesso o password debole → 5 errori riga-per-riga con numero di riga; le righe valide sono comunque importate | ✅ |
| Duplicato nel file | stessa matricola 2 volte → seconda segnalata, un solo account | ✅ |
| File degradati | intestazione v1.3 → 400 esplicito; file vuoto → 400; solo intestazione → 200/0 righe; `.exe` → 400; >2 MB → 400; file mancante → 400 | ✅ |
| Dry-run | 0 utenti creati, 0 cartelle, flag `predefinita` anticipato (password non esposta) | ✅ |
| CRUD admin | creazione singola (bcrypt, cartella, `must_change=1`), 409 duplicato, 400 su sesso/qualifica mancanti e password debole | ✅ |
| Reset password | login con la nuova, vecchia invalidata, cambio forzato; generazione automatica robusta; 404 su id assente | ✅ |
| Abilita/disabilita | login 403 da spento, riabilitazione OK; boolean rigoroso (stringa `"false"` → 400); **auto-lockout vietato** (400); sessione spenta muore alla richiesta successiva | ✅ |
| Wiring UI | modale nuovo utente: chiusura + toast + refresh SOLO su successo, errore in-dialog senza chiusura; reset/stato ricaricano la tabella; campi v1.4 (sesso con ALTRO + qualifica) presenti; nessun handler inline (CSP) | ✅ |

### FASE 3 — Caricamento certificati (dipendente) · `06` (9 test, 24 asserzioni)
| Area | Verifiche principali | Esito |
|---|---|---|
| Validazione form | titolo/ente/data/ore/area mancanti o viziati (data futura, ore `0`, `7.5`, `10000`, `otto`, area inventata) → **13 rifiuti 400** con nessun file orfano | ✅ |
| Esame finale | checkbox assente = `0` (comportamento HTML del checkbox); `1` → salvato `1` | ✅ |
| 6 aree tematiche | tutte e sole le 6 aree ammesse e salvate correttamente (elenco chiuso) | ✅ |
| **Self-healing FS** | cartella `{matricola}` cancellata manualmente → upload successivo **ricrea al volo** (201, mai 500); intera radice `uploads-qa/` cancellata → ricreazione completa del percorso | ✅ |
| Univocità file | 2 upload dello stesso nome → 2 file distinti `{timestamp}-{random8}_`; caratteri ostili sanificati | ✅ |
| Metadati | nel DB solo percorso RELATIVO; `percorso_file` MAI esposto al client; stato iniziale `IN_ATTESA` | ✅ |
| Password provvisoria | upload bloccato 403 `PASSWORD_TEMPORANEA` prima che il file tocchi il disco | ✅ |

### FASE 4 — Export e reportistica · `07` (13 test)
| Area | Verifiche principali | Esito |
|---|---|---|
| Completeness | header **18 colonne**; riga = anagrafica completa (matricola, cognome, nome, **sesso, qualifica**) + corso, ente, data, **ore, esame (Sì/No), area** + stato, file, **Link PDF**, dimensione, note | ✅ |
| Integrità encoding | **BOM UTF-8** per Excel; accenti `àèéìòù` e apostrofi intatti; nessun U+FFFD | ✅ |
| Quoting RFC-4180 | campo con `;` interno e virgolette doppie → riga sempre a 18 campi (parser RFC-4180 di verifica) | ✅ |
| Anti CSV-injection | valore che inizia con `=` → anteposto `'` (Excel non lo interpreta come formula) | ✅ |
| Filtri esatti | **Area tematica**; **Dipendente**; **date con estremi INCLUSI** (1 e 31 marzo compresi, 31 escluso con `al=03-30`); filtri combinati = intersezione; `q` con metacaratteri LIKE trattati letteralmente | ✅ |
| **QA-C2** | filtri presenti ma non validi (area inventata, `dipendenteId=abc`, `dal=ieri`, `al=2026-13-99`, `stato=INVENTATO`) → **400**, prima venivano ignorati (archivio completo senza filtro!) | ✅ |
| Consistenza | vista paginata e export rispondono agli stessi filtri con gli stessi risultati | ✅ |

---

## 4. Difetti individuati e correzioni applicate

### 🐞 QA-C1 — URL `/login` rispondeva 404 «Cannot GET /login» (Medio)
- **Dove**: `src/app.js`. **Riscontro**: `GET /login` → 404 HTML inglese (la pagina di
  accesso è `index.html` servita su `/`; un link/segnalibro a `/login` cadeva nel 404 di default).
- **Fix**: alias esplicito `app.get('/login', … → 302 '/')` prima dello static.
- **Regressione**: `01-autenticazione.test.js` — «FIX QA-C1».

### 🐞 QA-C2 — Filtri di ricerca non validi IGNORATI silenziosamente (Medio)
- **Dove**: `src/routes/admin.routes.js` (`filtriCertificati`, usata da vista e export).
- **Riscontro**: `?area=Area%20fantasiosa` o `?dipendenteId=abc` o `?al=2026-13-99`
  NON venivano rifiutati: il filtro era scartato e la risposta conteneva **tutto
  l'archivio**, ingannando l'operatore («il filtro non funziona»).
- **Fix**: ogni filtro presente ma non valido solleva `ErroreFiltro`, tradotto dal
  wrapper `filtriSicuri()` in **400 con messaggio in italiano** (stessa validazione
  della data con `Date.parse` per scartare `2026-13-99`).
- **Regressione**: `07-export-filtri.test.js` — «FIX QA-C2» (×2).

### 🐞 QA-C3 — Un PDF di ESATTAMENTE 5 MB veniva rifiutato (Medio, boundary)
- **Dove**: `src/routes/certificati.routes.js` (limite `fileSize` di busboy/Multer).
- **Riscontro riproducibile**: 5.242.879 byte → 201 OK; **5.242.880 byte (5 MB esatti)
  → 400 «File troppo grande»**. busboy interrompe il file quando il contatore *tocca*
  il limite, quindi il limite documentato «max 5 MB» era di fatto «max 5 MB − 1».
- **Fix**: a busboy viene lasciato un margine tecnico di +1 KB e il limite ESATTO è
  applicato subito dopo sul file salvato (`req.file.size > config.maxFileBytes` →
  400 + cancellazione del file scritto: nessun orfano).
- **Regressione**: `03-upload-sicurezza.test.js` — «BOUNDARY: 5 MB esatti accettati».

### 🐞 QA-C4 — `dipendenteId` tollerante: `parseInt("1;DROP") = 1` (Basso)
- **Dove**: stesso costruttore filtri. `Number.parseInt` accetta prefissi numerici:
  un valore sporco come `1;DROP` diventava filtro silenzioso su `id=1`.
- **Fix**: il valore deve combaciare integralmente con `/^\d+$/`, altrimenti 400
  (la query restava comunque parametrica: nessun SQL injection, solo igiene degli input).
- **Regressione**: `07-export-filtri.test.js` — «FIX QA-C2» (include `1;DROP` → 400).

### 🔧 Aggiustamenti alla suite (non sono difetti dell'app)
Durante il triage i seguenti test sono stati corretti perché affliggevano il test e
non il codice: cookie manomesso testato su agente senza sessione (il jar dell'agente
loggato sovrascriveva l'header); matcher Jest corretti (`toBe` non accetta
`stringMatching` asimmetrico); shape reale del report import (`{riga, matricola,
errore}`); comportamenti **by-design** ora verificati e documentati: in *dry-run* la
password non è esposta (solo il flag `predefinita`), la password fornita
dall'amministratore non viene restituita (già la conosce), `esame_finale` assente =
non superato (il checkbox HTML non trasmette nulla quando è vuoto).

---

## 5. Come eseguire la suite

```bash
# 1) Dipendenze di test (già dichiarate in devDependencies):
npm install          # installa anche jest + supertest

# 2) TUTTO: regressione (74) + collaudo QA (116) — richiede MariaDB attivo:
npm test

# 3) Solo la suite di collaudo Jest+Supertest:
npm run test:qa

# 4) Solo la regressione storica:
node tests/prepare-db.js && node --test --test-concurrency=1 tests/
```

Prerequisiti: MariaDB/MySQL attivo con accesso root locale (`sudo mysql`, usato da
`tests/prepare-db.js` per creare `certificati_comune_test` dallo schema ufficiale)
e il file `.env` configurato (vedi `GUIDA-INSTALLAZIONE.md`). I test NON toccano mai
il database di produzione: usano `certificati_comune_test` + `uploads-qa/`.

---

## 6. Comportamenti confermati critici per il rilascio

1. **Password**: mai in chiaro su DB (verificato con `bcrypt.compare` e scan dei campi),
   mai nei log, mai esposte due volte (solo alla generazione/reset).
2. **Isolamento per matricola**: l'id del proprietario deriva SEMPRE dal token JWT
   rileggendo il DB, mai dai parametri client.
3. **Storage**: percorsi relativi, sanificati, anti-traversal, auto-riparanti.
4. **Degradazione controllata**: ogni input malformato produce 4xx con messaggio
   italiano comprensibile; nessun 500 osservato su oltre 400 richieste ostili.

## 7. Osservazioni di sicurezza (non bloccanti, da backlog)

| # | Osservazione | Rischio | Raccomandazione |
|---|---|---|---|
| O1 | Le revoche di sessione (logout) vivono **in memoria**: un riavvio le dimentica; un token copiato prima del logout resterebbe valido fino a scadenza (8 h) | Basso (intranet single-instance; lo stato utente `attivo` è comunque riletto dal DB) | Per ambienti HA: tabella `sessioni_revocate` o Redis |
| O2 | Le pagine HTML non sono protette server-side (protezione client-side + API autorizzate): l'HTML non contiene dati sensibili | Molto basso | Accettato (architettura statica senza build) |
| O3 | Rate-limit e registro tentativi in memoria: per istanza singola | Basso | Come O1 se si scala orizzontalmente |

---

**Verdetto finale: ✅ GO** — l'applicazione è stabile, sicura e conforme ai requisiti;
le correzioni QA-C1…C4 sono in codice, sotto regressione (190 test verdi) e verificate
anche sul server reale (smoke test post-deploy).

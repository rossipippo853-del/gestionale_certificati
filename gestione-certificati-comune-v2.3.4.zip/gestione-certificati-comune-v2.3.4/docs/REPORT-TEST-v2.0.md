# 📋 REPORT DEI TEST — v2.0.0 «Codice Fiscale come chiave dello storage + Upload admin»

| | |
|---|---|
| **Data** | 15/09/2026 |
| **Versione** | 2.0.0 (da 1.5.0) |
| **Suite** | `tests/` 76 test di regressione (node --test) · `tests-qa/` 135 test di collaudo (Jest 30 + Supertest 7) — **211 totali** |
| **Esito** | ✅ **211/211 PASS** + collaudo funzionale end-to-end sul server reale |

---

## 1. Modifiche architetturali applicate

### 1.1 Codice Fiscale: nuovo identificativo delle cartelle PDF

| File | Modifica |
|---|---|
| `db/schema.sql` | `dipendenti.codice_fiscale VARCHAR(16) NOT NULL` + `UNIQUE KEY uq_dipendenti_cf` |
| `db/migrazione-v2.0.sql` (**nuovo**) | ALTER progressivo per DB esistenti: colonna NULL → segnaposto univoco `X+id` → NOT NULL + UNIQUE; note operative per uniformare i vecchi archivi (rinomina cartelle + UPDATE percorsi) |
| `src/utils/validazione.js` | `RE_CODICE_FISCALE` (formato italiano canonico); `validaDatiDipendente` richiede il CF, normalizzato MAIUSCOLO |
| `src/utils/file.js` | `cartellaDipendente(cf)` → `uploads/certificati/{CODICE_FISCALE}/` |
| `src/middleware/auth.js`, `src/routes/auth.routes.js` | profilo utente con `codiceFiscale` (visibile in Profilo dipendente e admin) |
| `src/routes/certificati.routes.js` | Multer scrive in `cartellaDipendente(req.utente.codice_fiscale)`; percorso DB `certificati/{cf}/{file}` |
| `src/routes/admin.routes.js` | creazione singola: CF obbligatorio (validazione + INSERT + cartella CF + messaggi 409 distinti per matricola/CF duplicato); elenco/ricerca/options con CF; **export CSV con colonna «Codice Fiscale»** (19 colonne) |
| `src/utils/importazione.js` | colonna `codice_fiscale` obbligatoria (alias `cf`); riga in errore se malformato, duplicato nel file o già a DB; **CF mai modificato dall'opzione «aggiorna»** (mismatch → errore di riga); INSERT + cartella CF |
| `db/seed.js` | generatore di CF demo validi e univoci; PDF demo nelle cartelle CF |
| `db/modello-dipendenti.csv` | formato `nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale;email;ruolo;password_temporanea` |
| `public/admin.html`, `public/js/admin.js` | tabella Dipendenti con colonna CF (10 colonne); form nuovo utente con `nu-codice-fiscale` (required, pattern, uppercase); dialog import e modello CSV v2.0; ricerca filtra anche per CF; profilo con CF |
| `public/dipendente.html`, `public/js/dipendente.js` | Profilo con riga Codice Fiscale |

### 1.2 Nuova funzionalità: «Carica certificato per dipendente» (admin)

| File | Modifica |
|---|---|
| `src/routes/admin.routes.js` | **`POST /api/admin/certificati`**: multipart con `dipendenteId` + campi del corso + PDF. Storage in memoria → validazioni (dipendente esistente, PDF genuino via magic bytes, ≤5 MB, campi) → scrittura manuale in `uploads/certificati/{CF_DEL_DIPENDENTE}/` con nome univoco → INSERT a nome del dipendente, stato `IN_ATTESA` |
| `public/admin.html` | Bottone **«⬆ Carica per dipendente»** nella toolbar dei Certificati + dialog `dlg-carica-cert` (menu dipendente con *matricola — cognome nome · CF*, campi Titolo/Ente/Data/Ore/Esame/Area, file PDF) |
| `public/js/admin.js` | `apriCaricaPer()` (popola il menu da `/utenti/options`, ora con CF) + `eseguiCaricaPer()` (multipart, toast, refresh tabelle, errori nel dialog) |

**Sicurezza invariata**: la rotta è dentro il router admin (solo AMMINISTRATORE); il dipendente continua a scrivere SOLO nella propria cartella CF; download/eliminazione restano legati ai percorsi registrati a DB (che puntano alle cartelle CF).

---

## 2. Esito dei test — tabella riassuntiva per area

| # | Area (file di test) | Verifiche principali | Test | Esito |
|---|---|---|---|---|
| 1 | Creazione singola con CF (`utenti.test`, `05`) | 201 con cartella `{CF}` creata SUBITO; CF salvato MAIUSCOLO anche se dato minuscolo | 6 | ✅ |
| 2 | CF assente/malformato (`utenti.test`, `05`) | senza CF → 400; 15 caratteri / cifre al posto delle lettere / alfabeto errato → 400 con messaggio dedicato | 6 | ✅ |
| 3 | CF duplicato (`utenti.test`, `05`) | già registrato per altro dipendente → **409** «Codice Fiscale già registrato», nessun utente, nessuna cartella | 4 | ✅ |
| 4 | Import CSV con CF (`importazione.test`, `04`) | 250 utenti con CF univoci ben formati; colonna mancante nell'intestazione → 400; **CF malformato → riga in errore SENZA bloccare le altre**; CF duplicato nel file → segnalato; CF già a DB (altro matricola) → errore di riga e nessuna creazione; 250 cartelle `{CF}`; report con CF nel dry-run | 18 | ✅ |
| 5 | Import «aggiorna» e CF (`importazione.test`, `04`) | anagrafica aggiornata solo se il CF del file COINCIDE; CF diverso → errore «codice_fiscale non corrispondente», DB invariato; password MAI toccata | 4 | ✅ |
| 6 | Upload DIPENDENTE (cartella propria) (`certificati.test`, `03`, `06`) | il PDF finisce SOLO in `uploads/certificati/{PROPRIO_CF}`; percorso DB `certificati/{cf}/{file}`; self-healing ricrea la cartella CF cancellata; nessun orfano sui rifiuti | 26 | ✅ |
| 7 | **Upload ADMIN per dipendente** (`06`, `02`) | 201 → file FISICAMENTE nella cartella `{CF}` del dipendente scelto; percorso DB e `dipendente_id` corretti; stato IN_ATTESA; il dipendente lo vede nel proprio elenco e lo scarica; senza `dipendenteId` → 400; dipendente inesistente → 404; file non-PDF o campi mancanti → 400 e **nessuna scrittura su disco**; un DIPENDENTE che chiama la rotta admin → **403** (matrice RBAC aggiornata) | 7 | ✅ |
| 8 | Export e reportistica (`certificati.test`, `07`) | intestazione **19 colonne** con «Codice Fiscale» in seconda posizione; valori CF corretti in ogni riga; filtri (area/dipendente/date) e quoting invariati | 16 | ✅ |
| 9 | Regressione completa (tutte le altre aree) | autenticazione/sessioni, RBAC, sicurezza upload (tipi/5MB/magic bytes), filtri, self-healing, v1.5 avviso non bloccante, wiring frontend (nu-codice-fiscale, cc-*) | 124 | ✅ |
| | **TOTALE** | | **211** | **✅ tutti passati** |

## 3. Collaudo funzionale end-to-end (server reale :3000)

| Passo | Riscontro | Esito |
|---|---|---|
| Import reale di `db/modello-dipendenti.csv` | 4 creati con CF (`CRTMRA80A01H501U`…) e 0 errori; 4 cartelle CF su disco | ✅ |
| Upload admin per il dipendente 10001 (CF `GRSMRX56B02A101X`) | 201; PDF in `uploads/certificati/GRSMRX56B02A101X/`; DB: `certificati/GRSMRX56B02A101X/…`, `dipendente_id=2` | ✅ |
| Login del dipendente 10001 (password provvisoria) | profilo con CF; certificato «Caricato dall admin v20» nel suo elenco; download PDF 200 | ✅ |
| Export CSV filtrato | riga intestazione `…;Matricola;Codice Fiscale;Cognome;…` e valori CF popolati | ✅ |
| Creazione singola senza CF | 400 «Codice Fiscale non valido…» | ✅ |

## 4. Correzioni apportate durante il collaudo

| # | Anomalia | File | Correzione |
|---|---|---|---|
| C1 | Test «paginazione utenti» e «alias intestazione» ancorati al vecchio formato (senza CF) → 400/mancato match | `tests/utenti.test.js`, `tests/importazione.test.js` | payload/intestazioni aggiornati al formato v2.0 |
| C2 | Test usava `h.query` non esistente nell'helper storico | `tests/importazione.test.js` | sostituito con `h.pool.query` |
| C3 | Indici colonna export non aggiornati dopo l'inserimento del CF (offset +1) | `tests-qa/07` | indici riallineati (verifica con valori attesi) |
| C4 | CF di prova in un test non conforme al formato (7 lettere iniziali) | `tests-qa/04` | CF corretto (`ATRCFM80A01H501U`) |
| C5 | Messaggio del messaggio «colonne mancanti» ora include `codice_fiscale` | `tests/importazione.test.js` | regex aggiornata |

Nessun difetto rilevato nel codice applicativo: la suite è passata dopo l'allineamento dei test (comportamento atteso dopo un cambio di formato).

## 5. Come eseguire

```bash
npm install     # dipendenze + jest/supertest
npm test        # 76 regressione + 135 collaudo (richiede MariaDB attivo)
```

**Migrazione di un database esistente:** `mysql -u root -p < db/migrazione-v2.0.sql`
(assegna a ogni utente storico un segnaposto `X000…` da sostituire con il CF reale;
le istruzioni per uniformare le vecchie cartelle sono nel file).

---

**Verdetto:** ✅ PASS — v2.0.0 pronta: storage organizzato per Codice Fiscale,
import CSV con validazione CF, upload certificati da parte dell'amministratore
per conto di qualunque dipendente.

# 🎨 Riprogettazione tabella «Certificati caricati (vista globale)»

**Problema:** la tabella admin ha **13 colonne** (≈ 1.540px di larghezza minima): su schermi standard
(1024–1440px) scatta lo scroll orizzontale e **Stato, Note e Azioni** — le informazioni su cui l'amministratore
agisce — restano nascoste fuori schermo.

**Target:** tutte le informazioni rilevanti consultabili a colpo d'occhio su desktop 1024px+, **senza scroll
orizzontale**. Demo visiva interattiva: [`docs/demo-tabella-admin.html`](demo-tabella-admin.html)

---

## Le soluzioni (in ordine di impatto)

### 1 · Master-Detail / Row Expansion ✅ (raccomandata — implementata in v2.2.6)

La riga mostra solo le **7 informazioni decisionali**; tutto il resto passa in una **riga di dettaglio
espandibile** al click (o Enter/Spazio da tastiera), disegnata come griglia di micro-sezioni.

| Riga principale (7 colonne, ≈ 985px) | Riga di dettaglio (espandibile) |
|---|---|
| **Dipendente** (stack: matricola + nome + qualifica) | **Caricato il** (data/ora + peso file) |
| **Corso** (stack: corso + ente) | **Esame finale** (Sì/No) |
| **Conseguimento** | **Documenti** (pulsanti «Scarica» v2.2.4, tooltip col nome) |
| **Durata** (+ badge mini «Esame ✓» se previsto) | **Note** dell'amministratore |
| **Area tematica** (troncata + tooltip) | |
| **Stato** — ora sempre visibile ✔ | |
| **Azioni** (✔ approva · ✖ rifiuta · 🗑 elimina) — ora sempre visibili ✔ | |

**Perché funziona:** l'admin confronta/rifiuta/approva senza mai scorrere; i dettagli secondari restano
a un click e il valore ~985px entra anche a 1024px. Dettagli indipendenti (più righe aperte insieme),
freccia ▸ che ruota, `aria-expanded` per l'accessibilità.

**Regole di interazione:**
- il click su **pulsanti e link NON espande** la riga (`e.target.closest('button, a')` → skip);
- i testi lunghi si **troncano con ellipsis** (`max-width: 26ch`) e il testo completo sta nel `title`;
- riga con `tabindex="0"` + gestione Enter/Spazio (accessibile da tastiera).

### 2 · Badge e icone compatti (~220px risparmiati)

| Prima | Dopo |
|---|---|
| Colonna «Esame» con pill Sì/No grande | Badge mini `Esame ✓` (verde) **solo quando c'è l'esame**, dentro la cella Durata |
| Colonna «Stato» con testo esteso «In attesa di approvazione» | Badge compatto `⏳ In attesa` / `✔ Approvato` / `✖ Rifiutato` |
| Colonna «File» col nome (anche 60+ caratteri) | Nel dettaglio: pulsanti `⬇ Scarica` / `📄 Scarica 1 · 🖼 Scarica 2`, nome nel tooltip |
| Azioni testuali | Icone-comando `✔ ✖ 🗑` già compatte (`.btn.piccolo`) |

```css
/* badge mini, scope solo sulla tabella certificati */
#tabella-certificati .badge { font-size: .7rem; padding: .1rem .45rem; }
```

### 3 · Accorpamento colonne + truncatura controllata

Informazioni affini vivono in **una cella su più righe** (già il pattern della vista dipendente):

```html
<td>
  <div class="cella-principale"><span class="freccia-espandi">▸</span> 10040</div>
  <div class="cella-secondaria">Cascio Sara</div>
  <div class="cella-secondaria tronca" title="Assistente amministrativo">Assistente amministrativo</div>
</td>
<td>
  <div class="tronca" title="Contratti pubblici - aggiornamento annuale">Contratti pubblici - aggiornamento annuale</div>
  <div class="cella-secondaria tronca" title="Scuola Superiore della P.A.">Scuola Superiore della P.A.</div>
</td>
```

```css
/* ellipsis: mai righe chilometriche; il testo pieno resta nel tooltip */
.tronca { max-width: 26ch; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
```

3 colonne (Dipendente, Qualifica) → 1 · 2 colonne (Corso, Ente) → 1 · Esame → dentro Durata.

### 4 · Fallback «a schede» sotto i 768px (opzionale, solo CSS)

Se la tabella viene aperta da telefono, ogni riga diventa una scheda con etichette:

```css
@media (max-width: 768px) {
  #tabella-certificati thead { display: none; }
  #tabella-certificati tr { display: block; padding: .5rem 0; border-bottom: 1px solid var(--bordo); }
  #tabella-certificati td { display: flex; justify-content: space-between; border: 0; }
  #tabella-certificati td::before {
    content: attr(data-etichetta); /* es. data-etichetta="Durata" */
    font-size: .7rem; font-weight: 700; text-transform: uppercase; color: var(--testo-2);
  }
}
```
*Non attiva in v2.2.6 (target desktop): pronta da abilitare aggiungendo i `data-etichetta` alle `<td>`.)*

### 5 · Alternative considerate e scartate

| Alternativa | Perché no |
|---|---|
| **Ridurre il font/la densità** | Non basta: 13 colonne ≈ 1540px, anche al 90% sborda a 1440px |
| **Nascondere colonne dietro un selettore «colonne visibili»** | Sposta il problema: l'admin deve configurare, e Note/Azioni restano nascoste per default |
| **Tabella affiancata a un pannello dettaglio (split-view vera)** | Eccellente su ≥1440px, ma a 1024px ruba larghezza alle righe; l'espansione inline dà gli stessi dati senza tagli |
| **Tailwind** | Il progetto usa un design system CSS proprio (`stile.css` con variabili): si resta in CSS standard, zero dipendenze |

---

## Il codice della soluzione implementata (v2.2.6)

### HTML — thead (admin.html)

```html
<tr>
  <th>Dipendente</th><th>Corso</th><th>Conseguimento</th><th>Durata</th>
  <th>Area tematica</th><th>Stato</th><th>Azioni</th>
</tr>
```

### Render (admin.js) — per ogni certificato: 2 `<tr>`

Riga principale `.riga-principale` (7 celle) + riga `.riga-dettaglio nascosto` con
`colspan="7"` e griglia `Caricato il · Esame finale · Documenti · Note`.
I pulsanti «Scarica» (endpoint invariati `/api/certificati/allegati/:id/file`) vivono nel dettaglio.

### Toggle in delega (admin.js)

```js
function espandiDettaglio(e) {
  if (e.target.closest('button, a')) return;          // mai su pulsanti/link
  const riga = e.target.closest('tr.riga-principale');
  if (!riga) return;
  const dettaglio = riga.nextElementSibling;
  if (!dettaglio || !dettaglio.classList.contains('riga-dettaglio')) return;
  const oraChiuso = dettaglio.classList.toggle('nascosto');
  riga.classList.toggle('aperta', !oraChiuso);
  riga.setAttribute('aria-expanded', oraChiuso ? 'false' : 'true');
}
```

### CSS (stile.css) — vedi blocco `[v2.2.6]` in coda al file

`.riga-principale` (cursor/hover/focus) · `.freccia-espandi` (rotazione) · `.riga-dettaglio`
(sfondo soft) · `.griglia-dettaglio` (grid `auto-fit minmax(190px,1fr)`) · `.dettaglio-titolo` · `.tronca`.

---

## Budget di larghezza dopo il redesign

| Colonna | ≈ px |
|---|---|
| Dipendente (stack) | 185 |
| Corso (stack) | 230 |
| Conseguimento | 110 |
| Durata (+ Esame ✓) | 105 |
| Area tematica | 175 |
| Stato | 95 |
| Azioni | 85 |
| **Totale** | **≈ 985px → entra a 1024px ✔** |

**Verifica:** suite completa 318/318 (127 `node --test` + 191 Jest) con nuovo test strutturale
v2.2.6 (7 colonne esatte, dettaglio con le 4 sezioni, toggle sicuro, CSS presenti).

---

## Addendum v2.2.7 — Download in AZIONI + filtro Durata

**Download nella colonna AZIONI (il download è un'azione, non un'informazione):**
- **file unico o allegato singolo** → icona `⬇` come primo pulsante (prima di ✔ ✖ 🗑): download immediato, tooltip col nome originale;
- **più allegati** → pulsante `⬇ n` che apre la riga di dettaglio, dove ogni documento è una riga «icona · nome originale · dimensione · ⬇ Scarica»;
- perché funziona: le azioni restano raggruppate in un'unica colonna (zero larghezza extra altrove), l'obiettivo primario dell'admin (vedere/salvare il documento) è a un click senza espandere.

**Filtro Durata (min·max) senza appesantire la barra:**
- posizione: subito dopo l'intervallo di date (gli intervalli stanno insieme), etichetta «Durata (h:mm)»;
- due micro-input (`4.8rem`) separati da «–», segnaposto esemplificativi («es. 0:30» / «es. 40») al posto dell'aiuto esplicativo;
- accetta «8» oppure «1:30» → conversione in minuti lato client (parser condiviso `parserDurata`);
- valore non valido: non filtra e il campo si borda di rosso (`.input-nonvalido`), zero dialoghi modali;
- «Azzera» pulisce anche la durata; l'export CSV eredita gli stessi filtri;
- backend: `durataMin`/`durataMax` in minuti interi (solo cifre, altrimenti 400) sulla durata totale `(ore*60+minuti)` → anche i corsi da 0:45 sono filtrabili.

```css
/* [v2.2.7] i due micro-input del filtro durata */
.durata-filtri { display: flex; align-items: center; gap: .3rem; }
.durata-filtri input { width: 4.8rem; min-width: 0; }
.input-nonvalido { border-color: var(--rosso); background: var(--rosso-bg); }
/* riga documento nel dettaglio: icona · nome · peso · scarica */
.elenco-documenti { display: flex; flex-direction: column; gap: .3rem; }
.riga-documento { display: flex; align-items: center; gap: .45rem; font-size: .82rem; }
```

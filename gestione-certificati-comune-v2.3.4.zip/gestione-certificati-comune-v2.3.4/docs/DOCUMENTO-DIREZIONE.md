# PIATTAFORMA PER LA GESTIONE DEI CERTIFICATI DEI DIPENDENTI
## Documento di presentazione per la Dirigenza

| | |
|---|---|
| **Destinatari** | Dirigente, Direzione, Ufficio Formazione e Personale |
| **Oggetto** | Presentazione della piattaforma informatica per la gestione digitale dei certificati di formazione dei dipendenti comunali |
| **Versione documento** | 1.0 — 07/09/2026 |
| **Stato del progetto** | Sviluppato, testato (59 test automatici superati) e pronto per l'installazione sul server comunale |
| **Documento tecnico di corredo** | `ANALISI-TECNICA.md` (per il personale IT) |

---

## 1. Sintesi Esecutiva e Obiettivi del Progetto

### 1.1 Che cos'è

La piattaforma è un'applicazione web interna che consente ai **circa 250
dipendenti del Comune** di caricare, conservare e tenere traccia dei propri
**certificati di formazione e aggiornamento professionale** (corsi di
sicurezza, antincendio, primo soccorso, privacy, formazione informatica e
simili) e all'**Amministrazione** di verificare, approvare, ricercare ed
esportare tali documenti in piena autonomia.

### 1.2 Le criticità che il progetto risolve

| Criticità attuale (gestione tradizionale) | Soluzione offerta dalla piattaforma |
|---|---|
| Certificati cartacei o file sparsi su posta elettronica e cartelle condivise | Un **unico archivio digitale ordinato**, una fotografia sempre aggiornata |
| Difficoltà a sapere chi possiede quale attestato (verifiche ispettive, sopralluoghi ASL/ORG) | **Vista globale con ricerca immediata** per dipendente, corso, data e stato |
| Documenti smarriti, fotocopie non leggibili | PDF originale conservato **sul server del Comune**, scaricabile ogni volta dall'originale |
| Assenza di tracciabilità delle verifiche | Ogni documento ha uno **stato** (in attesa / approvato / rifiutato) con indicazione di chi e quando ha verificato |
| Compilazione di elenchi a mano per i report | **Esportazione in un clic** del report in formato apribile con Excel |
| Gestione degli accessi non regolata (file raggiungibili da chi non deve) | Accesso **personale con matricola e password**, ruoli distinti dipendente/amministratore |

### 1.3 Obiettivi

1. **Digitalizzazione completa** del flusso certificati per i ~250 dipendenti, con eliminazione del cartaceo.
2. **Tracciabilità integrale**: ogni caricamento, approvazione e rifiuto è registrato con data e autore.
3. **Sovranità dei dati**: tutto risiede sui server del Comune, all'interno della rete interna.
4. **Efficienza amministrativa**: riduzione dei tempi di ricerca, verifica e rendicontazione della formazione.

---

## 2. Funzionalità e Architettura dell'Applicazione

### 2.1 Profilo Dipendente — cosa fa il dipendente

- **Accesso personale** con matricola e password (nessun altro dato necessario).
- Al primo accesso con password provvisoria, il sistema **obbliga a sceglierne
  una nuova** (le scritture restano bloccate finché non lo fa).
- Sezione **Profilo**: consulta i propri dati e cambia la password quando vuole.
- Sezione **I miei certificati**:
  - carica un attestato compilando tre campi (titolo del corso, ente
    erogatore, data di conseguimento) e allegando il **PDF** (massimo 5 MB;
    il sistema rifiuta automaticamente file non validi o troppo grandi);
  - consulta l'elenco dei propri certificati con lo **stato di verifica** e
    l'eventuale motivazione comunicata dall'amministrazione in caso di rifiuto;
  - apre e scarica i propri documenti in qualsiasi momento.
- **Non può** vedere i certificati degli altri colleghi.

### 2.2 Pannello Amministratore — cosa fa l'ufficio preposto

- **Dashboard** con i numeri aggiornati: dipendenti, certificati caricati, in attesa, approvati, rifiutati.
- **Gestione dei dipendenti** (~250 utenti):
  - ricerca immediata per matricola o cognome;
  - creazione di nuovi account (il sistema propone una password provvisoria da comunicare al dipendente);
  - reset della password in caso di smarrimento;
  - disabilitazione/riabilitazione degli account (es. cessazioni, trasferimenti).
- **Verifica dei certificati**:
  - vista di **tutti** i documenti caricati, con filtri combinabili (dipendente, corso, periodo, stato);
  - apertura e scaricamento del PDF originale;
  - **approvazione** o **rifiuto motivato** di ogni attestato;
  - eliminazione definitiva di documenti errati o obsoleti.
- **Reportistica**: esportazione con un clic del registro completo (o della sola selezione filtrata) in **file CSV apribile con Excel**.

### 2.3 Organizzazione dei file e sicurezza dell'archivio

I certificati sono conservati come **normali file PDF sul disco del server
comunale**, dentro una cartella riservata per ciascun dipendente:

```
Server comunale
└── certificati/
    ├── 10001/   ← cartella personale del dipendente 10001
    │   ├── 173…-a1b2_sicurezza.pdf
    │   └── …
    ├── 10002/   …
    └── …250 cartelle…
```

- Il **database** contiene solo l'indice (chi ha caricato cosa, quando, con
  quale esito): resta leggero, veloce e semplice da salvare.
- Ogni cartella è accessibile **solo attraverso l'applicazione**, dopo login e
  con i controlli descritti al §3.2: non è raggiungibile "a mano" dalla rete.
- Le cartelle vengono **create automaticamente** alla registrazione del
  dipendente e, in caso di necessità, ricreate dal sistema al momento del
  caricamento: nessuna operazione manuale richiesta al personale IT.

---

## 3. Infrastruttura, Requisiti Tecnologici e Sicurezza dei Dati

### 3.1 Tecnologie impiegate (panoramica non tecnica)

| Componente | Tecnologia | Perché |
|---|---|---|
| Applicazione | Node.js (server web interno) | tecnologia matura, gratuita, ridotte esigenze hardware |
| Archivio dati | MySQL/MariaDB | database relazionale standard, già noto al personale IT |
| Documenti | File system del server (PDF) | i documenti restano "fisici" sul server, gestibili con i normali backup |
| Interfaccia | Qualsiasi browser web moderno | **i dipendenti non installano nulla** |

### 3.2 Misure di sicurezza implementate

| Ambito | Misura adottata |
|---|---|
| Password | conservate esclusivamente in forma **cifrata non invertibile** (algoritmo bcrypt, standard di settore) |
| Accessi | massimo 5 tentativi di accesso errato ogni 15 minuti per matricola; sessioni con scadenza a 8 ore; disconnessione che invalida realmente la sessione |
| Ruoli | due profili netti (dipendente / amministratore): ogni operazione è autorizzata sul server, non solo nell'interfaccia |
| Riservatezza dei documenti | ciascun dipendente accede **unicamente** ai propri certificati; i file richiesti al di fuori della propria posizione vengono negati |
| Documenti caricati | accettati **solo PDF autentici** fino a 5 MB, con controllo del contenuto reale e nomi tecnici non indovinabili |
| Tracciabilità | data di caricamento, esito della verifica, autore e data della verifica registrati nel database |
| Protezione dell'applicazione | sottoposta a **suite di 59 verifiche automatiche** (accessi, permessi, file, dati) tutte superate; aggiornamenti di sicurezza applicabili senza modifiche al codice |

### 3.3 Autonomia infrastrutturale

- La piattaforma **funziona interamente all'interno della rete interna
  comunale (intranet)**: nessuna connessione a Internet è richiesta per l'uso quotidiano.
- **Nessun servizio cloud esterno a pagamento**: tutto il software utilizzato
  è libero e gratuito; i costi ricorrenti si limitano all'energia e alla
  manutenzione ordinaria del server già in dotazione.
- Requisiti minimi del server: sistema Linux (o Windows) con Node.js e
  MariaDB, qualche centinaio di MB di spazio per l'applicazione e circa 1 MB
  per ogni certificato caricato (stimabile ~1 GB/anno a regime pieno).
- **Backup**: il personale IT dispone di istruzioni per il salvataggio
  programmato dell'indice (database) e dei documenti (cartella PDF).

> **Nota operativa**: l'applicazione è pensata per la rete interna. Qualora in
> futuro si volesse consentire l'accesso da remoto (es. smart working),
> l'ufficio IT dovrà predisporre il collegamento protetto (HTTPS) secondo le
> indicazioni incluse nella documentazione tecnica.

---

## 4. Istruzioni per l'Uso e Flusso di Lavoro (Manuale Utente Sintetico)

### 4.1 Guida per il DIPENDENTE

| Passo | Operazione |
|---|---|
| 1 | Aprire il browser e collegarsi all'indirizzo interno fornito dall'ufficio IT (es. `http://certificati.comune.local`) |
| 2 | Inserire **matricola** e **password** e premere «Accedi». Al primo accesso: inserire la password provvisoria ricevuta e **sceglierne subito una nuova** (minimo 8 caratteri, con lettere e numeri) |
| 3 | Aprire la scheda **«I miei certificati»** e compilare il form di caricamento: titolo del corso, ente erogatore, data di conseguimento |
| 4 | Selezionare il **PDF** del certificato (max 5 MB) e premere «Carica certificato» |
| 5 | Il documento compare nell'elenco con lo stato **«In attesa»**: attendere la verifica dell'ufficio |
| 6 | Tornando sulla pagina si potrà controllare l'esito: **«Approvato»**, oppure **«Rifiutato»** con la motivazione (in tal caso ricaricare un documento corretto) |
| 7 | In ogni momento è possibile **aprire** o **scaricare** i propri certificati; nella scheda «Profilo» si cambia la propria password |

### 4.2 Guida per l'AMMINISTRATORE

| Passo | Operazione |
|---|---|
| 1 | Accedere con le proprie credenziali: si apre il pannello amministrativo con i **contatori riepilogativi** |
| 2 | **Gestire i dipendenti**: scheda «Dipendenti» → cercare per matricola o cognome; pulsanti per **creare** un nuovo account (con password provvisoria da comunicare), **reimpostare** una password o **disabilitare/riabilitare** l'accesso |
| 3 | **Verificare i certificati**: scheda «Certificati» → filtrare per dipendente, stato, periodo o testo libero; aprire il PDF con «Scarica» |
| 4 | Per ogni documento in attesa: premere **✔** per approvare, oppure **✖** per rifiutare indicando la motivazione (visibile al dipendente) |
| 5 | Se necessario, **eliminare** definitivamente un documento errato (con conferma) |
| 6 | **Estrarre i report**: impostare eventuali filtri e premere «Export CSV» per ottenere il registro apribile con Excel |
| 7 | Buona prassi: cambiare la propria password al primo utilizzo e conservarla in modo adeguato |

### 4.3 Flusso di lavoro complessivo (sintesi)

```
DIPENDENTE                          SISTEMA                          UFFICIO PERSONALE
     │  carica il PDF del corso   →  archivia e marca "IN ATTESA"  →  avvisa (visibile in dashboard)
     │                                                                 │  apre e verifica il PDF
     │                                                                 ├── APPROVA  → il dipendente vede l'esito verde
     │  (se rifiutato: legge la     ←  registra esito e nota         ├── RIFIUTA con motivazione
     │   motivazione e ricarica)                                          └── oppure elimina (doc. errato)
     │                                                                 │  estrae report Excel quando richiesto
```

---

### In sintesi per la Dirigenza

- **Un solo strumento** per tutta la catena: caricamento da parte del dipendente, verifica dell'ufficio, archivio sempre interrogabile, report pronti per Excel.
- **Dati rimangono in Comune**, su server interno, con accessi regolati da matricola, password cifrate e ruoli.
- **Costi di gestione nulli o trascurabili**: software libero, nessuna licenza, nessun cloud.
- **Pronto all'uso**: applicazione sviluppata, collaudata con verifiche automatiche, con documentazione tecnica e manuale operativo inclusi.

# Nome invece dell'IP, SENZA passare dall'IT — opzioni reali (v2.2.9)

**Vincolo**: nessuna modifica sui PC dei dipendenti, nessuna richiesta al
gestore del DNS/server di rete.

**Premessa tecnica**: un PC trasforma un nome in IP solo consultando una
"rubrica" (DNS interno della rete, file hosts del singolo PC, oppure il DNS
pubblico di Internet). Le prime due sono escluse dal vincolo → l'unica strada
libera è un **nome pubblico esistente su Internet**.

---

## Le opzioni, in sintesi

| Opzione | Il dipendente… | Dati | Sforzo | Giudizio |
|---|---|---|---|---|
| **A. Link / segnalibio / QR code** | **clicca un link** (zero digitazione) | restano interni ✅ | 10 minuti | ★★★ **consigliata** |
| **B. Redirect Vercel** («insegna al neon») | digita un **nome** pubblico che riporta al portale interno | restano interni ✅ (su Vercel non passa nulla) | ~30 minuti | ★★ se volete proprio il nome |
| C. App completa su Vercel | digita un nome | **finiscono su cloud estero** ❌ + riscrittura (serverless: no filesystem, no MySQL) | settimane | ✗ sconsigliata |
| D. DNS interno (record A) | digita un nome interno | interni ✅ | 1 email all'IT | la soluzione "giusta", esclusa dal vincolo |

> Perché la C è scartata: Vercel è **serverless** — non conserva file su disco
> (gli allegati sparirebbero) e non offre MySQL/MariaDB; e per un ente pubblico
> mettere dati personali del personale su un cloud commerciale senza accordi è
> un problema GDPR oltre che tecnico.

---

## OPZIONE A — Link, segnalibio o QR code (consigliata)

Il bisogno reale è «i dipendenti non digitano numeri». Un link lo soddisfa
senza nomi, senza IT, senza rischi:

1. Completare il **PASSO 1** della guida NGINX (`GUIDA-NGINX-SEMPLICE`): da
   quel momento il portale risponde su `http://IP-DEL-SERVER/` (senza `:3000`).
2. Distribuire il **link** ai dipendenti, es. mail circolare:
   «Accedi al Portale Formazione: **http://192.168.1.50** — aggiungilo ai
   preferiti (Ctrl+D) e non dovrai più riscriverlo».
3. In alternativa (o in più) stampare un **QR code** (qualsiasi generatore
   gratuito) e affiggerlo: si punta il telefono… o si apre la camera dal PC e
   il browser offre di aprire l'indirizzo.

Il segnalibio una volta salvato è **più comodo di un nome a memoria**: un clic
e si è dentro, per sempre.

## OPZIONE B — Redirect Vercel («insegna al neon»)

Un sito minuscolo su Vercel (account gratuito) contiene **una sola istruzione**:
«chi entra qui → manda lo a `http://IP-DEL-SERVER`». Il nome pubblico viene
risolto dal DNS di Internet: nessuna modifica ai PC, nessun dato su Vercel.

Cartella pronta nel progetto: **`deploy/reindirizzamento-vercel/`**

```bash
# 1) sostituisci 192.168.1.50 con l'IP reale in vercel.json e index.html
# 2) installa lo strumento (una volta):
npm install -g vercel
# 3) dalla cartella deploy/reindirizzamento-vercel/:
vercel --prod
# 4) scegli «new project», nome visibile es. «portale-milazzo»
#    → i dipendenti useranno:  https://portale-milazzo.vercel.app
```

oppure, senza riga di comando: vercel.com → Add New Project → trascina la
cartella → Deploy.

**Limiti da conoscere** (trasparenza):
- i PC devono avere accesso a Internet (nella PA c'è quasi sempre; se c'è un
  proxy aziendale molto restrittivo potrebbe bloccare `*.vercel.app` → fai una
  prova da un PC dipendente prima di diffondere);
- dopo il click la barra degli indirizzi torna a mostrare l'IP (è il redirect
  stesso): nessun problema, i dipendenti non digitano più nulla;
- digitando solo il nome si finisce sulla **porta 80 del server → NGINX**:
  anche qui serve il PASSO 1 della guida NGINX.

### Perché in questo progetto c'è NGINX allora?

NGINX fa la «portineria» (porta 80 → 3000): è il pezzo comune a TUTTE le
opzioni (A, B e D). Quello che non può fare è creare nomi — i nomi vengono
sempre da una rubrica DNS, pubblica o interna che sia.

---

## Nota doverosa (una riga, poi taccio)

Anche scegliendo A o B, vale la pena **segnalare all'IT** l'esistenza del
servizio interno: se un domani acconsentiranno, un **unico record DNS**
(l'opzione D, 1 minuto di lavoro loro) dà ai dipendenti il nome interno
definitivo `portale.certificati`, senza Vercel e senza Internet.

---

*Guida v2.2.9 — file pronti per l'opzione B in `deploy/reindirizzamento-vercel/`,
configurazione NGINX in `deploy/nginx.conf`.*

# 🖥 GUIDA INSTALLAZIONE PC SERVER UFFICIO — Portale Formazione e Certificati
## Città di Milazzo · v2.2.9 · Windows 10/11 (percorsi consigliati) · ~1 ora

Obiettivo: trasformare il **PC dell'ufficio** nel server permanente del portale.
I dipendenti aprono il browser e digitano `http://IP-DEL-SERVER/` (senza
`:3000`, grazie a NGINX). Dopo l'installazione il PC resta **acceso sempre**.

> **Casi particolari**: se il server avesse **Ubuntu/Debian** invece di Windows,
> seguire `docs/GUIDA-SERVER-INTRANET.md` + `deploy/nginx.conf` (stessi passaggi
> logici, comandi Linux). Questa guida copre Windows, il caso più comune.

**Prima di iniziare servono:**
- il PC destinato a server (anche un PC normale va bene), collegato via **cavo** alla rete dell'ufficio;
- lo zip del portale (`gestione-certificati-comune-v2.2.9.zip`);
- diritti di **amministratore** su quel PC;
- ~1 GB di spazio libero su disco (cresceranno con gli allegati).

---

## PASSO 1 — IP fisso del server (10 min)

Il server deve avere un indirizzo che **non cambia mai**.

1. Trova i parametri attuali: `Win+R` → `cmd` → `ipconfig` → annota
   **Indirizzo IPv4** (es. `192.168.1.77`), **Subnet mask**, **Gateway predefinito**.
2. Imposta l'IP statico: **Impostazioni → Rete e Internet → Ethernet →
   Assegnazione IP → Modifica → Manuale → IPv4 attivo**:
   - Indirizzo IP: il tuo, cambiando solo l'ultimo numero in un valore alto e
     libero (es. `192.168.1.50`);
   - Subnet mask: `255.255.255.0` (o quella annotata);
   - Gateway e DNS preferito: il gateway annotato (es. `192.168.1.1`).
3. Verifica che il PC abbia ancora Internet: apri un sito qualsiasi.

*Alternativa elegante: fissare l'IP con una «prenotazione DHCP» sul router
dell'ufficio (se hai l'accesso): il PC resta in automatico e riceve sempre
lo stesso indirizzo.*

## PASSO 2 — Installare Node.js (5 min)

1. Scarica **Node.js LTS** da https://nodejs.org (installer Windows .msi).
2. Avanti → Avanti → spunta eventualmente «Add to PATH» (già di default) → Install.
3. Verifica (nuovo `cmd`): `node -v` → deve rispondere `v20…` o `v22…`.

## PASSO 3 — Installare MariaDB (database) (10 min)

1. Scarica **MariaDB** da https://mariadb.org/download (MSI per Windows).
2. Nel wizard:
   - **root password**: scegline una FORTE e **annotala** (servirà sempre);
   - lascia spuntato **«Install as Service»** con avvio **Automatico**;
   - lascia la porta **3306** e «UTF8 as default».
3. Verifica (nuovo `cmd`): `mysql -u root -p` → digiti la password → appare
   `MariaDB [(none)]>` → scrivi `exit`.

## PASSO 4 — Copiare il progetto e prepararlo (10 min)

1. Crea la cartella **`C:\certificati-comune`** ed estrai dentro lo zip
   (deve contenere `server.js`, `src`, `public`, `db`, `deploy`, `package.json`…).
2. `cmd` (normale):
   ```bat
   cd C:\certificati-comune
   npm install --omit=dev
   ```
   (scarica le librerie; richiede Internet SOLO in questo momento).

## PASSO 5 — Creare il database e l'utente dell'app (10 min)

`cmd` in `C:\certificati-comune`:

```bat
mysql -u root -p < db\schema.sql
```
(crea il database `certificati_comune` con tutte le tabelle, inclusa `audit_log`)

Poi crea l'utente che l'app usa per parlare col database (scegli una password
forte e **annotala**):
```bat
mysql -u root -p -e "CREATE USER IF NOT EXISTS 'cert_app'@'localhost' IDENTIFIED BY 'Forte!2026Milazzo'; CREATE USER IF NOT EXISTS 'cert_app'@'127.0.0.1' IDENTIFIED BY 'Forte!2026Milazzo'; GRANT ALL PRIVILEGES ON certificati_comune.* TO 'cert_app'@'localhost'; GRANT ALL PRIVILEGES ON certificati_comune.* TO 'cert_app'@'127.0.0.1'; FLUSH PRIVILEGES;"
```

**Primo account amministratore** (se parte da zero):
```bat
node db\seed.js --skip-certificati
```
crea l'admin `admin` / `Admin@2026` (più 12 dipendenti DEMO). In produzione
togli subito i demo (il DB è vuoto, non serve query speciale):
```bat
mysql -u root -p -e "DELETE FROM dipendenti WHERE matricola <> 'admin';"
```
Poi **entra e cambia subito la password dell'admin** (icona profilo → Cambia
password) e carica il personale reale con «Importa da CSV»
(v. `docs/IMPORT-DIPENDENTI.md`). Per una prova con 250 demo: `node db\seed.js`.

*Aggiornamento da un vecchio DB già esistente: dopo `schema.sql` esegui anche
`mysql -u root -p certificati_comune < db\migrazione-v2.2.9.sql`.*

## PASSO 6 — Configurare il file `.env` (5 min)

In `C:\certificati-comune`: copia `.env.example` e rinominalo **`.env`**.
Aprilo (Blocco note) e adatta:

| Riga | Valore consigliato | Note |
|---|---|---|
| `PORT` | `3000` | non si tocca |
| `HOST` | `127.0.0.1` | con NGINX davanti l'app resta "interna" |
| `DB_USER` / `DB_PASSWORD` | `cert_app` / la password del PASSO 5 | |
| `JWT_SECRET` | frase lunga casuale (min. 32 caratteri) | è la chiave dei login |
| `COOKIE_SECURE` | `false` | intranet in http (diventerebbe `true` solo con HTTPS) |
| `UPLOAD_DIR` | `uploads` | qui finiscono i PDF/JPG |

## PASSO 7 — Primo avvio di prova (5 min)

```bat
cd C:\certificati-comune
npm start
```
Sul server: apri `http://127.0.0.1:3000` → login admin → cambia la password.
Lasciare questa finestra aperta per ora; il PASSO 10 la renderà automatica.

## PASSO 8 — NGINX (porta 80, per togliere «:3000») (10 min)

1. Scarica la versione **Windows** di NGINX: https://nginx.org/en/download.html
   (Stable version, zip). Estrai in **`C:\nginx`**.
2. Copia `C:\certificati-comune\deploy\nginx-windows.conf` in
   `C:\nginx\conf\nginx.conf` (sostituisci il file esistente).
3. Verifica e avvia (`cmd`):
   ```bat
   cd C:\nginx
   nginx.exe -t          (deve dire «successful»)
   start nginx.exe
   ```
4. Prova: `http://127.0.0.1/` → login del portale SENZA `:3000`.
   Per fermarlo in futuro: `nginx.exe -s stop` (da `C:\nginx`).

## PASSO 9 — Firewall: apri SOLO la porta 80 (5 min)

`cmd` **come Amministratore**:
```bat
netsh advfirewall firewall add rule name="Portale Formazione (HTTP 80)" dir=in action=allow protocol=TCP localport=80
```
Non aprire la 3000: dall'esterno si entra solo tramite NGINX. (Se al PASSO 7
hai messo `HOST=127.0.0.1`, la 3000 non è raggiungibile dalla rete nemmeno
bypasstando il firewall: doppia protezione.)

## PASSO 10 — Avvio automatico al riavvio del PC (10 min)

MariaDB si avvia già da solo (servizio installato al PASSO 3). Per **app**
e **NGINX**, da `cmd` come Amministratore:

```bat
schtasks /Create /TN "Portale - App"    /TR "C:\certificati-comune\deploy\windows\avvio-portale.bat" /SC ONSTART /RU SYSTEM /RL HIGHEST /F
schtasks /Create /TN "Portale - NGINX"  /TR "\"C:\nginx\nginx.exe\" -p C:\nginx" /SC ONSTART /RU SYSTEM /RL HIGHEST /F
```

**Prova del nove**: riavvia il PC → attendi 1 minuto → da un PC qualsiasi
dell'ufficio apri `http://IP-DEL-SERVER/` → compare il login. Riavvio
superato = installazione a prova di domenica.

## PASSO 11 — Backup automatici (10 min, da fare SÌ)

1. Crea `C:\certificati-comune\deploy\windows\backup.cnf` (Blocco note) con:
   ```
   [client]
   password="PASSWORD-ROOT-MARIADB"
   ```
2. Crea la cartella `C:\Backup`.
3. Pianifica il backup quotidiano delle 20:30 (Amministratore):
   ```bat
   schtasks /Create /TN "Portale - Backup" /TR "C:\certificati-comune\deploy\windows\backup-giornaliero.bat" /SC DAILY /ST 20:30 /RU SYSTEM /RL HIGHEST /F
   ```
4. Al primo giorno controlla che esista `C:\Backup\Portale\AAAA-MM-GG\` con
   `database.sql` + la cartella `uploads`.
5. **Consiglio**: ogni tanto copia una cartella di backup su un disco USB o su
   un'altra macchina (i backup sullo stesso disco non proteggono dai guasti).

---

## Manutenzione e buone regole

| Tema | Regola |
|---|---|
| **Nuova versione del portale** | estrai lo zip nuovo in una cartella temporanea → copia i file SU `C:\certificati-comune` tranne `.env` e `uploads\` → `npm install --omit=dev` → esegui eventuali `db\migrazione-*.sql` → riavvia: `schtasks /Run /TN "Portale - App"` (e riavvia NGINX solo se è cambiato) |
| **Il PC server si riaccende** | tutto riparte da solo: MariaDB (servizio) + app + NGINX (attività pianificate) |
| **Non esporre su Internet** | niente «apertura porte» sul router verso il server: il portale è per la rete interna |
| **PC sempre acceso** | disattiva lo spegnimento automatico notturno (solo lo schermo può spegnersi); un UPS (gruppo di continuità) è un plus |
| **Windows Update** | va bene: dopo il riavvio tutto riparte da solo (v. PASSO 10) |
| **Vercel (Opzione B)** | nei file di `deploy\reindirizzamento-vercel\` metti l'IP del server ufficio SENZA `:3000` (es. `http://192.168.1.50/`) e ri-pubblica |
| **Problemi** | log app: finestra attività o `logs\` ; log NGINX: `C:\nginx\logs\` ; guida `GUIDA-NGINX-SEMPLICE-v2.2.9.md` |

## Checklist finale

- [ ] `http://IP-DEL-SERVER/` apre il login da un PC qualsiasi (senza :3000)
- [ ] login admin OK, password cambiata
- [ ] personale reale importato da CSV
- [ ] upload di prova (PDF) e download OK
- [ ] PC riavviato → tutto riparte da solo
- [ ] backup giornaliero attivo e verificato
- [ ] (opzionale) redirect Vercel aggiornato con l'IP del server

---

*Guida v2.2.9 — Città di Milazzo, Portale Formazione e Certificati.*

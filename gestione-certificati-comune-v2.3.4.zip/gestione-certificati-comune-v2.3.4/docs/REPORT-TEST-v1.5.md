# 📋 REPORT FINALE DEI TEST — v1.5.0 «Onboarding senza blocchi + Server Intranet»

| | |
|---|---|
| **Data** | 12/09/2026 |
| **Versione** | 1.5.0 (da 1.4.1) |
| **Suite** | `tests/` 74 test di regressione (node --test) · `tests-qa/` 126 test di collaudo (Jest 30 + Supertest 7) — **200 totali** |
| **Esito** | ✅ **200/200 PASS** — modifiche verificate anche sul server reale (smoke test HTTP su interfaccia di rete) |

---

## 1. Modifica logica applicata (onboarding)

**Richiesta:** il dipendente con password provvisoria deve poter caricare i
certificati SENZA alcun blocco, vedendo solo un avviso che ricorda di cambiare
la password assegnata dall'admin.

### File modificati
| File | Modifica |
|---|---|
| `src/routes/certificati.routes.js` | **Rimosso** il middleware `richiediPasswordAggiornata` dal `POST /api/certificati` (upload sempre consentito). Documentazione aggiornata. |
| `src/middleware/auth.js` | Il middleware resta definito e usato SOLO dall'area ADMIN (scritture amministrative); documentazione aggiornata a v1.5. |
| `public/js/dipendente.js` | Rimosso il ramo client che gestiva l'errore `PASSWORD_TEMPORANEA` («Operazione bloccata…»); l'upload non è mai intercettato. Banner informativo NON bloccante confermato. |
| `public/dipendente.html` | Banner riformulato: «stai usando la password provvisoria… **puoi usare subito tutte le funzioni (incluso il caricamento dei certificati)**, ti consigliamo di cambiarla dal Profilo; l'avviso sparirà dopo il cambio». |

**Comportamento residuo voluto:** l'ADMIN con password provvisoria continua a
avere le proprie SCRITTURE amministrative bloccate (reset password, import,
approvazioni…): requisito di sicurezza distinto, non toccato da questa modifica.

---

## 2. Tabella dei test — Modifica logica (v1.5)

| # | Test (file) | Verifica | Esito |
|---|---|---|---|
| T1 | `[v1.5] con password provvisoria si PUÒ caricare` (`tests/utenti.test.js`) | login con provvisoria → upload → **201**; `must_change_password` resta 1 (avviso attivo); dopo il cambio → `/me` con `mustChangePassword=false` | ✅ Passato |
| T2 | `[v1.5] upload CONSENTITO + avviso attivo` (`tests-qa/06`) | come T1 su Jest/Supertest + file PDF salvato sul disco + record in elenco | ✅ Passato |
| T3 | `avviso non bloccante: nessun blocco client-side` (`tests-qa/06`) | in `dipendente.js` NON esiste più il ramo `codice === 'PASSWORD_TEMPORANEA'` né il messaggio «Operazione bloccata»; il bottone upload si disabilita solo durante l'invio | ✅ Passato |
| T4 | `il banner è informativo` (`tests-qa/06`) | banner parte nascosto, mostrato quando `mustChangePassword=true`, testo esplicitamente non bloccante, link alla sezione Profilo | ✅ Passato |
| T5 | `dopo il cambio password il banner viene nascosto` (`tests-qa/06`) | wiring del nascondimento banner nel gestore `cambiaPassword` | ✅ Passato |
| T6 | **Smoke live su server :3000** | utente demo 10001 (password `Benvenuto@2026`, cambio obbligatorio): login 200 → `/me` `mustChangePassword=true` → upload PDF **201** | ✅ Passato |

## 3. Tabella dei test — Server Intranet / rete (nuovo file `tests-qa/08`)

| # | Test | Verifica | Esito |
|---|---|---|---|
| N1 | `default HOST = 0.0.0.0` | config di ascolto parametrica via `HOST` env, predefinita su tutte le schede | ✅ Passato |
| N2 | `.env.example documenta HOST/COOKIE_SECURE/PORT` | configurazione di rete autodocumentata | ✅ Passato |
| N3 | `risponde su 127.0.0.1` | loopback operativo su porta effimera | ✅ Passato |
| N4 | `risponde su OGNI IP IPv4 non-internal` | richieste servite sull'interfaccia di rete (= client remoto della intranet su `http://IP:3000`) | ✅ Passato |
| N5 | `login + chiamata autenticata ATTRAVERSO l'interfaccia di rete` | cookie `SameSite=Lax`, `secure=false`: sessione valida via IP di rete | ✅ Passato |
| N6 | `pagine senza risorse esterne` | nessun CDN/script/immagine esterna: funziona anche senza Internet | ✅ Passato |
| N7 | `nessun Access-Control-Allow-Origin` | frontend a stessa origine: CORS correttamente non presente | ✅ Passato |
| N8 | **Smoke live via IP reale** (`169.254.0.21:3000`) | salute 200 · login admin 200 · API admin 200 | ✅ Passato |

**Conclusioni configurazione**: nessuna modifica a rotte/CORS/cookie richiesta
per la intranet; unico parametro nuovo `HOST=0.0.0.0` nel `.env` (documentato in
`.env.example`, in `src/config.js` e in `server.js`, che ora logga l'URL di
accesso di rete).

## 4. Tabella dei test — Stabilità delle funzioni esistenti (regressione)

| Area | Suite | Test | Esito |
|---|---|---|---|
| Autenticazione/sessioni/redirect | `tests/api.test.js` + `tests-qa/01` | 24 | ✅ Passati |
| RBAC e isolamento certificati | `tests-qa/02` | 10 | ✅ Passati |
| Sicurezza upload (tipi, 5 MB, magic bytes, univocità) | `tests-qa/03` | 11 | ✅ Passati |
| Import CSV 250 utenti, duplicati, dry-run, cartelle | `tests/importazione.test.js` + `tests-qa/04` | 24 | ✅ Passati |
| CRUD admin + wiring UI (modali, tabelle) | `tests/utenti.test.js` + `tests-qa/05` | 27 | ✅ Passati |
| Validazione form certificato + self-healing FS | `tests/certificati.test.js` + `tests-qa/06` | 22 | ✅ Passati |
| Export CSV/Excel 18 colonne + filtri esatti | `tests-qa/07` | 13 | ✅ Passati |
| Frontend (loop login, api(), CSP, banner) | `tests/frontend.test.js` | 12 | ✅ Passati |
| **Totale** | | **200** | **✅ tutti passati** |

## 5. Correzioni apportate durante il ciclo

| # | Anomalia rilevata | Azione correttiva | Esito |
|---|---|---|---|
| C1 | Test strutturale T3 matchava i COMMENTI esplicativi («Niente più caso PASSWORD_TEMPORANEA…») al posto della logica | regex puntata sul vecchio ramo operativo (`codice === 'PASSWORD_TEMPORANEA'`, messaggio «Operazione bloccata») | ✅ corretto |
| C2 | Ambiente di collaudo reinizializzato tra le sessioni (MariaDB assente, `node_modules` persi) | reinstallato MariaDB 11.8, dipendenze, ricostruito DB demo (251 utenti) e utenti applicativi | ✅ risolto |
| C3 | `schema.sql` crea `cert_app` con password predefinita (IF NOT EXISTS non sovrascrive) → Access denied del seed | `ALTER USER` allineato alla password di `.env` (procedura già documentata in GUIDA-SERVER-INTRANET §A3) | ✅ risolto |

Nessun difetto nel codice applicativo: la modifica logica v1.5 è passata al primo
colpo su tutti i test API e frontend, oltre allo smoke live.

## 6. Come rieseguire i test

```bash
npm install          # dipendenze + devDependencies (jest, supertest)
npm test             # 74 regressione + 126 collaudo (richiede MariaDB attivo)
npm run test:qa      # solo la suite Jest/Supertest
```

---

**Verdetto:** ✅ PASS — la v1.5.0 è pronta per il deployment sul PC server
dell'intranet comunale (guida: `docs/GUIDA-SERVER-INTRANET.md`).

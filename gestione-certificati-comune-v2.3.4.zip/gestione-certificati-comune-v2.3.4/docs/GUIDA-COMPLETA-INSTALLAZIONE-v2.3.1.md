# GUIDA COMPLETA — Portale Formazione e Certificati · Città di Milazzo
## Installazione ambiente di TEST (casa) e di PRODUZIONE (intranet comunale) · v2.3.1

Questa guida sostituisce e unifica le guide d'installazione precedenti
(GUIDA-SERVER-INTRANET, GUIDA-SEMPlice-PC-SERVER, GUIDA-INSTALLAZIONE-SERVER,
GUIDA-NGINX-SEMPLICE e relative varianti). Stack tecnico (da `package.json`):
**Node.js ≥ 18 (consigliato 20 LTS)** · Express · **MariaDB/MySQL** (driver
`mysql2` — non è usato SQLite né PostgreSQL) · bcryptjs · multer.

Convenzioni: sostituisci sempre `192.168.1.50` con l'IP reale del server e
`C:\certificati-comune` con la cartella reale del progetto.

---

# PARTE 1 — INSTALLAZIONE AMBIENTE DI TEST (PC DI CASA)

Obiettivo: far girare e collaudare il portale sul tuo PC personale.

## 1. Requisiti e preparazione

| Software | Versione | Dove |
|---|---|---|
| Node.js | ≥ 18, consigliato **20 LTS** | https://nodejs.org (installer .msi/.pkg: Avanti→Fine) |
| MariaDB | 10.6+ (consigliata 11.x) | https://mariadb.org/download — wizard Windows: **password root** da annotare + «Install as Service» spuntato |

Verifica (nuovo terminale):

```bash
node -v     # → v20.x.x o superiore
mysql --version
```

## 2. Configurazione ambiente (.env)

Dalla cartella del progetto: copia `.env.example` e rinominalo **`.env`**.

```bash
# Windows:  copy .env.example .env
# Linux/macOS:
cp .env.example .env
```

Contenuto adatto al test casalingo (genera il segreto JWT con
`openssl rand -hex 32`, oppure da Windows:
`node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`):

```ini
PORT=3000
HOST=0.0.0.0
DB_HOST=localhost
DB_PORT=3306
DB_USER=cert_app
DB_PASSWORD=C3rt!2026Demo
DB_NAME=certificati_comune
JWT_SECRET=INCOLLA-QUI-IL-SEGRETO-DI-64-CARATTERI-ESADECIMALE
JWT_SCADENZA=8h
COOKIE_SECURE=false
UPLOAD_DIR=uploads
```

> `COOKIE_SECURE=false` è obbligatorio in http locale: con `true` il browser
> rifiuta i cookie e il login non funziona.

## 3. Installazione e avvio

```bash
# 3.1 dipendenze (una volta sola)
npm install

# 3.2 database: schema completo (db + tabelle + audit_log)
#     Linux: sudo mariadb   ·   Windows: mysql -u root -p
sudo mariadb < db/schema.sql

# 3.3 utente applicativo (la stessa password del .env)
sudo mariadb -e "CREATE USER IF NOT EXISTS 'cert_app'@'localhost' IDENTIFIED BY 'C3rt!2026Demo'; CREATE USER IF NOT EXISTS 'cert_app'@'127.0.0.1' IDENTIFIED BY 'C3rt!2026Demo'; GRANT ALL PRIVILEGES ON certificati_comune.* TO 'cert_app'@'localhost'; GRANT ALL PRIVILEGES ON certificati_comune.* TO 'cert_app'@'127.0.0.1'; GRANT ALL PRIVILEGES ON certificati_comune_test.* TO 'cert_app'@'localhost'; GRANT ALL PRIVILEGES ON certificati_comune_test.* TO 'cert_app'@'127.0.0.1'; FLUSH PRIVILEGES;"

# 3.4 dati dimostrativi: admin + 250 dipendenti fittizi + certificati demo
node db/seed.js --dipendenti=250

# 3.5 avvio
npm start          # → «Server avviato su http://0.0.0.0:3000»
```

> Su un DB vecchio già esistente (installazioni pre-2.2.9) esegui anche la
> migrazione: `sudo mariadb certificati_comune < db/migrazione-v2.2.9.sql`.
> Le release 2.3.0/2.3.1 NON richiedono migrazioni (solo codice).

**Suite di test automatica** (facoltativa ma consigliata; usa il DB separato
`certificati_comune_test`):

```bash
sudo mariadb -e "DROP DATABASE IF EXISTS certificati_comune_test; CREATE DATABASE certificati_comune_test;"
sudo mariadb certificati_comune_test < db/schema.sql
npm test           # atteso: 143 + 232 = 375/375 PASS
```

## 4. Verifica e collaudo locale

| Verifica | Come | Atteso |
|---|---|---|
| App attiva | apri `http://localhost:3000` | pagina di login «Città di Milazzo» |
| Stato server | apri `http://localhost:3000/api/salute` | `{"stato":"ok",…}` |
| Login admin | `admin` / `Admin@2026` | area amministratore |
| Login dipendente | `10001` / `Benvenuto@2026` (matricole 10001–10250) | cambio password obbligatorio al primo accesso |
| Prova completa | carica un PDF ≤ 5 MB, poi approvalo da admin | ciclo di vita completo |

Cose da provare (novità recenti): dashboard formazione per dipendente
(admin → ricerca per nome/matricola/CF, KPI, target 40 ore, «✕ Chiudi
scheda») · tabelle senza scrollbar orizzontale · export CSV anagrafica ·
chiusura scheda/browser → re-login (sessione di scheda).

---

# PARTE 2 — INSTALLAZIONE SERVER DI PRODUZIONE (PC DEL COMUNE / INTRANET)

Obiettivo: PC dedicato sempre acceso; i dipendenti accedono da qualsiasi
postazione con `http://IP-DEL-SERVER/` (senza `:3000`, grazie a NGINX).

## 1. Preparazione server e requisiti di rete

1. **PC server**: Windows 10/11 o Ubuntu/Debian, collegato **via cavo**, mai
   spento (solo lo schermo può andare in standby). Installa Node.js LTS e
   MariaDB come in PARTE 1 §1 (Windows: MariaDB come servizio automatico).
2. **IP statico** (indispensabile: se cambia, i client non trovano più il
   portale).
   - *Windows*: `ipconfig` → annota IPv4/subnet/gateway → Impostazioni →
     Rete e Internet → Ethernet → Assegnazione IP → **Manuale** →
     IP `192.168.1.50` (ultimo numero alto e libero), subnet `255.255.255.0`,
     gateway e DNS = gateway annotato.
   - *Linux (netplan)*:

     ```yaml
     network:
       version: 2
       ethernets:
         eth0:
           addresses: [192.168.1.50/24]
           routes:
             - to: default
               via: 192.168.1.1
           nameservers:
             addresses: [192.168.1.1]
     ```
3. **Firewall — aprire SOLO la porta 80** (la 3000 resta interna):

   ```bat
   :: Windows, cmd come Amministratore
   netsh advfirewall firewall add rule name="Portale Formazione (HTTP 80)" dir=in action=allow protocol=TCP localport=80
   ```

   ```bash
   # Linux
   sudo ufw allow 80/tcp
   ```
4. **Mai** aprire porte del router verso Internet: il portale è solo intranet.

## 2. Configurazione e migrazioni

1. Copia il progetto in **`C:\certificati-comune`** (Windows) o
   **`/opt/certificati-comune`** (Linux), poi:

   ```bash
   npm install --omit=dev
   ```

2. **`.env` di produzione** (parti da `.env.example`): differenze chiave vs test

   ```ini
   PORT=3000
   HOST=127.0.0.1              # dietro NGINX l'app resta interna alla macchina
   DB_USER=cert_app
   DB_PASSWORD=PASSWORD-FORTE-DEDICATA          # NON la password del test
   DB_NAME=certificati_comune
   JWT_SECRET=SEGRETO-NUOVO-E-RISERVATO-64-CARATTERI   # MAI condiviso col test
   JWT_SCADENZA=8h
   COOKIE_SECURE=false         # intranet http (true solo se attivi HTTPS su NGINX)
   UPLOAD_DIR=uploads
   ```

3. **Database nuovo** (installazione da zero):

   ```bash
   sudo mariadb < db/schema.sql          # crea db, tabelle e audit_log
   ```

   ```sql
   -- utente applicativo con password forte
   CREATE USER IF NOT EXISTS 'cert_app'@'localhost' IDENTIFIED BY 'PASSWORD-FORTE-DEDICATA';
   GRANT ALL PRIVILEGES ON certificati_comune.* TO 'cert_app'@'localhost';
   GRANT ALL PRIVILEGES ON certificati_comune.* TO 'cert_app'@'127.0.0.1';
   FLUSH PRIVILEGES;
   ```

   **Migrazioni — solo se aggiorni un DB vecchio già esistente** (installazione
   fresca: salta). Esegui in ordine, una volta sola, le mancanti:

   ```bash
   sudo mariadb certificati_comune < db/migrazione-v1.4.sql      # da v1.3 o precedente
   sudo mariadb certificati_comune < db/migrazione-v2.0.sql      # codici fiscali
   sudo mariadb certificati_comune < db/migrazione-v2.2.sql      # durata hh:mm
   sudo mariadb certificati_comune < db/migrazione-v2.2.5.sql    # aree tematiche
   sudo mariadb certificati_comune < db/migrazione-v2.2.9.sql    # audit_log
   # v2.3.0 e v2.3.1: nessuna migrazione (solo codice)
   ```

4. **Account amministratore e personale reale**:

   ```bash
   node db/seed.js --skip-certificati     # crea admin (Admin@2026) + 12 demo
   sudo mariadb -e "DELETE FROM dipendenti WHERE matricola <> 'admin';"   # via i demo
   ```

   Accedi subito come `admin`, **cambia la password** (icona profilo), poi
   carica il personale con «Importa da CSV» (modello: `db/modello-dipendenti.csv`,
   istruzioni in `docs/IMPORT-DIPENDENTI.md`).

## 3. Gestione del servizio e avvio automatico

**Windows** — attività pianificate (app + NGINX ripartono da soli al riavvio;
MariaDB è già un servizio):

```bat
schtasks /Create /TN "Portale - App"   /TR "C:\certificati-comune\deploy\windows\avvio-portale.bat" /SC ONSTART /RU SYSTEM /RL HIGHEST /F
schtasks /Create /TN "Portale - NGINX" /TR "\"C:\nginx\nginx.exe\" -p C:\nginx" /SC ONSTART /RU SYSTEM /RL HIGHEST /F
```

**Alternativa multipiattaforma PM2** (gestione log e riavvii):

```bash
sudo npm i -g pm2
pm2 start deploy/ecosystem.config.js
pm2 save && pm2 startup            # Linux: avvio al boot
pm2 save && pm2-startup install    # Windows (npm i -g pm2-windows-startup)
```

**Linux systemd** (unità già pronta in `deploy/certificati.service`):

```bash
sudo cp deploy/certificati.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now certificati
```

## 4. Reverse proxy e webserver (NGINX)

NGINX riceve i client sulla **porta 80** e instrada tutto all'app (porta 3000);
gli asset statici (`css/`, `js/`, immagini) sono serviti dall'app stessa
attraverso il proxy — nessuna configurazione aggiuntiva. Il limite per gli
upload multipli è già impostato (`client_max_body_size 25m`).

**Windows** (zip da https://nginx.org/en/download.html → estrai in `C:\nginx`):

```bat
copy C:\certificati-comune\deploy\nginx-windows.conf C:\nginx\conf\nginx.conf
cd C:\nginx
nginx.exe -t          && start nginx.exe
```

**Linux** (config già pronta, `server_name portale.certificati` inclusa):

```bash
sudo apt install -y nginx
sudo cp deploy/nginx.conf /etc/nginx/sites-available/portale-certificati
sudo ln -s /etc/nginx/sites-available/portale-certificati /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
```

Contenuto essenziale (già nei file indicati — non riscriverlo):

```nginx
server {
    listen 80;
    server_name portale.certificati certificati.comune.milazzo.it;
    client_max_body_size 25m;
    location / {
        proxy_pass         http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
    }
}
```

> Nome «parlante» per i dipendenti (opzionale): record A sul DNS interno
> (`portale.certificati` → IP server, guida `GUIDA-DOMINIO-LOCALE`) oppure
> redirect pubblico via Vercel (`COME-ACCEDERE-SENZA-DNS`). Il portale
> funziona comunque subito con `http://IP-DEL-SERVER/`.

## 5. Accesso e manutenzione

**Primo accesso dalla rete interna**

1. Da un PC qualsiasi: `http://192.168.1.50/` → login `admin`
   → **cambia subito la password**.
2. Importa il personale reale («Importa da CSV»).
3. Prova del ciclo completo: upload PDF da un dipendente → approvazione admin
   → download numerato.

**Backup giornalieri automatici** (database + allegati)

- *Windows* — crea `deploy\windows\backup.cnf` con la password root:

  ```ini
  [client]
  password="PASSWORD-ROOT-MARIADB"
  ```

  poi pianifica (alle 20:30; il `.bat` esegue mysqldump + copia `uploads\`
  e cancella i backup oltre 30 giorni):

  ```bat
  schtasks /Create /TN "Portale - Backup" /TR "C:\certificati-comune\deploy\windows\backup-giornaliero.bat" /SC DAILY /ST 20:30 /RU SYSTEM /RL HIGHEST /F
  ```

  Verifica il giorno dopo: `C:\Backup\Portale\AAAA-MM-GG\` con `database.sql`
  e la cartella `uploads`. Copia periodicamente un backup su disco USB esterno.

- *Linux* — cron:

  ```bash
  sudo crontab -e
  # 20:30 backup DB + allegati, retention 30 giorni
  30 20 * * * mysqldump --defaults-extra-file=/root/.my.cnf certificati_comune > /var/backups/portale/db-$(date +\%F).sql && tar czf /var/backups/portale/uploads-$(date +\%F).tgz /opt/certificati-comune/uploads && find /var/backups/portale -mtime +30 -delete
  ```

**Aggiornamento a una nuova versione**

```bash
# 1) estrai il nuovo zip in una cartella temporanea
# 2) copia tutto nel progetto ESCLUSO .env e uploads\
# 3) dipendenze + eventuali migrazioni (vedi §2 punto 3) + riavvio
npm install --omit=dev
sudo systemctl restart certificati        # Linux
schtasks /Run /TN "Portale - App"         # Windows
sudo systemctl reload nginx               # solo se è cambiato nginx.conf
```

**Problemi frequenti**

| Sintomo | Causa | Rimedio |
|---|---|---|
| `502 Bad Gateway` | app non attiva sulla 3000 | avvia il servizio; `curl http://127.0.0.1:3000/api/salute` |
| Login al giro di boa fallisce | `COOKIE_SECURE=true` su http | riportalo a `false` e riavvia |
| «Database non raggiungibile» | MariaDB fermo o `.env` errato | avvia il servizio DB; controlla utente/password |
| Upload rifiutato | file > 5 MB o MIME alterato | il limite per file è 5 MB (PDF/JPG/PNG) |
| Il nome `portale.certificati` non risolve | DNS interno non configurato | usa l'IP, o configura il DNS (guida dedicata) |

---

*Guida unica v2.3.1 — dettagli storici e alternative nelle guide specifiche di
`docs/`; configurazioni in `deploy/`. Suite di collaudo di riferimento:
375/375 PASS.*

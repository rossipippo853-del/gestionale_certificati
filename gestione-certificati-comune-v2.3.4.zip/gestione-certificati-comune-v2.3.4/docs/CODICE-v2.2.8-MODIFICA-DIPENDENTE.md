# 💾 Modifica anagrafica dipendente (v2.2.8) — codice completo per file

> **Funzionalità:** l'amministratore modifica nome, cognome, matricola, codice fiscale,
> sesso, qualifica professionale ed email di qualsiasi dipendente. Frammenti estratti
> **verbatim** dai file del progetto (app funzionante, suite 330/330).

## File toccati (4 + test)

| File | Modifica |
|---|---|
| `src/routes/admin.routes.js` | **NUOVO endpoint** `PUT /api/admin/utenti/:id` (solo admin) |
| `public/admin.html` | **NUOVO dialog** `dlg-modifica-utente` con i 7 campi |
| `public/js/admin.js` | Bottone ✏️ nelle azioni, apertura precompilata, validazione client, submit |
| `db/seed.js` | Email demo rese uniche (coerenza con la nuova regola di unicità) |
| `tests-qa/05-crud-admin.test.js` | 8 test di integrazione (happy path, 409×3, 400×5, 404, RBAC, cambio matricola) |
| `tests/frontend.test.js` | Test strutturale del dialog e del wiring |

**Nessuna migrazione DB**: la tabella `dipendenti` ha già tutte le colonne (v2.0) e gli
indice UNIQUE su `matricola` e `codice_fiscale`; l'unicità dell'**email** è applicativa.

---

## 1 · BACKEND — `src/routes/admin.routes.js` (nuovo endpoint, sopra la rotta password)

```javascript
/** PUT /utenti/:id — [v2.2.8] modifica anagrafica e dati lavorativi del
 *  dipendente: nome, cognome, matricola, codice fiscale, sesso, qualifica
 *  professionale ed email. Stesse regole di validazione della creazione;
 *  unicità di matricola/CF/email rispetto agli ALTRI dipendenti (409).
 *  Ruolo, stato account e password NON si toccano qui: hanno rotte/policy
 *  dedicate (stato, reset password). */
router.put('/utenti/:id', async (req, res, next) => {
  try {
    /* [AUDIT v2.2-b F5] Solo CIFRE: niente parseInt tolleranti su input esterni. */
    if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ errore: 'Identificativo non valido.' });
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ errore: 'Identificativo non valido.' });

    const [esistente] = await pool.query('SELECT id FROM dipendenti WHERE id = ?', [id]);
    if (!esistente.length) return res.status(404).json({ errore: 'Utente non trovato.' });

    /* Validazione completa (stesse regole della creazione: matricola, CF in
     * formato italiano maiuscolo, nome/cognome/qualifica, sesso, email). */
    const { errori, valori } = validaDatiDipendente(req.body || {});
    if (errori.length) return res.status(400).json({ errore: errori.join(' ') });

    /* Unicità rispetto a un ALTRO account: il confronto esclude se stesso
     * (ri-salvare i propri dati non deve dare conflitto). */
    const conflitti = [];
    const [dupMatricola] = await pool.query(
      'SELECT id FROM dipendenti WHERE matricola = ? AND id <> ? LIMIT 1', [valori.matricola, id]);
    if (dupMatricola.length) conflitti.push('Matricola già assegnata a un altro dipendente.');
    const [dupCF] = await pool.query(
      'SELECT id FROM dipendenti WHERE codice_fiscale = ? AND id <> ? LIMIT 1', [valori.codiceFiscale, id]);
    if (dupCF.length) conflitti.push('Codice Fiscale già assegnato a un altro dipendente.');
    if (valori.email) {
      const [dupEmail] = await pool.query(
        'SELECT id FROM dipendenti WHERE email = ? AND id <> ? LIMIT 1', [valori.email, id]);
      if (dupEmail.length) conflitti.push('Email già assegnata a un altro dipendente.');
    }
    if (conflitti.length) return res.status(409).json({ errore: conflitti.join(' ') });

    try {
      /* UPDATE solo dei campi anagrafici/lavorativi richiesti. */
      const [esito] = await pool.query(
        `UPDATE dipendenti
         SET matricola = ?, codice_fiscale = ?, nome = ?, cognome = ?,
             sesso = ?, qualifica = ?, email = ?
         WHERE id = ?`,
        [valori.matricola, valori.codiceFiscale, valori.nome, valori.cognome,
         valori.sesso, valori.qualifica, valori.email || null, id]
      );
      if (!esito.affectedRows) return res.status(404).json({ errore: 'Utente non trovato.' });
      res.json({ ok: true, messaggio: `Dati di ${valori.cognome} ${valori.nome} aggiornati.` });
    } catch (err) {
      /* Race su UNIQUE (matricola/CF): il pre-check ha già filtrato i casi
       * normali; qui catturiamo le concorrenze vere. */
      if (err && err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ errore: 'Matricola o Codice Fiscale già in uso da un altro dipendente.' });
      }
      throw err;
    }
  } catch (err) { next(err); }
});
```

**Regole implementate:** solo ruolo AMMINISTRATORE (il router applica `soloAdmin`);
`id` solo cifre (guardia F5) → 400; utente inesistente → 404; stesse validazioni della
creazione (`validaDatiDipendente`) → 400; matricola/CF/email già usati da un ALTRO
dipendente → 409 (il confronto esclude se stesso: ri-salvare i propri dati è permesso);
race su UNIQUE → 409; ruolo/stato/password NON modificabili qui (rotte dedicate).

---

## 2 · FRONTEND HTML — `public/admin.html` (nuovo dialog, prima di «rifiuta certificato»)

```html
  <!-- ============ [v2.2.8] Dialog: modifica dipendente ============
       Anagrafica e dati lavorativi (nome, cognome, matricola, CF, sesso,
       qualifica, email) precompilati con i valori attuali; ruolo, stato
       account e password si gestiscono dalle azioni dedicate. -->
  <dialog id="dlg-modifica-utente">
    <h3>Modifica dipendente</h3>
    <form id="form-modifica-utente">
      <div class="griglia-form">
        <label class="campo">
          <span>Matricola *</span>
          <input type="text" id="mu-matricola" required maxlength="20" placeholder="es. 10251">
        </label>
        <label class="campo">
          <span>Codice Fiscale *</span>
          <input type="text" id="mu-codice-fiscale" required maxlength="16" minlength="16"
                 pattern="[A-Za-z]{6}[0-9]{2}[A-Za-z][0-9]{2}[A-Za-z][0-9]{3}[A-Za-z]"
                 title="16 caratteri nel formato italiano (es. RSSMRA80A01H501U)"
                 placeholder="es. RSSMRA80A01H501U" style="text-transform:uppercase">
        </label>
        <label class="campo">
          <span>Nome *</span>
          <input type="text" id="mu-nome" required maxlength="100">
        </label>
        <label class="campo">
          <span>Cognome *</span>
          <input type="text" id="mu-cognome" required maxlength="100">
        </label>
        <label class="campo">
          <span>Sesso *</span>
          <select id="mu-sesso" required>
            <option value="M">M</option>
            <option value="F">F</option>
            <option value="ALTRO">ALTRO</option>
          </select>
        </label>
        <label class="campo">
          <span>Qualifica professionale *</span>
          <input type="text" id="mu-qualifica" required maxlength="120" placeholder="es. Istruttore direttivo">
        </label>
        <label class="campo campo-interra">
          <span>Email (facoltativa)</span>
          <input type="email" id="mu-email" maxlength="150">
        </label>
      </div>
      <p id="mu-errore" class="alert errore nascosto"></p>
      <div class="azioni">
        <button type="button" class="btn secondario" id="mu-annulla">Annulla</button>
        <button type="submit" class="btn primario">Salva modifiche</button>
      </div>
    </form>
  </dialog>
```

---

## 3 · FRONTEND JS — `public/js/admin.js`

**a) Bottone ✏️ nella colonna AZIONI della tabella Dipendenti (render della riga):**

```javascript
            <button class="btn piccolo secondario" data-azione="modifica" data-id="${u.id}"
              data-nome="${escapeHtml(u.cognome)} ${escapeHtml(u.nome)}" title="Modifica anagrafica e dati lavorativi">✏️</button>
            <button class="btn piccolo secondario" data-azione="reset" data-id="${u.id}"
              data-nome="${escapeHtml(u.cognome)} ${escapeHtml(u.nome)}" title="Reimposta password">🔑</button>
```

**b) Cache dell'elenco per la precompilazione (in `caricaDipendenti`):**

```javascript
    ultimiUtenti = dati.utenti; // [v2.2.8] serve alla precompilazione del dialog
```

**c) Apertura, validazione client e salvataggio (nuove funzioni):**

```javascript
/* -------------------- [v2.2.8] Modifica dipendente -------------------- */

/** Precompila il dialog di modifica con i valori ATTUALI del dipendente
 *  (dalla cache dell'ultimo elenco caricato). */
function apriModificaUtente(id) {
  const u = ultimiUtenti.find((x) => x.id === id);
  if (!u) { toast('Dipendente non trovato: ricarica la pagina.', 'errore'); return; }
  modificaId = id;
  document.getElementById('mu-matricola').value = u.matricola || '';
  document.getElementById('mu-codice-fiscale').value = u.codice_fiscale || '';
  document.getElementById('mu-nome').value = u.nome || '';
  document.getElementById('mu-cognome').value = u.cognome || '';
  document.getElementById('mu-sesso').value = u.sesso || 'M';
  document.getElementById('mu-qualifica').value = u.qualifica || '';
  document.getElementById('mu-email').value = u.email || '';
  document.getElementById('mu-errore').classList.add('nascosto');
  document.getElementById('dlg-modifica-utente').showModal();
}

/** Validazione lato CLIENT, specchio delle regole del server
 *  (src/utils/validazione.js): stessi formati, stessi messaggi. */
function validaAnagraficaClient(v) {
  const errori = [];
  if (!/^[A-Za-z0-9_-]{3,20}$/.test(v.matricola)) errori.push('Matricola non valida (3-20 caratteri alfanumerici).');
  if (!/^[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]$/.test(v.codice_fiscale)) errori.push('Codice Fiscale non valido: inserire 16 caratteri nel formato italiano (es. RSSMRA80A01H501U).');
  if (v.nome.length < 2 || v.nome.length > 100) errori.push('Nome non valido (2-100 caratteri).');
  if (v.cognome.length < 2 || v.cognome.length > 100) errori.push('Cognome non valido (2-100 caratteri).');
  if (!['M', 'F', 'ALTRO'].includes(v.sesso)) errori.push('Sesso non valido: usare M, F o ALTRO.');
  if (v.qualifica.length < 2 || v.qualifica.length > 120) errori.push('Qualifica professionale non valida (2-120 caratteri).');
  if (v.email && (v.email.length > 150 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email))) errori.push('Email non valida.');
  return errori;
}

/** Submit del dialog: validazione client → PUT → toast + refresh. */
async function eseguiModificaUtente(e) {
  e.preventDefault();
  const erroreEl = document.getElementById('mu-errore');
  erroreEl.classList.add('nascosto');

  const payload = {
    matricola: document.getElementById('mu-matricola').value.trim(),
    codice_fiscale: document.getElementById('mu-codice-fiscale').value.trim().toUpperCase(),
    nome: document.getElementById('mu-nome').value.trim(),
    cognome: document.getElementById('mu-cognome').value.trim(),
    sesso: document.getElementById('mu-sesso').value,
    qualifica: document.getElementById('mu-qualifica').value.trim(),
    email: document.getElementById('mu-email').value.trim(),
  };
  const errori = validaAnagraficaClient(payload);
  if (errori.length) {
    erroreEl.textContent = errori.join(' ');
    erroreEl.classList.remove('nascosto');
    return;
  }

  try {
    const dati = await api(`/api/admin/utenti/${modificaId}`, { method: 'PUT', body: payload });
    chiudi('dlg-modifica-utente');
    toast(dati.messaggio || 'Dati aggiornati.', 'successo');
    await Promise.all([caricaDipendenti(), caricaStatistiche()]);
  } catch (err) {
    erroreEl.textContent = err.message;   // es. 409 «Matricola già assegnata…»
    erroreEl.classList.remove('nascosto');
  }
}
```

**d) Ramo nell'event delegation `azioneUtente`:**

```javascript
  /* [v2.2.8] modifica anagrafica: apre il dialog precompilato. */
  if (btn.dataset.azione === 'modifica') {
    apriModificaUtente(id);
    return;
  }
```

**e) Binding in `init()`:**

```javascript
  /* [v2.2.8] dialog di modifica anagrafica del dipendente */
  document.getElementById('mu-annulla').addEventListener('click', () => chiudi('dlg-modifica-utente'));
  document.getElementById('form-modifica-utente').addEventListener('submit', eseguiModificaUtente);
```

---

## 4 · DATABASE

**UPDATE** (dentro l'endpoint, parametrico):

```sql
UPDATE dipendenti
   SET matricola = ?, codice_fiscale = ?, nome = ?, cognome = ?,
       sesso = ?, qualifica = ?, email = ?
 WHERE id = ?
```

Schema già pronto (nessuna migrazione): `UNIQUE KEY uq_dipendenti_matricola (matricola)`,
`UNIQUE KEY uq_dipendenti_cf (codice_fiscale)`; l'email è unica a livello applicativo.

**`db/seed.js`** — le email demo diventano uniche (il vecchio schema `nome.cognome@comune.demo`
generava duplicati, incoerenti con la nuova regola):

```javascript
const email = `${nome.toLowerCase()}.${cognome.toLowerCase().replace(/\s+/g, '')}.${matricola}@comune.demo`; // [v2.2.8] unica per dipendente
```

---

## 5 · Note operative

- **Cambio matricola**: la matricola è lo username → l'utente accede con la nuova
  (coperto da test: la vecchia dà 401, la nuova 200, stessa password).
- **Cambio Codice Fiscale**: le cartelle `uploads/certificati/{CF}` dei file GIÀ caricati
  non vengono spostate: i download continuano a funzionare (i percorsi sono memorizzati a DB);
  i nuovi upload finiranno nella cartella col nuovo CF.
- **Duplicati preesistenti**: se un DB storico contiene email duplicate (es. create dal vecchio
  seed), la modifica di uno di quei dipendenti chiederà di differenziare l'email (409 finché
  il conflitto non è risolto): è il comportamento voluto della nuova regola.
- **RBAC**: `PUT /api/admin/utenti/:id` risponde 403 a un dipendente, 401 ad un anonimo.

# CODICE v2.3.0 — Dashboard formazione per dipendente + Tabelle zero-scroll

Documento tecnico della release 2.3.0 del **Portale Formazione e Certificati —
Città di Milazzo**. Estratti ripresi VERBATIM dai file del progetto.

## Indice
1. Backend: `GET /api/admin/utenti/:id/formazione` (metriche + target 40h)
2. admin.html: la nuova card «Dashboard formazione per dipendente»
3. admin.js: ricerca dinamica, KPI, stato formazione
4. dipendente.js: azioni compatte a icona (zero ingombro)
5. stile.css: schede KPI scure, barra target, chips aree, tabelle zero-scroll
6. Note sul contratto API e sulle soglie

---

## 1. Backend — `src/routes/admin.routes.js` (nuovo endpoint)

```javascript
/** GET /utenti/:id/formazione — [v2.3.0] dashboard di formazione del singolo
 *  dipendente: contatori per stato, ore approvate, ore mancanti al TARGET di
 *  40 ore obbligatorie e ripartizione per area tematica (solo APPROVATI).
 *  Consumata dalla card «Dashboard formazione per dipendente» di admin.html. */
const TARGET_FORMAZIONE_MINUTI = 40 * 60;

router.get('/utenti/:id/formazione', async (req, res, next) => {
  try {
    /* [AUDIT v2.2-b F5] solo cifre: niente parseInt tolleranti su input esterni. */
    if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ errore: 'Identificativo non valido.' });
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ errore: 'Identificativo non valido.' });

    const [righe] = await pool.query(
      `SELECT id, matricola, codice_fiscale, nome, cognome, qualifica, attivo
       FROM dipendenti WHERE id = ?`, [id]);
    if (!righe.length) return res.status(404).json({ errore: 'Dipendente non trovato.' });
    const dipendente = righe[0];

    /* Contatori per stato (una sola riga di aggregazione). */
    const [[conteggi]] = await pool.query(
      `SELECT COUNT(*) AS totale,
              COALESCE(SUM(stato = 'APPROVATO'), 0) AS approvati,
              COALESCE(SUM(stato = 'IN_ATTESA'), 0) AS inAttesa,
              COALESCE(SUM(stato = 'RIFIUTATO'), 0) AS rifiutati
       FROM certificati WHERE dipendente_id = ?`, [id]);

    /* Ripartizione per area dei SOLO corsi approvati: la somma dei minuti di
     * questa query È il totale ore svolte (rifiuti e attese esclusi). */
    const [aree] = await pool.query(
      `SELECT area_tematica AS area, COUNT(*) AS certificati,
              COALESCE(SUM(numero_ore * 60 + numero_minuti), 0) AS minuti
       FROM certificati
       WHERE dipendente_id = ? AND stato = 'APPROVATO'
       GROUP BY area_tematica
       ORDER BY minuti DESC, area ASC`, [id]);

    const oreApprovateMinuti = aree.reduce((somma, a) => somma + Number(a.minuti), 0);
    const oreMancantiMinuti = Math.max(0, TARGET_FORMAZIONE_MINUTI - oreApprovateMinuti);
    const percentuale = Math.min(100, Math.round((oreApprovateMinuti / TARGET_FORMAZIONE_MINUTI) * 100));
    const stato = oreApprovateMinuti >= TARGET_FORMAZIONE_MINUTI ? 'IN_REGOLA'
      : (oreApprovateMinuti > 0 ? 'IN_CORSO' : 'SOTTO_SOGLIA');

    res.json({
      dipendente,
      certificati: {
        totale: Number(conteggi.totale),
        approvati: Number(conteggi.approvati),
        inAttesa: Number(conteggi.inAttesa),
        rifiutati: Number(conteggi.rifiutati),
      },
      targetMinuti: TARGET_FORMAZIONE_MINUTI,
      oreApprovateMinuti,
      oreMancantiMinuti,
      percentuale,
      stato,
      perArea: aree.map((a) => ({ area: a.area, certificati: Number(a.certificati), minuti: Number(a.minuti) })),
    });
  } catch (err) { next(err); }
});
```

Contratto: `dipendente` (anagrafica sintetica) · `certificati` {totale,
approvati, inAttesa, rifiutati} · `targetMinuti` (2400) ·
`oreApprovateMinuti` (solo APPROVATI) · `oreMancantiMinuti` = max(0, 2400 −
approvate) · `percentuale` = min(100, round(approvate/2400*100)) · `stato`
(IN_REGOLA | IN_CORSO | SOTTO_SOGLIA) · `perArea` (solo APPROVATI, minuti DESC).
Guardie: id non numerico → 400; dipendente assente → 404; RBAC admin → 403.

## 2. admin.html — la nuova card (in sostituzione del grafico globale v2.2.9)

```html
<!-- [v2.3.0] Dashboard formazione del SINGOLO dipendente (sostituisce il
             grafico globale v2.2.9): ricerca per nome/cognome/matricola/CF e
             KPI verso il target delle 40 ore obbligatorie. -->
        <div class="card card-dashboard" id="card-dashboard-dipendente" style="margin-top:1rem">
          <h2>Dashboard formazione per dipendente</h2>
          <p class="hint">Cerca un dipendente per <strong>nome, cognome, matricola o codice fiscale</strong>: la dashboard ne mostra i certificati, le ore approvate e la distanza dal target delle 40 ore.</p>
          <div class="campo combo-campo" style="margin-bottom:1rem">
            <span>Dipendente</span>
            <input type="text" id="fd-dipendente-cerca" class="combo-input"
                   placeholder="Digita nome, cognome, matricola o CF…"
                   autocomplete="off" role="combobox" aria-expanded="false"
                   aria-controls="fd-dipendente-lista" aria-autocomplete="list">
            <input type="hidden" id="fd-dipendente">
            <div id="fd-dipendente-lista" class="combo-lista nascosto" role="listbox"></div>
          </div>
… (segue #fd-dash con KPI, barra target e ripartizione: vedi sorgente)
```

## 3. admin.js — blocco v2.3.0 completo (estratto integrale)

```javascript
/* ---------- [v2.3.0] Dashboard formazione del singolo dipendente ---------- */

const STATI_FORMAZIONE = {
  IN_REGOLA: ['In regola con il target 40h', 'verde'],
  IN_CORSO: ['In corso', 'ambra'],
  SOTTO_SOGLIA: ['Sotto la soglia', 'rosso'],
};

/** Ore in formato h:mm a partire da dei minuti. */
function minutiInHhMm(minuti) {
  return formattaDurata(Math.floor(minuti / 60), minuti % 60);
}

/** Chiama l'API metriche e disegna le schede KPI scure della dashboard. */
async function caricaDashboardFormazione(id) {
  const dash = document.getElementById('fd-dash');
  const vuoto = document.getElementById('fd-vuoto');
  try {
    const d = await api(`/api/admin/utenti/${id}/formazione`);

    vuoto.classList.add('nascosto');
    dash.classList.remove('nascosto');

    document.getElementById('fd-nome').textContent = `${d.dipendente.cognome} ${d.dipendente.nome}`;
    document.getElementById('fd-sotto').textContent =
      `Matricola ${d.dipendente.matricola} · CF ${d.dipendente.codice_fiscale || '—'} · ${d.dipendente.qualifica || 'qualifica non indicata'}${d.dipendente.attivo ? '' : ' · ACCOUNT DISABILITATO'}`;

    const [testoStato, coloreStato] = STATI_FORMAZIONE[d.stato] || [d.stato, 'grigio'];
    const badge = document.getElementById('fd-stato');
    badge.textContent = testoStato;
    badge.className = `badge ${coloreStato}`;

    document.getElementById('fd-cert-tot').textContent = d.certificati.totale;
    document.getElementById('fd-approvati').textContent = d.certificati.approvati;
    document.getElementById('fd-attesa').textContent = d.certificati.inAttesa;
    document.getElementById('fd-rifiutati').textContent = d.certificati.rifiutati;

    document.getElementById('fd-ore').textContent = minutiInHhMm(d.oreApprovateMinuti);
    document.getElementById('fd-mancanti').textContent = minutiInHhMm(d.oreMancantiMinuti);

    document.getElementById('fd-percentuale').textContent = `${d.percentuale}%`;
    const barra = document.getElementById('fd-barra');
    barra.style.width = `${d.percentuale}%`;
    barra.parentElement.setAttribute('aria-valuenow', String(d.percentuale));

    const aree = document.getElementById('fd-aree');
    aree.innerHTML = d.perArea.length
      ? d.perArea.map((a) => `
          <span class="chip-area"><strong>${escapeHtml(a.area)}</strong>
            <span>${minutiInHhMm(a.minuti)} · ${a.certificati} ${a.certificati === 1 ? 'certificato' : 'certificati'}</span></span>`).join('')
      : '<span class="hint">Nessuna formazione approvata: le aree compariranno alla prima approvazione.</span>';
  } catch (err) {
    dash.classList.add('nascosto');
    vuoto.classList.remove('nascosto');
    vuoto.textContent = `Dashboard non disponibile: ${err.message}`;
  }
}

/** Selezione dalla ricerca: l'id va nel campo nascosto e si carica la dashboard. */
function selezionaDipendenteDashboard(o) {
  document.getElementById('fd-dipendente').value = o.id;
  document.getElementById('fd-dipendente-cerca').value = `${o.cognome} ${o.nome} (${o.matricola})`;
  const lista = document.getElementById('fd-dipendente-lista');
  lista.classList.add('nascosto');
  document.getElementById('fd-dipendente-cerca').setAttribute('aria-expanded', 'false');
  caricaDashboardFormazione(o.id);
}

/** Rende i risultati della ricerca nel pannello a discesa della dashboard. */
function mostraListaDashboard(risultati) {
  const lista = document.getElementById('fd-dipendente-lista');
  const input = document.getElementById('fd-dipendente-cerca');
  lista.innerHTML = '';
  if (!risultati.length) {
    lista.classList.add('nascosto');
    input.setAttribute('aria-expanded', 'false');
    return;
  }
  for (const o of risultati) {
    const voce = document.createElement('button');
    voce.type = 'button';
    voce.setAttribute('role', 'option');
    voce.innerHTML = `<strong>${escapeHtml(o.cognome)} ${escapeHtml(o.nome)}</strong>
      <span class="cella-secondaria">${escapeHtml(o.matricola)} · CF ${escapeHtml(o.codice_fiscale || '—')}</span>`;
    voce.addEventListener('click', () => selezionaDipendenteDashboard(o));
    lista.appendChild(voce);
  }
  lista.classList.remove('nascosto');
  input.setAttribute('aria-expanded', 'true');
}

/** Stessa logica di filtro della combobox di caricamento (nome/cognome/
 *  matricola/CF), ma al servizio della dashboard. */
function inizializzaRicercaDashboard() {
  const input = document.getElementById('fd-dipendente-cerca');
  const lista = document.getElementById('fd-dipendente-lista');
  if (!input) return;
  input.addEventListener('input', () => {
    document.getElementById('fd-dipendente').value = '';
    mostraListaDashboard(filtraDipendenti(input.value));
  });
  input.addEventListener('keydown', (e) => {
    const voci = Array.from(lista.querySelectorAll('button'));
    if (!voci.length) return;
    const attiva = voci.findIndex((v) => v.classList.contains('attiva'));
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const nuova = e.key === 'ArrowDown' ? Math.min(attiva + 1, voci.length - 1) : Math.max(attiva - 1, 0);
      voci.forEach((v) => v.classList.remove('attiva'));
      voci[nuova].classList.add('attiva');
      voci[nuova].scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'Enter' && attiva >= 0) {
      e.preventDefault(); voci[attiva].click();
    } else if (e.key === 'Escape') {
      lista.classList.add('nascosto');
      input.setAttribute('aria-expanded', 'false');
    }
  });
  input.addEventListener('blur', () => setTimeout(() => lista.classList.add('nascosto'), 180));
}
```

## 4. dipendente.js — colonna Azioni compatta (requisito 2)

```javascript
      <td class="azioni-cell">
        <div class="azioni">
          <!-- [v2.3.0] azioni compatte a icona con tooltip: la colonna occupa
               pochissimo e la tabella resta interamente visibile senza scroll. -->
          <a class="btn piccolo secondario btn-icona" target="_blank" rel="noopener"
             title="Visualizza il documento" aria-label="Visualizza il documento"
             href="/api/certificati/${c.id}/file?modo=visualizza">👁</a>
          <a class="btn piccolo secondario btn-icona" title="⬇ Scarica il documento"
             aria-label="Scarica il documento" href="/api/certificati/${c.id}/file">⬇</a>
        </div>
      </td>`;

```

## 5. stile.css — blocco v2.3.0 completo

```css
/* ═══════════ [v2.3.0] DASHBOARD FORMAZIONE PER DIPENDENTE ═══════════ */

.fd-testata {
  display: flex; justify-content: space-between; align-items: center;
  gap: 1rem; flex-wrap: wrap; margin-bottom: .8rem;
}
.fd-nome { font-size: 1.15rem; font-weight: 800; }
.fd-sotto { color: var(--testo-2); font-size: .82rem; margin-top: .1rem; }

/* Schede KPI scure e moderne (stile metrics) */
.griglia-kpi {
  display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: .7rem; margin-bottom: .9rem;
}
.kpi {
  background: linear-gradient(160deg, #1c4d8f 0%, #12315c 100%);
  color: #fff; border-radius: 12px; padding: .8rem .95rem;
  box-shadow: 0 6px 16px rgba(18, 49, 92, .25);
}
.kpi-etichetta {
  font-size: .68rem; font-weight: 700; text-transform: uppercase;
  letter-spacing: .06em; color: #b9cdec; margin-bottom: .25rem;
}
.kpi-valore { font-size: 1.55rem; font-weight: 800; line-height: 1.1; }
.kpi-dettaglio { font-size: .74rem; color: #d7e3f6; margin-top: .3rem; }
.kpi-dettaglio .mini { display: inline-block; margin-right: .5rem; white-space: nowrap; }
.kpi-dettaglio .mini.verde  { color: #8fe6b0; }
.kpi-dettaglio .mini.ambra  { color: #ffd98a; }
.kpi-dettaglio .mini.rosso  { color: #ff9f9f; }

/* Barra di avanzamento verso il target 40h */
.fd-target { margin-bottom: 1rem; }
.fd-target-testo {
  display: flex; justify-content: space-between; font-size: .8rem;
  font-weight: 600; margin-bottom: .25rem;
}
.fd-barra {
  height: 14px; background: #e6ecf5; border-radius: 999px; overflow: hidden;
  box-shadow: inset 0 1px 3px rgba(15, 23, 42, .12);
}
.fd-barra-riempimento {
  height: 100%; border-radius: 999px; transition: width .4s ease;
  background: linear-gradient(90deg, var(--oro) 0%, #2a7fc9 55%, var(--blu-scuro) 100%);
}

/* Ripartizione per area tematica (badge-scheda) */
.fd-sezione {
  font-size: .72rem; font-weight: 700; text-transform: uppercase;
  letter-spacing: .06em; color: var(--testo-2); margin-bottom: .4rem;
}
.aree-chips { display: flex; flex-wrap: wrap; gap: .45rem; }
.chip-area {
  display: inline-flex; flex-direction: column; gap: .05rem;
  background: #f4f8fd; border: 1px solid #c9dcf2; border-left: 4px solid var(--blu);
  border-radius: 9px; padding: .38rem .65rem; font-size: .76rem;
}
.chip-area strong { font-size: .78rem; }
.chip-area span { color: var(--testo-2); }

/* ═══════════ [v2.3.0] TABELLE ZERO-SCROLL (admin e dipendente) ═══════════
   Obiettivo d'invariante: a 1024px+ TUTTE le colonne visibili a colpo
   d'occhio, ZERO scrollbar orizzontale. */
table.dati { table-layout: fixed; }              /* larghezze decise dal CSS, non dal contenuto */
table.dati th, table.dati td {
  overflow-wrap: anywhere; word-break: break-word; /* il testo lungo va a capo, non allarga */
}
table.dati td { padding: .42rem .45rem; }        /* padding ridotto */
table.dati th { padding: .5rem .45rem; }

/* Larghezze per colonna — Gestione Dipendenti (admin, 10 colonne) */
#tabella-utenti th:nth-child(1) { width: 7.5%; }   /* matricola  */
#tabella-utenti th:nth-child(2) { width: 10%; }    /* CF         */
#tabella-utenti th:nth-child(3) { width: 12.5%; }  /* cognome+nome */
#tabella-utenti th:nth-child(4) { width: 4%; }     /* sesso      */
#tabella-utenti th:nth-child(5) { width: 14%; }    /* qualifica  */
#tabella-utenti th:nth-child(6) { width: 16%; }    /* email      */
#tabella-utenti th:nth-child(7) { width: 7%; }     /* ruolo      */
#tabella-utenti th:nth-child(8) { width: 8%; }     /* stato      */
#tabella-utenti th:nth-child(9) { width: 7%; }     /* 1° accesso */
#tabella-utenti th:nth-child(10) { width: 14%; }   /* azioni     */

/* Larghezze per colonna — I Miei Certificati (dipendente, 10 colonne) */
.tabella-cert-dip th:nth-child(1) { width: 16%; }  /* corso         */
.tabella-cert-dip th:nth-child(2) { width: 11%; }  /* ente          */
.tabella-cert-dip th:nth-child(3) { width: 8%; }   /* conseguimento */
.tabella-cert-dip th:nth-child(4) { width: 5.5%; } /* ore           */
.tabella-cert-dip th:nth-child(5) { width: 5%; }   /* esame         */
.tabella-cert-dip th:nth-child(6) { width: 13%; }  /* area          */
.tabella-cert-dip th:nth-child(7) { width: 15%; }  /* file          */
.tabella-cert-dip th:nth-child(8) { width: 7%; }   /* stato         */
.tabella-cert-dip th:nth-child(9) { width: 9.5%; } /* note          */
.tabella-cert-dip th:nth-child(10) { width: 10%; } /* azioni        */

/* Larghezze per colonna — Certificati globali (admin, 7 colonne) */
.tabella-cert-admin th:nth-child(1) { width: 14%; }
.tabella-cert-admin th:nth-child(2) { width: 24%; }
.tabella-cert-admin th:nth-child(3) { width: 9%; }
.tabella-cert-admin th:nth-child(4) { width: 6.5%; }
.tabella-cert-admin th:nth-child(5) { width: 18%; }
.tabella-cert-admin th:nth-child(6) { width: 8.5%; }
.tabella-cert-admin th:nth-child(7) { width: 20%; }

/* Azioni compatte: button-group orizzontale a icone con tooltip */
.azioni-cell .azioni { display: flex; gap: .28rem; flex-wrap: nowrap; align-items: center; }
.btn-icona { min-height: 0; padding: .24rem .42rem; font-size: .82rem; line-height: 1; }

/* Badge più piccoli: meno spazio orizzontale */
.badge { padding: .12rem .4rem; font-size: .64rem; }

/* Sotto i 760px la compattazione lascia il posto al minimo vitale */
@media (max-width: 760px) {
  table.dati { font-size: .78rem; }
  .griglia-kpi { grid-template-columns: 1fr 1fr; }
}
```

## 6. Note di contratto e soglie

- **Target**: 40 ore obbligatorie = 2400 minuti (costante lato server,
  unica fonte di verità; il client non ricalcola).
- **Stato**: approvate ≥ 2400 → IN_REGOLA («In regola con il target 40h»);
  0 < approvate < 2400 → IN_CORSO («In corso»); approvate = 0 → SOTTO_SOGLIA
  («Sotto la soglia»).
- **Rifiuti e attesi**: contati nella scheda «Certificati caricati», MAI nelle
  ore svolte né nella ripartizione per area (coerente col badge storico v2.2.3).
- **Ripartizione aree**: il sistema ha 18 aree reali (+6 d'archivio); la
  dashboard mostra solo le aree con almeno un corso APPROVATO del dipendente.
- **Zero-scroll**: `table-layout: fixed` + `overflow-wrap: anywhere` +
  larghezze percentuali per colonna; il testo lungo va a capo e non allarga
  più le tabelle; badge ridotti (.64rem) e azioni a icone con tooltip.
- Le due tabelle omonime `#tabella-certificati` (admin 7 colonne,
  dipendente 10 colonne) sono distinte dalle classi `tabella-cert-admin` /
  `tabella-cert-dip`.

---

*Città di Milazzo — Portale Formazione e Certificati · release 2.3.0 ·
suite di collaudo 362/362 PASS (139 `node --test` + 223 Jest, 13 suite).*

# 📗 GUIDA OPERATIVA — Gestione Certificati v1.4.0
## Come installare, aggiornare, popolare e usare la piattaforma

*Documento operativo passo-passo per il personale IT e per gli utilizzatori
(ufficio personale/formazione e dipendenti). Aggiornato alle funzionalità
introdotte in v1.4: profilo completo (Sesso, Qualifica), nuovi campi
obbligatori sui certificati (Numero ore, Esame finale, Area tematica),
filtri ed esportazione estesi.*

---

## 1. Installazione/aggiornamento del database MySQL

### 1.1 Nuova installazione (database vuoto)

```bash
cd certificati-comune
mysql -u root -p < db/schema.sql        # crea DB, tabelle (già v1.4) e utente applicativo
cp .env.example .env                    # poi modificare .env (password DB + JWT_SECRET)
node db/seed.js --dipendenti=0          # crea SOLO l'account amministratore iniziale
npm start                               # avvio: http://localhost:3000
```

Lo schema v1.4 crea già tutte le colonne nuove:

| Tabella | Colonna | Tipo | Note |
|---|---|---|---|
| dipendenti | `sesso` | ENUM('M','F','ALTRO') | obbligatorio |
| dipendenti | `qualifica` | VARCHAR(120) | obbligatoria |
| certificati | `numero_ore` | INT UNSIGNED | obbligatorio (≥ 1, validato dall'app) |
| certificati | `esame_finale` | TINYINT(1) | 1 = il corso prevedeva esame |
| certificati | `area_tematica` | ENUM con 6 aree | classificazione obbligatoria |

### 1.2 Aggiornamento di un'installazione ESISTENTE (v1.3 → v1.4)

⚠ **Non** rieseguire `schema.sql`: usare lo script di migrazione, che conserva
tutti i dati presenti (utenti, certificati, PDF):

```bash
mysql -u root -p < db/migrazione-v1.4.sql
# poi riavviare l'applicazione:
sudo systemctl restart certificati      # (o pm2 restart / npm start)
```

Lo script esegue gli `ALTER TABLE` seguenti (riportati per chiarezza — **da
eseguire una sola volta**):

```sql
USE certificati_comune;

ALTER TABLE dipendenti
  ADD COLUMN sesso     ENUM('M','F','ALTRO') NOT NULL DEFAULT 'M' AFTER matricola,
  ADD COLUMN qualifica VARCHAR(120)          NOT NULL DEFAULT ''  AFTER sesso;
ALTER TABLE dipendenti ADD KEY idx_dipendenti_qualifica (qualifica);

ALTER TABLE certificati
  ADD COLUMN numero_ore    INT UNSIGNED NOT NULL DEFAULT 0 AFTER data_conseguimento,
  ADD COLUMN esame_finale  TINYINT(1)   NOT NULL DEFAULT 0 AFTER numero_ore,
  ADD COLUMN area_tematica ENUM('Competenze linguistiche',
                                'Leadership e soft skills',
                                'Principi e valori della PA',
                                'Transizione digitale',
                                'Transizione ecologica',
                                'Transizione amministrativa')
                             NOT NULL DEFAULT 'Principi e valori della PA' AFTER esame_finale;
ALTER TABLE certificati ADD KEY idx_cert_area (area_tematica);
```

> I record STORICI ricevono i valori predefiniti (sesso 'M', qualifica vuota,
> 0 ore, area di default). Si possono completare in qualsiasi momento con
> `UPDATE`, ad esempio:
> `UPDATE certificati SET numero_ore = 8 WHERE id = 1;`

**Verifica post-migrazione** (consigliata):

```sql
DESCRIBE dipendenti;      -- attendere le colonne sesso e qualifica
DESCRIBE certificati;     -- attendere numero_ore, esame_finale, area_tematica
SELECT COUNT(*) FROM dipendenti;   -- invariato rispetto a prima
SELECT COUNT(*) FROM certificati;  -- invariato rispetto a prima
```

---

## 2. Importazione massiva dei 250 dipendenti reali

### 2.1 Struttura del file CSV

Formato (UTF-8, separatore `;` `,` o TAB — riconosciuto automaticamente).
Modello pronto da compilare: **`db/modello-dipendenti.csv`**.

```csv
nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale;email;ruolo;password_temporanea
Maria;Carta;30011;CRTMRA80A01H501U;F;Istruttore direttivo;maria.carta@comune.it;DIPENDENTE;Benvenuto2026
Luigi;Spano;30012;SPNLUJ85M20D963T;M;Agente di polizia locale;;DIPENDENTE;
Sara;Melis;30013;MLSSRA90C45G822W;F;Assistente amministrativo;sara.melis@comune.it;DIPENDENTE;
Gianni;Fadda;30014;FDDGNI75B10Z611Q;M;Dirigente;;AMMINISTRATORE;
```

| Colonna | Obbligatoria | Regole |
|---|---|---|
| `nome`, `cognome` | ✅ | 2-100 caratteri |
| `matricola` | ✅ | 3-20 caratteri alfanumerici; **username di accesso** e nome della cartella sul server; univoca |
| `codice_fiscale` | ✅ | 16 caratteri formato italiano, univoco → cartella PDF `uploads/certificati/{CF}` (v2.0) |
| `sesso` | ✅ | `M`, `F` oppure `ALTRO` |
| `qualifica_professionale` | ✅ | 2-120 caratteri (es. "Istruttore direttivo") |
| `email` | — | facoltativa |
| `ruolo` | — | `DIPENDENTE` (predefinito) o `AMMINISTRATORE` |
| `password_temporanea` | — | se **vuota** viene usata la password standard **`Benvenuto@2026`**; se indicata: min 8 caratteri con lettere e numeri |

Da Excel: *File → Salva con nome → **CSV UTF-8 (delimitato dal punto e
virgola)***. Limite: 2000 righe per file.

### 2.2 Procedura consigliata per caricare i 250 utenti

1. **Compilare il CSV** con l'elenco ufficiale del personale (una riga per dipendente).
2. Accedere al pannello **Amministratore → scheda «Dipendenti» → «⬆ Importa da CSV»**.
3. Selezionare il file, lasciare «Ignora il record esistente», attivare
   **«Prova generale»** e premere «Verifica e importa»: il sistema mostra cosa
   accadrebbe (nuovi account, duplicati, errori riga per riga) **senza salvare**.
4. Correggere eventuali righe segnalate nel file e ripetere la prova.
5. Disattivare «Prova generale» e premere di nuovo: l'importazione è effettiva.
6. Nel report: premere **«⬇ Scarica credenziali (CSV)»** (file
   `matricola;password_temporanea`) e conservarlo in un luogo sicuro per
   comunicare le credenziali a ciascun dipendente.
7. Al primo accesso ogni dipendente sarà **obbligato a sostituire** la password.

> Alternativa da riga di comando (per l'IT): `node db/import-dipendenti.js elenco.csv --dry-run`
> e poi senza `--dry-run`. Guida completa: `docs/IMPORT-DIPENDENTI.md`.

**Cosa fa il sistema per ogni utente importato:** valida i dati → cifra la
password con bcrypt → crea la cartella `uploads/certificati/{matricola}/` →
registra l'account attivo con cambio password obbligatorio → lo inserisce nel
report. Le matricole già presenti vengono ignorate (o aggiornate nell'anagrafica
se si sceglie «Aggiorna»).

---

## 3. Come il DIPENDENTE inserisce un certificato (nuovi campi)

1. Accedere con **matricola e password** (cambiare la password provvisoria al primo accesso).
2. Scheda **«I miei certificati»** → form «Carica un nuovo certificato».
3. Compilare **tutti** i campi obbligatori:

   | Campo | Esempio | Note |
   |---|---|---|
   | Nome/Titolo del corso | «Sicurezza sul lavoro – formazione generale» | 3-200 caratteri |
   | Ente erogatore | «Scuola Superiore della P.A.» | 2-150 caratteri |
   | Data di conseguimento | 15/05/2026 | non futura |
   | **Numero ore** (v1.4) | `12` | numero intero (1-9999) |
   | **Esame finale** (v1.4) | ☑ spuntato / non spuntato | indica se il corso prevedeva l'esame |
   | **Area tematica** (v1.4) | «Transizione digitale» | menu con le 6 aree: Competenze linguistiche · Leadership e soft skills · Principi e valori della PA · Transizione digitale · Transizione ecologica · Transizione amministrativa |
   | File documenti | `attestato.pdf`, `scan.jpg`, `scan.png`… | PDF/JPG/PNG, max 5 MB ciascuno, fino a 5 file per corso — salvati in `uploads/certificati/{codice_fiscale}/` |
   | Durata | ore + minuti | es. 8 ore 30 minuti → mostrato come «8:30»; anche corsi sotto l'ora (0 ore 45 minuti) |

4. Premere «📤 Carica certificato»: il documento compare nell'elenco con lo
   stato **«In attesa»**, e le nuove colonne **Ore / Esame / Area** sono
   subito visibili nella propria tabella.
5. Nella scheda **«Profilo»** il dipendente trova ora le informazioni complete:
   Matricola, Cognome e nome, **Sesso**, **Qualifica professionale**, Email, Ruolo.

---

## 4. Come l'AMMINISTRATORE consulta ed esporta i dati

### 4.1 Consultazione

- **⬆ Carica per dipendente (v2.0)**: dalla scheda «Certificati» l'amministratore può
  caricare un certificato PER CONTO di un dipendente (menu con matricola, nome e CF):
  il PDF finisce nella cartella CF del dipendente e risulterà a lui intestato.
- **Scheda «Certificati»**: tabella completa con tutti i dettagli — caricamento,
  **Dipendente (matricola, cognome e nome)**, **Qualifica**, Corso, Ente,
  Data, **Numero ore**, **Esame finale (Sì/No)**, **Area tematica**, File,
  Stato, Note e azioni (approva ✔ / rifiuta ✖ / elimina 🗑).
- **Filtri combinabili**: testo libero (corso, ente, matricola, nome),
  Dipendente, Stato, **Area tematica (v1.4)** e intervallo di date
  («Conseguimento dal/al»).
- **Scheda «Dipendenti»**: elenco con Matricola, Cognome e nome, **Sesso**,
  **Qualifica**, Email, Ruolo, Stato; azioni: nuovo dipendente (singolo,
  con i nuovi campi obbligatori), reset password, abilita/disabilita,
  importazione massiva da CSV.

### 4.2 Esportazione del report completo (CSV / Excel)

1. Impostare eventuali filtri (es. solo «Transizione digitale», oppure un solo
   dipendente, oppure un intervallo di date).
2. Premere **«⬇ Export CSV»**: il file si apre con doppio click in Excel
   (UTF-8, separatore «;»).
3. Il report contiene **anagrafica + certificato**:

   `ID · Matricola · Codice Fiscale · Cognome · Nome · Sesso · Qualifica · Corso · Ente
   erogatore · Data conseguimento · Numero ore · Esame finale (Si/No) ·
   Area tematica · Stato certificato · Caricato il · File originale ·
   Link PDF · Dimensione (KB) · Note`

   La colonna **Link PDF** contiene l'indirizzo interno del documento
   (`/api/certificati/{id}/file`): aperto da un amministratore connesso,
   scarica il PDF originale.

### 4.3 Verifica dei documenti

Per ogni certificato «In attesa»: aprire il PDF («⬇ PDF»), verificare la
coerenza con i dati dichiarati (ore, area) e decidere:
- **✔** approva → il dipendente vede l'esito verde;
- **✖** rifiuta (con motivazione facoltativa visibile al dipendente);
- **🗑** elimina (rimuove riga e PDF dal server, con conferma).

---

## 5. Test e collaudo dell'applicazione aggiornata

```bash
npm test        # 74 verifiche automatiche (database di test dedicato, ~6 secondi)
```

Le verifiche coprono, tra le altre: migrazioni/schema (creazione con i nuovi
campi), **obbligatorietà** di sesso/qualifica/ore/area, validazione delle 6
aree tematiche, import CSV nel nuovo formato (inclusa la password predefinita
`Benvenuto@2026` cifrata con bcrypt e la creazione delle cartelle per
matricola), filtri ed export estesi, oltre a tutto quanto già coperto in v1.3.

**Collaudo funzionale rapido a mano:**

1. `npm start` → accesso admin (`admin`/`Admin@2026`) → verifica nuove colonne in «Dipendenti».
2. Importa `db/modello-dipendenti.csv` con «Prova generale» → poi reale → controlla report e credenziali.
3. Login come dipendente importato → cambia password → carica un PDF compilando ore/esame/area → verifica le colonne nella propria tabella.
4. Come admin: filtra per area tematica → approva → **Export CSV** → apri il file in Excel e controlla le colonne Qualifica, Numero ore, Esame finale, Area tematica, Link PDF.

---

## 6. Problemi frequenti

| Sintomo | Soluzione |
|---|---|
| «Duplicate column name 'sesso'» eseguendo la migrazione | la migrazione è già stata applicata: non serve rifarla |
| Upload rifiutato «Seleziona un'area tematica valida» | il menu Area tematica è obbligatorio (6 sole aree ammesse) |
| «Il numero di ore deve essere un intero tra 1 e 9999» | inserire un intero senza decimali |
| Import rifiuta il file | intestazione con le 5 colonne obbligatorie (usare `db/modello-dipendenti.csv`), file ≤ 2 MB e ≤ 2000 righe, formato CSV UTF-8 |
| «sesso non valido (usare M, F o ALTRO)» nel report import | correggere la colonna sesso (M/F/ALTRO) |
| Report export senza i nuovi dati | assicurarsi di aver riavviato l'applicazione dopo la migrazione (`systemctl restart certificati`) |

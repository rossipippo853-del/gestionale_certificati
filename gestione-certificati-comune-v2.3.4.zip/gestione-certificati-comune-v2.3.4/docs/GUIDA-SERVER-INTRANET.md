# 🖥 GUIDA DI INSTALLAZIONE E CONFIGURAZIONE — SERVER INTRANET COMUNALE
## Gestione Certificati Dipendenti · PC server dedicato con IP fisso · v1.5.0

*Documento operativo per il System Administrator. Obiettivo finale: l'applicazione
gira in modo permanente su un PC dedicato della rete locale; i ~250 dipendenti
accedono dal proprio browser digitando `http://192.168.X.X:3000` (IP fisso del
server), senza alcuna installazione sulle postazioni di lavoro.*

---

### Scenario di riferimento (esempi usati in tutta la guida)

| Parametro | Valore d'esempio | Come leggerlo sul VOSTRO server |
|---|---|---|
| IP statico del server | `192.168.1.50` | sceglierlo secondo §1.3 |
| Subnet mask | `255.255.255.0` (/24) | §1.2 |
| Gateway predefinito | `192.168.1.1` | §1.2 |
| Sistema operativo | Ubuntu Server 22.04+ / Debian 12+ **oppure** Windows 10/11 | — |
| Applicazione | cartella `certificati-comune/` (v1.5.0), porta **3000** | — |

> Sostituite `192.168.1.50` e `192.168.1.0/24` con i valori reali della vostra rete.

---

## 1. Configurazione del Server e dell'IP Statico (Windows / Linux)

### 1.1 Windows 10/11 — individuare i parametri di rete attuali

Da **prompt dei comandi** (`cmd`) o PowerShell:

```bat
ipconfig /all
```

Annotate i valori della scheda **Ethernet** (quella collegata alla rete del Comune):

- **Indirizzo IPv4** attuale (es. `192.168.1.77`) → il server terrà lo stesso indirizzo o uno vicino;
- **Subnet mask** (es. `255.255.255.0`);
- **Gateway predefinito** (es. `192.168.1.1` — tipicamente il router/firewall aziendale);
- **Server DNS** (es. `192.168.1.1` oppure i DNS dell'ufficio/provider).

> 💡 **Regola d'oro**: i primi 3 numeri dell'IP (rete) restano quelli attuali;
> cambiate solo l'ultimo numero (host). Così il server resta nella stessa rete
> dei dipendenti e mantiene gateway/DNS validi.

### 1.2 Ubuntu Server / Debian — individuare i parametri di rete attuali

```bash
ip a                          # IP attuale e nome dell'interfaccia (es. enp3s0, eth0)
ip route | grep default       # GATEWAY: la riga "default via 192.168.1.1"
resolvectl status | grep -A2 "DNS Servers"   # DNS in uso (oppure: cat /etc/resolv.conf)
```

Annotate: **nome interfaccia**, **IP/CIDR attuale** (es. `/24` = mask `255.255.255.0`),
**gateway**, **DNS**.

### 1.3 Scegliere l'IP fisso in modo sicuro (importante)

1. Verificate che l'IP scelto non sia già usato e non sia nel pool del DHCP:

   ```bash
   # da un PC qualsiasi della rete (Windows: ping equivalente)
   ping -c 2 192.168.1.50        # Linux
   ping -n 2 192.168.1.50        # Windows
   ```
   *Risposta «irraggiungibile»/timeout = IP libero (ok). Risposta = occupato, sceglierne un altro.*

2. **Consigliato**: chiedere al responsabile del router/firewall di **riservare**
   quell'IP (DHCP reservation) per il PC server, oppure di escluderlo dal pool DHCP.
3. Scegliete un IP **basso e memorizzabile** (es. `.50`), fuori dai range che il
   DHCP assegna dinamicamente alle postazioni.

### 1.4 Impostare l'IP statico — Windows 10/11

**Metodo GUI (consigliato):**

1. `Impostazioni → Rete e Internet → Ethernet → Assegnazione IP → Modifica`;
2. In **Modifica impostazioni IP**: selezionare **Manuale**, attivare **IPv4**;
3. Compilare:
   - Indirizzo IP: `192.168.1.50` · Subnet mask: `255.255.255.0` (o prefisso `24`)
   - Gateway: `192.168.1.1` · DNS preferito: `192.168.1.1` (DNS secondario: `8.8.8.8` se uscito);
4. **Salva** e chiudere.

**Metodo prompt (amministratore) — pronto da incollare:**

```bat
netsh interface ip set address name="Ethernet" static 192.168.1.50 255.255.255.0 192.168.1.1
netsh interface ip set dns name="Ethernet" static 192.168.1.1
ipconfig /all
```
> Se la scheda si chiama diversamente (es. `Ethernet 2`), usate quel nome (vedi `ipconfig`).

### 1.5 Impostare l'IP statico — Ubuntu Server (netplan)

```bash
sudo nano /etc/netplan/01-ip-statico.yaml
```

Contenuto (adattare il nome dell'interfaccia e i parametri rilevati in §1.2):

```yaml
network:
  version: 2
  ethernets:
    enp3s0:                          # nome reale dell'interfaccia (ip a)
      dhcp4: false
      addresses: [192.168.1.50/24]   # IP statico + CIDR
      routes:
        - to: default
          via: 192.168.1.1           # gateway
      nameservers:
        addresses: [192.168.1.1]     # DNS
```

Applicare e verificare:

```bash
sudo netplan apply
ip a show enp3s0            # deve mostrare 192.168.1.50/24
ping -c 2 192.168.1.1       # il gateway deve rispondere
```

**Debian senza netplan** (`/etc/network/interfaces`):

```conf
auto enp3s0
iface enp3s0 inet static
    address 192.168.1.50/24
    gateway 192.168.1.1
    dns-nameservers 192.168.1.1
```
```bash
sudo systemctl restart networking
```

**Verifica finale (da un ALTRO PC della rete):**

```bat
ping 192.168.1.50     # deve rispondere
```

---

## 2. Adattamento dell'Applicazione Node.js per la Rete Intranet

### 2.0 Prerequisiti rapidi (se il server è nuovo)

**Linux:**
```bash
# Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
# MariaDB
sudo apt-get install -y mariadb-server
sudo systemctl enable --now mariadb
```

**Windows:** installer grafico di **Node.js 20 LTS** (nodejs.org) e di
**MariaDB** (mariadb.org — al wizard: impostare la password di root e lasciare
spuntato *«Install as service»* + avvio *Automatico*, vedi §4).

**Database + applicazione (entrambi i sistemi), dalla cartella del progetto:**

```bash
sudo mysql < db/schema.sql          # Windows: mysql -u root -p < db\schema.sql
sudo mysql -e "ALTER USER 'cert_app'@'localhost' IDENTIFIED BY 'PasswordForte2026!'; FLUSH PRIVILEGES;"
npm install --omit=dev
node db/seed.js --dipendenti=0      # crea SOLO l'account amministratore
# i 250 dipendenti: pannello admin → «Importa da CSV» (db/modello-dipendenti.csv)
```

### 2.1 Il file `.env` per la rete (UNICO adattamento richiesto)

Copiate `.env.example` in `.env` e configurate così:

```ini
# --- Rete --------------------------------------------------------
PORT=3000                 # porta raggiunta dai browser: http://IP:3000
HOST=0.0.0.0              # ⬅ FONDAMENTALE: ascolta su TUTTE le schede di rete
                          #    ('127.0.0.1' sarebbe solo locale = dipendenti esclusi)

# --- Database (rimane LOCALE al server: non esponetelo alla LAN) --
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=cert_app
DB_PASSWORD=PasswordForte2026!
DB_NAME=certificati_comune

# --- Sessioni -----------------------------------------------------
JWT_SECRET=<incolla qui l'output di: openssl rand -hex 32>
JWT_SCADENZA=8h
COOKIE_SECURE=false       # ⬅ OBBLIGATORIO su http://IP diretto (senza HTTPS)

# --- Storage ------------------------------------------------------
UPLOAD_DIR=uploads        # cartella dei PDF (relativa al progetto) o percorso assoluto
```

**Perché questi valori (già predisposti nel codice v1.5):**

| Voce | Comportamento dell'app | Azione richiesta |
|---|---|---|
| `HOST` | `server.js` ascolta su `config.host` (default **`0.0.0.0`**). Il log d'avvio mostra «Accesso dalla rete locale: http://\<IP-DEL-SERVER\>:3000» | nessuna modifica al codice: basta il `.env` |
| CORS | **Non esiste un middleware CORS e non serve**: il frontend (HTML/JS) è servito dallo stesso Node → le chiamate `/api/*` sono *stessa origine*. Nessun `<script>` o font esterno: funziona anche senza Internet | nessuna |
| Cookie di sessione | `httpOnly` + `SameSite=Lax` con `secure` legato a `COOKIE_SECURE`. Con **`false`** (HTTP puro di intranet) il browser accetta il cookie dopo il login. Da nginx/HTTPS in futuro → `true` | impostare `false` |
| Percorsi upload | I percorsi sono **relativi alla radice del progetto** (`uploads/certificati/{codice_fiscale}/{timestamp-casuale}_{file}.pdf` (v2.0: cartelle per Codice Fiscale)), risolti da `src/config.js` in modo indipendente da IP, host e cartella di avvio: spostare il progetto o cambiare IP NON invalida i riferimenti a DB. Cartella creata automaticamente al primo upload e all'import | nessuna; `UPLOAD_DIR` se serve un altro disco |

### 2.2 Verifica che il server ascolti correttamente

```bash
npm start
```

Log atteso:

```
[OK] Connessione al database stabilita.
[OK] Server avviato su http://0.0.0.0:3000
     Accesso dalla rete locale: http://<IP-DEL-SERVER>:3000
```

Controllo dal server (Linux):

```bash
ss -tlnp | grep 3000        # atteso: 0.0.0.0:3000  (NON 127.0.0.1:3000)
```

Windows (PowerShell):

```powershell
netstat -ano | findstr :3000     # atteso: 0.0.0.0:3000 IN ASCOLTO
```

> ❗ Se vedete `127.0.0.1:3000` il `.env` non è stato letto (o HOST è sbagliato):
> i dipendenti NON riusciranno a collegarsi.

---

## 3. Configurazione del Firewall aziendale

### 3.1 Windows Firewall — sbloccare la porta 3000/TCP

**Metodo GUI (wf.msc):**

1. `Win+R` → digitare `wf.msc` → INVIO (Firewall di Windows Defender con sicurezza avanzata);
2. voce **«Regole connessioni in entrata»** → nel pannello destro **«Nuova regola…»**;
3. Tipo di regola: **Porta** → Avanti;
4. Protocollo: **TCP** · selezionare **«Porte locali specifiche»**: `3000` → Avanti;
5. Azione: **«Consenti la connessione»** → Avanti;
6. Profili: lasciare spuntati **Dominio / Privato**; *sconsigliato* il profilo
   **Pubblico** (se il server non è mai usato fuori sede, toglietelo) → Avanti;
7. Nome: `Certificati Comune — porta 3000` → Fine.

**Metodo comando (prompt ESEGUITO COME AMMINISTRATORE) — pronto da incollare:**

```bat
netsh advfirewall firewall add rule name="Certificati Comune - porta 3000" dir=in action=allow protocol=TCP localport=3000 remoteip=192.168.1.0/24 profile=domain,private
```

**Metodo PowerShell (amministratore) — equivalente:**

```powershell
New-NetFirewallRule -DisplayName "Certificati Comune - porta 3000" -Direction Inbound -Protocol TCP -LocalPort 3000 -RemoteAddress 192.168.1.0/24 -Profile Domain,Private -Action Allow
```

> `remoteip=192.168.1.0/24` limita l'apertura alla sola rete locale (principio
> del minimo privilegio). Rimuovete quel parametro se la rete usa altri range.

Verifica:

```bat
netsh advfirewall firewall show rule name="Certificati Comune - porta 3000"
```

**Firewall del database:** la porta **3306 NON va aperta** — l'applicazione parla
con MariaDB in locale (`127.0.0.1`). Un DB esposto alla LAN è un rischio inutile.

### 3.2 Linux (Ubuntu/Debian) — ufw

```bash
# variante semplice (porta aperta da qualunque sorgente):
sudo ufw allow 3000/tcp

# variante CONSIGLIATA (solo dalla rete locale comunale):
sudo ufw allow from 192.168.1.0/24 to any port 3000 proto tcp

sudo ufw enable            # se ufw non era ancora attivo
sudo ufw status numbered   # verifica: 3000/tcp ALLOW
```

Se in uso è **firewalld** (RHEL/CentOS/Rocky):

```bash
sudo firewall-cmd --permanent --add-port=3000/tcp
sudo firewall-cmd --reload
```

Se il Comune ha un **firewall di rete centrale** (es. pfSense/FortiGate), nessuna
regola è necessaria: il traffico è interno alla LAN (stessa sottorete).

---

## 4. Avvio Automatico e Gestione dei Servizi (Background & Reboot)

Obiettivo: dopo un black-out o un riavvio del PC server, **MariaDB e l'app
ripartono da soli**, senza che nessuno effettui login al desktop.

### 4.A Linux — systemd (consigliato)

**1) MariaDB in avvio automatico:**

```bash
sudo systemctl enable --now mariadb     # "enable" = al boot, "--now" = anche adesso
systemctl is-enabled mariadb            # atteso: enabled
systemctl status mariadb --no-pager     # atteso: active (running)
```
*(Su sistemi con MySQL: stessi comandi con `mysql` al posto di `mariadb`.)*

**2) Applicazione come servizio systemd** — il progetto fornisce già
`deploy/certificati.service`:

```ini
[Unit]
Description=Gestione Certificati Dipendenti Comunali (Node.js)
After=network.target mariadb.service mysql.service
Wants=mariadb.service

[Service]
Type=simple
User=www-data                            # adattare all'utente reale
WorkingDirectory=/opt/certificati-comune # adattare al percorso reale
ExecStart=/usr/bin/node /opt/certificati-comune/server.js
Restart=always                           # se cade, riparte dopo 5 s
RestartSec=5
Environment=NODE_ENV=production
NoNewPrivileges=true
ProtectSystem=full
ReadWritePaths=/opt/certificati-comune/uploads

[Install]
WantedBy=multi-user.target
```

Installazione e attivazione:

```bash
sudo cp deploy/certificati.service /etc/systemd/system/
sudo nano /etc/systemd/system/certificati.service   # verificare User= e i percorsi
sudo systemctl daemon-reload
sudo systemctl enable --now certificati
systemctl status certificati --no-pager             # atteso: active (running)
journalctl -u certificati -f                        # log in tempo reale (CTRL+C per uscire)
```

Il servizio è **a livello di sistema**: parte al boot, senza login e senza
sessione grafica. `Restart=always` gestisce anche i crash dell'app.

**3) Reboot di collaudo:**

```bash
sudo reboot
# ...al ritorno, dal server o da un PC client:
systemctl status mariadb certificati --no-pager
curl -s http://192.168.1.50:3000/api/salute
```

*Alternativa PM2 su Linux:* `npm i -g pm2 && pm2 start deploy/ecosystem.config.js && pm2 save && pm2 startup`
(seguite l'istruzione che pm2 stampa a video) — ma su Linux il servizio systemd
resta la scelta più robusta.

### 4.B Windows — PM2 + pm2-windows-startup (e servizio MariaDB)

**1) MariaDB in avvio automatico:**

- Se l'installer MariaDB è stato completato con *«Install as service»* +
  avvio *Automatico*, non serve nulla (verifica al punto successivo);
- Verifica/correzione da prompt **amministratore**:

```bat
sc config MariaDB start= auto
net start MariaDB
sc query MariaDB
```
  *(il nome del servizio può essere `MariaDB`, `MariaDB11.8` o `MySQL`: vedi `services.msc`).
  In alternativa: `services.msc` → MariaDB → Proprietà → Tipo di avvio: **Automatico** → Avvia.)*

**2) Applicazione con PM2:**

```bat
npm install -g pm2 pm2-windows-startup
cd C:\certificati-comune
pm2 start deploy\ecosystem.config.js
pm2 list                      # atteso: certificati → online
pm2 logs certificati          # log (CTRL+C per uscire)
pm2 save                      # salva l'elenco dei processi da ripristinare
pm2-startup install           # registra il ripristino AUTOMATICO all'accensione
```

Con `pm2 save` + `pm2-startup install`, all'accensione del PC PM2 riporta
online l'elenco salvato (l'app legge il suo `.env` dalla `cwd` impostata in
`deploy/ecosystem.config.js`).

> ⚠ **Nota operativa onesta su Windows**: `pm2-windows-startup` aggancia il
> riavvio alla **sessione utente** (Startup del profilo). Se il criterio
> aziendale vuole il servizio vivo **anche senza alcun login**, due alternative
> equivalenti:
> **(a) NSSM** (servizio Windows vero, consigliata):
> ```bat
> :: scaricare nssm.exe da nssm.cc in C:\nssm poi:
> C:\nssm\nssm.exe install Certificati "C:\Program Files\nodejs\node.exe" "C:\certificati-comune\server.js"
> C:\nssm\nssm.exe set Certificati AppDirectory C:\certificati-comune
> C:\nssm\nssm.exe set Certificati Start SERVICE_AUTO_START
> net start Certificati
> ```
> **(b) Utilità di pianificazione**: nuova attività → *«All'avvio del computer»* →
> programma `node.exe`, argomento `server.js`, cartella `C:\certificati-comune` →
> Proprietà → ✓ *«Esegui indipendentemente dalla connessione degli utenti»*.

**3) Reboot di collaudo:**

```bat
shutdown /r /t 0
:: al ritorno (senza fare login con l'utente applicativo):
pm2 list
net start | findstr /i "maria"
:: da un client: http://192.168.1.50:3000
```

### 4.C Ordine di avvio garantito

- **Linux**: `certificati.service` dichiara `After=mariadb.service` +
  `Wants=mariadb.service` e l'app ha `Restart=always` → se il DB fosse lento a
  salire, l'app riparte da sola fino a connettersi.
- **Windows**: MariaDB (servizio automatico) e PM2/NSSM convivono; in caso di
  avvio più lento del DB, l'app logga l'errore e PM2/NSSM la riavvia
  automaticamente (restart_DELAY 5 s in `ecosystem.config.js`).

---

## 5. Guida di Accesso per i Dipendenti e Risoluzione Problemi

### 5.1 Come si collega un dipendente (o l'amministratore)

1. Aprire il browser (Chrome/Edge/Firefox di qualunque PC della rete);
2. Digitare nella barra degli indirizzi:

   ```
   http://192.168.1.50:3000
   ```
3. Effettuare l'accesso con **matricola e password**;
4. *(Consigliato)* salvare l'indirizzo nei **segnalibri** o impostarlo come
   homepage/intranet link del comune;
5. *(Facoltativo, richiede il DNS aziendale)* creare un nome comodo, es.
   `http://certificati.comune.local`, aggiungendo un record DNS A verso `192.168.1.50`.

**Flusso tipico del dipendente**: al primo accesso usa la password provvisoria
comunicata dall'ufficio personale (es. `Benvenuto@2026`) → la pagina mostra in
alto un **avviso non bloccante** che invita a cambiarla dalla sezione *Profilo*
(è possibile comunque caricare subito i certificati) → carica i PDF nella scheda
*I miei certificati*. L'**amministratore** accede con la propria matricola e
gestisce utenti (import CSV), approvazioni, filtri ed export dalla *console admin*.

### 5.2 Troubleshooting — i tre problemi più comuni

#### 🔴 A) «Il sito non si carica dalle postazioni dei colleghi»

Checklist in ordine (dal PC del collega):

| Passo | Comando / azione | Cosa significa il risultato |
|---|---|---|
| 1. Il server è raggiungibile? | `ping 192.168.1.50` | se NON risponde: PC server spento, cavo/Wi-Fi, oppure IP sbagliato → verificare sul server con `ip a` / `ipconfig` |
| 2. Stessa rete? | `ipconfig` sul client: IP `192.168.1.x`? | subnet diverse (es. `192.168.0.x` vs `192.168.1.x`) → problema di VLAN/assegnazione IP, non dell'app |
| 3. La porta è ascoltata? *(sul server)* | `ss -tlnp \| grep 3000` (Linux) · `netstat -ano \| findstr :3000` (Win) | se manca `0.0.0.0:3000`: app spenta (§5.2.B) o `HOST` errato nel `.env` |
| 4. Firewall server | Linux: `sudo ufw status` · Windows: `wf.msc` → regole in entrata | manca la regola del §3 → aggiungerla |
| 5. App attiva? *(sul server)* | `systemctl status certificati` / `pm2 list` | `inactive`/`stopped` → `sudo systemctl start certificati` / `pm2 restart certificati` |
| 6. Porta occupata da altro? *(sul server)* | stesso comando del passo 3 ma guardando il PID | conflitto → cambiare `PORT` nel `.env`, riavviare e aggiornare la regola firewall |
| 7. Browser client | CTRL+F5 (aggorna senza cache); provare un altro browser | l'app non usa cache sulle API, ma la pagina HTML può essere in cache |

> Se dal server `http://localhost:3000` funziona ma dai client no, il problema è
> **quasi sempre** firewall (passo 4) o ascolto su `127.0.0.1` (passo 3).

#### 🟠 B) «Errore di connessione al DB MySQL dopo un riavvio del server»

Sintomo: la pagina mostra errore o il log dell'app dice
`[FATALE] Database non raggiungibile` / `ECONNREFUSED`.

```bash
# LINUX — diagnosi
systemctl status mariadb            # attivo?
sudo systemctl start mariadb        # se spento: avvio
sudo systemctl enable mariadb       # ⬅ se "disabled" era il problema: attivare l'autostart!
systemctl status certificati        # l'app con Restart=always si è già ripresa da sola?
journalctl -u certificati -n 50     # ultimi log dell'app
```

```bat
:: WINDOWS — diagnosi (prompt amministratore)
sc query MariaDB                    :: attivo?
net start MariaDB                   :: se fermo: avvio
sc config MariaDB start= auto       :: se "DISABLED" o "DEMAND_START": autostart!
pm2 list                            :: l'app è online? se no: pm2 restart certificati
pm2 logs certificati --lines 50     :: ultimi log
```

Altri casi:
- **Credenziali**: testare ciò che l'app usa →
  `mysql -u cert_app -p certificati_comune -e "SELECT 1;"` (con la password del
  `.env`). Se rifiuta: allineare `DB_PASSWORD` del `.env` con
  `ALTER USER 'cert_app'@'localhost' IDENTIFIED BY '…';` e riavviare l'app.
- **App partita prima del DB** (riavvio lento): con `Restart=always`/PM2 si
  riattiva da sola entro qualche secondo; in caso contrario riavviare l'app.

#### 🟡 C) «Impossibile scaricare o visualizzare i PDF caricati»

| Causa probabile | Diagnosi | Rimedio |
|---|---|---|
| File cancellato dal disco (record in DB senza file) | il download risponde **«File non presente sul server»**; controllare `uploads/certificati/{codice_fiscale}/` | ripristinare il file dal **backup** (§5.3); il record resta comunque consultabile |
| Permessi della cartella uploads (Linux) | `ls -l uploads/certificati` → proprietario sbagliato (non `www-data`) | `sudo chown -R www-data:www-data /opt/certificati-comune/uploads` |
| Progetto/cartella spostata o disco diverso | i record puntano a `certificati/{matricola}/…` relativi alla radice: la radice dipende da `UPLOAD_DIR` | impostare `UPLOAD_DIR` al percorso giusto nel `.env` e riavviare (i percorsi relativi restano validi) |
| Sessione scaduta durante la consultazione | il browser mostra «Sessione scaduta» | rifare il login (i download sono protetti: solo il proprietario o l'admin) |
| Blocco del browser sui file inline | il PDF «non si apre» ma scaricandolo si apre | verificare impostazioni download/visualizzatore PDF del browser |
| Antivirus di rete che intercetta i download | stessa operazione da un altro PC | concordare con l'IT un'esenzione per l'IP del server |

Verifica di integrità rapida (sul server):

```bash
# un file per ogni matricola con certificati + nessun record orfano nel log
ls uploads/certificati | head
sudo mysql certificati_comune -e "SELECT COUNT(*) AS certificati, COUNT(DISTINCT dipendente_id) AS dipendenti FROM certificati;"
```

### 5.3 Nota finale: backup (mini-runbook)

L'app tiene i **dati su MariaDB** e i **PDF su disco** (per scelta di progetto,
mai BLOB): un backup completo è due comandi:

```bash
# Linux (esempio da pianificare in cron, es. ogni notte alle 23:00)
mariadb-dump -u cert_app -p certificati_comune > /backup/certificati_$(date +%F).sql
tar -czf /backup/uploads_$(date +%F).tar.gz -C /opt/certificati-comune uploads
```

Su Windows: `mysqldump.exe -u cert_app -p certificati_comune > backup.sql` più una
copia della cartella `uploads\` (Utilità di pianificazione → script `.bat`).

---

## ✅ Checklist finale del deployment

| # | Controllo | ✔ |
|---|---|---|
| 1 | IP statico configurato e pingabile dai client (`ping 192.168.1.50`) | ☐ |
| 2 | `.env` con `HOST=0.0.0.0`, `PORT=3000`, `COOKIE_SECURE=false`, `JWT_SECRET` casuale | ☐ |
| 3 | `ss -tlnp`/`netstat` mostra **0.0.0.0:3000** | ☐ |
| 4 | Regola firewall 3000/TCP attiva (solo rete locale) | ☐ |
| 5 | MariaDB e app con avvio **automatico** (`systemctl is-enabled` / `sc config … start= auto` + `pm2 save`) | ☐ |
| 6 | **Reboot di collaudo** superato senza login manuale | ☐ |
| 7 | Login admin OK da un PC client + import dei 250 dipendenti effettuato | ☐ |
| 8 | Upload di un certificato di prova da una postazione + download OK | ☐ |
| 9 | Backup pianificato (DB + `uploads/`) | ☐ |
| 10 | Password dell'admin iniziale cambiata; credenziali depositate in cassaforte IT | ☐ |

*Con questi 10 punti spuntati, il servizio è operativo e resiliente ai riavvii.
Guida d'uso funzionale per il personale: `docs/GUIDA-OPERATIVA.md`.*

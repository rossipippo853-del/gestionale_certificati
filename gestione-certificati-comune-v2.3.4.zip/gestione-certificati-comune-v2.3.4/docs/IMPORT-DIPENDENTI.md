# 📥 Importazione massiva dei dipendenti (Import Batch)
## Guida operativa — v1.3.0

Questa guida spiega come inserire in un'unica operazione l'**anagrafica reale
dei dipendenti** (es. i ~250 effettivi) al posto dei dati dimostrativi creati
da `db/seed.js`. La funzionalità è disponibile in **due modalità equivalenti**
che condividono lo stesso motore di validazione e sicurezza:

| Modalità | Adatta a | Avvio |
|---|---|---|
| **A. Pannello Amministratore** (consigliata per l'ufficio personale) | operatore non tecnico, con report a schermo e download delle credenziali | scheda «Dipendenti» → pulsante **«⬆ Importa da CSV»** |
| **B. Riga di comando / CLI** (consigliata per l'IT) | automazioni, ripetizioni, ambienti senza interfaccia | `node db/import-dipendenti.js file.csv [opzioni]` |

---

## 1. Strategie a confronto (e perché abbiamo scelto così)

| Strategia | Vantaggi | Limiti | Verdetto |
|---|---|---|---|
| **Import CSV dal pannello admin** | guidato, validazione riga per riga con report, password generate mostrate una sola volta, nessun accesso diretto al server | richiede un operatore con ruolo admin | ✅ **consigliata** per l'uso ordinario |
| **Script CLI** (`db/import-dipendenti.js`) | scriptabile/ripetibile, utilizzabile in deployment automatici, codici di uscita per il monitoring | richiede accesso al server e utilizzo del prompt | ✅ **consigliata** per l'IT e per i caricamenti ripetuti |
| SQL diretto (`INSERT` multipli, `LOAD DATA INFILE`) | velocità assoluta | **salta le garanzie di sicurezza**: le password andrebbero in chiaro o con hash improvvisato, nessuna creazione delle cartelle per matricola, nessuna validazione, nessun report | ⛔ **sconsigliata** |
| Sincronizzazione automatica con Active Directory/LDAP | nessun file da gestire | richiede infrastruttura AD e sviluppo dedicato | 🔜 evoluzione futura possibile |

> In entrambe le modalità consigliate le password vengono **cifrare con bcrypt
> prima di toccare il database** e per ogni nuovo account viene **creata la
> cartella `uploads/certificati/{matricola}`** sul server: le operazioni SQL
> manuali non garantiscono nessuna di queste cose.

---

## 2. Formato del file richiesto

File **CSV in UTF-8** (da Excel: *File → Salva con nome → CSV UTF-8 (delimitato
dal punto e virgola)*). Il separatore viene **riconosciuto automaticamente**
(`;`, `,` o TAB). Riconosciuti anche BOM UTF-8, campi tra virgolette e fine
riga Windows/Mac.

### Colonne

| # | Colonna | Obbligatoria | Regole |
|---|---|---|---|
| 1 | `nome`, `cognome` | ✅ | 2-100 caratteri |
| `matricola` | ✅ | 3-20 caratteri alfanumerici (`A-Z a-z 0-9 _ -`); è lo **username** di accesso e il nome della cartella sul server; **univoca** |
| `codice_fiscale` | ✅ | 16 caratteri formato italiano, univoco; nomina la cartella PDF (v2.0) |
| `sesso` | ✅ | `M`, `F` o `ALTRO` (v1.4) |
| `qualifica_professionale` | ✅ | 2-120 caratteri (v1.4) |
| 2 | `nome` | ✅ | 2-100 caratteri |
| 3 | `cognome` | ✅ | 2-100 caratteri |
| 4 | `email` | — | facoltativa; se presente deve essere valida (max 150 caratteri) |
| 5 | `ruolo` | — | `DIPENDENTE` (predefinito se vuota) oppure `AMMINISTRATORE` |
| 6 | `password_temporanea` | — | se vuota il sistema **genera** una password sicura di 10 caratteri; se indicata: min 8 caratteri, almeno una lettera e un numero |

Sono accettati anche gli alias di intestazione `password_provvisoria`/`password`
e `e-mail`/`mail`. Le righe completamente vuote vengono ignorate (e conteggiate
nel report). Limite: **2000 righe per file, 2 MB**.

### Esempio (fornito in `db/modello-dipendenti.csv`)

**Formato v2.0** (con Codice Fiscale, Sesso e Qualifica professionale obbligatori):

```csv
nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale;email;ruolo;password_temporanea
Maria;Carta;30011;CRTMRA80A01H501U;F;Istruttore direttivo;maria.carta@comune.it;DIPENDENTE;Benvenuto2026
Luigi;Spano;30012;SPNLUJ85M20D963T;M;Agente di polizia locale;;DIPENDENTE;
Sara;Melis;30013;MLSSRA90C45G822W;F;Assistente amministrativo;sara.melis@comune.it;DIPENDENTE;
```

- `codice_fiscale` (v2.0): **16 caratteri nel formato italiano** (es. RSSMRA80A01H501U);
  DEVE essere unico: righe con CF malformato, duplicato nel file o già a DB finiscono in
  errore SENZA bloccare le altre; la cartella PDF del dipendente è
  `uploads/certificati/{codice_fiscale}/`; con «aggiorna» il CF non viene mai modificato;
- `sesso`: `M`, `F` o `ALTRO` (obbligatorio);
- `qualifica_professionale`: 2-120 caratteri (obbligatoria);
- `password_temporanea` vuota → viene usata la password predefinita **`Benvenuto@2026`**
  (cifrata con bcrypt; il cambio al primo accesso resta obbligatorio).

Il vecchio formato v1.3 (senza sesso/qualifica) non è più accettato: il report
indica chiaramente le colonne mancanti.

- `30011` → password temporanea indicata nel file (`Benvenuto2026`);
- `30012` → password **generata automaticamente** dal sistema;
- la riga dell'intestazione è obbligatoria esattamente come sopra.

---

## 3. Cosa fa il sistema durante l'importazione

Per ogni riga **valida**:

1. **Validazione completa** (matricola, nomi, email, ruolo, policy password);
   le righe con errori non bloccano le altre: finiscono nel **report con il
   numero di riga** del file.
2. Se la **matricola esiste già**:
   - `ignora` (predefinito) → il record viene saltato e segnalato nel report;
   - `aggiorna` → vengono aggiornati **solo** nome, cognome, email e ruolo
     (la password e lo stato dell'account restano invariati).
3. Per ogni **nuovo** utente:
   - la password (dal file o generata) viene **cifrata con bcrypt** e salvata
     solo come hash;
   - viene creata la cartella **`uploads/certificati/{matricola}/`** sul server;
   - l'account nasce con **cambio password obbligatorio al primo accesso**
     (le operazioni di scrittura restano bloccate finché non la sostituisce).
4. A fine elaborazione: **report completo** — nuovi account (con le password
   generate, visibili una sola volta), aggiornati, saltati, errori riga per riga.

> 💡 **Consiglio operativo**: eseguire sempre prima un'importazione in
> **«Prova generale»** (dry-run): il sistema verifica tutto il file e mostra
> cosa accadrebbe, senza salvare nulla. Poi si rilancia senza la prova.

---

## 4. Modalità A — Import dal Pannello Amministratore

1. Accedere come **AMMINISTRATORE** → scheda **«👥 Dipendenti»**.
2. Premere **«⬆ Importa da CSV»**.
3. (facoltativo) **«⬇ Scarica il modello CSV di esempio»**: file pronto da
   compilare con i dati reali.
4. Selezionare il file, scegliere come trattare le matricole già esistenti e
   attivare **«Prova generale»** per la prima verifica.
5. Premere **«Verifica e importa»** e attendere (con centinaia di righe la
   cifratura delle password può richiedere qualche decina di secondi).
6. Leggere il **report**: contatori riepilogativi, elenco dei nuovi account con
   le password generate, record saltati, errori riga per riga.
7. Con i nuovi account creati sono disponibili:
   - **«📋 Copia matricole e password generate»** (per incollarle in una
     comunicazione ai dipendenti);
   - **«⬇ Scarica credenziali (CSV)»** (file `matricola;password_temporanea`
     da conservare in un luogo sicuro: le password generate **non** saranno più
     visibili in seguito).
8. Le righe con errori si correggono nel file e si rilancia l'importazione:
   le matricole già inserite verranno riconosciute come duplicate e saltate
   (nessun doppio inserimento).

## 5. Modalità B — Script da riga di comando (CLI)

```bash
# 1) sola verifica: mostra cosa accadrebbe, senza salvare nulla
node db/import-dipendenti.js dipendenti_comune.csv --dry-run

# 2) importazione effettiva (matricole esistenti = salta)
node db/import-dipendenti.js dipendenti_comune.csv

# 3) importazione aggiornando l'anagrafica delle matricole già presenti
node db/import-dipendenti.js dipendenti_comune.csv --duplicati=aggiorna

# equivalente con npm
npm run importa -- dipendenti_comune.csv --dry-run
```

**Requisiti**: essere nella cartella del progetto, MySQL/MariaDB attivo e file
`.env` configurato (le credenziali del database sono le stesse del server web).

**Output di esempio** (dry-run su database di prova):

```
════════════════════════════════════════════════════════════
 Importazione dipendenti — Gestione Certificati
════════════════════════════════════════════════════════════
 File:               /percorso/dipendenti_comune.csv
 Righe dati:         3 (vuote ignorate: 0)
 Duplicati:          IGNORA (salta)
 Modalità:           PROVA GENERALE — nessuna modifica verrà salvata
────────────────────────────────────────────────────────────
► NUOVI ACCOUNT (3)
   30011        Maria Carta           password: —
   30012        Luigi Spano           password: —
   30013        Sara Melis            password: —

────────────────────────────────────────────────────────────
 RIEPILOGO: elaborate 3 · nuovi 3 · aggiornati 0 · saltati 0 · errori 0
 (prova generale: NESSUNA modifica è stata salvata)
════════════════════════════════════════════════════════════
```

**Codici di uscita** (per script automatici e monitoring):
`0` = completato senza errori · `1` = errore bloccante (file/argomenti/database)
· `2` = completato ma con righe in errore (vedere il report).

---

## 6. Domande frequenti e problemi

| Situazione | Comportamento / soluzione |
|---|---|
| Matricola già esistente | con `ignora` viene saltata; con `aggiorna` si aggiornano solo nome, cognome, email e ruolo (mai la password) |
| Stessa matricola ripetuta **nel file** | la seconda occorrenza va in errore («matricola duplicata nel file») |
| Password troppo semplice nel file | riga rifiutata: min 8 caratteri, almeno una lettera e un numero (oppure lasciare vuota e far generare) |
| Accenti strani dopo l'apertura in Excel | salvare come **«CSV UTF-8»** (il vecchio «CSV» di Excel non è UTF-8) |
| «Colonne obbligatorie mancanti» | l'intestazione deve contenere almeno `matricola`, `nome`, `cognome` (usare il modello) |
| Upload rifiutato | verificare estensione `.csv`/`.txt`, dimensione ≤ 2 MB, righe ≤ 2000 |
| Ho perso le password generate | non sono recuperabili (sono cifrate): usare il reset password dal pannello per l'account interessato |
| Da sostituire i 250 dipendenti demo | importare i reali e poi disabilitare/eliminare gli account demo dal pannello; i file PDF demo si rimuovono dalla cartella `uploads/certificati/` delle matricole demo |

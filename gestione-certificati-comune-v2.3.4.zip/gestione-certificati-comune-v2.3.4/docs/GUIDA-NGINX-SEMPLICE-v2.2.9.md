# Accedere al portale con un NOME (senza toccare i PC) — Guida semplificata

**Obiettivo**: il dipendente digita `http://portale.certificati` e arriva al
portale. **Nessuna modifica** sui PC dei dipendenti.

---

## Le 3 cose (e chi le fa)

| # | Cosa | Chi la fa | Dove |
|---|---|---|---|
| 1 | **NGINX**: riceve sulla porta 80 e passa tutto al portale (3000) | Tu, **una volta sola** | PC server del portale |
| 2 | **Record DNS**: «portale.certificati = IP del server» | Chi gestisce il server della rete (IT comunale), **una riga sola** | Server di rete (es. Windows Server) |
| 3 | Verifica | Tu, da un PC qualunque | Qualsiasi PC dipendente |

> **Concetto chiave**: il NOME non lo crea NGINX. NGINX fa solo da «portineria»
> (porta 80 → porta 3000). Il nome lo risolve il **DNS della rete**: aggiunto
> lì una volta, funziona per TUTTI i PC automaticamente, perché tutti i PC
> chiedono già a quel DNS (è così che trovano stampanti e file server).

---

## PASSO 1 — NGINX sul PC server (5 minuti)

Dalla cartella del portale (il file `deploy/nginx.conf` è già pronto):

```bash
sudo apt update && sudo apt install -y nginx
sudo cp deploy/nginx.conf /etc/nginx/sites-available/portale-certificati
sudo ln -s /etc/nginx/sites-available/portale-certificati /etc/nginx/sites-enabled/
sudo nginx -t                 # deve dire «syntax is ok»
sudo systemctl reload nginx
```

Verifica immediata (dal server stesso):

```bash
curl -I http://127.0.0.1/     # → HTTP/1.1 200 OK
```

Da questo momento il portale risponde **anche** sull'indirizzo
`http://IP-DEL-SERVER/` (senza :3000). L'app Node si lascia dove è.

## PASSO 2 — Il record DNS (una telefonata/richiesta all'IT)

Chiedi a chi gestisce il server di rete (in un comune: l'IT che amministra
Windows Server / Active Directory). Puoi inoltrare testualmente questa
richiesta:

> **Oggetto**: nuovo record DNS interno per il portale formazione
>
> Nel DNS della rete (zona interna) aggiungi un record **A**:
> - **Nome**: `portale.certificati`
> - **Indirizzo IP**: `192.168.x.x` (IP del PC server del portale)
>
> È un record solo interno, non tocca Internet né l'esterno. Grazie!

Sul server Windows l'IT farà: **DNS Manager → zona della rete → Nuovo host (A)**
→ nome `portale.certificati`, IP del server. Operazione di 1 minuto.

⚠️ **Non è possibile farlo dal tuo PC/server da solo**: il DNS centrale è
gestito da chi amministra la rete. Se non sapete chi sia, chiedete al
responsabile dell'IT comunale «chi gestisce il DNS interno?».

## PASSO 3 — Verifica (da un PC dipendente qualsiasi)

```bash
ping portale.certificati      # deve rispondere l'IP del server
```

poi apri il browser e digita: **`portale.certificati`** → compare la pagina di
login «Città di Milazzo — Portale Formazione e Certificati». Fatto.

*(Se il ping dà errore nei primi minuti è solo la cache DNS del PC: dopo
pochissimo, o riavviando il browser, funziona.)*

---

## E se NON esiste un DNS centrale gestibile?

Rarissimo in una rete comunale, ma in alternativa:

| Alternativa | Come | Limiti |
|---|---|---|
| **DNS sul router/firewall** | Molti router aziendali permettono una voce «DNS locale/statico»: nome `portale.certificati` → IP server | Dipende dal modello di router |
| **Solo IP, senza nome** | Nulla da fare: il portale già risponde su `http://IP-DEL-SERVER/` dopo il PASSO 1 | I dipendenti digitano i numeri, non il nome |

---

## Perché NGINX e non direttamente la porta 80 all'app?

Potresti far ascoltare l'app Node direttamente sulla 80. NGINX davanti è però
lo standard perché: (1) separa i ruoli — l'app resta interna e NGINX la
espone; (2) in futuro puoi attivare **HTTPS** e altre protezioni toccando solo
NGINX; (3) tiene un **log** di tutti gli accessi in
`/var/log/nginx/portale-certificati.access.log`.

---

*Guida semplificata v2.2.9 — dettagli tecnici completi in
`docs/GUIDA-DOMINIO-LOCALE-v2.2.9.md` e configurazione in `deploy/nginx.conf`.*

# TEST DI CARICO — 1.158 certificati · 351 dipendenti · 1.218 allegati PDF (v2.3.3)

Obiettivo: verificare che il portale funzioni correttamente e con tempi di
risposta ottimali anche con una grande mole di dati. Ambiente: sandbox Linux,
Node 20, MariaDB 11.8, app v2.3.3, misurazioni lato HTTP reale (curl/fetch).

---

## 1. Dati generati

| Voce | Valore |
|---|---|
| Dipendenti totali (incl. 1 admin) | **351** (250 seed + 100 aggiunti + admin) |
| Certificati totali | **1.158** (1.000 generati + 75 «utenti pesanti» + 79 del seed + 4 di prova) |
| Distribuzione stati | 713 APPROVATO · 334 IN_ATTESA · 111 RIFIUTATO |
| Allegati PDF **reali su disco** | **1.218 file**, ~20 MB (16–22 KB cad., 1–2 per corso) |
| Dipendente più carico | `10017` — 10 certificati, 9 aree, 125 h 30 m conteggiate |
| Tempo di generazione | 2,0 s (1.158 INSERT + 1.218 file) |

Tutti i certificati hanno: corso, ente, data 2022-2026, durata h:mm, esame, area
(pescata dalle 18 reali), stato coerente (approvati con `approvato_da`, rifiuti
con nota), allegati con percorso relativo corretto e PDF scaricabile.

## 2. Latenza degli endpoint (mediana su 8 richieste; ambiente freddo e a caldo)

| Endpoint | Volume gestito | Mediana | Max | Esito |
|---|---|---:|---:|---|
| POST /api/auth/login (bcrypt) | 351 account | 83 ms | 88 ms | ✅ |
| GET /admin certificati, pag. 1 (25) | 1.158 righe indicizzate | **11 ms** | 21 ms | ✅ |
| GET /admin certificati, ultima pagina (47) | paginazione profonda | **11 ms** | 11 ms | ✅ nessuna degradazione |
| GET /admin certificati, filtro stato=IN_ATTESA | 334 risultati | 7 ms | 9 ms | ✅ |
| GET /admin certificati, ricerca q=Rossi | 48 risultati | 11 ms | 12 ms | ✅ |
| GET /admin certificati, filtro area=Altro | 60 risultati | 6 ms | 17 ms | ✅ |
| GET /admin certificati **?perPagina=tutti** | **1.154 righe** | 36 ms | 36 ms | ✅ |
| GET /admin utenti pag. 1 | 351 account, 15 pagine | **4 ms** | 5 ms | ✅ |
| GET /admin utenti 50 righe + ricerca | 16 risultati | 5 ms | 10 ms | ✅ |
| GET /admin utenti/options (combobox) | 349 voci | 6 ms | 7 ms | ✅ |
| GET /admin stats (dashboard) | 6 sub-select + 18 aree | 6 ms | 8 ms | ✅ |
| GET /admin **monitoraggio** (tab analytics) | LEFT JOIN 351×1.158 + 2 GROUP BY | **7 ms** | 8 ms | ✅ |
| GET /admin formazione dip. più carico | 10 certificati, 9 aree | 5 ms | 9 ms | ✅ |
| GET /admin audit (ultime 100) | — | 4 ms | 4 ms | ✅ |
| GET /admin utenti/export | CSV 352 righe (header + 351) | 5 ms | 6 ms | ✅ |
| GET /admin certificati/export | **CSV 1.155 righe** | 26 ms | 37 ms | ✅ |

## 3. Lato dipendente (flusso completo reale)

| Operazione | Risultato |
|---|---|
| Login dipendente + cambio password obbligatorio (2×bcrypt) | 269 ms totale, poi token di scheda |
| GET /api/certificati (vista completa propria) | **~4 ms** (10 corsi + allegati + ore totali 125 h 30 m, badge 40h VERDE) |
| Download allegato PDF | 200 · 16.103 byte · 6,6 ms |
| (v2.3.3) rientro con SOLO cookie | 401 → login obbligatorio, come da progetto |

## 4. Scrittura (upload reali via API, multipart)

| Test | Risultato |
|---|---|
| Upload 1 PDF (6,5 h, multipart) | **201 in 5–11 ms** |
| Upload 5 PDF in una richiesta (massimo consentito) | **201 in 7,6 ms** |
| Verifica DB dopo le scritture | 1.158 certificati · 1.218 allegati ✅ |

## 5. Concorrenza (150 richieste simultanee, 5 ondate da 30, endpoint misti)

| Ondata | 30 richieste parallele |
|---|---:|
| 1 | 154 ms |
| 2 | 116 ms |
| 3 | 100 ms |
| 4 | 84 ms |
| 5 | 106 ms |
| **Totale** | **150/150 OK · 0 errori · ~267 richieste/s** |

Nessun timeout, nessun 5xx, nessuna connessione DB in esaurimento
(l'app usa un pool di connessioni riutilizzabili).

## 6. Risorse

| Risorsa | Valore |
|---|---|
| Memoria app Node (RSS) | **66,6 MB** (picco teorico 1 GB virtuale: normale per Node) |
| Database MariaDB | dipendenti 0,2 MB · certificati 0,5 MB · allegati 0,3 MB (totali, incl. indici) |
| File su disco (uploads/) | 29 MB |
| Uptime app durante il test | ~2 h senza riavvii |

## 7. Verifiche di CORRETTEZZA sui dati di carico

| Controllo | Atteso | Ottenuto | ✅ |
|---|---|---|---|
| Monitoraggio: persone al target 40h (ore conteggiate = approvate+attesa) | coerente con i dati | 273/351 (78%) | ✅ |
| Monitoraggio: somma caricamenti per area | 1.158 | 1.154+4 = tutti i caricamenti contati | ✅ |
| Dashboard dip. più carico: ore conteggiate | coincide con vista dipendente | 125 h 30 m = 7.530′ | ✅ |
| CSV anagrafica | header + 351 | 352 righe | ✅ |
| CSV certificati | header + 1.158 | 1.155 righe (+3 di test) | ✅ |
| Impaginazione utenti | 351/25 → 15 pagine | 15 pagine | ✅ |
| Paginazione profonda certificati | 1.158 = 46×25+4 | ultima pagina = 4 righe | ✅ |
| Filtri (stato/area/ricerca) | coerenti | 334 / 60 / 48 risultati | ✅ |

## 8. Conclusioni

1. **Nessun collasso né degradazione**: con oltre 1.100 certificati e 350
   account, TUTTE le pagine rispondono in **≤ 36 ms** (la peggiore è
   l'elenco completo «perPagina=tutti», che per progetto carica tutto).
2. Le scelte progettuali reggono il carico: **impaginazione server-side**
   (25/50), **una sola query** con allegati mappati per id (nessun loop N+1),
   **aggregazioni SQL** (SUM/GROUP BY) invece di calcoli in JavaScript,
   indici su `dipendente_id`/`certificato_id`/`stato`.
3. Il **login è la voce più lenta (83 ms)** per via voluta di bcrypt
   (protezione anti brute-force): non scala col volume di dati.
4. Proiezione: con dati ×10 (~10.000 certificati, 350 utenti) le pagine
   impaginate restano O(log n) — le uniche voci da tenere d'occhio sarebbero
   `?perPagina=tutti` e i CSV (a quel punto si può impaginare anche l'export).

> I dati di carico sono rimasti nel database DEMO (`certificati_comune`):
> puoi esplorarli dall'anteprima (admin → Certificati/Monitoraggio).
> Per ripartire da zero: `DROP DATABASE certificati_comune; CREATE DATABASE
> certificati_comune;` + `schema.sql` + `node db/seed.js --dipendenti=250`.

---
*Test di carico v2.3.3 — generatore e misurazioni eseguiti nel workspace;
report redatto il 2026-09-21.*

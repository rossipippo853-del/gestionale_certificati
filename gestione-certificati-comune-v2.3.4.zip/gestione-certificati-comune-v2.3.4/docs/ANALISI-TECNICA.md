# 📘 ANALISI TECNICA DEL CODICE SORGENTE
## Gestione Certificati Dipendenti Comunali — v1.4.0

> **Novità v1.4**: `dipendenti.{sesso, qualifica}` e
> `certificati.{numero_ore, esame_finale, area_tematica}` (ENUM a 6 aree) sono
> obbligatori e validati in `utils/validazione.js` (costanti `SESSI`,
> `AREE_TEMATICHE`, `ORE_MIN/MAX`); l'import CSV richiede le nuove colonne e
> usa la password predefinita `Benvenuto@2026` (`PASSWORD_PREDEFINITA_CSV`);
> migrazione `ALTER` in `db/migrazione-v1.4.sql`.
*Documentazione di supporto allo sviluppo e alla manutenzione (Parte 1)*

> **Come leggere questo documento**: il capitolo 2 spiega il ciclo di vita di
> una richiesta attraverso tutti i livelli; i capitoli 3–5 analizzano i file
> blocco per blocco (backend, database, frontend); il capitolo 6 illustra le
> sequenze operative complete; il capitolo 7 raccoglie la mappa delle scelte
> di sicurezza. Ogni blocco citato rimanda al file sorgente, che contiene
> commenti coerenti con questa analisi.

---

## 1. Mappa del progetto e responsabilità dei file

```
certificati-comune/
├── server.js                     AVVIO: storage, connessione DB, listen, shutdown
├── src/
│   ├── app.js                    CONFIGURAZIONE EXPRESS: middleware, sicurezza, mount router
│   ├── config.js                 LETTURA .env: un solo punto di configurazione
│   ├── db.js                     POOL MySQL: connessioni riciclate, query parametriche
│   ├── middleware/
│   │   ├── auth.js               JWT da cookie httpOnly, ruolo admin, password provvisoria
│   │   └── errori.js             Traduzione errori (Multer, JSON, 500) in messaggi utente
│   ├── routes/
│   │   ├── auth.routes.js        POST login/logout · GET me · PUT password
│   │   ├── certificati.routes.js GET/POST certificati · GET :id/file   [area dipendente]
│   │   └── admin.routes.js       utenti, certificati globali, CSV, approvazioni [area admin]
│   └── utils/
│       ├── validazione.js        Regole sui dati in ingresso (fonte di verità)
│       ├── file.js               Cartelle matricola, nomi univoci, magic bytes, path-safe
│       ├── sessioni.js           Registro di revoca dei token (logout reale)
│       ├── password.js           Generazione password provvisorie (CSPRNG)
│       └── importazione.js       Motore import CSV: parser, validazioni, esecuzione
├── db/
│   ├── schema.sql                DDL: database, tabelle, indici, utente applicativo
│   └── seed.js                   Popolamento demo (idempotente) + generatore PDF
├── public/                       FRONTEND statico servito da Express
│   ├── index.html + js/login.js  Pagina di accesso
│   ├── dipendente.html + js/dipendente.js
│   ├── admin.html + js/admin.js
│   ├── js/common.js              api(), dialog, toast, escapeHtml, paginazione
│   └── css/stile.css             Foglio di stile unico (nessuna dipendenza esterna)
├── tests/                        SUITE QA: 59 test (npm test)
└── uploads/certificati/{matricola}/  STORAGE PDF (creato a runtime)
```

**Dipendenze runtime** (`package.json`): `express` (server HTTP), `mysql2`
(driver MySQL), `jsonwebtoken` (firma/verifica token), `bcryptjs` (hash
password), `multer` (upload multipart), `cookie-parser` (lettura cookie),
`dotenv` (file .env). **Nessuna dipendenza frontend** e nessun CDN: tutto
funziona in una rete isolata.

---

## 2. Ciclo di vita di una richiesta (come comunicano i livelli)

### 2.1 Richiesta API autenticata (es. elenco certificati)

```
Browser (dipendente.html)
   │  fetch('/api/certificati', {credentials:'same-origin'})
   │  ── il browser allega AUTOMATICAMENTE il cookie `token` (httpOnly)
   ▼
Express (src/app.js)
   │  middleware globali: json → cookieParser → header di sicurezza
   ▼
router.use(autenticazione)                (certificati.routes.js)
   │  1. leggo req.cookies.token
   │  2. jwt.verify(token, JWT_SECRET) → payload {id, matricola, jti, exp}
   │  3. eRevocato(jti)?                → logout precedente? 401
   │  4. SELECT utente dal DB           → esiste ed è attivo?
   │  5. req.utente = {...}             → passa al controller
   ▼
controller GET /                          (certificati.routes.js)
   │  pool.query('… WHERE dipendente_id = ?', [req.utente.id])
   │        └────────── MySQL: prepared statement, valori separati dal SQL ──┐
   ▼                                                                          │
res.json({ certificati })                                    MySQL/MariaDB ◄──┘
   │
   ▼
Browser: dati.certificati → renderTabella() con escapeHtml()
```

Punti chiave della catena:

| Anello | Responsabilità | File |
|---|---|---|
| `fetch` con `same-origin` | il cookie di sessione viaggia solo verso lo stesso sito | `common.js` |
| `autenticazione` | chi sei? token valido, non revocato, utente ancora attivo | `middleware/auth.js` |
| `req.utente` | identità **derivata dal token**: il client non può fingere l'id | `middleware/auth.js` |
| query parametriche | input utente MAI concatenato al testo SQL | ovunque |
| `escapeHtml` | i dati che tornano a schermo sono inerti (anti XSS) | `common.js` |

### 2.2 Richiesta di pagina (navigazione)

`GET /dipendente` → Express static risponde con `public/dipendente.html` (nessun
rendering server-side). La pagina esegue `proteggiPagina('DIPENDENTE')` che
chiama `GET /api/auth/me`: in caso di 401 il redirect avviene **solo se non si
è già sulla pagina di login** (guardia anti-loop, BUG#1). Il controllo di ruolo
client-side è di *comodità*: quello vero è nei middleware del server.

### 2.3 Gestione dei file (flusso biforcuto MySQL + disco)

Il database e il file system hanno ruoli netti e separati:

| Archivio | Contiene | Non contiene |
|---|---|---|
| **MySQL** | metadati: corso, ente, date, stato, audit, **percorso relativo** del PDF | i PDF (zero BLOB) |
| **File system** | `uploads/certificati/{matricola}/{timestamp}-{random}_{nome}.pdf` | — |

Conseguenze pratiche: il DB resta leggero e i backup rapidi; spostare lo
storage = cambiare `UPLOAD_DIR` nel `.env`; l'eliminazione di un certificato
richiede **entrambe** le cancellazioni (riga + file), ed è ciò che fa
`DELETE /api/admin/certificati/:id`.

---

## 3. Analisi del backend — blocco per blocco

### 3.1 `server.js` — avvio e ciclo di vita del processo

| Blocco | Cosa fa | Note operative |
|---|---|---|
| `fs.mkdirSync(DIR_CERTIFICATI, {recursive:true})` | crea `uploads/certificati/` se manca | idempotente: rilanciabile senza effetti |
| `testConnection()` | apre una connessione dal pool e fa `ping` | **fail-fast**: senza DB il server si ferma con messaggio chiaro |
| `app.listen(config.port, '0.0.0.0')` | ascolta su tutte le interfacce | `0.0.0.0` = raggiungibile dalla intranet, non solo da localhost |
| `spegni(segnale)` | su SIGTERM/SIGINT: smette di accettare connessioni → chiude il pool → exit | evita query troncate a metà (systemd `stop`, riavvii) |
| `unhandledRejection` | registra i rifiuti di promessa non gestiti | diagnostica, il processo non muore in silenzio |

### 3.2 `src/app.js` — il "collante" Express

Sequenza di registrazione (l'ordine è semanticamente rilevante):

1. **Parsing**: `express.json({limit:'1mb'})` limita la dimensione dei body
   JSON (anti DoS banale); `cookieParser` popola `req.cookies`.
2. **Header di sicurezza** su ogni risposta:
   - `X-Content-Type-Options: nosniff` → il browser non indovina il tipo;
   - `X-Frame-Options: SAMEORIGIN` → anti clickjacking;
   - `Referrer-Policy: same-origin` → niente URL interni verso l'esterno;
   - **CSP** `script-src 'self'` → il browser rifiuta script inline/esterni:
     anche un XSS ipotetico non riuscirebbe a eseguire codice;
   - `Cache-Control: no-store` sulle `/api/*` → nessuna risposta autenticata
     in cache (proxy, disco del client).
3. **Static**: `public/` con `extensions:['html']` per URL puliti.
4. **API**: salute (pubblica) → `auth` → `certificati` → `admin`. Il montaggio
   sul prefisso dedicato `/api/certificati` (e non su `/api`) è deliberato:
   il middleware di autenticazione del router non "sporca" rotte altrui.
5. **404 API** strutturato (sempre JSON) e **gestore errori** in coda.

### 3.3 `src/config.js` — configurazione

Ogni variabile d'ambiente ha un valore di default sicuro per lo sviluppo; le
costanti derivate (`cookieMaxAgeMs`, `maxFileBytes`) sono calcolate qui. La
radice degli upload è risolta con `__dirname/..` e **non** con `process.cwd()`:
avviare il server da una cartella diversa (systemd con `WorkingDirectory`
sbagliato) non sposta più lo storage. La guardia finale avvisa se `JWT_SECRET`
è assente o lasciata al valore d'esempio.

### 3.4 `src/db.js` — accesso dati

`mysql.createPool(config.db)` con `connectionLimit: 10` e `dateStrings: true`.
Il pool è **l'unico punto di accesso al DB**: i controller chiamano
`pool.query(sql, params)`; `testConnection()` mostra il pattern
`getConnection() → ping → release()` (la connessione torna al pool, non si chiude).

### 3.5 `middleware/auth.js` — i tre guardiani

**`autenticazione`** (dettaglio nel §2.1). Due scelte vanno sottolineate:
- **rilettura dal DB a ogni richiesta**: `attivo` è fonte di verità → la
  disabilitazione di un account uccide le sue sessioni in tempo reale;
- **registro di revoca**: il campo `jti` del payload permette al logout di
  invalidare *il singolo token* (`utils/sessioni.js`, Map in memoria con
  pulizia automatica: adeguata al server singolo; per cluster → Redis).

**`soloAdmin`**: 403 se `req.utente.ruolo !== 'AMMINISTRATORE'`. Applicato una
sola volta a livello di router admin: nessuna rotta admin può nascerne sprovvista.

**`richiediPasswordAggiornata`**: risponde `403 {codice:'PASSWORD_TEMPORANEA'}`
se `must_change_password=1`. Usato: sulle scritture dell'area dipendente
(upload) e sulle scritture dell'area admin. La lettura resta libera di
proposito (le pagine devono caricarsi per mostrare l'avviso), e `/api/auth/password`
è sempre accessibile, altrimenti l'utente non potrebbe sbloccarsi.

### 3.6 `middleware/errori.js` — traduzione degli errori

Ordine di valutazione: `headersSent` (delega) → `MulterError` (limiti upload →
400 con messaggio chiaro) → errori con messaggio contenente "pdf" (fileFilter →
400) → body malformato/troppo grande (400) → fallback **500 generico** con log
completo lato server. Contratto: mai dettagli interni (stack/query/percorsi)
verso il client.

### 3.7 `utils/validazione.js` — regole sui dati

| Funzione | Input | Output | Regole |
|---|---|---|---|
| `pulisci` | valore raw | stringa trimmata | gestisce array da parametri ripetuti |
| `validaDatiCertificato` | body del form upload | `{errori[], valori}` | lunghezze corso/ente, data ISO, **no date future** |
| `validaNuovaPassword` | password | `null` o messaggio | 8–72 char, ≥1 lettera, ≥1 numero (72 = limite bcrypt) |
| `validaDatiDipendente` | body creazione utente | `{errori[], valori}` | matricola `^[A-Za-z0-9_-]{3,20}$`, nome/cognome, email, ruolo in enum |

`RE_MATRICOLA` ha anche un ruolo di sicurezza: la matricola diventa il nome di
una cartella, e il pattern esclude `/ \ . ..` e spazi.

### 3.8 `utils/file.js` — storage sicuro

- `cartellaDipendente(matricola)` → `uploads/certificati/{matricola}` creata con
  `mkdirSync recursive` (**idempotente**): è il meccanismo che rende l'upload
  autosufficiente e la creazione-utente immediata (BUG#3).
- `nomeFileUnivoco()` → `{Date.now()}-{8 hex crypto.randomBytes}_{nome}`: il
  suffisso casuale elimina la corsa di due upload nello stesso millisecondo.
- `ePdf(buffer)` → confronto dei primi 5 byte con `'%PDF-'` (magic bytes):
  blocca file rinominati che il MIME, dichiarato dal client, non intercetta.
- `percorsoAssoluto(rel)` → **tripla barriera anti path traversal**: rifiuto di
  `..`, risoluzione `path.resolve`, verifica `startsWith(radice + sep)`.
- `eliminaFile(rel)` → `unlink` best effort, mai propagato all'utente.

### 3.9 `utils/sessioni.js` — revoca dei token

Map `jti → scadenza`; `revoca()` al logout (fino a `exp` del token),
`eRevocato()` nel middleware. Pulizia automatica a soglia (10.000 voci) e
periodica. Conoscere i limiti: in-memory = per server singolo (il caso target).

### 3.10 `routes/auth.routes.js` — login e credenziali

**Rate limiter in memoria** (`tentativi: Map matricola → {n, scadenza}`):
`loginConsentito` controlla la finestra; `registraFallimento` incrementa e al
5° errore apre la finestra da 15'; pulizia anti memory-leak oltre 500 voci.

**POST /login** — i 6 passi commentati nel sorgente: pulizia input → guardia
rate-limit → `SELECT … WHERE matricola = ?` → `bcrypt.compare` → firma JWT con
`jti` → cookie. Due finezze di sicurezza:
- messaggio d'errore **identico** per matricola inesistente e password errata
  (non si enumerano le matricole valide);
- cookie `httpOnly` (invisibile a JS), `sameSite=lax` (mitigazione CSRF),
  `secure` solo dietro HTTPS.

**POST /logout** — decodifica il payload (senza verifica: il cookie sta per
morire in ogni caso), `revoca(jti, exp*1000)`, `clearCookie`. Il token
presentato di nuovo → 401 (testato).

**GET /me** — profilo proiettato da `profiloPubblico()`: **mai `password_hash`**.

**PUT /password** — verifica della password attuale (protezione da sessioni
incustodite) → policy → hash del nuovo valore → `must_change_password=0`
(l'utente "provvisorio" si sblocca da solo).

### 3.11 `routes/certificati.routes.js` — pipeline di upload

La sequenza dei middleware è significativa:

```
POST /api/certificati
 ├─ autenticazione                (router.use)
 ├─ richiediPasswordAggiornata    ← PRIMA di multer: se blocca, nessun file scritto
 └─ upload.single('file')         Multer: estensione+MIME → disco (nome univoco)
      └─ controller:
          1. req.file esiste? (altrimenti 400, messaggio distinto per oversize)
          2. validaDatiCertificato → se errori: UNLINK del file (niente orfani)
          3. magiaPdfValida(path) → se falsa: UNLINK + 400
          4. percorso relativo → INSERT MySQL (stato IN_ATTESA)
          catch: UNLINK + 500
```

Il download (`GET /:id/file`) valida l'id, legge il record, verifica la
**proprietà** (`cert.dipendente_id === req.utente.id` o ruolo admin), risolve
il percorso in modo path-safe e risponde con `sendFile` (inline,
`?modo=visualizza`) o `download` (allegato).

### 3.12 `routes/admin.routes.js` — area amministratore

Protezione in cascata a livello di router: `autenticazione → soloAdmin →
(gate scritture se password provvisoria)`. Funzioni di supporto: `parametriPagina`
(clamp 5–100), `likeSicuro` (escape di `% _ \`), `generaPasswordProvvisoria`
(CSPRNG, 8 lettere senza ambiguità + 2 cifre, Fisher-Yates), `csvCampo`
(anti formula injection + quoting RFC 4180).

**POST /utenti** — il protocollo a 3 passi che sincronizza DB e file system
(pre-check duplicato → cartella → INSERT con UNIQUE come backstop; rimozione
della cartella solo se la matricola davvero non esiste a DB) è commentato nel
sorgente riga per riga: chiude le due race condition note (doppio click e
create concorrenti).

**PUT /utenti/:id/stato** — `attivo` deve essere boolean rigoroso; vietato
l'auto-disaggio; effetto immediato sulle sessioni grazie alla rilettura DB.

**Filtri certificati** — `filtriCertificati()` costruisce WHERE solo con
segnaposto; condivisa tra vista globale ed export (stessi filtri del pannello
si ritrovano nel CSV).

**CSV** — `'\uFEFF'` (BOM) + `;` + CRLF: doppio click su Excel italiano senza
import. `Content-Disposition` con data del giorno.

**Approvazione** — `COALESCE(?, note_admin)` conserva la nota precedente se
non fornita; audit `approvato_da/approvato_il` popolati con l'admin corrente.

**DELETE** — lettura percorso → DELETE riga → `eliminaFile` best effort.

### 3.13 `utils/importazione.js` — motore di import massiva (v1.3)

Modulo **condiviso** tra il pannello web (`POST /api/admin/utenti/import`) e la
CLI (`db/import-dipendenti.js`): un'unica implementazione = comportamento identico.

- **`parseCsv(testo)`**: parser senza dipendenze — BOM UTF-8, CRLF/LF, campi
  tra virgolette con `""` letterali, **rilevamento automatico del separatore**
  (`;` `,` TAB) contando i candidati fuori virgolette sulla riga di intestazione.
- **`analizzaCsv(testo)`**: mappa le colonne con alias (`password_provvisoria`,
  `e-mail`…), verifica le colonne obbligatorie (`matricola`, `nome`, `cognome`),
  valida ogni riga (matricola, nomi, email, ruolo, policy password) e segnala
  i duplicati **dentro il file**; le righe vuote sono ignorate e conteggiate.
- **`eseguiImport(analisi, {duplicati, dryRun})`**: per ogni riga valida —
  1. riga con errori → `errori[]` con numero di riga, si prosegue;
  2. matricola a DB → `ignora` (saltata) oppure `aggiorna` (UPDATE di nome,
     cognome, email, ruolo — **mai la password**);
  3. nuovo utente → password dal file o generata (`utils/password.js`),
     **cartella matricola creata PRIMA dell'INSERT** (fallimento disco = riga
     in errore, nessun utente "senza cartella"), **bcrypt** sull'hash,
     INSERT con `must_change_password=1`;
  4. `ER_DUP_ENTRY` in corsa → trattato come duplicato; dryRun → nessuna scrittura.

Limiti: 2 MB, 2000 righe. La rotta web riceve il file in memoria (multer
memoryStorage) e traduce i suoi errori in messaggi CSV-specifici.

---

## 4. Database (`db/schema.sql`)

### `dipendenti`

| Colonna | Tipo | Perché così |
|---|---|---|
| `id` | INT UNSIGNED PK AI | chiave tecnica stabile (mai esposta come dati) |
| `matricola` | VARCHAR(20) UNIQUE | username del sistema + indice di ricerca |
| `password_hash` | VARCHAR(100) | bcrypt `$2b$10$…` (60 char): MAI password in chiaro |
| `ruolo` | ENUM | solo 2 valori ammessi dal DB stesso |
| `attivo` | TINYINT(1) | disabilitazione reversibile (niente DELETE anagrafica) |
| `must_change_password` | TINYINT(1) | politica password provvisoria applicata dal middleware |
| `created_at`/`updated_at` | TIMESTAMP | audit automatico |

Indici: `UNIQUE(matricola)`, `KEY(cognome, nome)` per l'ordinamento della lista.

### `certificati`

Chiavi esterne esplicite con comportamenti diversi: `dipendente_id → ON DELETE
CASCADE` (la cronologia segue il dipendente), `approvato_da → ON DELETE SET
NULL` (l'audit del documento sopravvive alla cancellazione dell'admin).
Indici mirati sui filtri reali dell'app: `dipendente_id`, `stato`,
`data_conseguimento`. `percorso_file` memorizza il percorso **relativo**
(`certificati/{matricola}/{file}.pdf`): la posizione fisica è una scelta del
`.env`, non dei dati.

### Utente applicativo

`cert_app` ha solo SELECT/INSERT/UPDATE/DELETE sul singolo schema: nessun DDL,
nessun accesso ad altri database. Un'iniezione o un bug non può `DROP`are tabelle
né leggere dati fuori dal proprio schema.

---

## 5. Analisi del frontend

### 5.1 `public/js/common.js` — la libreria condivisa

| Funzione | Ruolo | Nota di sicurezza/robustezza |
|---|---|---|
| `api(url, opts)` | wrapper di `fetch`: JSON in/out, cookie `same-origin` | **anti-loop 401** (BUG#1): non reindirizza se `location.pathname` è il login; propaga `err.status` e `err.codice` (es. `PASSWORD_TEMPORANEA`) |
| `proteggiPagina(ruolo)` | gate client-side di pagina | reindirizza al proprio area se il ruolo non corrisponde |
| `escapeHtml(s)` | neutralizza `< > & " '` | usato su OGNI valore renderizzato |
| `dataIt/dataOraIt` | formattazione date senza `Date` | niente sorprese di fuso orario |
| `badgeStato` | badge colorato per stato certificato | mappa chiusa + fallback |
| `toast` | notifiche non bloccanti | testo puro (`textContent`) |
| `conferma(testo, opts)` | `Promise<boolean>` su `<dialog>` | **BUG#2**: bottoni in `<form method="dialog">` + `returnValue` azzerato → ESC/Annulla = sempre `false` |
| `renderPaginazione` | controlli prev/next | mai chiamata se 1 sola pagina |
| `attivaTab` | navigazione a schede | una sola sezione visibile |

### 5.2 `public/js/login.js` + `index.html`

All'avvio: `api('/api/auth/me')` → se ok (sessione attiva) redirect per ruolo;
il 401 atteso viene **inghiottito** (guardia anti-loop). Sul submit: `POST
/api/auth/login`, al successo redirect `/admin` o `/dipendente`; al fallimento
messaggio nell'alert inline e riabilitazione del bottone.

### 5.3 `public/js/dipendente.js`

- `init()`: `proteggiPagina('DIPENDENTE')` → decorazione topbar/profilo →
  banner password provvisoria → caricamento dati → binding form.
- Upload: pre-controlli client (estensione, 5 MB con feedback sull'hint) →
  `FormData` con i 3 campi + file → `POST /api/certificati` → gestione del
  codice `PASSWORD_TEMPORANEA` (mostra banner) → ricaricamento elenco.
- `renderTabella`: righe costruite con `escapeHtml` su ogni cella; azioni
  *Visualizza* (`?modo=visualizza`, tab `_blank`) e *Scarica*.

### 5.4 `public/js/admin.js`

- Caricamenti iniziali in **parallelo** (`Promise.all`): stats, utenti,
  certificati, opzioni filtro.
- Ricerche con `debounce` (350 ms) sul testo; filtri combinabili sui
  certificati; `azzeraFiltri`.
- **Event delegation** sui `<tbody>`: un listener per tabella gestisce le righe
  renderizzate dinamicamente (`closest('button[data-azione]')`).
- Flussi con dialog: creazione utente → dialog credenziale con la provvisoria
  (unica occasione, `addEventListener` CSP-compatibile); reset password;
  rifiuto con motivazione; eliminazioni con `conferma()`.
- Ogni operazione di successo: toast + ricaricamento di tabella e statistiche.
- `errorePasswordProvvisoria(err)`: riconosce il codice 403 dedicato e mostra
  il banner invece di un errore generico.

### 5.5 Pagine HTML

Struttura comune: `topbar` (identità + logout) → banner condizionale → `tabs` →
`section.sezione` (una per tab). I `<dialog>` nativi sostituiscono i popup:
`showModal()` è modale e accessibile da tastiera. Nessuno script inline (CSP).
`admin.html` contiene 3 dialog statici (nuovo dipendente, reset password,
rifiuta) più quelli creati da codice (conferma, credenziale).

---

## 6. Sequenze operative complete

### 6.1 Login (con i tre esiti)
```
utente → index.html → login.js → POST /api/auth/login {matricola, password}
  ├─ 200: Set-Cookie token (httpOnly) {utente:{ruolo}} → redirect per ruolo
  ├─ 401: messaggio generico (rate-limit dopo 5 errori → 429)
  └─ 403: account disabilitato
```

### 6.2 Upload di un certificato (end-to-end)
```
dipendente → form → FormData → POST /api/certificati
  → autenticazione → password ok? → Multer (estensione/MIME/5MB → disco
     uploads/certificati/qa001/{ts}-{rand}_nome.pdf, cartella auto-creata)
  → campi validi? → magic bytes %PDF-?
  → INSERT certificati (stato IN_ATTESA, percorso relativo)
  ← 201 → UI: toast + tabella aggiornata
   (qualsiasi fallimento intermedio → unlink del file: nessun orfano)
```

### 6.3 Verifica amministratore
```
admin → vista globale (filtri) → ✔ approva | ✖ rifiuta (nota) | 🗑 elimina
  PUT /api/admin/certificati/:id/stato → UPDATE + audit (approvato_da/il)
  DELETE /api/admin/certificati/:id   → DELETE riga + unlink PDF
  → il dipendente vede lo stato e la nota al proprio prossimo accesso
```

### 6.4 Reset password da parte dell'admin
```
admin → 🔑 → PUT /api/admin/utenti/:id/password {nuovaPassword?}
  → bcrypt hash + must_change_password=1 → 200 {passwordProvvisoria}
  → dialog "comunica al dipendente" (mostrata una sola volta)
  → al primo accesso: banner + scritture bloccate finché non la cambia
```

---

## 7. Mappa delle scelte di sicurezza (riepilogo per rischio)

| Rischio | Contromisura | Dove |
|---|---|---|
| Password rubate dal DB | bcrypt costo 10, mai chiaro/loggata | auth.routes, admin.routes |
| Indovinare credenziali | rate limit 5/15' + messaggi generici | auth.routes |
| Sessione trafugata (XSS) | cookie httpOnly + SameSite=Lax + CSP `script-src 'self'` + `escapeHtml` ovunque | app.js, common.js |
| Sessione perpetua dopo logout | revoca per `jti` | utils/sessioni, middleware/auth |
| Account sospeso ancora attivo | rilettura utente dal DB a ogni richiesta | middleware/auth |
| Password provvisorie permanenti | blocco scritture `PASSWORD_TEMPORANEA` | middleware/auth + router |
| Privilegi eccessivi | `autenticazione → soloAdmin` a livello router + controllo proprietà sul download | admin.routes, certificati.routes |
| SQL injection | query 100% parametriche + utente DB a privilegi minimi | ovunque + schema.sql |
| Path traversal | matricola sanificata, rifiuto `..`, `resolve`+`startsWith` | utils/file |
| File mascherati da PDF | estensione + MIME + magic bytes `%PDF-`, cleanup su errore | certificati.routes, utils/file |
| Sovrascrittura file (race) | nome `{timestamp}-{random8}` | utils/file |
| Cartella utente persa (race/fs) | creazione immediata + self-healing upload + rmdir sicuro | admin.routes, utils/file |
| Upload oversize / flood | Multer 5 MB / 1 file + `express.json` limitato | certificati.routes, app.js |
| Formula injection in Excel | apice sui prefissi `= + - @` nel CSV | admin.routes |
| Clickjacking / sniffing | X-Frame-Options, nosniff, Referrer-Policy | app.js |
| Cache di risposte riservate | `Cache-Control: no-store` su `/api/*` | app.js |

## 8. Come eseguire e verificare

```bash
npm start      # avvio (richiede MySQL attivo e .env configurato)
npm run dev    # sviluppo con reload automatico
npm test       # 70 test: prepara DB di test dedicato e li esegue in sequenza
```

La suite (`tests/`) copre autenticazione/sessione, profilo, CRUD utenti,
file/cartelle, permessi e frontend (unit reali di `common.js` in sandbox VM),
ed è il riferimento più aggiornato sul comportamento atteso del sistema.

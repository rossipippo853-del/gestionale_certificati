# Dominio interno `http://portale.certificati` — Guida operativa (v2.2.9)

Obiettivo: i dipendenti del Comune raggiungono il portale digitando
`http://portale.certificati` (o `http://certificati.comune.milazzo.it`)
invece di `http://IP-SERVER:3000`. L'applicazione Node resta su porta 3000;
NGINX fa da reverse proxy sulla 80.

---

## 1. Avvio dell'applicazione (PC server)

```bash
cd /percorso/gestione-certificati-comune
npm start          # oppure: node src/server.js   (app su 127.0.0.1:3000)
```

Per tenerla attiva come servizio suggerito (opzionale) `pm2`:

```bash
sudo npm i -g pm2
pm2 start src/server.js --name portale-certificati
pm2 save && pm2 startup
```

## 2. Installazione e configurazione NGINX

```bash
sudo apt update && sudo apt install -y nginx
sudo cp deploy/nginx.conf /etc/nginx/sites-available/portale-certificati
sudo ln -s /etc/nginx/sites-available/portale-certificati /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default      # opzionale
sudo nginx -t && sudo systemctl reload nginx
```

Da questo momento `http://IP-DEL-SERVER/` (porta 80) risponde con il portale.

## 3. Scelta A — DNS interno (server DNS aziendale, consigliata)

Sul server DNS della rete comunale (es. Windows Server DNS, BIND, dnsmasq)
aggiungere un record **A**:

| Record | Tipo | Valore |
|---|---|---|
| `portale.certificati` | A | `192.168.x.x` (IP interno PC server) |
| `certificati.comune.milazzo.it` | A | `192.168.x.x` (IP interno PC server) |

- **Windows Server DNS**: DNS Manager → zona inoltrata della rete → Nuovo host (A) →
  nome `portale.certificati`, IP del server.
- **dnsmasq** (`/etc/dnsmasq.conf`):
  `address=/portale.certificati/192.168.x.x`
  poi `sudo systemctl restart dnsmasq`.
- **BIND** (file di zona): `portale  IN  A  192.168.x.x` → `rndc reload`.

Verifica da un client: `nslookup portale.certificati` deve restituire l'IP del server.

> Nota: se viene usato `certificati.comune.milazzo.it` come nome pubblico/risolto
> dal DNS della PA, il record va fatto aggiungere all'amministratore del DNS
> del dominio `comune.milazzo.it`. In rete interna basta il DNS aziendale.

## 4. Scelta B — file `hosts` sui client (rete senza DNS interno)

Su ogni PC client aggiungere una riga al file hosts:

- **Windows** (come amministratore): `notepad C:\Windows\System32\drivers\etc\hosts`
- **Linux/macOS**: `sudo nano /etc/hosts`

Riga da aggiungere:

```
192.168.x.x    portale.certificati
192.168.x.x    certificati.comune.milazzo.it
```

(sostituire `192.168.x.x` con l'IP reale del PC server).

## 5. Verifica finale

```bash
# dal PC server
curl -I http://portale.certificati/            # → HTTP/1.1 200 OK
# dal client (dopo DNS/hosts)
curl -I http://portale.certificati/api/salute  # → 200, JSON di stato
```

Poi dal browser: `http://portale.certificati` → pagina di login con stemma
«Città di Milazzo — Portale Formazione e Certificati».

## 6. Problemi frequenti

| Sintomo | Causa probabile | Rimedio |
|---|---|---|
| `502 Bad Gateway` | app Node non attiva sulla 3000 | avviare `npm start`, verificare `curl http://127.0.0.1:3000/api/salute` |
| Il nome non si risolve | DNS/hosts non configurato sul client | ripetere §3 o §4; `ipconfig /flushdns` su Windows |
| Upload fallisce oltre N MB | limite corpo richiesta | già impostato `client_max_body_size 25m` in §2; verificare di aver copiato il file corretto |
| Porta 80 occupata | altro servizio (es. IIS/Apache) | `sudo ss -ltnp \| grep :80`, disattivare il conflitto |

---
*Guida redatta per la release v2.2.9 — Città di Milazzo, Portale Formazione e Certificati.*

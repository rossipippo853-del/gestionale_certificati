# 💾 Codice aggiornato — Download in AZIONI + filtro Durata (v2.2.7)

> Riferimento per lo sviluppatore: tutti i frammenti sono **estratti verbatim dai file del progetto**
> (app già funzionante, testata 321/321). Il progetto usa CSS standard con variabili proprie
> (`stile.css`), non Tailwind — le classi `.btn`, `.badge`, `.campo` sono il design system esistente.

---

## 1 · Download del certificato

### Posizionamento (UX)
- **Un solo file** → icona **`⬇`** come *primo* pulsante della colonna AZIONI (prima di ✔ ✖ 🗑):
  download immediato, nome originale nel tooltip (`title`).
- **Più allegati** → pulsante **`⬇ n`**: apre la riga di dettaglio (nessuna navigazione extra),
  dove ogni documento è una riga «icona · **nome originale** · **dimensione** · **`⬇ Scarica`**».
- Il dettaglio resta apribile anche cliccando sulla riga; i pulsanti non espandono mai per sbaglio.

### HTML — colonna AZIONI e dettaglio (generati da `public/js/admin.js`, render della riga)

```javascript
      /* [v2.2.7] pulsante di download nella colonna AZIONI: scarica subito il
       * documento (file unico o allegato singolo); con più allegati apre la
       * riga di dettaglio dove sono elencati tutti con nome e dimensione. */
      const fileSingolo = (c.allegati && c.allegati.length === 1)
        ? { href: `/api/certificati/allegati/${c.allegati[0].id}/file`, nome: c.allegati[0].nome }
        : (!c.allegati || !c.allegati.length)
          ? { href: `/api/certificati/${c.id}/file`, nome: c.nome_file_originale }
          : null;
      const bottoneAzioniFile = fileSingolo
        ? `<a class="btn piccolo secondario" href="${fileSingolo.href}"
             title="Scarica ${escapeHtml(fileSingolo.nome)}" aria-label="Scarica il documento">⬇</a>`
        : `<button class="btn piccolo secondario" data-azione="dettaglio" data-id="${c.id}"
             title="${c.allegati.length} documenti: apri i dettagli per scaricarli"
             aria-label="Apri i dettagli e scarica">⬇ ${c.allegati.length}</button>`;

      /* [v2.2.7] DETTAGLIO DOCUMENTI: nome originale, dimensione e pulsante
       * di download dedicato per ogni file. */
      const documentiDettaglio = (c.allegati && c.allegati.length)
        ? c.allegati.map((a) => `<div class="riga-documento">
            <span aria-hidden="true">${iconaTipo(a.tipo)}</span>
            <span class="tronca" title="${escapeHtml(a.nome)}">${escapeHtml(a.nome)}</span>
            <span class="cella-secondaria">${dimensioneUmana(a.dimensione_file)}</span>
            <a class="btn piccolo secondario btn-scarica" href="/api/certificati/allegati/${a.id}/file"
               title="Scarica ${escapeHtml(a.nome)}">⬇ Scarica</a></div>`).join('')
        : `<div class="riga-documento"><span aria-hidden="true">📄</span>
            <span class="tronca" title="${escapeHtml(c.nome_file_originale)}">${escapeHtml(c.nome_file_originale)}</span>
            <span class="cella-secondaria">${dimensioneUmana(c.dimensione_file)}</span>
            <a class="btn piccolo secondario btn-scarica" href="/api/certificati/${c.id}/file"
               title="Scarica ${escapeHtml(c.nome_file_originale)}">⬇ Scarica</a></div>`;
```

### JS — apertura condivisa del dettaglio (`public/js/admin.js`)

```javascript
/** [v2.2.6] Apre/chiude la riga di dettaglio di una riga principale. */
function toggleDettaglio(riga) {
  const dettaglio = riga.nextElementSibling;
  if (!dettaglio || !dettaglio.classList.contains('riga-dettaglio')) return;
  const oraChiuso = dettaglio.classList.toggle('nascosto');
  riga.classList.toggle('aperta', !oraChiuso);
  riga.setAttribute('aria-expanded', oraChiuso ? 'false' : 'true');
}

/** [v2.2.6] Espansione riga (master-detail): un click sulla riga principale
 *  apre/chiude la riga di dettaglio sottostante. I click su pulsanti e link
 *  (approva/rifiuta/elimina/scarica) NON attivano l'espansione. */
function espandiDettaglio(e) {
  if (e.target.closest('button, a')) return;
  const riga = e.target.closest('tr.riga-principale');
  if (!riga) return;
  toggleDettaglio(riga);
}
```

Nel gestore dei click (`azioneCertificato`) il pulsante «⬇ n» è gestito prima delle azioni di stato:

```javascript
  /* [v2.2.7] «⬇ n» nella colonna Azioni (corso con più allegati): apre la
   * riga di dettaglio, dove ogni documento ha nome, dimensione e download. */
  if (btn.dataset.azione === 'dettaglio') {
    const riga = btn.closest('tr.riga-principale');
    if (riga) toggleDettaglio(riga);
    return;
  }
```

### Backend — la dimensione dell'allegato nel payload (serve al dettaglio)

```javascript
// src/routes/admin.routes.js (idem in certificati.routes.js)
`SELECT id, certificato_id, nome_originale, tipo_file, dimensione_file
 FROM allegati WHERE certificato_id IN (?) ORDER BY id ASC`
// mapping → { id, nome, tipo, dimensione_file }
```

---

## 2 · Filtro «Durata (h:mm)» (minimo – massimo)

### Posizionamento (UX)
- Nella barra dei filtri **subito dopo l'intervallo di date** («Conseguimento dal / al»):
  gli intervalli stanno insieme, zero peso visivo (due micro-input da 4.8rem + separatore «–»).
- Formato flessibile: **«8»** = 8 ore, **«1:30»** = un'ora e mezza (parser comune `parserDurata`).
- Valore non valido → **non filtra** e il campo si borda di rosso (`.input-nonvalido`); nessun popup.
- «Azzera» ripristina anche la durata; l'**export CSV eredita gli stessi filtri**.

### HTML — i due campi nella barra filtri (`public/admin.html`)

```html
          <!-- [v2.2.7] filtro per DURATA: min e max in formato ore o h:mm
               (es. «0:45», «8», «40»); il frontend converte in minuti. -->
          <label class="campo">
            <span>Durata (h:mm)</span>
            <div class="durata-filtri">
              <input type="text" id="ce-durata-min" inputmode="numeric"
                     placeholder="es. 0:30" aria-label="Durata minima">
              <span class="durata-sep" aria-hidden="true">–</span>
              <input type="text" id="ce-durata-max" inputmode="numeric"
                     placeholder="es. 40" aria-label="Durata massima">
            </div>
          </label>
```

### JS — conversione in minuti e binding (`public/js/admin.js`)

```javascript
/** [v2.2.7] Legge un campo durata del filtro («8», «1:30»…, vuoto = senza
 *  limite) e lo converte in MINUTI; il valore non valido non filtra e il
 *  campo resta evidenziato in rosso finché non viene corretto. */
function leggiDurataFiltro(id) {
  const el = document.getElementById(id);
  const testo = el.value.trim();
  if (testo === '') { el.classList.remove('input-nonvalido'); return ''; }
  const d = parserDurata(testo);
  if (!d) { el.classList.add('input-nonvalido'); return ''; }
  el.classList.remove('input-nonvalido');
  return String(d.ore * 60 + d.minuti);
}
```

```javascript
// dentro il gestore dei filtri (stesso gruppo di ce-q / ce-stato / …)
/* [v2.2.7] durata: testo «h» o «h:mm» → MINUTI (parser comune); un
       * valore non valido non filtra e segnala il campo in rosso. */
      filtriCert.durataMin = leggiDurataFiltro('ce-durata-min');
      filtriCert.durataMax = leggiDurataFiltro('ce-durata-max');
```

### Backend — `durataMin` / `durataMax` in minuti sulla durata TOTALE (`src/routes/admin.routes.js`)

```javascript
  /* [v2.2.7] filtro DURATA: durataMin/durataMax in MINUTI interi, sulla durata
   * totale (numero_ore * 60 + numero_minuti) così anche i corsi sotto l'ora
   * (es. 0:45 → 45) restano correttamente filtrabili. */
  for (const [chiave, operatore, etichetta] of [
    ['durataMin', '>=', 'durata minima'], ['durataMax', '<=', 'durata massima'],
  ]) {
    const v = pulisci(query[chiave]);
    if (v === '') continue;
    if (!/^\d{1,6}$/.test(v)) {
      throw new ErroreFiltro(`Filtro «${etichetta}» non valido: inserire i minuti come numero intero.`);
    }
    condizioni.push(`(c.numero_ore * 60 + c.numero_minuti) ${operatore} ?`);
    parametri.push(Number.parseInt(v, 10));
  }
```

> Filtrare su `(numero_ore * 60 + numero_minuti)` è ciò che rende utili i corsi **sotto l'ora**:
> «durataMin=45» trova anche un corso inserito come 0 ore e 45 minuti.

---

## 3 · CSS aggiunto (`public/css/stile.css`, blocco v2.2.7)

```css
/* ── [v2.2.7] Filtro durata (min–max) + documenti nel dettaglio ── */
.durata-filtri { display: flex; align-items: center; gap: .3rem; }
.durata-filtri input { width: 4.8rem; min-width: 0; }
.durata-sep { color: var(--testo-2); }
.input-nonvalido { border-color: var(--rosso); background: var(--rosso-bg); }
.elenco-documenti { display: flex; flex-direction: column; gap: .3rem; }
.riga-documento { display: flex; align-items: center; gap: .45rem; font-size: .82rem; }
.riga-documento .tronca { max-width: 30ch; }
```

---

## 4 · Variante opzionale: soglie rapide (chips)

Se in futuro volessi il «filtro rapido per soglie» al posto dei due campi, basta una riga di chip
che riempiono gli stessi input (nessun cambio backend):

```html
<div class="durata-chips">
  <button type="button" data-min="0" data-max="60">≤ 1h</button>
  <button type="button" data-min="60" data-max="480">1–8h</button>
  <button type="button" data-min="480" data-max="">8h+</button>
</div>
```
```javascript
document.querySelectorAll('.durata-chips button').forEach((b) => b.addEventListener('click', () => {
  document.getElementById('ce-durata-min').value = b.dataset.min / 60;
  document.getElementById('ce-durata-max').value = b.dataset.max ? b.dataset.max / 60 : '';
  document.getElementById('ce-durata-min').dispatchEvent(new Event('change'));
}));
```
*Non attiva in v2.2.7: la coppia min–max copre già ogni intervallo.*

# CODICE v2.3.2 — Tab «Monitoraggio» (dashboard spostata + analytics aggregate)

Estratti VERBATIM dai file del progetto. Punto 1 (sessione di scheda) era già
parte della v2.3.1: i file coinvolti sono `public/js/common.js` (token in
sessionStorage + header `Authorization: Bearer`), `public/js/login.js`
(salvataggio token dopo login e primo accesso), `src/middleware/auth.js`
(accettazione Bearer) e `src/routes/auth.routes.js` (token nel body, cookie di
sessione senza Max-Age/Expires) — nessun `localStorage` nel progetto
(verificato con grep). Il punto 2 (Tab Monitoraggio) è di questa release.

## 1. Backend — `GET /api/admin/monitoraggio` (src/routes/admin.routes.js)

```javascript
/** [v2.3.0] Soglia di formazione obbligatoria: 40 ore = 2400 minuti. */
const TARGET_FORMAZIONE_MINUTI = 40 * 60;

/** GET /monitoraggio — [v2.3.2] aggregated analytics della tab «Monitoraggio»:
 *  1) Target 40h: quante persone hanno raggiunto le 40 ore considerando TUTTI
 *     i certificati caricati (APPROVATI + IN ATTESA; i rifiuti restano fuori);
 *  2) aree tematiche: numero di certificati per area (ogni caricamento conta);
 *  3) KPI: media ore conteggiate per dipendente, totale certificati in attesa,
 *     top 3 aree più frequentate. */
router.get('/monitoraggio', async (req, res, next) => {
  try {
    /* Ore CONTEGGIATE per ogni dipendente (una sola query, LEFT JOIN: anche
     * chi non ha caricato nulla compare con 0 minuti). */
    const [righeDip] = await pool.query(
      `SELECT d.id,
              COALESCE(SUM(IF(c.stato IN ('APPROVATO', 'IN_ATTESA'),
                              c.numero_ore * 60 + c.numero_minuti, 0)), 0) AS minuti
       FROM dipendenti d
       LEFT JOIN certificati c ON c.dipendente_id = d.id
       GROUP BY d.id`
    );

    const totaleDipendenti = righeDip.length;
    const sommaMinuti = righeDip.reduce((acc, r) => acc + Number(r.minuti), 0);
    const raggiunti = righeDip.filter((r) => Number(r.minuti) >= TARGET_FORMAZIONE_MINUTI).length;
    const nonRaggiunti = totaleDipendenti - raggiunti;
    const percentuale = totaleDipendenti
      ? Math.round((raggiunti / totaleDipendenti) * 100)
      : 0;
    const mediaOreMinuti = totaleDipendenti
      ? Math.round(sommaMinuti / totaleDipendenti)
      : 0;

    /* Aree tematiche: TUTTI i certificati caricati (la scelta dell'area avviene
     * al caricamento, indipendentemente dalla decisione dell'amministratore). */
    const [aree] = await pool.query(
      `SELECT area_tematica AS area, COUNT(*) AS certificati
       FROM certificati
       GROUP BY area_tematica
       ORDER BY certificati DESC, area ASC`
    );

    const [[{ inAttesa }]] = await pool.query(
      "SELECT COUNT(*) AS inAttesa FROM certificati WHERE stato = 'IN_ATTESA'"
    );

    res.json({
      target: { totaleDipendenti, raggiunti, nonRaggiunti, percentuale },
      mediaOreMinuti,
      certificatiInAttesa: Number(inAttesa),
      aree: aree.map((a) => ({ area: a.area, certificati: Number(a.certificati) })),
      topAree: aree.slice(0, 3).map((a) => ({ area: a.area, certificati: Number(a.certificati) })),
    });
  } catch (err) { next(err); }
});
```

Contratto: `target` {totaleDipendenti, raggiunti, nonRaggiunti, percentuale}
(conteggio su ore CONTEGGIATE = approvate + in attesa, rifiuti esclusi) ·
`mediaOreMinuti` · `certificatiInAttesa` · `aree[]` (TUTTI i caricamenti,
ordinati per numero) · `topAree[]` (prime 3). RBAC admin (403 ai dipendenti).

## 2. admin.html — il nuovo menu e la nuova sezione

```html
<nav class="tabs">
      <button class="tab attiva" data-tab="utenti">👥 Dipendenti</button>
      <button class="tab" data-tab="certificati">📜 Certificati</button>
      <button class="tab" data-tab="monitoraggio">📊 Monitoraggio</button>
      <button class="tab" data-tab="profilo">👤 Profilo</button>
    </nav>
```

La card «Dashboard formazione per dipendente» è stata SPOSTATA (intatta, con
ricerca e «✕ Chiudi scheda») dentro la sezione, seguita da:

```html
<!-- ============ SEZIONE MONITORAGGIO (tab, v2.3.2) ============
         Dashboard per singolo dipendente + analytics aggregate: target 40h
         (ore conteggiate = approvate + in attesa), aree tematiche e KPI. -->
    <section id="sezione-monitoraggio" class="sezione">

<!-- [v2.3.2] Dashboard formazione per dipendente (spostata dalla schermata
             principale nella tab «Monitoraggio»): ricerca per nome/cognome/
             matricola/CF e KPI verso il target delle 40 ore obbligatorie. -->
        <div class="card card-dashboard" id="card-dashboard-dipendente" style="margin-top:1rem">
          <h2>Dashboard formazione per dipendente</h2>
          <p class="hint">Cerca un dipendente per <strong>nome, cognome, matricola o codice fiscale</strong>: la dashboard ne mostra i certificati, le ore approvate e la distanza dal target delle 40 ore.</p>
          <div class="campo combo-campo" style="margin-bottom:1rem">
            <span>Dipendente</span>
            <input type="text" id="fd-dipendente-cerca" class="combo-input"
                   placeholder="Digita nome, cognome, matricola o CF…"
                   autocomplete="off" role="combobox" aria-expanded="false"
                   aria-controls="fd-dipendente-lista" aria-autocomplete="list">
            <input type="hidden" id="fd-dipendente">
            <div id="fd-dipendente-lista" class="combo-lista nascosto" role="listbox"></div>
          </div>

          <div id="fd-dash" class="nascosto">
            <div class="fd-testata">
              <div>
                <div class="fd-nome" id="fd-nome"></div>
                <div class="fd-sotto" id="fd-sotto"></div>
              </div>
              <div class="fd-testata-destra">
                <span class="badge ambra" id="fd-stato"></span>
                <!-- [v2.3.1] chiusura scheda: nasconde i dati e azzera la ricerca -->
                <button type="button" class="btn piccolo secondario fd-chiudi" id="fd-chiudi"
                        title="Chiudi la scheda e azzera la ricerca" aria-label="Chiudi la scheda del dipendente">✕ Chiudi scheda</button>
              </div>
            </div>

            <div class="griglia-kpi">
              <div class="kpi">
                <div class="kpi-etichetta">Certificati caricati</div>
                <div class="kpi-valore" id="fd-cert-tot">0</div>
                <div class="kpi-dettaglio">
                  <span class="mini verde">✔ <b id="fd-approvati">0</b></span>
                  <span class="mini ambra">⏳ <b id="fd-attesa">0</b></span>
                  <span class="mini rosso">✖ <b id="fd-rifiutati">0</b></span>
                </div>
              </div>
              <div class="kpi">
                <div class="kpi-etichetta">Ore approvate</div>
                <div class="kpi-valore" id="fd-ore-approvate">0:00</div>
                <div class="kpi-dettaglio">convalidate dall'amministratore</div>
              </div>
              <div class="kpi">
                <div class="kpi-etichetta">Ore totali inviate</div>
                <div class="kpi-valore" id="fd-ore-inviate">0:00</div>
                <div class="kpi-dettaglio">di cui <b id="fd-ore-attesa">0:00</b> in attesa</div>
              </div>
              <div class="kpi">
                <div class="kpi-etichetta">Ore mancanti al target</div>
                <div class="kpi-valore" id="fd-mancanti">40:00</div>
                <div class="kpi-dettaglio">max(0; 40h − ore conteggiate)</div>
              </div>
            </div>

            <div class="fd-target">
              <div class="fd-target-testo"><span>Avanzamento: ore approvate + in attesa sul target delle 40 ore</span><b id="fd-percentuale">0%</b></div>
              <div class="fd-barra" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="fd-barra-riempimento" id="fd-barra" style="width:0%"></div></div>
            </div>

            <div class="fd-aree">
              <div class="fd-sezione">Ripartizione per area tematica</div>
              <div class="aree-chips" id="fd-aree"></div>
            </div>
          </div>
          <p class="hint" id="fd-vuoto">Nessun dipendente selezionato: la dashboard comparirà qui dopo la ricerca.</p>
        </div>
```

```html
<div class="griglia-monitoraggio">
        <!-- Grafico 1: ciambella del target 40 ore -->
        <div class="card" id="card-target-40">
          <h2>Target 40 ore</h2>
          <p class="hint">Dipendenti che hanno raggiunto le 40 ore di corsi totali
             (<strong>approvati + in attesa di approvazione</strong>; i rifiuti non contano).</p>
          <div class="donut-wrap">
            <svg id="donut-target" viewBox="0 0 140 140" role="img" aria-label="Grafico a ciambella: percentuale di dipendenti al target delle 40 ore">
              <circle class="donut-base" cx="70" cy="70" r="56"></circle>
              <circle class="donut-arco" id="donut-arco" cx="70" cy="70" r="56"
                      transform="rotate(-90 70 70)"></circle>
              <text class="donut-percento" id="donut-percento" x="70" y="66">0%</text>
              <text class="donut-sotto" id="donut-sotto" x="70" y="86">0 su 0</text>
            </svg>
            <div class="donut-legenda">
              <div><span class="pallino verde"></span><span><b id="tg-raggiunti">0</b> al target (≥ 40h)</span></div>
              <div><span class="pallino grigio"></span><span><b id="tg-non">0</b> sotto il target</span></div>
              <div><span class="pallino blu"></span><span><b id="tg-tot">0</b> persone totali</span></div>
            </div>
          </div>
        </div>

        <!-- Grafico 2: ripartizione dei certificati per area tematica -->
        <div class="card" id="card-aree-tematiche">
          <h2>Aree tematiche</h2>
          <p class="hint">Distribuzione dei certificati caricati per area
             (percentuale sul totale e numero assoluto).</p>
          <div id="barre-aree"></div>
        </div>
      </div>

      <!-- Pannello KPI aggiuntivi -->
      <div class="card" id="card-kpi-extra" style="margin-top:1rem">
        <h2>KPI di sintesi</h2>
        <div class="griglia-kpi">
          <div class="kpi">
            <div class="kpi-etichetta">Media ore per dipendente</div>
            <div class="kpi-valore" id="kpi-media-ore">0:00</div>
            <div class="kpi-dettaglio">ore conteggiate (approvate + in attesa)</div>
          </div>
          <div class="kpi">
            <div class="kpi-etichetta">Totale certificati in attesa</div>
            <div class="kpi-valore" id="kpi-in-attesa">0</div>
            <div class="kpi-dettaglio">in fila per l'approvazione</div>
          </div>
          <div class="kpi">
            <div class="kpi-etichetta">Top 3 aree tematiche</div>
            <ol class="top-aree" id="kpi-top-aree"></ol>
          </div>
        </div>
      </div>
    </section>
```

## 3. admin.js — rendering e wiring

```javascript
/* ---------- [v2.3.2] Tab «Monitoraggio»: analytics aggregate ---------- */

/** Disegna la ciambella del target 40h (SVG con stroke-dasharray). */
function renderDonutTarget(t) {
  const raggio = 56;
  const circonferenza = 2 * Math.PI * raggio;
  const arco = document.getElementById('donut-arco');
  arco.setAttribute('stroke-dasharray', `${(circonferenza * t.percentuale) / 100} ${circonferenza}`);

  document.getElementById('donut-percento').textContent = `${t.percentuale}%`;
  document.getElementById('donut-sotto').textContent = `${t.raggiunti} su ${t.totaleDipendenti}`;
  document.getElementById('tg-raggiunti').textContent = t.raggiunti;
  document.getElementById('tg-non').textContent = t.nonRaggiunti;
  document.getElementById('tg-tot').textContent = t.totaleDipendenti;
}

/** Disegna le barre percentuali per area tematica (tutti i caricamenti). */
function renderBarreAree(aree) {
  const contenitore = document.getElementById('barre-aree');
  const totale = aree.reduce((somma, a) => somma + a.certificati, 0);
  contenitore.innerHTML = aree.length
    ? aree.map((a) => {
        const pct = totale ? Math.round((a.certificati / totale) * 100) : 0;
        return `<div class="area-riga">
          <div class="area-testo"><span title="${escapeHtml(a.area)}">${escapeHtml(a.area)}</span>
            <span class="cella-secondaria">${a.certificati} ${a.certificati === 1 ? 'certificato' : 'certificati'} · ${pct}%</span></div>
          <div class="area-traccia"><div class="area-riempimento" style="width:${pct}%"></div></div>
        </div>`;
      }).join('')
    : '<p class="hint">Nessun certificato caricato: la distribuzione comparirà al primo caricamento.</p>';
}

/** Pannello KPI: media ore, certificati in attesa, top 3 aree. */
function renderKpiExtra(d) {
  document.getElementById('kpi-media-ore').textContent = minutiInHhMm(d.mediaOreMinuti);
  document.getElementById('kpi-in-attesa').textContent = d.certificatiInAttesa;
  const top = document.getElementById('kpi-top-aree');
  top.innerHTML = d.topAree.length
    ? d.topAree.map((a, i) =>
        `<li><span class="posizione">${i + 1}.</span> ${escapeHtml(a.area)} <span class="cella-secondaria">(${a.certificati})</span></li>`).join('')
    : '<li class="cella-secondaria">Nessun dato disponibile</li>';
}

/** Aggiorna l'intera tab Monitoraggio (chiamata all'avvio e all'apertura). */
async function caricaMonitoraggio() {
  try {
    const d = await api('/api/admin/monitoraggio');
    renderDonutTarget(d.target);
    renderBarreAree(d.aree);
    renderKpiExtra(d);
  } catch (err) { toast(`Monitoraggio non disponibile: ${err.message}`, 'errore'); }
}
```

Caricamento iniziale + refresh a ogni apertura della tab:

```javascript
await Promise.all([caricaStatistiche(), caricaDipendenti(), caricaCertificati(), caricaOpzioniDipendenti(), caricaMonitoraggio()]);

```

## 4. stile.css — blocco v2.3.2

```css
/* ═══════════ [v2.3.2] TAB «MONITORAGGIO» ═══════════ */

.griglia-monitoraggio {
  display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 1rem; margin-top: 1rem;
}

/* Ciambella target 40h */
.donut-wrap {
  display: flex; align-items: center; gap: 1.2rem; flex-wrap: wrap;
  margin-top: .6rem;
}
.donut-wrap svg { width: 168px; height: 168px; flex: 0 0 auto; }
.donut-base  { fill: none; stroke: #e6ecf5; stroke-width: 16; }
.donut-arco  {
  fill: none; stroke: var(--blu); stroke-width: 16; stroke-linecap: round;
  transition: stroke-dasharray .5s ease;
}
.donut-percento {
  font-size: 26px; font-weight: 800; fill: var(--blu-scuro);
  text-anchor: middle;
}
.donut-sotto { font-size: 11px; fill: var(--testo-2); text-anchor: middle; }
.donut-legenda { display: grid; gap: .35rem; font-size: .82rem; }
.donut-legenda div { display: flex; align-items: center; gap: .45rem; }
.pallino {
  width: 11px; height: 11px; border-radius: 50%; display: inline-block;
  flex: 0 0 auto;
}
.pallino.verde  { background: var(--verde); }
.pallino.grigio { background: #c7cfd9; }
.pallino.blu    { background: var(--blu); }

/* Barre aree tematiche (grafico 2) */
.area-riga { margin: .5rem 0; }
.area-testo {
  display: flex; justify-content: space-between; gap: 1rem;
  font-size: .8rem; margin-bottom: .15rem;
}
.area-testo span:first-child { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.area-traccia {
  height: 12px; background: #eef2f7; border-radius: 999px; overflow: hidden;
  box-shadow: inset 0 1px 3px rgba(15, 23, 42, .08);
}
.area-riempimento {
  height: 100%; border-radius: 999px; transition: width .4s ease;
  background: linear-gradient(90deg, var(--oro) 0%, #2a7fc9 55%, var(--blu-scuro) 100%);
}

/* KPI: top 3 aree (lista dentro la scheda scura) */
.top-aree { margin: .3rem 0 0; padding-left: 1.1rem; font-size: .78rem; }
.top-aree li { margin: .2rem 0; line-height: 1.25; }
.top-aree .posizione { font-weight: 800; color: #ffd98a; }
```

---

*Città di Milazzo — Portale Formazione e Certificati · release 2.3.2 ·
suite di collaudo 380/380 PASS (144 `node --test` + 236 Jest, 15 suite).*

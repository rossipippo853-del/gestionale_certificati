# Opzione B — Redirect Vercel: guida passo-passo + prova a casa (v2.2.9)

Scopo: i dipendenti digitano un **nome** (es. `https://portale-milazzo.vercel.app`)
e finiscono sul portale che resta **interno**, senza toccare i PC e senza
passare dall'IT. Questa guida include **come provarlo TUTTO da casa** con il
portale installato sul tuo PC personale.

---

## Come funziona (4 salti, da memorizzare)

```
1. Il dipendente digita   https://portale-milazzo.vercel.app
2. Il nome viene risolto dal DNS PUBBLICO di Internet  →  server Vercel
3. Vercel risponde con una sola istruzione: «vai a http://IP-DEL-SERVER»
4. Il browser si collega al PC server  →  pagina di login del portale
```

Su Vercel **non transita nessun dato**: è solo il cartello. I certificati
restano sul disco del server. ⚠️ Di conseguenza: **su Vercel carichi SOLO la
cartella `deploy/reindirizzamento-vercel/`** (3 file), MAI il progetto del
portale.

---

## PARTE 1 — Preparazione (a casa, sul tuo PC)

### 1.1 Portale attivo in locale

```bash
cd cartella-portale
npm install        # solo la prima volta
npm start          # → «Server avviato su http://0.0.0.0:3000»
```

Verifica: apri `http://localhost:3000` nel browser → compare il login
«Città di Milazzo». (Se il portale a casa ti funziona già, salta.)

### 1.2 Trova l'IP del tuo PC nella rete di casa

| Sistema | Comando | Cosa cercare |
|---|---|---|
| **Windows** | `Win+R` → `cmd` → `ipconfig` | «Indirizzo IPv4» della Wi-Fi/Ethernet (es. `192.168.1.70`) |
| **macOS** | Icona Wi-Fi nel menu → «Impostazioni Wi-Fi…» → «Dettagli…» | «Indirizzo IP» |
| **Linux** | `ip addr` | `inet 192.168.x.x` |

⚠️ NON usare `localhost` o `127.0.0.1` nella destinazione: sul telefono di un
altro dispositivo quel nome indicherebbe il telefono stesso. Serve l'**IP di
rete** (192.168.x.x).

### 1.3 Test 0 — il portale è raggiungibile da un altro dispositivo? (consigliato)

Prima di pubblicare qualsiasi cosa, dal **telefono collegato alla STESSA Wi-Fi di
casa**, apri: `http://192.168.1.70:3000` (il TUO IP).
- ✅ Compare il login → perfetto, prosegui.
- ❌ Non carica → è il **firewall**: vedi §5 (risoluzione) e riprova.

Questo test isola i problemi: se il Test 0 funziona, il redirect Vercel
funzionerà di conseguenza.

### 1.4 Adatta i 2 file del redirect

Nella cartella `deploy/reindirizzamento-vercel/` del progetto, sostituisci
l'IP di esempio con il tuo IP **e aggiungi `:3000`** (a casa NON hai NGINX,
quindi il portale resta sulla sua porta; a lavoro, dopo NGINX, si toglie).

**`vercel.json`** (prima → dopo):
```json
"destination": "http://192.168.1.50/"
```
```json
"destination": "http://192.168.1.70:3000/"
```

**`index.html`** (due punti da correggere, stessa identica modifica):
```html
<meta http-equiv="refresh" content="0; url=http://192.168.1.70:3000/">
...
<a href="http://192.168.1.70:3000/">clicca qui per accedere al portale</a>
```

---

## PARTE 2 — Pubblicare su Vercel (account gratuito)

### Via A — dal browser, senza riga di comando (consigliata)

1. Vai su **vercel.com** → **Sign Up** → registrati con la tua email
   (piano **Hobby**, gratuito; conferma l'email).
2. Una volta dentro: **Add New… → Project**.
3. Se chiede di collegare un repository: scegli **«Skip» / deploy senza Git**.
4. Trascina la **cartella** `reindirizzamento-vercel` (con dentro i 3 file
   modificati) nella zona di upload.
5. Nel campo del nome progetto scrivi es. `portale-milazzo`
   (diventerà il nome che digiteranno i dipendenti).
6. **Deploy** → dopo ~30 secondi lo stato diventa **«Ready»**.
7. Nella pagina del progetto copia il **dominio**: `https://portale-milazzo.vercel.app`
   (se il nome è occupato, Vercel ne propone uno simile: va bene lo stesso).

### Via B — dal terminale (alternativa)

```bash
npm install -g vercel
vercel login                       # confermi con l'email
cd deploy/reindirizzamento-vercel
vercel --prod                      # rispondi ai prompt, nome: portale-milazzo
```

> Se al momento del deploy Vercel segnalasse un errore sul campo
> `destination` (per via della porta `:3000`): elimina `vercel.json` dalla
> cartella e ri-pubblica — resta `index.html`, che fa lo stesso redirect con
> il meta-refresh e supporta qualsiasi porta.

---

## PARTE 3 — Testare da casa

### Test 1 — dal tuo PC (il più rapido)

Apri `https://portale-milazzo.vercel.app` nel browser.
Dopo 1–2 secondi deve comparire la **pagina di login del portale**.
In barra indirizzi vedrai `http://192.168.1.70:3000`: è **normale** — il
cartello ha fatto il suo lavoro e ti ha "passato la mano" al portale.

### Test 2 — dal telefono (simula il PC di un collega)

Dal telefono, sempre sulla Wi-Fi di casa, apri lo stesso indirizzo
`https://portale-milazzo.vercel.app` → login del portale → fai anche un login
vero (matricola demo) per sicurezza.

**Se Test 1 e Test 2 funzionano, la soluzione è dimostrata**: lunedì sarà la
stessa identica cosa, cambiando solo l'IP di destinazione (quello del server
dell'ufficio). Il meccanismo Vercel→redirect→portale non cambia.

---

## PARTE 4 — Checklist per lunedì a lavoro

| # | Azione | Nota |
|---|---|---|
| 1 | Installa NGINX sul PC server (guida `GUIDA-NGINX-SEMPLICE`, PASSO 1) | il portale risponde su porta 80, senza `:3000` |
| 2 | Nei 2 file: metti l'IP **del server** e **togli** `:3000` | `http://192.168.x.x/` |
| 3 | Ri-pubblica su Vercel (ridistribuendo la cartella o `vercel --prod`) | stesso nome progetto = stesso indirizzo |
| 4 | Prova da un PC dell'ufficio: `https://portale-milazzo.vercel.app` | se il proxy aziendale blocca `vercel.app` (raro), resta l'Opzione A: link + segnalibio + QR |
| 5 | (consigliato) mail circolare con il link | anche solo come segnalibio, indipendentemente da Vercel |

---

## PARTE 5 — Problemi frequenti (a casa)

| Sintomo | Causa | Rimedio |
|---|---|---|
| Il telefono non apre `http://IP:3000` (Test 0 fallito) | Firewall di Windows blocca Node in rete privata | Vedi sotto «Consentire Node nel firewall» |
| Test 0 ok da PC ma non dal telefono | Router con «isolamento client/AP» attivo (reti ospiti!) | Usa la rete Wi-Fi principale, non quella ospiti |
| `vercel.app` non si apre | Deploy non completato | Dashboard Vercel → il progetto deve risultare «Ready»; controlla l'URL esatto |
| Pagina bianca, nessun redirect | `vercel.json` rifiutato | Elimina `vercel.json`, ri-pubblica (resta il meta-refresh) |
| Dopo il click: «sito non raggiungibile» ma `http://IP:3000` funziona | IP/porta sbagliati nei 2 file | Correggi `vercel.json` e `index.html`, ri-pubblica |
| Ieri funzionava, oggi no | Il router ha cambiato l'IP del PC (IP dinamico) | Per la prova breve: ripeti §1.2, aggiorna i file, ri-pubblica. Per fissarlo: assegna un IP fisso al PC (o «reservation» sul router) |
| Pagina «La connessione non è privata» sull'indirizzo finale | Normale: il portale interno è http (non https) | Prosegui; è una rete interna, comportamento atteso |

**Consentire Node nel firewall (Windows)**: Pannello di controllo →
«Consenti un'app tramite Windows Defender Firewall» → trova **Node.js** →
spunta sulle colonne **Privata** (e Pubblica se serve) → OK.
Se Node non è in elenco: «Cambia impostazioni → Consenti un'altra app» e
indica il file `node.exe`. (Alla prima partenza Windows di solito chiede da
sé «Consenti accesso»: basta cliccare Consenti sulle reti private.)

---

## Promemoria privacy

- Su Vercel: 3 file di testo, zero dati del portale.
- Il portale (con anagrafiche e certificati) resta sul PC server interno.
- Se un domani l'IT acconsentisse, il record DNS interno resta la soluzione
  «definitiva» e potrai dismettere il redirect.

---

*Guida v2.2.9 — file da pubblicare: `deploy/reindirizzamento-vercel/`;
altre opzioni in `docs/COME-ACCEDERE-SENZA-DNS-v2.2.9.md`.*

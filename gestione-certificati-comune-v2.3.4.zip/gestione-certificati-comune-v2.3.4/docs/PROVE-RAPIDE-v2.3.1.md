# Prove rapide v2.3.1 — sessione di scheda, ore conteggiate, matricola

Piano di verifica MANUALE (5 minuti) per controllare con i propri occhi le
novità della v2.3.1, da fare dopo l'avvio del portale (`npm start`,
`http://localhost:3000`).

---

## 1. Chiusura della sessione alla chiusura della scheda

> **Aggiornato alla v2.3.3 (modalità rigida)**: il cookie httpOnly viene
> accettato SOLO sui download diretti (Scarica/Visualizza/Export). Per ogni
> altra richiesta conta SOLO il token di scheda in `sessionStorage`.

| # | Passaggio | Risultato atteso |
|---|---|---|
| 1 | Apri `http://localhost:3000` → accedi (es. `admin` / `Admin@2026`) | entri nell'area admin |
| 2 | Chiudi la **scheda** del browser (Ctrl+W) | — |
| 3 | Riapri una nuova scheda e vai su `http://localhost:3000` | **pagina di LOGIN**: nessun accesso automatico (il cookie sopravvissuto NON è più accettato) |
| 4 | Chiudi l'**intero browser**, riaprilo e torna su `http://localhost:3000` | di nuovo la pagina di LOGIN |
| 5 | Entra e ricarica la pagina (F5) o cambi tab interne | resta autenticato (stessa scheda: il sessionStorage vive) |
| 6 | Da una scheda aperta: «⬇ Scarica» un certificato o «Esporta Anagrafica CSV» | download funzionanti (unico caso in cui il cookie è ancora valido) |

**Verifica tecnica (DevTools → Rete)**: dopo la chiusura e riapertura della
scheda, la richiesta a `/api/auth/me` risponde **401** → la pagina di login
resta sul login.

⚠️ Unica eccezione nota (comportamento del browser, non del portale): se
Chrome/Edge è impostato su «Continua da dove eri», al riavvio può ripristinare
anche `sessionStorage`. È un'impostazione del client, non un difetto del
portale.

**Verifica tecnica (DevTools → Application/Archiviazione):**
- `sessionStorage` → deve comparire `token_portale` dopo il login, SPARIRE dopo la chiusura della scheda;
- `Cookie → localhost` → `token` senza colonna «Scadenza» (cookie di sessione).

## 2. Matricola a 2 cifre

| # | Passaggio | Risultato atteso |
|---|---|---|
| 1 | Entra come admin → Dipendenti → «Nuovo dipendente» | — |
| 2 | Matricola `12`, compila nome/cognome/CF/sesso/qualifica → Salva | ✅ creazione riuscita (nessun errore «3-20») |
| 3 | Riprova con matricola `x` (1 carattere) | ❌ errore «2-20 caratteri alfanumerici» |
| 4 | Esci e accedi con `12` + la password provvisoria mostrata | login OK → cambio password obbligatorio |
| 5 | (opzionale) «Importa da CSV» con una riga `12;CF…;…` | importazione accettata |

*(Nel DB demo dello sviluppo la matricola `12` è già stata usata per la prova:
se il campo segnala «già esistente», rimuoverla prima da Dipendenti.)*

## 3. Dashboard formazione: «✕ Chiudi scheda» e ore conteggiate

| # | Passaggio | Risultato atteso |
|---|---|---|
| 1 | Admin → Dashboard → cerca un dipendente (es. il suo nome) | compaiono le schede KPI scure |
| 2 | Premi «✕ Chiudi scheda» (in alto a destra) | i KPI scompaiono, la ricerca si svuota, messaggio iniziale |
| 3 | Ricarica un dipendente con un corso IN ATTESA (non ancora approvato) | «Ore totali inviate» ≥ «Ore approvate»; «di cui … in attesa» > 0:00; la barra AVANZA anche con le ore in attesa |
| 4 | Dalla tabella Certificati RIFIUTA quel corso in attesa (con nota) | riaprendo la scheda: le ore scendono, le «mancanti» salgono, la barra si riduce |
| 5 | Nelle chip «Ripartizione per area» | le aree con corsi in attesa mostrano «(⏳ h:mm in attesa)» |

Formule (v2.3.1): `Ore conteggiate = approvate + in attesa` ·
`Mancanti = max(0; 40h − conteggiate)` · rifiuti SEMPRE esclusi.

---

*Prove rapide (aggiornate alla v2.3.3) — suite automatica: 385/385 PASS (v. QA-REPORT.md).*

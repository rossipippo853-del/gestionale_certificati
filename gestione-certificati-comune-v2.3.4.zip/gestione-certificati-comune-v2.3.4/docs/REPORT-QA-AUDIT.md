# 🧪 REPORT QA AUDIT — Gestione Certificati Comunale v2.1.1

> Auditoria di secondo livello (Principal QA): analisi dei **gap** rispetto alla
> suite di collaudo esistente (216 test), progettazione di test mirati su moduli,
> confini, concorrenza e sicurezza, esecuzione completa e **correzioni apportate**.

---

## 1. Metodo e perimetro

| Fase | Attività |
|---|---|
| 1. Gap analysis | Lettura di `src/utils/*`, `src/routes/*`, `src/middleware/*` e mappatura dei 216 test esistenti: i moduli puri erano coperti solo in modo **transitivo** (via API) |
| 2. Progettazione | 5 aree: unit puri · integrazione · edge/race · sicurezza · confini di campo |
| 3. Esecuzione | `npm test` (regressione `node --test` + collaudo/audit Jest) — ambiente isolato (`certificati_comune_test`, `uploads-test/`, `uploads-qa/`) |
| 4. Correzioni | Ogni difetto emerso è stato corretto nell'app e blindato dal relativo test |

## 2. Nuove suite (53 test)

### `tests/audit-unit.test.js` — 29 unit test puri (runner nativo `node --test`)

| Modulo | Cosa verifica (esempi) |
|---|---|
| `validazione.validaNuovaPassword` | confini 7/8/72/73, solo lettere/solo cifre, lettere non ASCII, input non stringa (null, 42, {}, array) |
| `validazione.RE_CODICE_FISCALE` | 4 CF validi; 10 rifiuti: minuscolo, 15/17 char, omocodie (O per 0), spazi, cifre al posto delle lettere |
| `validazione.pulisci` | trim, parametri ripetuti (array), numeri/oggetti/booleani → `''` |
| `validazione.validaDatiCertificato` | ore (0, 1, 9999, 10000, 12.5, abc, -3, '0008', '  5  '), esame booleano permissivo ma chiuso, area a elenco chiuso (case-sensitive), nome 3/200, ente 2/150, **date**: formato non ISO, 2026-02-30, futuro, oggi, 29/02 bisestile |
| `validazione.validaDatiDipendente` | normalizzazioni (CF maiuscolo, sesso, ruolo predefinito) + confini di tutti i 9 campi |
| `sessioni` | roundtrip revoca, jti assenti, scadenze, **auto-pulizia a soglia 10.000** (anti memory-leak) |
| `file.ePdf` / `nomeFileUnivoco` / `percorsoAssoluto` / `cartellaDipendente` | magic bytes (6 casi), univocità nello stesso ms, sanificazione emoji/SQL/traversal, **anti path traversal totale** (6 tentativi di fuga rifiutati) |
| `importazione.parseCsv/analizzaCsv` | BOM Excel, CRLF/CR/LF, virgolette con `;` e `""` interne, rilevamento separatore (;/,/tab), file vuoto, header-only, colonne mancanti, errori di riga, duplicati nel file, tetto 2.000 righe |

### `tests-audit/audit-integrazione-sicurezza.test.js` — 24 test (Jest + Supertest su app reale)

| Gruppo | Cosa verifica (esempi) |
|---|---|
| A · HTTP | JSON malformato → 400 JSON (mai HTML/crash); metodo errato → 404 JSON; body senza Content-Type → 400 |
| B · Token/cookie | cookie `HttpOnly`+`SameSite=Lax` e **mai token nel body**; payload JWT manomesso → 401; token `alg:none` → 401; token_cambio scaduto → 401; account disabilitato tra login e cambio → 401 |
| C · **Race condition** | 2 POST `/utenti` paralleli stessa matricola → {201,409} e **zero cartelle orfane**; 3 upload paralleli → 3 file distinti; **doppio consumo parallelo del cookie di primo accesso → un solo 200** |
| D · Upload | PDF di **esattamente 5 MB → 201**; 5 MB+2 KB → 400 senza orfani; 0 byte → 400; PDF+1 MB di spazzatura → 201; MIME falso → 400; doppia estensione → 400; nomi ostili (`../../`, emoji, `'; DROP TABLE`) → sanificati, percorsi DB senza `..` |
| E · Campi v1.4 via API | ore 0/1/9999/10000/12.5/abc/-3; date futura/inesistente/non ISO/mese 13/oggi; confini esatti nome corso ed ente |
| F · Paginazione/ricerca/CF | `perPagina` 1→5 e 100000→100, `pagina` -5/abc→1; ricerche XSS/SQL/metacaratteri → 200 con 0 risultati; **CF minuscolo → normalizzato a DB e cartella maiuscola**, duplicato intercettato |

## 3. Difetti trovati e CORRETTI (tutti ora blindati dai test)

| ID | Gravità | Difetto | Correzione |
|---|---|---|---|
| **C3** | 🔴 Alta | Il cookie monouso di primo accesso poteva essere **consumato due volte in parallelo** ([200,200]): finestra di gara tra verifica e revoca attraverso gli `await` (bcrypt/query); la password finale poteva risultare quella dell'altro tab | `auth.routes.js`: prenotazione **sincrona** dei jti (`CAMBI_IN_CORSO`, atomica sull'event-loop) con rilascio su errore di validazione; test C3 ora impone {200,401} |
| **F3** | 🟠 Media | Le date inesistenti nel calendario (`2026-02-30`) superavano la validazione: V8 le arrotola al mese successivo e MySQL le respingeva a valle (rischio 500) | `validazione.js`: verifica del calendario reale per componenti (anno/mese/giorno round-trip) |
| **F2** | 🟡 Bassa | Race su POST `/utenti` con la stessa matricola: la cartella CF del "perdente" restava **orfana** sul disco | `admin.routes.js`: rimozione della cartella del perdente **solo se vuota** (mai un documento esistente) |
| **F1** | ⚪ Difensiva | `cartellaDipendente('')` avrebbe restituito la radice dei certificati | `file.js`: chiave vuota → errore esplicito (i chiamanti passano sempre un CF validato) |

## 4. Esito finale

```
node --test tests/          → 107/107 PASS (78 regressione + 29 unit audit)
jest (9 suite)              → 162/162 PASS (138 collaudo + 24 audit)
TOTALE                      → 269/269 PASS
```

Comandi: `npm test` (tutto) · `node --test tests/audit-unit.test.js` (solo unit) ·
`npx jest tests-audit` (solo audit di integrazione).

## 5. Raccomandazioni successive (non bloccanti)

1. **Rate-limit su `/api/auth/primo-accesso`**: il cookie è firmato e monouso, ma un
   contatore per-matricola come quello del login aggiungerebbe profondità difensiva.
2. **Registro revoche in memoria**: per deploy multi-istanza future, spostarlo su
   Redis/tabella (già previsto in `utils/sessioni.js`).
3. **Header `Content-Security-Policy` con nonce** se in futuro si aggiungeranno
   script di terze parti (oggi `script-src 'self'` è pienamente sufficiente).

# CODICE v2.2.9 — «Città di Milazzo»: sessione, brand, admin UX, DevOps

Documento tecnico della release 2.2.9 del **Portale Formazione e Certificati —
Città di Milazzo** (~300 dipendenti, 6 aree). Tutti gli estratti sono ripresi
VERBATIM dai file del progetto. File NUOVI di questa release:
`deploy/nginx.conf`, `docs/GUIDA-DOMINIO-LOCALE-v2.2.9.md`,
`db/migrazione-v2.2.9.sql`, `tests-qa/09-v229-sessione-modifiche.test.js`.

## Indice
1. Cookie di sessione (auth.routes.js) — requisito 2
2. Backend admin: audit, modifica certificati, export CSV, orePerArea — req. 4·5
3. 18ª area «Procedimenti amministrativi» (validazione.js) — requisito 1①
4. admin.html: brand, combobox, impaginazione, dialoghi — req. 1③④·3·5
5. admin.js: autocompletamento, modifica, storico, grafico
6. dipendente: bottone «💾 Salva» — requisito 1②
7. index.html — login brandizzato
8. stile.css — palette Milazzo + nuovi componenti
9. Migrazione DB v2.2.9
10. NGINX e dominio locale — requisito 4

---

## 1. Cookie di sessione — `src/routes/auth.routes.js`

Il cookie di accesso NON ha più scadenza: è un cookie di SESSIONE (RFC 6265).
Chiuso il browser → token perso → re-login obbligatorio. Il JWT interno
conserva la propria scadenza di sicurezza (8h, revocabile via jti).

```javascript
function impostaCookieSessione(res, token) {
  res.cookie('token', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.cookieSecure,
    path: '/',
    // niente maxAge / expires: cookie di sessione
  });
}

```

Il cookie del primo accesso resta invece persistente per 15 minuti:

```javascript
function impostaCookieCambio(res, token) {
  res.cookie('token_cambio', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.cookieSecure,
    maxAge: 15 * 60 * 1000,
    path: '/',
  });
}
```

---

## 2. Backend admin — `src/routes/admin.routes.js`

### 2.1 Helper `scriviAudit` (mai blocca il flusso: catch + log)

```javascript
async function scriviAudit(adminId, azione, certificatoId, dettagli) {
  try {
    await pool.query(
      'INSERT INTO audit_log (admin_id, azione, certificato_id, dettagli) VALUES (?, ?, ?, ?)',
      [adminId, azione, certificatoId, dettagli ? String(dettagli).slice(0, 500) : null]
    );
  } catch (err) { console.error('[AUDIT LOG] scrittura fallita:', err.message); }
}
```

### 2.2 orePerArea in GET /stats (solo corsi APPROVATI)

```javascript
const [aree] = await pool.query(`
      SELECT area_tematica AS area,
             COALESCE(SUM(numero_ore * 60 + numero_minuti), 0) AS minuti,
             COUNT(*) AS corsi
      FROM certificati
      WHERE stato = 'APPROVATO'
      GROUP BY area_tematica
      ORDER BY minuti DESC
    `);
orePerArea: aree.map((a) => ({ ...a, minuti: Number(a.minuti) })) });```

### 2.3 GET /audit — ultime 100 modifiche (storico admin)

```javascript
router.get('/audit', async (req, res, next) => {
  try {
    const [righe] = await pool.query(
      `SELECT a.id, a.azione, a.certificato_id, a.dettagli, a.creato_il,
              d.matricola AS admin_matricola, d.nome AS admin_nome, d.cognome AS admin_cognome
       FROM audit_log a JOIN dipendenti d ON d.id = a.admin_id
       ORDER BY a.id DESC LIMIT 100`
    );
    res.json({ righe });
  } catch (err) { next(err); }
});

/** GET /utenti/export — [v2.2.9] «Esporta Anagrafica CSV»: elenco completo
 *  degli account con anagrafica (formato friendly Excel: BOM + ';'). */
```

### 2.4 GET /utenti/export — «Esporta Anagrafica CSV»

```javascript
router.get('/utenti/export', async (req, res, next) => {
  try {
    const [righe] = await pool.query(
      `SELECT nome, cognome, matricola, codice_fiscale, sesso, qualifica, attivo
       FROM dipendenti ORDER BY cognome ASC, nome ASC`
    );
    const righeCsv = [
      'Nome;Cognome;Matricola;Codice Fiscale;Sesso;Qualifica;Stato',
      ...righe.map((u) => [
        u.nome, u.cognome, u.matricola, u.codice_fiscale, u.sesso,
        u.qualifica, u.attivo ? 'Attivo' : 'Disabilitato',
      ].join(';')),
    ];
    const csv = '\uFEFF' + righeCsv.join('\r\n') + '\r\n';
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="anagrafica-dipendenti.csv"');
    res.send(csv);
  } catch (err) { next(err); }
});
```

### 2.5 PUT /certificati/:id — correzione metadati (stato e file INTATTI)

```javascript
router.put('/certificati/:id', async (req, res, next) => {
  try {
    /* [AUDIT v2.2-b F5] Solo CIFRE: niente parseInt tolleranti su input esterni. */
    if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ errore: 'Identificativo non valido.' });
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ errore: 'Identificativo non valido.' });

    const [presente] = await pool.query('SELECT nome_corso FROM certificati WHERE id = ?', [id]);
    if (!presente.length) return res.status(404).json({ errore: 'Certificato non trovato.' });

    const { errori, valori } = validaDatiCertificato(req.body || {});
    if (errori.length) return res.status(400).json({ errore: errori.join(' ') });

    const [esito] = await pool.query(
      `UPDATE certificati
       SET nome_corso = ?, ente_erogatore = ?, data_conseguimento = ?,
           numero_ore = ?, numero_minuti = ?, esame_finale = ?, area_tematica = ?
       WHERE id = ?`,
      [valori.nomeCorso, valori.ente, valori.data, valori.numeroOre,
       valori.numeroMinuti, valori.esameFinale, valori.areaTematica, id]
    );
    if (!esito.affectedRows) return res.status(404).json({ errore: 'Certificato non trovato.' });

    /* Storico modifiche (richiesta 5.1): chi ha corretto cosa e quando. */
    await scriviAudit(req.utente.id, 'MODIFICA_CERTIFICATO', id,
      `Corso «${presente[0].nome_corso}» → «${valori.nomeCorso}»`);

    res.json({ ok: true, messaggio: 'Certificato aggiornato.' });
  } catch (err) { next(err); }
});
```

Nello stesso file: `scriviAudit(...)` anche su APPROVAZIONE, RIFIUTO (PUT
stato) e su DELETE (SELECT preventiva con `nome_corso`, audit ELIMINAZIONE).

---

## 3. Aree tematiche 18 — `src/utils/validazione.js`

«Procedimenti amministrativi» entra PRIMA di «Altro» (17 → 18; con le 6
storiche d'archivio AREE_AMMESSE = 24):

```javascript
const AREE_TEMATICHE = [
  'Conoscenza dello specifico contesto lavorativo',
  'Gestione Economico-Finanziaria Enti Locali',
  'Innovazione Digitale e Transizione Digitale',
  'Lingue straniere',
  'Corsi obbligatori(Salute e sicurezza sul lavoro)',
  'Privacy,anticorruzione,antiriciclaggio,trasparenza',
  'Salvaguardia/Impatto ambientale',
  'Ambiente',
  'Risorse umane',
  'Codice appalti e e-procurement',
  'Servizi sociali',
  'Edilizia e urbanistica',
  'GDPR e trattamento dei dati personali',
  'Attività Produttive e Sviluppo Economico',
  'Polizia Locale e Sicurezza Urbana',
  'Affari Generali, Demografici e Statistica',
  'Procedimenti amministrativi', // [v2.2.9] richiesta Comune di Milazzo
  'Altro',
];
```

---

## 4. admin.html — brand Milazzo, combobox, impaginazione, dialoghi

### 4.1 Header brandizzato con stemma SVG (scudo blu, fascia rossa, stella oro)

```html
<div class="brand">
      <svg class="logo" viewBox="0 0 24 28" aria-hidden="true" focusable="false"><path d="M2 2h20v14c0 6-5.2 9.4-10 11C7.2 25.4 2 22 2 16Z" fill="#1c4d8f" stroke="#c9a227" stroke-width="1.6"/><rect x="2" y="10" width="20" height="5" fill="#b31b34"/><path d="M12 3.6l1.4 2.9 3.2.4-2.3 2.2.6 3.2-2.9-1.6-2.9 1.6.6-3.2L7.4 6.9l3.2-.4Z" fill="#e8b923"/></svg>
      <div><strong>Città di Milazzo — Portale Formazione e Certificati</strong><small>Area amministratore</small></div>
    </div>
```

### 4.2 Ricerca autocompletante dipendente (upload per conto — requisito 1③)

```html
<!-- [v2.2.9] ricerca autocompletante: digita nome, cognome,
           matricola o CF; l'id scelto resta nel campo nascosto. -->
      <div class="campo combo-campo" style="margin-bottom:.8rem">
        <span>Dipendente *</span>
        <input type="text" id="cc-dipendente-cerca" class="combo-input"
               placeholder="Digita nome, cognome, matricola o CF…"
               autocomplete="off" role="combobox" aria-expanded="false"
               aria-controls="cc-dipendente-lista" aria-autocomplete="list">
        <input type="hidden" id="cc-dipendente">
        <div id="cc-dipendente-lista" class="combo-lista nascosto" role="listbox"></div>
      </div>
```

### 4.3 Selettore righe per pagina (impaginazione server-side 10/25/50)

```html
<label class="campo">
            <span>Righe per pagina</span>
            <!-- [v2.2.9] impaginazione lato server con selettore 10/25/50 -->
            <select id="ut-perPagina">
              <option value="10">10</option>
              <option value="25" selected>25</option>
              <option value="50">50</option>
            </select>
          </label>
```

### 4.4 Altri elementi (vedi sorgente)

- `#btn-export-utenti` — «Esporta Anagrafica CSV» (barra strumenti Dipendenti);
- `#btn-audit` — «📜 Storico modifiche» (header Certificati);
- `#card-analytics` con `#grafico-aree` — sotto le statistiche della dashboard;
- `#cc-area` e `#ce-area` — voce «Procedimenti amministrativi» prima di «Altro».

### 4.5 Dialog di modifica certificato

```html
<!-- ============ [v2.2.9] Dialog: modifica certificato ============
       Correzione dei metadati di un certificato esistente (titolo, ente,
       data, durata, esame, area). Lo stato e i file restano invariati;
       ogni modifica finisce nello storico (audit log). -->
  <dialog id="dlg-modifica-cert">
    <h3>Modifica certificato</h3>
    <form id="form-modifica-cert">
      <input type="hidden" id="mc-id">
      <div class="griglia-form">
        <label class="campo campo-interra">
          <span>Nome/Titolo del corso *</span>
          <input type="text" id="mc-corso" required maxlength="200">
        </label>
        <label class="campo campo-interra">
          <span>Ente erogatore *</span>
          <input type="text" id="mc-ente" required maxlength="150">
        </label>
        <label class="campo">
          <span>Data di conseguimento *</span>
          <input type="date" id="mc-data" required>
        </label>
        <label class="campo">
          <span>Durata del corso (hh:mm) *</span>
          <input type="text" id="mc-durata" required inputmode="numeric"
                 placeholder="es. 8:30 (oppure solo 8)" maxlength="8">
          <p class="hint">«8:30» = 8 ore e mezza · «0:45» = 45 minuti · «8» = 8 ore intere.</p>
        </label>
        <label class="campo">
          <span>Esame finale</span>
          <select id="mc-esame">
            <option value="0">No</option>
            <option value="1">Sì</option>
          </select>
        </label>
        <label class="campo">
          <span>Area tematica *</span>
          <select id="mc-area" required>
            <option>Conoscenza dello specifico contesto lavorativo</option>
            <option>Gestione Economico-Finanziaria Enti Locali</option>
            <option>Innovazione Digitale e Transizione Digitale</option>
            <option>Lingue straniere</option>
            <option>Corsi obbligatori(Salute e sicurezza sul lavoro)</option>
            <option>Privacy,anticorruzione,antiriciclaggio,trasparenza</option>
            <option>Salvaguardia/Impatto ambientale</option>
            <option>Ambiente</option>
            <option>Risorse umane</option>
            <option>Codice appalti e e-procurement</option>
            <option>Servizi sociali</option>
            <option>Edilizia e urbanistica</option>
            <option>GDPR e trattamento dei dati personali</option>
            <option>Attività Produttive e Sviluppo Economico</option>
            <option>Polizia Locale e Sicurezza Urbana</option>
            <option>Affari Generali, Demografici e Statistica</option>
            <option>Procedimenti amministrativi</option>
            <option>Altro</option>
            <optgroup label="Aree precedenti (archivio)">
              <option>Competenze linguistiche</option>
              <option>Leadership e soft skills</option>
              <option>Principi e valori della PA</option>
              <option>Transizione digitale</option>
              <option>Transizione ecologica</option>
              <option>Transizione amministrativa</option>
            </optgroup>
          </select>
        </label>
      </div>
      <p id="mc-errore" class="alert errore nascosto"></p>
      <div class="azioni">
        <button type="button" class="btn secondario" id="mc-annulla">Annulla</button>
        <button type="submit" class="btn primario">Salva modifiche</button>
      </div>
    </form>
  </dialog>
```

### 4.6 Dialog storico modifiche (audit log)

```html
<!-- ============ [v2.2.9] Dialog: storico modifiche (audit log) ============ -->
  <dialog id="dlg-audit" style="width:min(820px,94vw)">
    <h3>📜 Storico modifiche amministrative</h3>
    <p class="hint">Ultime 100 operazioni su certificati: correzioni dei metadati, approvazioni, rifiuti ed eliminazioni.</p>
    <div class="tabella-wrap" style="max-height:56vh; overflow:auto">
      <table class="dati">
        <thead><tr><th>Data e ora</th><th>Amministratore</th><th>Azione</th><th>Dettagli</th></tr></thead>
        <tbody id="audit-tbody"></tbody>
      </table>
    </div>
    <div class="azioni">
      <button type="button" class="btn secondario" id="audit-annulla">Chiudi</button>
    </div>
  </dialog>
```

---

## 5. admin.js — nuove funzioni (estratto integrale del blocco v2.2.9)

```javascript
/* ---------- [v2.2.9] Ricerca autocompletante dipendente (combobox) ---------- */

/** Filtra la cache dei dipendenti attivi su nome, cognome, matricola e CF. */
function filtraDipendenti(testo) {
  const q = testo.trim().toLowerCase();
  if (!q) return [];
  return opzioniDipendenti.filter((o) =>
    o.nome.toLowerCase().includes(q) ||
    o.cognome.toLowerCase().includes(q) ||
    o.matricola.toLowerCase().includes(q) ||
    (o.codice_fiscale || '').toLowerCase().includes(q)
  ).slice(0, 12);
}

/** Rende i risultati nel pannello a discesa della combobox. */
function mostraListaDipendenti(risultati) {
  const lista = document.getElementById('cc-dipendente-lista');
  const input = document.getElementById('cc-dipendente-cerca');
  lista.innerHTML = '';
  if (!risultati.length) { lista.classList.add('nascosto'); input.setAttribute('aria-expanded', 'false'); return; }
  for (const o of risultati) {
    const voce = document.createElement('button');
    voce.type = 'button';
    voce.setAttribute('role', 'option');
    voce.innerHTML = `<strong>${escapeHtml(o.cognome)} ${escapeHtml(o.nome)}</strong>
      <span class="cella-secondaria">${escapeHtml(o.matricola)} · CF ${escapeHtml(o.codice_fiscale || '—')}</span>`;
    voce.addEventListener('click', () => scegliDipendente(o));
    lista.appendChild(voce);
  }
  lista.classList.remove('nascosto');
  input.setAttribute('aria-expanded', 'true');
}

/** Selezione: l'id va nel campo nascosto (che parla con l'API), il testo
 *  leggibile nell'input. */
function scegliDipendente(o) {
  document.getElementById('cc-dipendente').value = o.id;
  document.getElementById('cc-dipendente-cerca').value = `${o.cognome} ${o.nome} (${o.matricola})`;
  const lista = document.getElementById('cc-dipendente-lista');
  lista.classList.add('nascosto');
  document.getElementById('cc-dipendente-cerca').setAttribute('aria-expanded', 'false');
}

function inizializzaComboDipendenti() {
  const input = document.getElementById('cc-dipendente-cerca');
  const lista = document.getElementById('cc-dipendente-lista');
  if (!input) return;
  input.addEventListener('input', () => {
    document.getElementById('cc-dipendente').value = ''; // la selezione è valida finché non si ricambia
    mostraListaDipendenti(filtraDipendenti(input.value));
  });
  input.addEventListener('keydown', (e) => {
    const voci = Array.from(lista.querySelectorAll('button'));
    if (!voci.length) return;
    const attiva = voci.findIndex((v) => v.classList.contains('attiva'));
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const nuova = e.key === 'ArrowDown' ? Math.min(attiva + 1, voci.length - 1) : Math.max(attiva - 1, 0);
      voci.forEach((v) => v.classList.remove('attiva'));
      voci[nuova].classList.add('attiva');
      voci[nuova].scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'Enter' && attiva >= 0) {
      e.preventDefault(); voci[attiva].click();
    } else if (e.key === 'Escape') {
      lista.classList.add('nascosto');
      input.setAttribute('aria-expanded', 'false');
    }
  });
  input.addEventListener('blur', () => setTimeout(() => lista.classList.add('nascosto'), 180));
}

/* ---------- [v2.2.9] Modifica metadati certificato (admin) ---------- */

/** Precompila il dialog con i valori ATTUALI del certificato (durata in h:mm). */
function apriModificaCert(id) {
  const c = ultimiCertificati.find((x) => x.id === id);
  if (!c) { toast('Certificato non trovato: ricarica la pagina.', 'errore'); return; }
  modificaCertId = id;
  document.getElementById('mc-id').value = id;
  document.getElementById('mc-corso').value = c.nome_corso || '';
  document.getElementById('mc-ente').value = c.ente_erogatore || '';
  document.getElementById('mc-data').value = (c.data_conseguimento || '').slice(0, 10);
  document.getElementById('mc-durata').value =
    `${c.numero_ore}:${String(c.numero_minuti).padStart(2, '0')}`;
  document.getElementById('mc-esame').value = c.esame_finale ? '1' : '0';
  document.getElementById('mc-area').value = c.area_tematica || 'Altro';
  document.getElementById('mc-errore').classList.add('nascosto');
  document.getElementById('dlg-modifica-cert').showModal();
}

/** Submit: validazione durata (parser comune) → PUT → refresh. */
async function eseguiModificaCert(e) {
  e.preventDefault();
  const erroreEl = document.getElementById('mc-errore');
  erroreEl.classList.add('nascosto');
  const durata = parserDurata(document.getElementById('mc-durata').value);
  if (!durata) {
    erroreEl.textContent = 'Durata non valida: usa il formato ore:minuti (es. 8:30, 0:45 oppure 8).';
    erroreEl.classList.remove('nascosto');
    return;
  }
  try {
    const dati = await api(`/api/admin/certificati/${modificaCertId}`, {
      method: 'PUT',
      body: {
        nome_corso: document.getElementById('mc-corso').value.trim(),
        ente_erogatore: document.getElementById('mc-ente').value.trim(),
        data_conseguimento: document.getElementById('mc-data').value,
        numero_ore: String(durata.ore),
        numero_minuti: String(durata.minuti),
        esame_finale: document.getElementById('mc-esame').value,
        area_tematica: document.getElementById('mc-area').value,
      },
    });
    chiudi('dlg-modifica-cert');
    toast(dati.messaggio || 'Certificato aggiornato.', 'successo');
    await Promise.all([caricaCertificati(), caricaStatistiche()]);
  } catch (err) {
    errorePasswordProvvisoria(err);
    erroreEl.textContent = err.message;
    erroreEl.classList.remove('nascosto');
  }
}

/* ---------- [v2.2.9] Storico modifiche (audit log) ---------- */

const ETICHETTE_AUDIT = {
  MODIFICA_CERTIFICATO: ['Modifica metadati', 'blu'],
  APPROVAZIONE: ['Approvazione', 'verde'],
  RIFIUTO: ['Rifiuto', 'rosso'],
  ELIMINAZIONE: ['Eliminazione', 'grigio'],
};

async function caricaAudit() {
  const tbody = document.getElementById('audit-tbody');
  try {
    const { righe } = await api('/api/admin/audit');
    tbody.innerHTML = righe.length ? '' : '<tr><td colspan="4" class="vuoto">Nessuna modifica registrata.</td></tr>';
    for (const r of righe) {
      const [etichetta, colore] = ETICHETTE_AUDIT[r.azione] || [r.azione, 'grigio'];
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${dataOraIt(r.creato_il)}</td>
        <td><span class="cella-principale">${escapeHtml(r.admin_matricola)}</span>
            <div class="cella-secondaria">${escapeHtml(r.admin_cognome)} ${escapeHtml(r.admin_nome)}</div></td>
        <td><span class="badge ${colore}">${escapeHtml(etichetta)}</span></td>
        <td>${escapeHtml(r.dettagli || '—')}${r.certificato_id ? ` <span class="cella-secondaria">(certificato #${r.certificato_id})</span>` : ''}</td>`;
      tbody.appendChild(tr);
    }
    document.getElementById('dlg-audit').showModal();
  } catch (err) { toast(`Storico non disponibile: ${err.message}`, 'errore'); }
}
```

Grafico aree dentro `caricaStatistiche()`:

```javascript
/* [v2.2.9] grafico a barre: ore approvate per area tematica. */
    const contenitore = document.getElementById('grafico-aree');
    if (contenitore) {
      const aree = orePerArea || [];
      const max = Math.max(1, ...aree.map((a) => a.minuti));
      contenitore.innerHTML = aree.length ? aree.map((a) => `
        <div class="barra-area">
          <div class="barra-area-testo"><span title="${escapeHtml(a.area)}">${escapeHtml(a.area)}</span>
            <span class="cella-secondaria">${formattaDurata(Math.floor(a.minuti / 60), a.minuti % 60)} · ${a.corsi} ${a.corsi === 1 ? 'corso' : 'corsi'}</span></div>
          <div class="barra-area-traccia"><div class="barra-area-riempimento" style="width:${Math.round((a.minuti / max) * 100)}%"></div></div>
        </div>`).join('') : '<p class="hint">Nessun corso approvato: il grafico sarà disponibile dopo le prime approvazioni.</p>';
    }
  // …
```

Cablaggio in `init()`:

```javascript
/* [v2.2.9] impaginazione utenti: righe per pagina (server-side) */
  document.getElementById('ut-perPagina').addEventListener('change', () => {
    filtriUtenti.perPagina = Number.parseInt(document.getElementById('ut-perPagina').value, 10) || 25;
    filtriUtenti.pagina = 1;
    caricaDipendenti();
  });
  /* [v2.2.9] esportazione anagrafica CSV */
  document.getElementById('btn-export-utenti').addEventListener('click', () => {
    window.location.assign('/api/admin/utenti/export');
  });
  /* [v2.2.9] storico modifiche (audit log) */
  document.getElementById('btn-audit').addEventListener('click', caricaAudit);
  document.getElementById('audit-annulla').addEventListener('click', () => chiudi('dlg-audit'));
  /* [v2.2.9] dialog di modifica certificato */
  document.getElementById('mc-annulla').addEventListener('click', () => chiudi('dlg-modifica-cert'));
  document.getElementById('form-modifica-cert').addEventListener('submit', eseguiModificaCert);
  inizializzaComboDipendenti();
```

---

## 6. dipendente.html / dipendente.js — requisito 1②

Header Milazzo («Area dipendente», stesso stemma). Il pulsante di conferma
dell'upload dell'UTENTE (solo lui) diventa «💾 Salva»; il form admin (#cc-btn)
resta «Carica certificato».

```html
<button type="submit" class="btn primario" id="btn-upload">💾 Salva</button>
```

Ripristino nel `finally` di `dipendente.js`:

```javascript
    bottone.textContent = '💾 Salva'; // [v2.2.9] testo del pulsante rinominato
```

---

## 7. index.html — login brandizzato

Stemma 74×86, `<h1>Città di Milazzo</h1>`, sottotitolo «Portale Formazione e
Certificati — Area dipendenti».

---

## 8. stile.css — palette istituzionale e nuovi componenti

```css
/* ═══════════ [v2.2.9] BRAND IDENTITY — Città di Milazzo ═══════════
   Palette istituzionale: blu/azzurro istituzionale + rosso araldico e oro.
   Le variabili ridefinite qui sotto sovrascrivono i valori base (la logica
   semantica dei nomi resta invariata); --oro è nuova. */
:root {
  --blu:        #1c4d8f;
  --blu-scuro:  #123a6d;
  --blu-chiaro: #dbe7f7;
  --rosso:      #b31b34;
  --rosso-bg:   #fbe4e8;
  --oro:        #c9a227;
  --oro-chiaro: #f4e8c8;
}
.topbar {
  background: linear-gradient(135deg, var(--blu-scuro) 0%, #235a9e 100%);
  border-bottom: 3px solid var(--oro);
}
.topbar .utente-info strong { color: #fff; }
.brand .logo { width: 34px; height: 38px; display: block; flex: 0 0 auto; }
.brand strong { color: #fff; }
.login-logo svg { width: 74px; height: 86px; }

/* Combobox di ricerca dipendente (dialog «Carica per dipendente») */
.combo-campo { position: relative; }
.combo-lista {
  position: absolute; z-index: 40; top: calc(100% + 2px); left: 0; right: 0;
  background: #fff; border: 1px solid var(--bordo); border-radius: 8px;
  box-shadow: 0 10px 24px rgba(15, 23, 42, .16);
  max-height: 240px; overflow: auto;
}
.combo-lista button {
  display: flex; flex-direction: column; gap: .05rem; width: 100%;
  padding: .45rem .75rem; text-align: left; background: none; border: 0;
  border-bottom: 1px solid var(--bordo); cursor: pointer; font: inherit;
}
.combo-lista button:last-child { border-bottom: 0; }
.combo-lista button:hover, .combo-lista button.attiva { background: var(--blu-chiaro); }

/* Dashboard analytics: barre ore per area tematica */
.grafico-aree { margin-top: .4rem; }
.barra-area { margin: .45rem 0; }
.barra-area-testo {
  display: flex; justify-content: space-between; gap: 1rem;
  font-size: .8rem; margin-bottom: .15rem;
}
.barra-area-testo span:first-child {
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.barra-area-traccia {
  height: 10px; background: #eef2f7; border-radius: 999px; overflow: hidden;
}
.barra-area-riempimento {
  height: 100%; border-radius: 999px;
  background: linear-gradient(90deg, var(--blu-scuro), #2a7fc9);
}
```

---

## 9. Migrazione DB — `db/migrazione-v2.2.9.sql`

```sql
-- ============================================================================
--  MIGRAZIONE v2.2.9 — Audit log delle modifiche amministrative
--  Da applicare ai database esistenti (le installazioni nuove usano schema.sql):
--      sudo mysql certificati_comune < db/migrazione-v2.2.9.sql
-- ============================================================================
USE certificati_comune;

CREATE TABLE IF NOT EXISTS audit_log (
  id             INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  admin_id       INT UNSIGNED     NOT NULL,
  azione         VARCHAR(50)      NOT NULL,
  certificato_id INT UNSIGNED     NULL,
  dettagli       VARCHAR(500)     NULL,
  creato_il      TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_data (creato_il),
  CONSTRAINT fk_audit_admin FOREIGN KEY (admin_id) REFERENCES dipendenti(id) ON DELETE CASCADE,
  CONSTRAINT fk_audit_cert  FOREIGN KEY (certificato_id) REFERENCES certificati(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

Applicata a `certificati_comune` e `certificati_comune_test`; per i DB nuovi la
tabella è già in coda a `schema.sql` (CREATE TABLE IF NOT EXISTS).

---

## 10. Reverse proxy e dominio locale — requisito 4

- **`deploy/nginx.conf`** — server 80 → `127.0.0.1:3000`; `server_name
  portale.certificati certificati.comune.milazzo.it`; `client_max_body_size
  25m`; header proxy completi (Host, X-Real-IP, X-Forwarded-*).
- **`docs/GUIDA-DOMINIO-LOCALE-v2.2.9.md`** — installazione NGINX, record DNS
  interno (A) oppure file `hosts` sui client, verifiche `curl`, tabella
  problemi frequenti.

---

*Città di Milazzo — Portale Formazione e Certificati · release 2.2.9 ·
suite di collaudo 355/355 PASS (137 `node --test` + 218 Jest, 12 suite).*

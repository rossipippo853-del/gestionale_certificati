# AGGIORNAMENTO v2.3.11 — Card «Siti di formazione» nella scheda Profilo

Delta da applicare su installazione **v2.3.10** intatta. Nessuna migrazione
DB, nessun nuovo pacchetto npm.

| File | Operazione |
|---|---|
| `public/js/common.js` | **Sostituisci** (array `SITI_FORMAZIONE` + renderer) |
| `public/js/dipendente.js` | **Sostituisci** (chiamata negli init) |
| `public/js/admin.js` | **Sostituisci** (chiamata negli init) |
| `public/dipendente.html` | **Sostituisci** (card nel Profilo) |
| `public/admin.html` | **Sostituisci** (card nel Profilo admin) |
| `public/css/stile.css` | **Sostituisci** (stili `.sito-formazione`) |
| `tests/frontend.test.js` | **Sostituisci** (test v2.3.11) |
| `package.json` → 2.3.11 · `README.md` §21 · `QA-REPORT.md` §v2.3.11 | **Sostituisci** |

Sono SOLO file statici: dopo la copia basta **Ctrl+F5** nel browser,
NON serve riavviare l'app.

## PERSONALIZZAZIONE dei siti (1 punto solo)

Apri `public/js/common.js` e modifica l'array in testa al blocco v2.3.11:

```js
const SITI_FORMAZIONE = [
  { nome: 'Syllabus', url: 'https://syllabus.formazione.it',
    descrizione: 'Piattaforma e-learning per la formazione del personale della PA', icona: '🎓' },
  { nome: 'Piattaforma Formativa 2', url: 'https://.../...', descrizione: '...', icona: '📘' },
  { nome: 'Piattaforma Formativa 3', url: 'https://.../...', descrizione: '...', icona: '📗' },
];
```
Aggiungi/togli righe quante vuoi: le card di dipendente e admin si aggiornano
da sole. I link si aprono sempre in nuova scheda.

Verifica: login → tab Profilo → card «Siti di formazione» con 3 righe;
clic su «Apri ↗» → nuova scheda. `npm test` atteso: 403/403 PASS.

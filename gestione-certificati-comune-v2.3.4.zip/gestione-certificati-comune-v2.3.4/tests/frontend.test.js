/**
 * frontend.test.js — Test dell'interfaccia:
 *  - unit test REALI di common.js eseguiti in una sandbox VM
 *    (regressioni BUG#1 loop login, gestione errori, utilità);
 *  - regressioni strutturali del dialog di conferma (BUG#2);
 *  - smoke test delle pagine e degli header di sicurezza (CSP).
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { test, before, after } = require('node:test');
const h = require('./helper');

const PUBBLICO = path.resolve(__dirname, '..', 'public');

before(async () => { await h.avvia(); });
after(async () => { await h.chiudi(); });

/** Carica common.js in una sandbox con DOM/location/fetch fittizi. */
function creaSandbox(pathname, fetchImpl) {
  const sandbox = {
    console,
    location: { href: '', pathname },
    document: {
      addEventListener() {},
      querySelectorAll() { return []; },
      getElementById() { return null; },
      createElement() { return { style: {}, classList: { add() {}, remove() {} }, appendChild() {} }; },
      body: { appendChild() {} },
    },
    fetch: fetchImpl,
    setTimeout, clearTimeout,
    URLSearchParams,
  };
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync(path.join(PUBBLICO, 'js', 'common.js'), 'utf8'), sandbox, { filename: 'common.js' });
  return sandbox;
}

/* ---------------- BUG#1: loop di ricaricamento sul login ---------------- */

test('BUG#1 (regressione): su /login un 401 NON provoca redirect', async () => {
  const sandbox = creaSandbox('/', async () => ({
    status: 401, json: async () => ({ errore: 'Non autenticato.' }),
  }));
  await h.assert.rejects(() => sandbox.api('/api/auth/me'), /Non autenticato/);
  h.assert.equal(sandbox.location.href, '', 'nessun location.href impostato → nessun loop');
});

test('BUG#1: fuori dal login un 401 reindirizza correttamente al login', async () => {
  const sandbox = creaSandbox('/dipendente', async () => ({
    status: 401, json: async () => ({ errore: 'Sessione scaduta.' }),
  }));
  await h.assert.rejects(() => sandbox.api('/api/certificati'));
  h.assert.equal(sandbox.location.href, '/', 'redirect alla pagina di login');
});

test('BUG#1: nemmeno un errore 5xx reindirizza (il redirect è solo sul 401)', async () => {
  const sandbox = creaSandbox('/', async () => ({
    status: 500, json: async () => ({ errore: 'Errore interno del server.' }),
  }));
  await h.assert.rejects(() => sandbox.api('/api/certificati'));
  h.assert.equal(sandbox.location.href, '');
});

/* ---------------- utilità api()/formattazione (unit test) --------------- */

test('api(): successo restituisce il JSON; 403 porta status e codice applicativo', async () => {
  const ok = creaSandbox('/', async () => ({ status: 200, ok: true, json: async () => ({ utente: { id: 7 } }) }));
  h.assert.deepEqual((await ok.api('/api/auth/me')).utente.id, 7);

  const ko = creaSandbox('/dipendente', async () => ({
    status: 403, json: async () => ({ errore: 'Devi prima sostituire la password provvisoria.', codice: 'PASSWORD_TEMPORANEA' }),
  }));
  await h.assert.rejects(async () => {
    try { await ko.api('/api/certificati', { method: 'POST', formData: new (class {})() }); }
    catch (e) { h.assert.equal(e.status, 403); h.assert.equal(e.codice, 'PASSWORD_TEMPORANEA'); throw e; }
  }, /provvisoria/);
});

test('escapeHtml neutralizza HTML pericoloso', () => {
  const s = creaSandbox('/', async () => ({ status: 200, json: async () => ({}) }));
  h.assert.equal(s.escapeHtml('<img src=x onerror="alert(1)">'),
    '&lt;img src=x onerror=&quot;alert(1)&quot;&gt;');
  h.assert.equal(s.escapeHtml("O'Brien & Figli"), 'O&#39;Brien &amp; Figli');
});

test('dataIt e dimensioneUmana formattano correttamente', () => {
  const s = creaSandbox('/', async () => ({ status: 200, json: async () => ({}) }));
  h.assert.equal(s.dataIt('2026-05-10'), '10/05/2026');
  h.assert.equal(s.dataIt('2026-05-10 14:30:00'), '10/05/2026'); // ignora l'ora
  h.assert.equal(s.dataIt(''), '');
  h.assert.equal(s.dimensioneUmana(512), '512 B');
  h.assert.equal(s.dimensioneUmana(2048), '2 KB');
  h.assert.equal(s.dimensioneUmana(3 * 1024 * 1024), '3.0 MB');
});

/* ---------------- BUG#2: dialog di conferma (tripwire strutturale) ------- */

test('BUG#2 (regressione): i bottoni del dialog sono in un form method="dialog" e returnValue viene azzerato', () => {
  const codice = fs.readFileSync(path.join(PUBBLICO, 'js', 'common.js'), 'utf8');
  h.assert.ok(codice.includes('<form method="dialog" class="azioni">'),
    'i bottoni devono appartenere a un form method=dialog per chiudere il <dialog>');
  h.assert.ok(codice.includes("dlg.returnValue = ''"),
    'returnValue azzerato prima di ogni apertura (ESC = sempre false)');
});

/* --------------------------- pagine e sicurezza -------------------------- */

test('pagine principali servite: login, dipendente, admin, CSS, JS', async () => {
  for (const percorso of ['/', '/dipendente', '/admin', '/css/stile.css', '/js/common.js', '/js/login.js', '/js/dipendente.js', '/js/admin.js']) {
    const { status } = await h.chiedi(percorso);
    h.assert.equal(status, 200, `GET ${percorso}`);
  }
});

test('CSP restrittiva presente e NESSUNO script inline nelle pagine', async () => {
  const { r, testo } = await h.chiedi('/');
  h.assert.match(r.headers.get('content-security-policy') || '', /script-src 'self'/);
  h.assert.ok(testo.includes('src="/js/login.js"'), 'lo script di login è esterno');
  h.assert.ok(!testo.includes('<script>'), 'nessuno script inline');

  for (const pagina of ['dipendente.html', 'admin.html']) {
    const html = fs.readFileSync(path.join(PUBBLICO, pagina), 'utf8');
    h.assert.ok(!html.includes('<script>'), `${pagina}: nessuno script inline`);
    h.assert.ok(!/\bon\w+\s*=\s*"/.test(html), `${pagina}: nessun handler inline`);
  }
  const js = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  h.assert.ok(!/onclick\s*=/.test(js), 'admin.js: nessun attributo onclick (CSP)');
});

test("admin.html contiene il banner password provvisoria e la sezione Profilo (FIX QA-B2/B8)", () => {
  const html = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  h.assert.ok(html.includes('banner-password'));
  h.assert.ok(html.includes('sezione-profilo'));
  h.assert.ok(html.includes('form-password'));
});

/* ---------- [v2.1] Modale bloccante di primo accesso (pagina di login) ---------- */

test('index.html: modale di cambio password obbligatorio con tutti i campi e nessuna chiusura', () => {
  const html = fs.readFileSync(path.join(PUBBLICO, 'index.html'), 'utf8');
  h.assert.match(html, /id="dlg-primo-accesso"/);
  h.assert.match(html, /Cambio Password Obbligatorio/);
  h.assert.match(html, /id="pa-nuova"/);
  h.assert.match(html, /id="pa-conferma"/);
  h.assert.match(html, /Conferma e Salva Nuova Password/);
  // nessun canale di chiusura nel markup della modale (bloccante)
  const modale = html.slice(html.indexOf('dlg-primo-accesso'), html.indexOf('</dialog>'));
  h.assert.ok(!/[×✕]|>Annulla<|>Esci</.test(modale), 'la modale non deve offrire una chiusura');
});

test('login.js: intercetta primoAccesso, apre la modale e la rende inaggirabile', () => {
  const js = fs.readFileSync(path.join(PUBBLICO, 'js', 'login.js'), 'utf8');
  h.assert.match(js, /risposta\.primoAccesso/);                  // intercetta la risposta del login
  h.assert.match(js, /dlg\.showModal\(\)/);                      // apre la modale nativa
  h.assert.match(js, /addEventListener\('cancel'[\s\S]{0,80}preventDefault/, // ESC bloccato
    "l'evento 'cancel' (ESC) deve essere annullato");
  h.assert.match(js, /api\('\/api\/auth\/primo-accesso'/);       // completa il cambio
  h.assert.match(js, /location\.href = risposta\.utente\.ruolo/); // redirect alla dashboard
});

/* ---------- [v2.2.2] Durata hh:mm unica, tendina esame, spunta verde ---------- */

test('v2.2.2: parserDurata (hh:mm) — formati validi, sporchi e rifiutati', () => {
  const src = fs.readFileSync(path.join(PUBBLICO, 'js', 'common.js'), 'utf8');
  const blocco = src.match(/function parserDurata\(testo\) \{[\s\S]*?\n\}/);
  h.assert.ok(blocco, 'parserDurata deve esistere in common.js');
  const parserDurata = new Function(`return ${blocco[0]}`)();

  h.assert.deepEqual(parserDurata('8:30'), { ore: 8, minuti: 30 });
  h.assert.deepEqual(parserDurata('8'), { ore: 8, minuti: 0 });
  h.assert.deepEqual(parserDurata('08:05'), { ore: 8, minuti: 5 });
  h.assert.deepEqual(parserDurata(' 0:45 '), { ore: 0, minuti: 45 });
  h.assert.deepEqual(parserDurata('9999:59'), { ore: 9999, minuti: 59 });
  for (const cattivo of ['', '   ', '8:5', '1:75', '-3', '8.30', 'abc', '0:00', '8:', ':30']) {
    h.assert.equal(parserDurata(cattivo), null, `deve rifiutare: ${JSON.stringify(cattivo)}`);
  }
});

test('v2.2.2: durata in UNA sola cella e tendina Esame finale in ENTRAMBE le aree', () => {
  const dip = fs.readFileSync(path.join(PUBBLICO, 'dipendente.html'), 'utf8');
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');

  // un unico input durata con formato hh:mm (niente più doppio campo ore/minuti)
  h.assert.match(dip, /id="up-durata"/);
  h.assert.match(dip, /hh:mm/);
  h.assert.ok(!dip.includes('id="up-ore"') && !dip.includes('id="up-minuti"'), 'niente campi separati ore/minuti');
  h.assert.match(adm, /id="cc-durata"/);
  h.assert.ok(!adm.includes('id="cc-ore"') && !adm.includes('id="cc-minuti"'), 'niente campi separati ore/minuti');

  // Esame finale a TENDINA (Sì/No) in entrambe le aree, niente più checkbox
  h.assert.ok(!dip.includes('type="checkbox" id="up-esame"'), 'la checkbox esame è stata sostituita');
  h.assert.match(dip, /<select id="up-esame">[\s\S]*?<option value="0">No<\/option>[\s\S]*?<option value="1">Sì<\/option>/);
  h.assert.match(adm, /<select id="cc-esame">/);

  // i due JS usano il parser condiviso
  for (const fileJs of ['js/dipendente.js', 'js/admin.js']) {
    const js = fs.readFileSync(path.join(PUBBLICO, fileJs), 'utf8');
    h.assert.match(js, /parserDurata\(document\.getElementById\('(up|cc)-durata'\)\.value\)/);
  }
});

test('v2.2.3: profilo — totale senza i RIFIUTATI e spunta VERDE oltre le 40 ore', () => {
  const dip = fs.readFileSync(path.join(PUBBLICO, 'dipendente.html'), 'utf8');
  h.assert.match(dip, /Ore formative totali \(corsi validi e in attesa; i rifiutati non contano\)/);
  h.assert.match(dip, /&#10004; 40\+ ore/);

  // il badge è VERDE (non più blu)
  const css = fs.readFileSync(path.join(PUBBLICO, 'css', 'stile.css'), 'utf8');
  const regola = css.match(/\.badge-verifica \{[\s\S]*?\}/);
  h.assert.ok(regola && /--verde/.test(regola[0]) && !/--blu/.test(regola[0]), 'badge-verifica deve usare il verde');

  // il backend somma TUTTI gli stati e usa la soglia strettamente maggiore
  const rotta = fs.readFileSync(path.resolve(__dirname, '..', 'src', 'routes', 'certificati.routes.js'), 'utf8');
  const sezione = rotta.slice(rotta.indexOf('ORE FORMATIVE TOTALI'), rotta.indexOf('const oreTotali'));
  h.assert.match(sezione, /stato <> 'RIFIUTATO'/, 'il totale ESCLUDE i rifiutati (v2.2.3)');
  h.assert.ok(!/stato = 'APPROVATO'/.test(sezione), 'il totale non filtra per APPROVATO (conta anche gli in attesa)');
  h.assert.match(rotta, /badge: totaleMinuti > SOGLIA_BADGE_MINUTI/, 'soglia STRETTAMENTE maggiore di 40 ore');

  /* [v2.3.5] la tabella admin dei certificati ORA ha l'impaginazione
   * server-side (10/25/50), identica alla tabella Dipendenti (supera la
   * scelta v2.2.3 «elenco completo», richiesta esplicitamente dall'utente). */
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  h.assert.ok(adm.includes('id="ce-perPagina"'), 'selettore righe per pagina certificati');
  h.assert.ok(adm.includes('id="paginazione-certificati"'), 'contenitore paginazione certificati');
  h.assert.match(admJs, /renderPaginazione\('paginazione-certificati'/, 'pager certificati cablato');
  h.assert.ok(!admJs.includes("perPagina: 'tutti'"), 'non si chiede più l\'elenco completo');

  /* [v2.3.5] impaginazione anche sul lato DIPENDENTE */
  const dipJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'dipendente.js'), 'utf8');
  h.assert.ok(dip.includes('id="dp-perPagina"'), 'selettore righe per pagina dipendente');
  h.assert.ok(dip.includes('id="paginazione-miei"'), 'contenitore paginazione dipendente');
  h.assert.match(dipJs, /renderPaginazione\('paginazione-miei'/, 'pager dipendente cablato');
  /* [v2.3.10] doppio binario: pager SEMPRE operativo — con metadati dal
   * server (backend aggiornato) oppure in impaginazione LOCALE della lista
   * completa (backend vecchio), senza mai «Pagina undefined». */
  h.assert.match(dipJs, /Number\.isFinite\(dati\.pagineTotali\)/, 'ramo backend aggiornato');
  h.assert.match(dipJs, /listaCompleta\.slice\(/, 'fallback: impaginazione locale della lista completa');
  h.assert.match(dipJs, /function conteggiDaLista/, 'conteggi locali nel fallback');
  h.assert.match(dipJs, /conteggi/, 'card statistiche alimentate dai conteggi (server o locali)');
  /* admin: pager nascosto se mancano i metadati (mai «undefined») */
  h.assert.match(admJs, /Number\.isFinite\(dati\.pagineTotali\)/, 'guardia pager anche su admin');
});

test('v2.3.6: filtri dei CERTIFICATI «a flusso» (uno dopo l\u2019altro, non 3 per riga)', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const css = fs.readFileSync(path.join(PUBBLICO, 'css', 'stile.css'), 'utf8');

  /* solo la barra dei certificati diventa a flusso: Dipendenti resta a griglia */
  h.assert.ok(adm.includes('filtro-barra filtro-flusso'), 'barra filtri certificati a flusso');
  h.assert.ok(adm.split('filtro-flusso').length - 1 === 1, 'classe filtro-flusso usata UNA volta sola');
  h.assert.match(css, /\.filtro-flusso \{[\s\S]*?display: grid;[\s\S]*?grid-template-columns: repeat\(5, minmax\(0, 1fr\)\);/, 'griglia fissa 5 colonne (DUE righe di 5 campi)');
  h.assert.match(css, /\.barra-certificati \.filtro-barra \{ flex: 1 1 100%; \}/, 'filtri a piena larghezza, azioni sotto a destra');
  h.assert.match(css, /@media \(max-width: 900px\)[\s\S]*?\.filtro-flusso \{ grid-template-columns: repeat\(2, minmax\(0, 1fr\)\); \}/, 'fallback 2 colonne su schermi stretti');
});

test('v2.2.4: colonna FILE = pulsante «Scarica» (admin e dipendente), non più nome-file', () => {
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  const dipJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'dipendente.js'), 'utf8');

  // niente più chip con il nome del file
  for (const js of [admJs, dipJs]) {
    h.assert.ok(!js.includes('chip-allegato'), 'chip-allegato rimosso');
  }

  // pulsanti di download sugli allegati: stessi endpoint, stile btn piccolo
  const btnAllegati = /class="btn piccolo secondario btn-scarica" href="\/api\/certificati\/allegati\/\$\{a\.id\}\/file"/;
  h.assert.match(admJs, btnAllegati);
  h.assert.match(dipJs, btnAllegati);

  // con più allegati: il dipendente mantiene i pulsanti numerati
  // (Scarica 1, Scarica 2…); l'admin (v2.2.7) elenca nel dettaglio
  // nome + dimensione + pulsante per ciascun documento
  const numerati = /Scarica\$\{c\.allegati\.length > 1 \? ' ' \+ \(i \+ 1\) : ''\}/;
  h.assert.match(dipJs, numerati);
  h.assert.match(admJs, /riga-documento/);
  h.assert.match(admJs, /dimensioneUmana\(a\.dimensione_file\)/);

  // il nome completo del file resta disponibile nel suggerimento (title)
  const tooltip = /title="Scarica \$\{escapeHtml\(a\.nome\)\}"/;
  h.assert.match(admJs, tooltip);
  h.assert.match(dipJs, tooltip);

  // admin, corso con file unico: «⬇ Scarica» al posto del vecchio link «⬇ PDF»
  h.assert.match(admJs, /href="\/api\/certificati\/\$\{c\.id\}\/file"[\s\S]*?>⬇ Scarica<\/a>/);
  h.assert.ok(!admJs.includes('⬇ PDF'), 'il vecchio link «⬇ PDF» è stato sostituito');

  // la vista dipendente conserva Visualizza/Scarica per il file unico;
  // dal v2.3.0 sono COMPATTE a icona con tooltip (zero ingombro in tabella)
  h.assert.match(dipJs, /modo=visualizza/);
  h.assert.match(dipJs, /title="⬇ Scarica il documento"[\s\S]*?>⬇<\/a>/);

  // CSS: contenitore flessibile dei pulsanti + regola .hint (pendente v2.2.2)
  const css = fs.readFileSync(path.join(PUBBLICO, 'css', 'stile.css'), 'utf8');
  h.assert.match(css, /\.cello-allegati \{ display: flex; flex-wrap: wrap/);
  h.assert.match(css, /^\.hint \{ font-size: \.76rem/m);
});

const NUOVE_LISTA = ["Conoscenza dello specifico contesto lavorativo", "Gestione Economico-Finanziaria Enti Locali", "Innovazione Digitale e Transizione Digitale", "Lingue straniere", "Corsi obbligatori(Salute e sicurezza sul lavoro)", "Privacy,anticorruzione,antiriciclaggio,trasparenza", "Salvaguardia/Impatto ambientale", "Ambiente", "Risorse umane", "Codice appalti e e-procurement", "Servizi sociali", "Edilizia e urbanistica", "GDPR e trattamento dei dati personali", "Attività Produttive e Sviluppo Economico", "Polizia Locale e Sicurezza Urbana", "Affari Generali, Demografici e Statistica", "Procedimenti amministrativi", "Altro"];
const STORICHE_LISTA = ["Competenze linguistiche", "Leadership e soft skills", "Principi e valori della PA", "Transizione digitale", "Transizione ecologica", "Transizione amministrativa"];

test('v2.2.5/9: aree tematiche — 18 voci (con Procedimenti amministrativi), archivio nel filtro, DB VARCHAR', () => {
  const dip = fs.readFileSync(path.join(PUBBLICO, 'dipendente.html'), 'utf8');
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');

  const opzioni = (html, id) => {
    const blocco = html.match(new RegExp(`<select id="${id}"[\\s\\S]*?<\\/select>`));
    h.assert.ok(blocco, `select ${id} presente`);
    return Array.from(blocco[0].matchAll(/<option(?: value="[^"]*")?>([^<]+)<\/option>/g)).map((m) => m[1]);
  };

  // form di caricamento: placeholder + esattamente le 18 voci, nell'ordine,
  // senza più le voci storiche
  for (const [html, id] of [[dip, 'up-area'], [adm, 'cc-area']]) {
    const voci = opzioni(html, id).filter((v) => v !== "— Seleziona l'area —");
    h.assert.deepEqual(voci, NUOVE_LISTA, `elenco 18 voci esatto in #${id}`);
  }

  // filtro admin: «Tutte» + le 18 + optgroup archivio con le 6 storiche
  const filtro = opzioni(adm, 'ce-area');
  h.assert.equal(filtro[0], 'Tutte');
  h.assert.deepEqual(filtro.slice(1, 19), NUOVE_LISTA);
  h.assert.match(adm, /<optgroup label="Aree precedenti \(archivio\)">[\s\S]*?<\/optgroup>/);
  for (const storica of STORICHE_LISTA) {
    h.assert.ok(filtro.includes(storica), `area storica "${storica}" ancora filtrabile`);
  }

  // backend: 18 nuove + 6 storiche = 24 ammesse in validazione e nei filtri
  const v = require(path.resolve(__dirname, '..', 'src', 'utils', 'validazione.js'));
  h.assert.deepEqual(v.AREE_TEMATICHE, NUOVE_LISTA);
  h.assert.equal(v.AREE_AMMESSE.length, 24);
  for (const storica of STORICHE_LISTA) h.assert.ok(v.AREE_AMMESSE.includes(storica));

  // schema DB: VARCHAR(100) governato dall'app + migrazione per i DB esistenti
  const schema = fs.readFileSync(path.resolve(__dirname, '..', 'db', 'schema.sql'), 'utf8');
  h.assert.match(schema, /area_tematica\s+VARCHAR\(100\)/);
  h.assert.ok(!schema.includes("ENUM('Competenze linguistiche'"), 'ENUM a 6 valori rimosso dallo schema');
  h.assert.ok(fs.existsSync(path.resolve(__dirname, '..', 'db', 'migrazione-v2.2.5.sql')), 'migrazione v2.2.5 presente');
});

test('v2.2.6: tabella admin a 7 colonne con riga di dettaglio espandibile (niente scroll orizzontale)', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  const css = fs.readFileSync(path.join(PUBBLICO, 'css', 'stile.css'), 'utf8');

  // thead della tabella CERTIFICATI (non quella utenti): 7 colonne primarie
  const sezione = adm.slice(adm.indexOf('id="tabella-certificati"'));
  const thead = sezione.slice(sezione.indexOf('<thead>'), sezione.indexOf('</thead>'));
  const colonne = Array.from(thead.matchAll(/<th>([^<]+)<\/th>/g)).map((m) => m[1]);
  h.assert.deepEqual(colonne, ['Dipendente', 'Corso', 'Conseguimento', 'Durata', 'Area tematica', 'Stato', 'Azioni']);

  // il render produce riga principale + riga di dettaglio con le secondarie
  h.assert.match(admJs, /className = 'riga-principale'/);
  h.assert.match(admJs, /className = 'riga-dettaglio nascosto'/);
  h.assert.match(admJs, /griglia-dettaglio/);
  for (const voce of ['Caricato il', 'Esame finale', 'Documenti', 'Note']) {
    h.assert.ok(admJs.includes(`<div class="dettaglio-titolo">${voce}</div>`), `dettaglio: ${voce}`);
  }
  h.assert.match(admJs, /colspan="7"/);
  h.assert.ok(!admJs.includes('colspan="9"'), 'vecchi colspan a 9 colonne rimossi');

  // toggle: click sulla riga (mai su pulsanti/link) + accessibile da tastiera
  h.assert.match(admJs, /function espandiDettaglio/);
  h.assert.match(admJs, /e\.target\.closest\('button, a'\)/);
  h.assert.match(admJs, /aria-expanded/);
  h.assert.match(admJs, /tabIndex = 0/);

  // i pulsanti «Scarica» (v2.2.4) restano nel dettaglio, con i tooltip
  h.assert.match(admJs, /btn-scarica/);
  h.assert.match(admJs, /title="Scarica \$\{escapeHtml\(a\.nome\)\}"/);

  // CSS: griglia del dettaglio, troncatura ellipsis, freccia rotante
  h.assert.match(css, /\.griglia-dettaglio \{ display: grid/);
  h.assert.match(css, /\.tronca \{ max-width/);
  h.assert.match(css, /tr\.riga-principale\.aperta \.freccia-espandi \{ transform: rotate\(90deg\)/);
});

test('v2.2.7: download in AZIONI e filtro Durata (min·max, h:mm → minuti)', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  const css = fs.readFileSync(path.join(PUBBLICO, 'css', 'stile.css'), 'utf8');

  // barra filtri: i due campi durata con etichette accessibili
  h.assert.match(adm, /id="ce-durata-min"/);
  h.assert.match(adm, /id="ce-durata-max"/);
  h.assert.match(adm, /aria-label="Durata minima"/);
  h.assert.match(adm, /aria-label="Durata massima"/);

  // il JS converte h:mm → minuti, segnala i valori non validi, l'Azzera pulisce
  h.assert.match(admJs, /function leggiDurataFiltro/);
  h.assert.match(admJs, /leggiDurataFiltro\('ce-durata-min'\)/);
  h.assert.match(admJs, /leggiDurataFiltro\('ce-durata-max'\)/);
  h.assert.match(admJs, /input-nonvalido/);
  h.assert.match(admJs, /d\.ore \* 60 \+ d\.minuti/);
  h.assert.match(admJs, /ce-durata-min'\)\.value = ''/);

  // colonna AZIONI: scarica immediato (file unico), «⬇ n» apre il dettaglio
  h.assert.match(admJs, /bottoneAzioniFile/);
  h.assert.match(admJs, /data-azione="dettaglio"/);
  h.assert.match(admJs, /aria-label="Scarica il documento"/);
  h.assert.match(admJs, /aria-label="Apri i dettagli e scarica"/);
  h.assert.match(admJs, /if \(btn\.dataset\.azione === 'dettaglio'\)/);
  h.assert.match(admJs, /function toggleDettaglio/);

  // backend: durataMin/durataMax solo cifre, filtro sulla durata TOTALE
  const rotta = fs.readFileSync(path.resolve(__dirname, '..', 'src', 'routes', 'admin.routes.js'), 'utf8');
  h.assert.match(rotta, /\^\\d\{1,6\}\$/);
  h.assert.match(rotta, /c\.numero_ore \* 60 \+ c\.numero_minuti\) \$\{operatore\} \?/);

  // gli allegati espongono la dimensione (serve al dettaglio ricco)
  for (const f of ['src/routes/admin.routes.js', 'src/routes/certificati.routes.js']) {
    const src = fs.readFileSync(path.resolve(__dirname, '..', f), 'utf8');
    h.assert.match(src, /tipo_file, dimensione_file/);
  }

  // CSS: coppia di campi compatta, righe documento, campo non valido in rosso
  h.assert.match(css, /\.durata-filtri \{ display: flex/);
  h.assert.match(css, /\.riga-documento \{ display: flex/);
  h.assert.match(css, /\.input-nonvalido \{ border-color: var\(--rosso\)/);
});

test('v2.2.8: dialog «Modifica dipendente» con 7 campi precompilati + validazione client', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');

  // dialog con tutti i campi richiesti (inclusi matricola e CF)
  h.assert.match(adm, /id="dlg-modifica-utente"/);
  for (const campo of ['mu-nome', 'mu-cognome', 'mu-matricola', 'mu-codice-fiscale', 'mu-sesso', 'mu-qualifica', 'mu-email']) {
    h.assert.match(adm, new RegExp(`id="${campo}"`), `campo ${campo}`);
  }
  h.assert.match(adm, /<select id="mu-sesso" required>/);       // sesso a tendina
  h.assert.match(adm, /pattern="\[A-Za-z\]\{6\}/);              // formato CF lato HTML
  h.assert.match(adm, /id="mu-errore"/);

  // bottone ✏️ nella riga + apertura precompilata dalla cache dell'elenco
  h.assert.match(admJs, /data-azione="modifica"/);
  h.assert.match(admJs, /function apriModificaUtente/);
  h.assert.match(admJs, /ultimiUtenti\.find/);
  for (const campo of ['mu-matricola', 'mu-codice-fiscale', 'mu-nome', 'mu-cognome', 'mu-sesso', 'mu-qualifica', 'mu-email']) {
    h.assert.ok(admJs.includes(`getElementById('${campo}').value = `), `precompila ${campo}`);
  }

  // validazione client specchio del server + PUT all'endpoint giusto
  h.assert.match(admJs, /function validaAnagraficaClient/);
  h.assert.match(admJs, /\[A-Z\]\{6\}\\d\{2\}/);                     // regex CF
  h.assert.match(admJs, /\[\^\\s@\]\+@\[\^\\s@\]/);                   // regex email
  h.assert.match(admJs, /api\(`\/api\/admin\/utenti\/\$\{modificaId\}`, \{ method: 'PUT'/);
  h.assert.match(admJs, /err\.message/);                                 // 409 mostrati nel dialog
});


/* ═══════════ [v2.2.9] BRAND MILAZZO, SESSIONE, ADMIN UX ═══════════ */
test('v2.2.9 — brand «Città di Milazzo», stemma e palette istituzionale', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const dip = fs.readFileSync(path.join(PUBBLICO, 'dipendente.html'), 'utf8');
  const idx = fs.readFileSync(path.join(PUBBLICO, 'index.html'), 'utf8');
  const css = fs.readFileSync(path.join(PUBBLICO, 'css', 'stile.css'), 'utf8');

  // header e login con dicitura istituzionale + stemma SVG (non più l'emoji)
  for (const pagina of [adm, dip, idx]) {
    h.assert.ok(pagina.includes('Città di Milazzo — Portale Formazione e Certificati') || pagina.includes('<h1>Città di Milazzo</h1>'));
    h.assert.match(pagina, /<svg class="logo" viewBox="0 0 24 28"/);
    h.assert.ok(!pagina.includes('🏛️'));
  }
  h.assert.ok(adm.includes('<small>Area amministratore</small>'));
  h.assert.ok(dip.includes('<small>Area dipendente</small>'));

  // palette Milazzo: variabili blu/azzurro + rosso/oro araldico
  for (const variabile of ['--blu:        #1c4d8f', '--rosso:      #b31b34', '--oro:        #c9a227']) {
    h.assert.ok(new RegExp(variabile.replace(/\s+/g, '\\s*').replace('#', '\\#')).test(css), `variabile ${variabile.trim()}`);
  }
  h.assert.match(css, /border-bottom: 3px solid var\(--oro\)/);
});

test('v2.2.9 — area «Procedimenti amministrativi» in TUTTI i select, prima di «Altro»', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const dip = fs.readFileSync(path.join(PUBBLICO, 'dipendente.html'), 'utf8');
  for (const pagina of [adm, dip]) {
    h.assert.ok(pagina.indexOf('Procedimenti amministrativi') > -1);
    h.assert.ok(pagina.indexOf('Procedimenti amministrativi') < pagina.lastIndexOf('<option>Altro</option>'));
  }
  // dialog di modifica: 18 aree + optgroup archivio (6 voci)
  const inizioMc = adm.indexOf('id="mc-area"');
  const mc = adm.slice(inizioMc, adm.indexOf('</optgroup>', inizioMc));
  h.assert.equal((mc.match(/<option>/g) || []).length, 18 + 6);
});

test('v2.2.9 — bottone utente «💾 Salva» (admin resta «Carica certificato»)', () => {
  const dip = fs.readFileSync(path.join(PUBBLICO, 'dipendente.html'), 'utf8');
  const dipJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'dipendente.js'), 'utf8');
  h.assert.match(dip, /id="btn-upload">💾 Salva<\/button>/);
  h.assert.ok(dipJs.includes("bottone.textContent = '💾 Salva'"));
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  h.assert.match(adm, /id="cc-btn"[^>]*>Carica certificato</);
});

test('v2.2.9 — combobox dipendente (autocompletamento) e suo wiring in admin.js', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  for (const id of ['cc-dipendente-cerca', 'cc-dipendente', 'cc-dipendente-lista']) {
    h.assert.ok(adm.includes(`id="${id}"`), `elemento ${id}`);
  }
  for (const funzione of ['function filtraDipendenti', 'function mostraListaDipendenti',
    'function scegliDipendente', 'function inizializzaComboDipendenti']) {
    h.assert.match(admJs, new RegExp(funzione));
  }
  h.assert.match(admJs, /codice_fiscale \|\| ''\)\.toLowerCase\(\)\.includes/); // filtro su CF
  h.assert.match(admJs, /Seleziona un dipendente dalla ricerca/);               // guardia submit
});

test('v2.2.9 — modifica certificato: dialog, bottone ✏️ e chiamata PUT', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  for (const id of ['dlg-modifica-cert', 'mc-id', 'mc-corso', 'mc-ente', 'mc-data', 'mc-durata', 'mc-esame', 'mc-area', 'mc-errore', 'mc-annulla']) {
    h.assert.ok(adm.includes(`id="${id}"`), `elemento ${id}`);
  }
  h.assert.match(admJs, /data-azione="modifica-cert"/);
  h.assert.match(admJs, /function apriModificaCert/);
  h.assert.match(admJs, /api\(`\/api\/admin\/certificati\/\$\{modificaCertId\}`, \{\s*method: 'PUT'/);
  h.assert.match(admJs, /parserDurata/);                       // validazione durata lato client
  h.assert.match(admJs, /ultimiCertificati\.find/);            // precompilazione dalla cache
});

test('v2.2.9 — impaginazione utenti, export CSV e storico: elementi + wiring', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  for (const id of ['ut-perPagina', 'btn-export-utenti', 'btn-audit', 'dlg-audit', 'audit-tbody']) {
    h.assert.ok(adm.includes(`id="${id}"`), `elemento ${id}`);
  }
  for (const valore of ['<option value="10">10</option>', '<option value="25" selected>25</option>', '<option value="50">50</option>']) {
    h.assert.ok(adm.includes(valore), `selettore ${valore}`);
  }
  h.assert.ok(adm.includes('Esporta Anagrafica CSV'));
  h.assert.match(admJs, /perPagina: 25/);
  h.assert.match(admJs, /'\/api\/admin\/utenti\/export'/);
  h.assert.match(admJs, /function caricaAudit/);
  h.assert.match(admJs, /MODIFICA_CERTIFICATO/);
  /* [v2.3.4] etichette DINAMICHE dello storico: i codici specifici NON sono
   * scritti a mano uno per uno — vengono tradotti dalla funzione dinamica
   * (prefisso azione + campo) con badge colorati per famiglia. */
  h.assert.match(admJs, /function etichettaAzione/);
  h.assert.match(admJs, /const CAMPI_AUDIT/);
  for (const campo of ['TITOLO_CORSO: \'Titolo Corso\'', 'ENTE_EROGATORE: \'Ente Erogatore\'', 'DURATA: \'Durata\'', 'AREA_TEMATICA: \'Area Tematica\'']) {
    h.assert.ok(admJs.includes(campo), `mappa campi audit: ${campo}`);
  }
  h.assert.ok(admJs.includes('(MODIFICA|ELIMINAZIONE|APPROVAZIONE|RIFIUTO|CAMBIO)_'), 'regola dinamica per prefisso azione');
  h.assert.ok(admJs.includes('`Eliminazione ${campo}`'), 'etichetta dinamica eliminazione');
});

test('v2.2.9 — cookie di sessione: auth.routes.js NON imposta maxAge per il token', () => {
  const aut = fs.readFileSync(path.resolve(__dirname, '..', 'src', 'routes', 'auth.routes.js'), 'utf8');
  const sezione = aut.slice(aut.indexOf('function impostaCookieSessione'), aut.indexOf('function impostaCookieCambio'))
    .replace(/^\s*\/\/.*$/gm, '');                 // via i commenti: conta il CODICE
  h.assert.ok(!/maxAge/.test(sezione), 'nessun maxAge nel cookie di sessione');
  h.assert.ok(!/expires/.test(sezione), 'nessun expires nel cookie di sessione');
  const cambio = aut.slice(aut.indexOf('function impostaCookieCambio'));
  h.assert.match(cambio, /maxAge: 15 \* 60 \* 1000/);            // token_cambio resta 15 min
});

test('v2.2.9 — reverse proxy: nginx.conf con porta 80 → 3000 e nomi server', () => {
  const ng = fs.readFileSync(path.resolve(__dirname, '..', 'deploy', 'nginx.conf'), 'utf8');
  h.assert.match(ng, /listen 80;/);
  h.assert.match(ng, /proxy_pass\s+http:\/\/127\.0\.0\.1:3000;/);
  h.assert.match(ng, /server_name portale\.certificati certificati\.comune\.milazzo\.it;/);
  h.assert.match(ng, /client_max_body_size 25m;/);
  h.assert.ok(fs.existsSync(path.resolve(__dirname, '..', 'docs', 'GUIDA-DOMINIO-LOCALE-v2.2.9.md')));
});

/* ═══════════ [v2.3.0] DASHBOARD FORMAZIONE + TABELLE ZERO-SCROLL ═══════════ */
test('v2.3.0 — dashboard formazione per dipendente (sostituisce il grafico globale)', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  const css = fs.readFileSync(path.join(PUBBLICO, 'css', 'stile.css'), 'utf8');

  // la vista globale v2.2.9 è FUORI (html, js e css)
  h.assert.ok(!adm.includes('grafico-aree') && !adm.includes('card-analytics'), 'grafico globale rimosso dall HTML');
  h.assert.ok(!css.includes('grafico-aree'), 'stili grafico rimossi');
  h.assert.ok(!admJs.includes('orePerArea'), 'admin.js non consuma più orePerArea');

  // ricerca dinamica + struttura KPI della nuova dashboard
  for (const id of ['card-dashboard-dipendente', 'fd-dipendente-cerca', 'fd-dipendente',
    'fd-dipendente-lista', 'fd-dash', 'fd-nome', 'fd-sotto', 'fd-stato', 'fd-cert-tot',
    'fd-approvati', 'fd-attesa', 'fd-rifiutati', 'fd-ore-approvate', 'fd-ore-inviate',
    'fd-ore-attesa', 'fd-mancanti', 'fd-percentuale', 'fd-barra', 'fd-aree', 'fd-vuoto']) {
    h.assert.ok(adm.includes(`id="${id}"`), `elemento ${id}`);
  }
  h.assert.match(admJs, /function caricaDashboardFormazione/);
  h.assert.match(admJs, /api\(`\/api\/admin\/utenti\/\$\{id\}\/formazione`\)/);
  h.assert.match(admJs, /function inizializzaRicercaDashboard/);
  h.assert.match(admJs, /function selezionaDipendenteDashboard/);
  h.assert.match(admJs, /function mostraListaDashboard/);
  h.assert.match(admJs, /inizializzaRicercaDashboard\(\)/);
  h.assert.match(admJs, /In regola con il target 40h/);
  h.assert.match(admJs, /'Sotto la soglia'/);

  // schede KPI scure (palette Milazzo) + barra target
  h.assert.match(css, /linear-gradient\(160deg, #1c4d8f 0%, #12315c 100%\)/);
  h.assert.match(css, /\.fd-barra-riempimento/);
  h.assert.match(css, /\.chip-area/);
});

test('v2.3.0 — tabelle zero-scroll: layout fisso, larghezze, badge piccoli, azioni compatte', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const dip = fs.readFileSync(path.join(PUBBLICO, 'dipendente.html'), 'utf8');
  const dipJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'dipendente.js'), 'utf8');
  const css = fs.readFileSync(path.join(PUBBLICO, 'css', 'stile.css'), 'utf8');

  // classi distintive delle due tabelle omonime (admin 7 col vs dipendente 10 col)
  h.assert.ok(adm.includes('tabella-cert-admin'));
  h.assert.ok(dip.includes('tabella-cert-dip'));

  // layout fisso + testo a capo (mai colonne allargate dal contenuto)
  h.assert.match(css, /table\.dati \{ table-layout: fixed; \}/);
  h.assert.match(css, /overflow-wrap: anywhere/);
  h.assert.match(css, /word-break: break-word/);
  h.assert.match(css, /table\.dati td \{ padding: \.42rem \.45rem; \}/);

  // larghezze esplicite: ultima colonna azioni contenuta
  h.assert.match(css, /#tabella-utenti th:nth-child\(10\) \{ width: 14%; \}/);
  h.assert.match(css, /\.tabella-cert-dip th:nth-child\(10\) \{ width: 10%; \}/);
  h.assert.match(css, /\.tabella-cert-admin th:nth-child\(7\) \{ width: 20%; \}/);

  // badge ridotti e button-group orizzontale a icone
  h.assert.match(css, /\.badge \{ padding: \.12rem \.4rem; font-size: \.64rem; \}/);
  h.assert.match(css, /\.azioni-cell \.azioni \{ display: flex; gap: \.28rem; flex-wrap: nowrap; align-items: center; \}/);
  h.assert.match(css, /\.btn-icona/);
  h.assert.match(dipJs, /btn-icona/);
  h.assert.ok(!dipJs.includes('>👁 Visualizza<'), 'azione estesa sostituita da icona compatta');
});

/* ═══════════ [v2.3.1] CHIUDI SCHEDA, ORE CONTEGGIATE, SESSIONE, MATRICOLA ═══════════ */
test('v2.3.1 — pulsante «✕ Chiudi scheda» e reset della dashboard', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  h.assert.match(adm, /id="fd-chiudi"[^>]*>✕ Chiudi scheda<\/button>/);
  h.assert.match(admJs, /function chiudiDashboardFormazione/);
  h.assert.match(admJs, /getElementById\('fd-chiudi'\)\.addEventListener\('click', chiudiDashboardFormazione\)/);
  // il reset svuota ricerca e selezione e ripristina il messaggio iniziale
  h.assert.match(admJs, /fd-dipendente-cerca'\)\.value = ''/);
  h.assert.match(admJs, /la dashboard comparirà qui dopo la ricerca/);
});

test('v2.3.1 — KPI ore distinte e target su ORE CONTEGGIATE (approvate + in attesa)', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  h.assert.ok(adm.includes('Ore approvate') && adm.includes('Ore totali inviate'));
  h.assert.match(adm, /Avanzamento: ore approvate \+ in attesa sul target/);
  h.assert.match(adm, /max\(0; 40h − ore conteggiate\)/);
  h.assert.match(admJs, /fd-ore-approvate'\)\.textContent = minutiInHhMm\(d\.oreApprovateMinuti\)/);
  h.assert.match(admJs, /fd-ore-inviate'\)\.textContent = minutiInHhMm\(d\.oreConteggiateMinuti\)/);
  h.assert.match(admJs, /fd-ore-attesa'\)\.textContent = minutiInHhMm\(d\.oreInAttesaMinuti\)/);
  h.assert.match(admJs, /minutiAttesa/); // le chip di area mostrano l'attesa
});

test('v2.3.1 — sessione di SCHEDA: token in sessionStorage + header Bearer', () => {
  const com = fs.readFileSync(path.join(PUBBLICO, 'js', 'common.js'), 'utf8');
  const log = fs.readFileSync(path.join(PUBBLICO, 'js', 'login.js'), 'utf8');
  const aut = fs.readFileSync(path.resolve(__dirname, '..', 'src', 'middleware', 'auth.js'), 'utf8');
  const rt = fs.readFileSync(path.resolve(__dirname, '..', 'src', 'routes', 'auth.routes.js'), 'utf8');

  // frontend: il token vive in sessionStorage e va nell'header Authorization
  h.assert.match(com, /sessionStorage\.setItem\(CHIAVE_TOKEN/);
  h.assert.match(com, /sessionStorage\.removeItem\(CHIAVE_TOKEN/);
  h.assert.match(com, /headers\['Authorization'\] = `Bearer \$\{t\}`/);
  h.assert.match(com, /function rimuoviToken/);
  // login + completamento primo accesso: entrambi salvano il token di scheda
  h.assert.equal((log.match(/salvaToken\(risposta\.token\)/g) || []).length, 2);
  // backend: header Bearer accettato dal middleware + token nel body di login e cambio
  h.assert.match(aut, /authorization \|\| req\.headers\.Authorization/);
  h.assert.match(aut, /header\.startsWith\('Bearer '\)/);
  h.assert.match(rt, /res\.json\({ utente: profiloPubblico\(utente\), token }\)/);
  h.assert.match(rt, /token: tokenSessione,/);
  // il cookie di sessione resta SENZA scadenza (invariante v2.2.9)
  const sezione = rt.slice(rt.indexOf('function impostaCookieSessione'), rt.indexOf('function impostaCookieCambio'))
    .replace(/^\s*\/\/.*$/gm, '');
  h.assert.ok(!/maxAge/.test(sezione) && !/expires/.test(sezione));
});

test('v2.3.1 — matricola 2-20 (regex aggiornata su server, client e import)', () => {
  const v = require(path.resolve(__dirname, '..', 'src', 'utils', 'validazione.js'));
  h.assert.match(String(v.RE_MATRICOLA), /\^\[A-Za-z0-9_-\]\{2,20\}\$/);
  h.assert.ok(v.RE_MATRICOLA.test('12'));
  h.assert.ok(v.RE_MATRICOLA.test('ab'));
  h.assert.ok(!v.RE_MATRICOLA.test('x'));

  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  h.assert.match(admJs, /\^\[A-Za-z0-9_-\]\{2,20\}\$/);
  h.assert.ok(admJs.includes('2-20 caratteri alfanumerici'));

  const imp = fs.readFileSync(path.resolve(__dirname, '..', 'src', 'utils', 'importazione.js'), 'utf8');
  h.assert.ok(imp.includes('2-20 caratteri alfanumerici'));
});

/* ═══════════ [v2.3.2] TAB «MONITORAGGIO» ═══════════ */
test('v2.3.2 — la dashboard dipendente vive nella nuova tab «Monitoraggio» (non più sopra i tab)', () => {
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  const css = fs.readFileSync(path.join(PUBBLICO, 'css', 'stile.css'), 'utf8');

  // nuova voce nel menu, tra Certificati e Profilo
  h.assert.match(adm, /data-tab="monitoraggio"[^>]*>📊 Monitoraggio<\/button>/);
  const iCert = adm.indexOf('data-tab="certificati"');
  const iMon = adm.indexOf('data-tab="monitoraggio"');
  const iPro = adm.indexOf('data-tab="profilo"');
  h.assert.ok(iCert > -1 && iCert < iMon && iMon < iPro, 'ordine tab: certificati < monitoraggio < profilo');

  // la card dashboard è DENTRO la sezione monitoraggio e NON più sopra i tab
  const iNav = adm.indexOf('<nav class="tabs">');
  const iSec = adm.indexOf('<section id="sezione-monitoraggio"');
  const iCard = adm.indexOf('id="card-dashboard-dipendente"');
  h.assert.ok(iSec > iNav, 'la sezione è dopo i tab');
  h.assert.ok(iCard > iSec && iCard < adm.indexOf('</section>', iSec), 'la card è dentro la sezione');
  h.assert.ok(adm.slice(0, iNav).indexOf('card-dashboard-dipendente') === -1, 'più nulla di monitoraggio sopra i tab');

  // grafico 1 (ciambella), grafico 2 (barre aree), KPI aggiuntivi
  for (const id of ['card-target-40', 'donut-arco', 'donut-percento', 'tg-raggiunti', 'tg-non', 'tg-tot',
    'card-aree-tematiche', 'barre-aree', 'card-kpi-extra', 'kpi-media-ore', 'kpi-in-attesa', 'kpi-top-aree']) {
    h.assert.ok(adm.includes(`id="${id}"`), `elemento ${id}`);
  }
  h.assert.ok(adm.includes('approvati + in attesa di approvazione'), 'il target dichiara di includere le ore in attesa');

  // wiring JS: endpoint + render + refresh all'apertura della tab
  h.assert.match(admJs, /api\('\/api\/admin\/monitoraggio'\)/);
  h.assert.match(admJs, /function renderDonutTarget/);
  h.assert.match(admJs, /function renderBarreAree/);
  h.assert.match(admJs, /function renderKpiExtra/);
  h.assert.match(admJs, /function caricaMonitoraggio/);
  h.assert.match(admJs, /, caricaMonitoraggio\(\)\]\);/);             // nel Promise.all iniziale
  h.assert.match(admJs, /\[data-tab="monitoraggio"\]'\)\.addEventListener\('click', caricaMonitoraggio\)/);

  // stile donut + griglia monitoraggio
  h.assert.match(css, /\.donut-arco/);
  h.assert.match(css, /\.griglia-monitoraggio/);
  h.assert.match(css, /\.area-riempimento/);
});

test('v2.3.11: scheda Profilo — card «Siti di formazione» con link esterni configurabili', () => {
  const comune = fs.readFileSync(path.join(PUBBLICO, 'js', 'common.js'), 'utf8');
  const adm = fs.readFileSync(path.join(PUBBLICO, 'admin.html'), 'utf8');
  const dip = fs.readFileSync(path.join(PUBBLICO, 'dipendente.html'), 'utf8');
  const admJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'admin.js'), 'utf8');
  const dipJs = fs.readFileSync(path.join(PUBBLICO, 'js', 'dipendente.js'), 'utf8');

  /* configurazione UNICA e personalizzabile in common.js */
  h.assert.match(comune, /const SITI_FORMAZIONE = \[/, 'array di configurazione SITI_FORMAZIONE');
  h.assert.match(comune, /nome: 'Syllabus'/, 'voce Syllabus presente');
  h.assert.match(comune, /url: 'https:\/\/syllabus\.formazione\.it'/, 'URL Syllabus');
  h.assert.match(comune, /nome: 'Piattaforma Formativa 2'/, 'placeholder 2');
  h.assert.match(comune, /nome: 'Piattaforma Formativa 3'/, 'placeholder 3');
  h.assert.match(comune, /function renderSitiFormazione/, 'renderer condiviso');
  h.assert.match(comune, /a\.target = '_blank';/, 'apertura in NUOVA scheda');
  h.assert.match(comune, /a\.rel = 'noopener noreferrer';/, 'rel noopener sui link esterni');
  h.assert.match(comune, /escapeHtml\(sito\.nome\)/, 'escape del nome (difesa XSS)');

  /* card presente in ENTRAMBE le schede Profilo, con contenitore dedicato */
  for (const [nome, html] of [['admin.html', adm], ['dipendente.html', dip]]) {
    h.assert.ok(html.includes('Siti di formazione'), `${nome}: titolo card`);
    h.assert.ok(html.includes('id="siti-formazione"'), `${nome}: contenitore`);
  }

  /* il rendering è agganciato negli init di entrambe le pagine */
  h.assert.match(admJs, /renderSitiFormazione\('siti-formazione'\)/, 'init admin agganciato');
  h.assert.match(dipJs, /renderSitiFormazione\('siti-formazione'\)/, 'init dipendente agganciato');
});

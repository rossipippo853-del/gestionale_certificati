/**
 * api.test.js — Flusso di AUTENTICAZIONE, PROFILO/cambio password,
 * PERMESSI per ruolo e gestione della sessione.
 */
'use strict';

const jwt = require('jsonwebtoken');
const {
  test, before, after,
} = require('node:test');
const h = require('./helper');

before(async () => { await h.avvia(); await h.resetDati(); });
after(async () => { await h.chiudi(); });

/* ------------------------------ LOGIN ------------------------------ */

test('login con credenziali valide → 200 + cookie di sessione + profilo', async () => {
  const { status, cookie, dati } = await h.login(h.DIP1.matricola, h.DIP1.password);
  h.assert.equal(status, 200);
  h.assert.match(cookie, /token=/);
  h.assert.match(cookie, /HttpOnly/i);
  h.assert.equal(dati.utente.matricola, h.DIP1.matricola);
  h.assert.equal(dati.utente.ruolo, 'DIPENDENTE');
  h.assert.equal(dati.utente.mustChangePassword, false);
});

test('login con password errata → 401 messaggio generico (non rivela la matricola)', async () => {
  const { status, dati } = await h.login(h.DIP1.matricola, 'PasswordSbagliata1');
  h.assert.equal(status, 401);
  h.assert.equal(dati.errore, 'Matricola o password non valide.');
});

test('login con matricola inesistente → 401 stesso identico messaggio', async () => {
  const { status, dati } = await h.login('inesistente', 'Qualsiasi123');
  h.assert.equal(status, 401);
  h.assert.equal(dati.errore, 'Matricola o password non valide.');
});

test('login con matricola disabilitata → 403', async () => {
  const id = await h.idDi(h.DIP2.matricola);
  const { cookie: cookieAdmin } = await h.login(h.ADMIN.matricola, h.ADMIN.password);
  await h.chiedi(`/api/admin/utenti/${id}/stato`, { method: 'PUT', cookie: cookieAdmin, body: { attivo: false } });

  const { status, dati } = await h.login(h.DIP2.matricola, h.DIP2.password);
  h.assert.equal(status, 403);
  h.assert.match(dati.errore, /disabilitato/i);
});

test('anti SQL injection: matricola con payload SQL → 401, mai 200/500', async () => {
  const { status } = await h.login("' OR '1'='1' -- ", 'x');
  h.assert.equal(status, 401);
});

test('rate limiting: 5 fallimenti → il 6° tentativo è 429', async () => {
  for (let i = 0; i < 5; i++) {
    const { status } = await h.login('rc000', 'Sbagliata1');
    h.assert.equal(status, 401);
  }
  const { status } = await h.login('rc000', 'Sbagliata1');
  h.assert.equal(status, 429);
});

/* --------------------------- SESSIONE / ME -------------------------- */

test('GET /api/auth/me con cookie valido → 200', async () => {
  const { cookie } = await h.login(h.DIP1.matricola, h.DIP1.password);
  const { status, dati } = await h.chiedi('/api/auth/me', { cookie });
  h.assert.equal(status, 200);
  h.assert.equal(dati.utente.matricola, h.DIP1.matricola);
});

test('GET /api/auth/me senza cookie → 401', async () => {
  const { status } = await h.chiedi('/api/auth/me');
  h.assert.equal(status, 401);
});

test('GET /api/auth/me con token REVOCATO (logout) → 401 e cookie cancellato', async () => {
  const { cookie } = await h.login(h.DIP1.matricola, h.DIP1.password);
  const uscita = await h.chiedi('/api/auth/logout', { method: 'POST', cookie });
  h.assert.equal(uscita.status, 200);
  // il client continua a presentare il vecchio cookie: deve essere rifiutato
  const dopo = await h.chiedi('/api/auth/me', { cookie });
  h.assert.equal(dopo.status, 401);
  h.assert.match(dopo.r.headers.get('set-cookie') || '', /token=;/);
});

test('token manomesso (firma invalida) → 401', async () => {
  const falso = jwt.sign({ id: 1, matricola: h.ADMIN.matricola }, 'segreto-sbagliato');
  const { status } = await h.chiedi('/api/auth/me', { cookie: `token=${falso}` });
  h.assert.equal(status, 401);
});

test('token scaduto → 401', async () => {
  const id = await h.idDi(h.ADMIN.matricola);
  const breve = jwt.sign({ id, matricola: h.ADMIN.matricola }, h.JWT_SECRET_TEST, { expiresIn: '1s' });
  await new Promise((r) => setTimeout(r, 1300));
  const { status } = await h.chiedi('/api/auth/me', { cookie: `token=${breve}` });
  h.assert.equal(status, 401);
});

test('logout → 200; la sessione non è più valida', async () => {
  const { cookie } = await h.login(h.DIP1.matricola, h.DIP1.password);
  const uscita = await h.chiedi('/api/auth/logout', { method: 'POST', cookie });
  h.assert.equal(uscita.status, 200);
  const dopo = await h.chiedi('/api/auth/me', { cookie });
  h.assert.equal(dopo.status, 401);
});

test('account disabilitato con sessione attiva → subito 401 su /me', async () => {
  // BUG#2 (lato server): la disabilitazione deve valere IMMEDIATAMENTE
  const id = await h.idDi(h.DIP2.matricola);
  const { cookie: cookieAdmin } = await h.login(h.ADMIN.matricola, h.ADMIN.password);
  // riabilita (test precedenti lo hanno disabilitato)…
  await h.chiedi(`/api/admin/utenti/${id}/stato`, { method: 'PUT', cookie: cookieAdmin, body: { attivo: true } });

  const { cookie } = await h.login(h.DIP2.matricola, h.DIP2.password);
  h.assert.equal((await h.chiedi('/api/auth/me', { cookie })).status, 200);

  // …poi disabilita: la sessione appena creata deve morire all'istante
  await h.chiedi(`/api/admin/utenti/${id}/stato`, { method: 'PUT', cookie: cookieAdmin, body: { attivo: false } });
  h.assert.equal((await h.chiedi('/api/auth/me', { cookie })).status, 401);
});

/* ------------------------- CAMBIO PASSWORD -------------------------- */

test('cambio password: attuale errata → 401', async () => {
  const { cookie } = await h.login(h.DIP1.matricola, h.DIP1.password);
  const { status } = await h.chiedi('/api/auth/password', {
    method: 'PUT', cookie, body: { passwordAttuale: 'Errata123', nuovaPassword: 'NuovaPass123' },
  });
  h.assert.equal(status, 401);
});

test('cambio password: nuova debole → 400', async () => {
  const { cookie } = await h.login(h.DIP1.matricola, h.DIP1.password);
  const { status, dati } = await h.chiedi('/api/auth/password', {
    method: 'PUT', cookie, body: { passwordAttuale: h.DIP1.password, nuovaPassword: 'abc' },
  });
  h.assert.equal(status, 400);
  h.assert.match(dati.errore, /8 caratteri/i);
});

test('cambio password: uguale alla precedente → 400', async () => {
  const { cookie } = await h.login(h.DIP1.matricola, h.DIP1.password);
  const { status } = await h.chiedi('/api/auth/password', {
    method: 'PUT', cookie, body: { passwordAttuale: h.DIP1.password, nuovaPassword: h.DIP1.password },
  });
  h.assert.equal(status, 400);
});

test('cambio password corretto → 200, la vecchia non funziona più, la nuova sì', async () => {
  const { cookie } = await h.login(h.DIP1.matricola, h.DIP1.password);
  const { status } = await h.chiedi('/api/auth/password', {
    method: 'PUT', cookie, body: { passwordAttuale: h.DIP1.password, nuovaPassword: 'NuovaPass123' },
  });
  h.assert.equal(status, 200);

  const vecchia = await h.login(h.DIP1.matricola, h.DIP1.password);
  h.assert.equal(vecchia.status, 401);

  const nuova = await h.login(h.DIP1.matricola, 'NuovaPass123');
  h.assert.equal(nuova.status, 200);

  // ripristino per gli altri test
  await h.chiedi('/api/auth/password', {
    method: 'PUT', cookie: nuova.cookie, body: { passwordAttuale: 'NuovaPass123', nuovaPassword: h.DIP1.password },
  });
});

/* ----------------------------- PERMESSI ----------------------------- */

test('dipendente su API admin → 403 (stats, lista utenti, creazione, export)', async () => {
  const { cookie } = await h.login(h.DIP1.matricola, h.DIP1.password);
  h.assert.equal((await h.chiedi('/api/admin/stats', { cookie })).status, 403);
  h.assert.equal((await h.chiedi('/api/admin/utenti', { cookie })).status, 403);
  h.assert.equal((await h.chiedi('/api/admin/utenti', {
    method: 'POST', cookie, body: { matricola: 'hx999', nome: 'Hacker', cognome: 'Test' },
  })).status, 403);
  h.assert.equal((await h.chiedi('/api/admin/certificati/export', { cookie })).status, 403);
});

test('dipendente non può modificare il proprio stato né eliminare certificati', async () => {
  const { cookie } = await h.login(h.DIP1.matricola, h.DIP1.password);
  const id = await h.idDi(h.DIP1.matricola);
  h.assert.equal((await h.chiedi(`/api/admin/utenti/${id}/stato`, {
    method: 'PUT', cookie, body: { attivo: false },
  })).status, 403);
  h.assert.equal((await h.chiedi('/api/admin/certificati/1', { method: 'DELETE', cookie })).status, 403);
});

test('endpoint di salute pubblico senza autenticazione → 200', async () => {
  const { status } = await h.chiedi('/api/salute');
  h.assert.equal(status, 200);
});

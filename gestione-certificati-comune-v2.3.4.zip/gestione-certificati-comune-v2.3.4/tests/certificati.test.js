/**
 * certificati.test.js — Upload/download PDF, creazione automatica e
 * self-healing delle cartelle, permessi sui file, approvazioni, eliminazione,
 * race condition sui nomi file, export CSV con anti formula-injection.
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { test, before, after } = require('node:test');
const h = require('./helper');

let percorsiDipCache = [];

/** Ricarica dal DB i certificati del dipendente qa001 (id crescente → ultimo = più recente). */
async function aggiornaCache() {
  percorsiDipCache = await percorsiDip(h.DIP1.matricola);
  return percorsiDipCache;
}

before(async () => { await h.avvia(); await h.resetDati(); });
after(async () => { await h.chiudi(); });

async function dipCookie() {
  const { cookie } = await h.login(h.DIP1.matricola, h.DIP1.password);
  return cookie;
}
async function adminCookie() {
  const { cookie } = await h.login(h.ADMIN.matricola, h.ADMIN.password);
  return cookie;
}
/* v2.0: le cartelle sono nominate col CODICE FISCALE → si parte dalla
 * matricola e si recupera il CF corrispondente. */
function cartellaDip(cf) {
  return path.join(h.DIR_CERT, cf);
}
async function cfDi(matricola) {
  const [r] = await h.pool.query('SELECT codice_fiscale FROM dipendenti WHERE matricola = ?', [matricola]);
  return r[0].codice_fiscale;
}
async function percorsiDip(matricola, corso = null) {
  const [righe] = await h.pool.query(
    `SELECT c.id, c.percorso_file, c.stato, c.nome_corso FROM certificati c
     JOIN dipendenti d ON d.id = c.dipendente_id
     WHERE d.matricola = ? ${corso ? 'AND c.nome_corso = ?' : ''}
     ORDER BY c.id ASC`, corso ? [matricola, corso] : [matricola]);
  return righe;
}

/* ------------------------------ UPLOAD ------------------------------ */

test('upload PDF valido → 201, file su disco con nome univoco, riga DB IN_ATTESA', async () => {
  const c = await dipCookie();
  const { status, dati } = await h.chiedi('/api/certificati', {
    method: 'POST', cookie: c,
    formData: h.uploadFormData({
      corso: 'Sicurezza base QA', ente: 'Ente QA', data: '2026-02-01', nomeFile: 'attestato.pdf',
    }),
  });
  h.assert.equal(status, 201);

  const righe = await percorsiDip(h.DIP1.matricola);
  h.assert.equal(righe.length, 1);
  h.assert.equal(righe[0].stato, 'IN_ATTESA');
  h.assert.match(righe[0].percorso_file, /^certificati\/VRDLGU80M01H501B\/\d{13}-[0-9a-f]{8}_attestato\.pdf$/,
    'formato {timestamp}-{random}_{nome}.pdf (univoco)');

  // v1.4: i nuovi campi obbligatori sono memorizzati correttamente
  const [riga] = await h.pool.query('SELECT numero_ore, esame_finale, area_tematica FROM certificati WHERE id = ?', [righe[0].id]);
  h.assert.equal(riga[0].numero_ore, 8);
  h.assert.equal(riga[0].esame_finale, 1);
  h.assert.equal(riga[0].area_tematica, 'Transizione digitale');

  const assoluto = path.resolve(path.dirname(h.DIR_CERT), righe[0].percorso_file);
  h.assert.ok(fs.existsSync(assoluto), 'il file esiste sul file system');
  h.assert.ok(fs.statSync(assoluto).size > 100);
  await aggiornaCache();
});

test('upload file non-PDF (testo rinominato .pdf) → 400 e NESSUN file orfano', async () => {
  const c = await dipCookie();
  const prima = fs.readdirSync(cartellaDip(await cfDi(h.DIP1.matricola))).length;

  const { status, dati } = await h.chiedi('/api/certificati', {
    method: 'POST', cookie: c,
    formData: h.uploadFormData({
      corso: 'Falso PDF', ente: 'Ente', data: '2026-02-01', nomeFile: 'falso.pdf',
      buffer: Buffer.from('QUESTO NON E UN PDF'), tipo: 'application/pdf',
    }),
  });
  h.assert.equal(status, 400);
  h.assert.match(dati.errore, /PDF/i);
  h.assert.equal(fs.readdirSync(cartellaDip(await cfDi(h.DIP1.matricola))).length, prima, 'nessun file lasciato');
});

test('upload con estensione sbagliata → 400', async () => {
  const { status } = await h.chiedi('/api/certificati', {
    method: 'POST', cookie: await dipCookie(),
    formData: h.uploadFormData({
      corso: 'Documento Word', ente: 'Ente', data: '2026-02-01',
      nomeFile: 'documento.docx', buffer: Buffer.from('%PDF-qualcosa'), tipo: 'application/msword',
    }),
  });
  h.assert.equal(status, 400);
});

test('upload > 5 MB → 400', async () => {
  const grande = Buffer.concat([h.pdfBuffer('Grande'), Buffer.alloc(5 * 1024 * 1024, 65)]);
  const { status, dati } = await h.chiedi('/api/certificati', {
    method: 'POST', cookie: await dipCookie(),
    formData: h.uploadFormData({
      corso: 'Troppo grande', ente: 'Ente', data: '2026-02-01',
      nomeFile: 'grande.pdf', buffer: grande,
    }),
  });
  h.assert.equal(status, 400);
  h.assert.match(dati.errore, /5 MB/i);
});

test('upload con data futura o campi mancanti → 400', async () => {
  const c = await dipCookie();
  h.assert.equal((await h.chiedi('/api/certificati', {
    method: 'POST', cookie: c,
    formData: h.uploadFormData({ corso: 'Nel futuro', ente: 'Ente', data: '2030-01-01' }),
  })).status, 400);
  h.assert.equal((await h.chiedi('/api/certificati', {
    method: 'POST', cookie: c,
    formData: h.uploadFormData({ corso: 'x', ente: 'Ente', data: '2026-01-01' }),
  })).status, 400);
});

test('v1.4: numero_ore non valido → 400 (0, mancante, non intero, oltre limite)', async () => {
  const c = await dipCookie();
  h.assert.equal((await h.chiedi('/api/certificati', {
    method: 'POST', cookie: c,
    formData: h.uploadFormData({ corso: 'Ore a zero', ente: 'Ente', data: '2026-02-01', ore: '0' }),
  })).status, 400);
  h.assert.equal((await h.chiedi('/api/certificati', {
    method: 'POST', cookie: c,
    formData: h.uploadFormData({ corso: 'Ore mancanti', ente: 'Ente', data: '2026-02-01', ore: '' }),
  })).status, 400);
  h.assert.equal((await h.chiedi('/api/certificati', {
    method: 'POST', cookie: c,
    formData: h.uploadFormData({ corso: 'Ore decimali', ente: 'Ente', data: '2026-02-01', ore: '7.5' }),
  })).status, 400);
  h.assert.equal((await h.chiedi('/api/certificati', {
    method: 'POST', cookie: c,
    formData: h.uploadFormData({ corso: 'Ore assurde', ente: 'Ente', data: '2026-02-01', ore: '10000' }),
  })).status, 400);
});

test('v1.4: area tematica mancante o fuori elenco → 400', async () => {
  const c = await dipCookie();
  h.assert.equal((await h.chiedi('/api/certificati', {
    method: 'POST', cookie: c,
    formData: h.uploadFormData({ corso: 'Senza area', ente: 'Ente', data: '2026-02-01', area: '' }),
  })).status, 400);
  h.assert.equal((await h.chiedi('/api/certificati', {
    method: 'POST', cookie: c,
    formData: h.uploadFormData({ corso: 'Area inventata', ente: 'Ente', data: '2026-02-01', area: 'Area fantasiosa' }),
  })).status, 400);
});

test('v1.4: esame_finale assente → salvato come 0 (booleano non spuntato)', async () => {
  const { status } = await h.chiedi('/api/certificati', {
    method: 'POST', cookie: await dipCookie(),
    formData: h.uploadFormData({ corso: 'Senza esame', ente: 'Ente', data: '2026-02-01', esame: '0' }),
  });
  h.assert.equal(status, 201);
});

test('BUG#3c (self-healing): cartella cancellata → l\'upload la ricrea', async () => {
  fs.rmSync(cartellaDip(await cfDi(h.DIP1.matricola)), { recursive: true, force: true }); // v2.0: cartella CF
  const { status } = await h.chiedi('/api/certificati', {
    method: 'POST', cookie: await dipCookie(),
    formData: h.uploadFormData({ corso: 'Ricreazione cartella', ente: 'Ente QA', data: '2026-02-02' }),
  });
  h.assert.equal(status, 201);
  h.assert.ok(fs.existsSync(cartellaDip(await cfDi(h.DIP1.matricola))), 'cartella {CF} ricreata al volo');
  await aggiornaCache();
});

test('RACE CONDITION: 5 upload simultanei stesso nome → 5 file DISTINCTI, nessuna sovrascrittura', async () => {
  const risultati = await Promise.all([1, 2, 3, 4, 5].map(async () => h.chiedi('/api/certificati', {
    method: 'POST', cookie: await dipCookie(),
    formData: h.uploadFormData({ corso: 'Concorrente', ente: 'Ente QA', data: '2026-02-03', nomeFile: 'uguale.pdf' }),
  })));
  h.assert.ok(risultati.every((r) => r.status === 201), 'tutti gli upload hanno successo');

  const righe = await percorsiDip(h.DIP1.matricola, 'Concorrente');
  h.assert.equal(righe.length, 5, '5 righe registrate');
  const percorsi = righe.map((r) => r.percorso_file);
  h.assert.equal(new Set(percorsi).size, percorsi.length, 'percorso_file tutti diversi');
  for (const rel of percorsi) {
    const assoluto = path.resolve(path.dirname(h.DIR_CERT), rel);
    h.assert.ok(fs.existsSync(assoluto), `esiste: ${path.basename(assoluto)}`);
  }
  await aggiornaCache();
});

/* ----------------------- DOWNLOAD / PERMESSI ------------------------ */

test('il proprietario scarica e visualizza il proprio PDF', async () => {
  const id = percorsiDipCache.at(-1).id;
  const c = await dipCookie();

  const down = await h.chiedi(`/api/certificati/${id}/file`, { cookie: c });
  h.assert.equal(down.status, 200);
  h.assert.ok(down.testo.startsWith('%PDF-'), 'contenuto PDF autentico');

  const view = await h.chiedi(`/api/certificati/${id}/file?modo=visualizza`, { cookie: c });
  h.assert.equal(view.status, 200);
  h.assert.match(view.headers.get('content-disposition') || '', /inline/);
  h.assert.equal(view.headers.get('content-type'), 'application/pdf');
});

test("un ALTRO dipendente NON può accedere al PDF altrui → 403", async () => {
  const id = percorsiDipCache.at(-1).id;
  const { cookie } = await h.login(h.DIP2.matricola, h.DIP2.password);
  const { status } = await h.chiedi(`/api/certificati/${id}/file`, { cookie });
  h.assert.equal(status, 403);
});

test("l'admin può scaricare il certificato di chiunque → 200", async () => {
  const id = percorsiDipCache.at(-1).id;
  const { status } = await h.chiedi(`/api/certificati/${id}/file`, { cookie: await adminCookie() });
  h.assert.equal(status, 200);
});

test('identificatori ostili → 400/404 (mai 500)', async () => {
  const c = await dipCookie();
  h.assert.equal((await h.chiedi('/api/certificati/abc/file', { cookie: c })).status, 400);
  h.assert.equal((await h.chiedi('/api/certificati/999999/file', { cookie: c })).status, 404);
  h.assert.equal((await h.chiedi('/api/certificati/0/file', { cookie: c })).status, 400);
});

test('elenco dipendente: solo i PROPRI certificati', async () => {
  // qa002 carica un suo certificato
  await h.chiedi('/api/certificati', {
    method: 'POST', cookie: (await h.login(h.DIP2.matricola, h.DIP2.password)).cookie,
    formData: h.uploadFormData({ corso: 'Solo mio', ente: 'Ente', data: '2026-02-04' }),
  });
  const { dati } = await h.chiedi('/api/certificati', { cookie: await dipCookie() });
  h.assert.ok(dati.certificati.every((x) => x.nome_corso !== 'Solo mio'));
  h.assert.ok(dati.certificati.length >= 1);
});

/* -------------------- APPROVAZIONE / ELIMINAZIONE ------------------- */

test('admin approva, poi rifiuta con nota; i requisiti si riflettono nel DB', async () => {
  const c = await adminCookie();
  const id = percorsiDipCache.at(-1).id;

  const ok = await h.chiedi(`/api/admin/certificati/${id}/stato`, {
    method: 'PUT', cookie: c, body: { stato: 'APPROVATO' },
  });
  h.assert.equal(ok.status, 200);
  const aggiornate = await percorsiDip(h.DIP1.matricola);
  h.assert.equal(aggiornate.find((r) => r.id === id).stato, 'APPROVATO');

  const ko = await h.chiedi(`/api/admin/certificati/${id}/stato`, {
    method: 'PUT', cookie: c, body: { stato: 'RIFIUTATO', note: 'Scan illeggibile QA' },
  });
  h.assert.equal(ko.status, 200);
  const [riga] = await h.pool.query('SELECT stato, note_admin, approvato_il FROM certificati WHERE id = ?', [id]);
  h.assert.equal(riga[0].stato, 'RIFIUTATO');
  h.assert.equal(riga[0].note_admin, 'Scan illeggibile QA');
  h.assert.ok(riga[0].approvato_il, 'audit della decisione presente');

  h.assert.equal((await h.chiedi(`/api/admin/certificati/${id}/stato`, {
    method: 'PUT', cookie: c, body: { stato: 'FORSE' },
  })).status, 400);
});

test('DELETE certificato: rimuove riga DB E file fisico', async () => {
  const id = percorsiDipCache.at(-1).id;
  const assoluto = path.resolve(path.dirname(h.DIR_CERT), percorsiDipCache.find((r) => r.id === id).percorso_file);
  h.assert.ok(fs.existsSync(assoluto));

  const { status } = await h.chiedi(`/api/admin/certificati/${id}`, { method: 'DELETE', cookie: await adminCookie() });
  h.assert.equal(status, 200);
  h.assert.ok(!fs.existsSync(assoluto), 'file eliminato dal disco');
  h.assert.equal((await h.pool.query('SELECT id FROM certificati WHERE id = ?', [id]))[0][0], undefined);
});

/* ---------------------------- EXPORT CSV ---------------------------- */

test('export CSV: BOM, intestazione, anti formula-injection, solo admin', async () => {
  // certificato "pericoloso" caricato da qa002
  await h.chiedi('/api/certificati', {
    method: 'POST', cookie: (await h.login(h.DIP2.matricola, h.DIP2.password)).cookie,
    formData: h.uploadFormData({ corso: '=1+1 SOMMA PERICOLOSA', ente: 'Ente', data: '2026-02-05' }),
  });

  const { r, buf, testo, status } = await h.chiedi('/api/admin/certificati/export', { cookie: await adminCookie() });
  h.assert.equal(status, 200);
  h.assert.ok(buf.subarray(0, 3).equals(Buffer.from([0xEF, 0xBB, 0xBF])), 'BOM UTF-8 per Excel');
  h.assert.ok(testo.includes('ID;Matricola;Codice Fiscale;Cognome;Nome;Sesso;Qualifica;Corso;Ente erogatore;Data conseguimento;Numero ore;Esame finale;Area tematica'),
    'intestazione v2.0 completa (anagrafica con CF + dettagli corso)');
  h.assert.ok(testo.includes('Link PDF'), 'colonna con il riferimento al PDF');
  h.assert.ok(testo.includes("'=1+1 SOMMA PERICOLOSA"), 'formula neutralizzata con apice');
  h.assert.equal(r.headers.get('content-type'), 'text/csv; charset=utf-8');

  // il dipendente non può esportare
  h.assert.equal((await h.chiedi('/api/admin/certificati/export', { cookie: await dipCookie() })).status, 403);
});

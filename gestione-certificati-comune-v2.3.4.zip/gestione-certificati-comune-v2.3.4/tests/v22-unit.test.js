/**
 * ============================================================================
 *  v22-unit.test.js — UNIT TEST DELLE NOVITÀ v2.2
 * ============================================================================
 *  Copertura diretta dei nuovi comportamenti:
 *    · tipoDaFirma    → riconoscimento PDF / JPEG / PNG dalla firma binaria;
 *    · formattaDurata → durata "8" / "8:30" / "0:45";
 *    · validaDatiCertificato → durata Ore:Minuti (0 ore con minuti ≥ 1 è
 *      ora VALIDA; 0:00 resta invalida; minuti 60 → rifiutati).
 *  Test PURI: nessun server, nessun database.
 * ============================================================================
 */
'use strict';

process.env.UPLOAD_DIR = 'uploads-test'; // prima dei require di src/

const assert = require('node:assert/strict');
const { test } = require('node:test');

const F = require('../src/utils/file');
const V = require('../src/utils/validazione');

/* --------------------------- tipoDaFirma --------------------------- */

test('[v2.2] tipoDaFirma: riconosce PDF, JPEG e PNG dalla firma binaria', () => {
  assert.equal(F.tipoDaFirma(Buffer.from('%PDF-1.7\n corpo')), 'pdf');
  assert.equal(F.tipoDaFirma(Buffer.from([0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46])), 'jpeg');
  assert.equal(F.tipoDaFirma(Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00])), 'png');
});

test('[v2.2] tipoDaFirma: rifiuta file travestiti, buffer corti e tipi errati', () => {
  // un .exe/.txt rinominato .pdf o .jpg NON deve passare
  assert.equal(F.tipoDaFirma(Buffer.from('MZ\x90\x00seguro eseguibile!')), null);
  assert.equal(F.tipoDaFirma(Buffer.from('testo qualsiasi non binario')), null);
  // firma JPEG troncata (solo 2 byte) → non riconoscibile
  assert.equal(F.tipoDaFirma(Buffer.from([0xFF, 0xD8])), null);
  assert.equal(F.tipoDaFirma(Buffer.alloc(0)), null);
  assert.equal(F.tipoDaFirma('stringa'), null);
  assert.equal(F.tipoDaFirma(null), null);
  // firma quasi-PNG (1 byte diverso) → rifiutata
  const falsoPng = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0B]);
  assert.equal(F.tipoDaFirma(falsoPng), null);
});

/* --------------------------- formattaDurata --------------------------- */

test('[v2.2] formattaDurata: "8", "8:30", "0:45" e casi sporchi', () => {
  assert.equal(F.formattaDurata(8, 0), '8');
  assert.equal(F.formattaDurata(8, 30), '8:30');
  assert.equal(F.formattaDurata(0, 45), '0:45');
  assert.equal(F.formattaDurata(12, 5), '12:05');   // padStart a 2 cifre
  assert.equal(F.formattaDurata(null, null), '0');  // input assenti → 0
  assert.equal(F.formattaDurata('3', '7'), '3:07'); // stringhe numeriche
});

/* --------------------- durata Ore:Minuti (validazione) --------------------- */

const BASE = {
  nome_corso: 'Corso breve', ente_erogatore: 'Ente', data_conseguimento: '2025-06-01',
  numero_ore: '8', esame_finale: '0', area_tematica: 'Transizione digitale',
};

test('[v2.2] durata: 0 ore + 45 minuti ora è VALIDA (corsi sotto l\u2019ora)', () => {
  const { errori, valori } = V.validaDatiCertificato({ ...BASE, numero_ore: '0', numero_minuti: '45' });
  assert.deepEqual(errori, []);
  assert.equal(valori.numeroOre, 0);
  assert.equal(valori.numeroMinuti, 45);
});

test('[v2.2] durata: senza minuti tutto resta come v1.x ("8" → 8h, 0 minuti)', () => {
  const { errori, valori } = V.validaDatiCertificato({ ...BASE });
  assert.deepEqual(errori, []);
  assert.equal(valori.numeroOre, 8);
  assert.equal(valori.numeroMinuti, 0);
});

test('[v2.2] durata: 0 ore e 0 minuti → rifiutata (la durata serve)', () => {
  const r = V.validaDatiCertificato({ ...BASE, numero_ore: '0', numero_minuti: '0' });
  assert.ok(r.errori.some((e) => /almeno 1 minuto/.test(e)));
  // anche OMETTENDO i minuti (come i client v1.x)
  const r2 = V.validaDatiCertificato({ ...BASE, numero_ore: '0' });
  assert.ok(r2.errori.some((e) => /almeno 1 minuto/.test(e)));
});

test('[v2.2] durata: minuti fuori range e non numerici', () => {
  for (const cattivo of ['60', '61', '-5', '7.5', 'abc', '100']) {
    const { errori } = V.validaDatiCertificato({ ...BASE, numero_minuti: cattivo });
    assert.ok(errori.some((e) => /minuti/.test(e)), `minuti "${cattivo}" deve essere rifiutato`);
  }
  for (const buono of ['0', '5', '59', '  30  ', '']) {
    const { errori } = V.validaDatiCertificato({ ...BASE, numero_minuti: buono });
    assert.ok(!errori.some((e) => /minuti/.test(e)), `minuti "${buono}" deve passare`);
  }
});

test('[v2.2] durata: ore 0 AMMESSE solo con minuti ≥ 1; ore negative/no testuali rifiutate', () => {
  assert.ok(!V.validaDatiCertificato({ ...BASE, numero_ore: '0', numero_minuti: '15' }).errori.length);
  for (const cattivo of ['-1', '12.5', 'otto', '10000']) {
    const { errori } = V.validaDatiCertificato({ ...BASE, numero_ore: cattivo, numero_minuti: '30' });
    assert.ok(errori.some((e) => /ore/.test(e)), `ore "${cattivo}" deve essere rifiutato`);
  }
});

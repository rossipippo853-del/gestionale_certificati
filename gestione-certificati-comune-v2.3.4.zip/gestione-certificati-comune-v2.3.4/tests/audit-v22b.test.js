/**
 * ============================================================================
 *  audit-v22b.test.js — AUDITORIA QA ROUND 2 (unit): superficie v2.2
 * ============================================================================
 *  Secondo giro di auditoria Principal QA, dedicato alle NOVITÀ v2.2:
 *    · F4 (regressione): i client JSON possono inviare ore/minuti NUMERICI —
 *      prima del fix venivano rifiutati (ore) o AZZERATI in silenzio (minuti);
 *    · tipi ostili per i campi durata (booleani, array, null, oggetti);
 *    · tipoDaFirma: limite documentato della verifica per firma (PNG di
 *      esattamente 8 byte passa: è una verifica di TIPO, non di integrità
 *      dell'immagine — come del resto era per i PDF nelle versioni precedenti).
 * ============================================================================
 */
'use strict';

process.env.UPLOAD_DIR = 'uploads-test'; // prima dei require di src/

const assert = require('node:assert/strict');
const { test } = require('node:test');

const F = require('../src/utils/file');
const V = require('../src/utils/validazione');

const BASE = {
  nome_corso: 'Corso audit', ente_erogatore: 'Ente audit', data_conseguimento: '2025-06-01',
  numero_ore: '8', esame_finale: '0', area_tematica: 'Transizione digitale',
};

/* ---------------- F4: campi durata numerici da client JSON ---------------- */

test('[audit F4] ore e minuti NUMERICI (client JSON) ora sono accettati', () => {
  const { errori, valori } = V.validaDatiCertificato({ ...BASE, numero_ore: 8, numero_minuti: 30 });
  assert.deepEqual(errori, []);
  assert.equal(valori.numeroOre, 8);
  assert.equal(valori.numeroMinuti, 30); // prima del fix: 0 (PERDITA di dato silenziosa)
});

test('[audit F4] 0 ore + minuti numerici 45 → valida (prima: 400)', () => {
  const { errori, valori } = V.validaDatiCertificato({ ...BASE, numero_ore: '0', numero_minuti: 45 });
  assert.deepEqual(errori, []);
  assert.equal(valori.numeroMinuti, 45);
});

test('[audit] numeri con decimali o negativi restano rifiutati anche da JSON', () => {
  assert.ok(V.validaDatiCertificato({ ...BASE, numero_minuti: 7.5 }).errori.some((e) => /minuti/.test(e)));
  assert.ok(V.validaDatiCertificato({ ...BASE, numero_ore: -2 }).errori.some((e) => /ore/.test(e)));
  assert.ok(V.validaDatiCertificato({ ...BASE, numero_ore: 8.5 }).errori.some((e) => /ore/.test(e)));
});

test('[audit] tipi ostili: boolean/array/null/oggetto trattati in modo sicuro', () => {
  // boolean → trattato come ASSENTE (minuti 0) o rifiutato per le ore: mai crash, mai valori inventati
  const boolMinuti = V.validaDatiCertificato({ ...BASE, numero_minuti: true });
  assert.ok(!boolMinuti.errori.some((e) => /minuti/.test(e)), 'boolean minuti → assente (0), non errore');
  assert.ok(V.validaDatiCertificato({ ...BASE, numero_ore: true }).errori.some((e) => /ore/.test(e)),
    'boolean ore → rifiutato (le ore servono)');
  // array → normalizzato al PRIMO valore (comportamento storico QA-B5 per
  // i parametri ripetuti): ['8'] vale 8; oggetto/null → rifiutati
  const arrayOtto = V.validaDatiCertificato({ ...BASE, numero_ore: ['8'] });
  assert.deepEqual(arrayOtto.errori.filter((e) => /ore/.test(e)), []);
  assert.equal(arrayOtto.valori.numeroOre, 8);
  assert.ok(V.validaDatiCertificato({ ...BASE, numero_ore: { a: 8 } }).errori.some((e) => /ore/.test(e)));
  assert.ok(V.validaDatiCertificato({ ...BASE, numero_ore: null, numero_minuti: null })
    .errori.length > 0, 'tutto nullo → rifiutato (errore di ore o di durata)');
  // NaN e Infinity non devono produrre strani effetti
  assert.ok(V.validaDatiCertificato({ ...BASE, numero_ore: NaN }).errori.some((e) => /ore/.test(e)));
});

/* ---------------- tipoDaFirma: limite documentato ---------------- */

test('[audit] tipoDaFirma: PNG di esattamente 8 byte (solo firma) è riconosciuto', () => {
  // La verifica è di TIPO (firma binaria), non di integrità dell'immagine:
  // un file troncato alla firma passa, esattamente come un PDF di 5 byte.
  const pngMinimo = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
  assert.equal(F.tipoDaFirma(pngMinimo), 'png');
});

test('[audit] formattaDurata: input come stringhe con zero iniziali e confini', () => {
  assert.equal(F.formattaDurata('08', '05'), '8:05');
  assert.equal(F.formattaDurata(0, 59), '0:59');
  assert.equal(F.formattaDurata(9999, 59), '9999:59');
});

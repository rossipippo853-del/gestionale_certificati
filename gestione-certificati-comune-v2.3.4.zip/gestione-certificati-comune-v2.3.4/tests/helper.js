/**
 * helper.js — infrastruttura condivisa dalla suite di test.
 *
 * - imposta le variabili d'ambiente PRIMA di importare l'app
 *   (database dedicato `certificati_comune_test`, upload in `uploads-test`,
 *    porta 3100): i test non toccano mai i dati reali;
 * - avvia/arresta il server HTTP;
 * - fornisce fixture note (1 admin + 2 dipendenti), helper di login/richiesta
 *   e un generatore di PDF validi.
 *
 * I file di test vengono eseguiti in processi separati e sequenziali
 * (`npm test` usa --test-concurrency=1): ogni processo chiude server e pool
 * nell'hook `after`.
 */
'use strict';

process.env.NODE_ENV = 'test';
process.env.DB_HOST = '127.0.0.1';
process.env.DB_PORT = '3306';
process.env.DB_USER = 'cert_app';
process.env.DB_PASSWORD = 'C3rt!2026Demo';
process.env.DB_NAME = 'certificati_comune_test';
process.env.JWT_SECRET = 'segreto-di-test-qa-suite-non-usare-in-prod';
process.env.JWT_SCADENZA = '8h';
process.env.COOKIE_SECURE = 'false';
process.env.UPLOAD_DIR = 'uploads-test';

const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const bcrypt = require('bcryptjs');
const { app } = require('../src/app');
const { pool } = require('../src/db');

const BASE = 'http://127.0.0.1:3100';
const JWT_SECRET_TEST = process.env.JWT_SECRET;
const DIR_CERT = path.resolve(__dirname, '..', 'uploads-test', 'certificati');

/* v2.0: ogni fixture ha un Codice Fiscale (formato italiano valido, univoco):
 * è la chiave delle cartelle uploads/certificati/{cf}/. */
const ADMIN = { matricola: 'qa000', codice_fiscale: 'ZNCMNA70A01H501A', nome: 'Amministra', cognome: 'Zione', password: 'AdminQa2026' };
const DIP1 = { matricola: 'qa001', codice_fiscale: 'VRDLGU80M01H501B', nome: 'Luigi', cognome: 'Verde', password: 'DipQa2026' };
const DIP2 = { matricola: 'qa002', codice_fiscale: 'GLLANN85C15G822C', nome: 'Anna', cognome: 'Gialli', password: 'DipQa2026' };

let server = null;

async function avvia() {
  if (server) return;
  server = app.listen(3100, '127.0.0.1');
  await new Promise((risolvi) => server.once('listening', risolvi));
}

/** Svuota tabelle e cartelle upload, poi ricrea le fixture note. */
async function resetDati() {
  // DELETE (non TRUNCATE, che richiederebbe il privilegio DROP) su un'unica
  // connessione: prima la tabella figlia, poi quella padre.
  const conn = await pool.getConnection();
  try {
    await conn.query('SET FOREIGN_KEY_CHECKS = 0');
    await conn.query('DELETE FROM allegati');
    await conn.query('DELETE FROM certificati');
    await conn.query('DELETE FROM dipendenti');
    await conn.query('SET FOREIGN_KEY_CHECKS = 1');
  } finally {
    conn.release();
  }

  fs.rmSync(DIR_CERT, { recursive: true, force: true });
  fs.mkdirSync(DIR_CERT, { recursive: true });

  const hashAdmin = await bcrypt.hash(ADMIN.password, 4);
  const hashDip = await bcrypt.hash(DIP1.password, 4);
  const ins = `INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, password_hash, ruolo, attivo, must_change_password)
               VALUES (?, ?, ?, ?, ?, ?, 1, 0)`;
  await pool.query(ins, [ADMIN.matricola, ADMIN.codice_fiscale, ADMIN.nome, ADMIN.cognome, hashAdmin, 'AMMINISTRATORE']);
  await pool.query(ins, [DIP1.matricola, DIP1.codice_fiscale, DIP1.nome, DIP1.cognome, hashDip, 'DIPENDENTE']);
  await pool.query(ins, [DIP2.matricola, DIP2.codice_fiscale, DIP2.nome, DIP2.cognome, hashDip, 'DIPENDENTE']);
}

async function chiudi() {
  if (server) {
    await new Promise((r) => {
      if (server.closeIdleConnections) server.closeIdleConnections();
      server.close(r);
    });
    server = null;
  }
  await pool.end();
}

/** Login: restituisce { status, cookie, dati }. */
async function login(matricola, password) {
  const r = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ matricola, password }),
  });
  // [v2.1] Con la password provvisoria il login emette il cookie monouso
  // `token_cambio` E la pulizia di `token`: scegliamo il cookie utile.
  const elencoCookie = r.headers.getSetCookie() || [];
  const cookie = elencoCookie.find((c) => c.startsWith('token_cambio='))
    || elencoCookie.find((c) => c.startsWith('token='))
    || '';
  const testo = await r.text();
  let dati = null;
  try { dati = JSON.parse(testo); } catch { /* corpo non JSON */ }
  return { status: r.status, cookie, dati };
}

/** Richiesta generica con cookie opzionale; legge SEMPRE il body (no socket appesi). */
async function chiedi(percorso, { method = 'GET', cookie = null, body = null, formData = null } = {}) {
  const headers = {};

  /* [v2.3.3] Modalità rigida: il token di scheda viaggia nell'header
   * Authorization (il frontend lo prende da sessionStorage). Se il test passa
   * un cookie `token=...` lo si replica anche come Bearer: il cookie resta
   * nella richiesta e continua a valere per i download diretti. */
  if (cookie) {
    headers.Cookie = cookie;
    const corrispondenza = /(?:^|;\s*)token=([^;]+)/.exec(cookie);
    if (corrispondenza) headers.Authorization = `Bearer ${decodeURIComponent(corrispondenza[1])}`;
  }
  if (body !== null) headers['Content-Type'] = 'application/json';
  const r = await fetch(BASE + percorso, {
    method,
    headers,
    body: body !== null ? JSON.stringify(body) : formData,
  });
  // arrayBuffer + decode manuale: TextDecoder/ r.text() rimuoverebbero il BOM
  // UTF-8 iniziale, rendendo impossibile testare l'export CSV per Excel.
  const buf = Buffer.from(await r.arrayBuffer());
  const testo = buf.toString('utf8');
  let dati = null;
  try { dati = JSON.parse(testo); } catch { /* non JSON (es. PDF/CSV) */ }
  return { r, status: r.status, dati, testo, buf, headers: r.headers };
}

/** Genera un PDF minimo ma valido (pagina singola, Helvetica). */
function pdfBuffer(testo = 'Certificato QA') {
  const esc = (s) => String(s).replace(/[\\()]/g, (c) => '\\' + c);
  const stream = `BT\n/F1 12 Tf\n60 780 Td\n(${esc(testo)}) Tj\nET`;
  const oggetti = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
    `<< /Length ${Buffer.byteLength(stream, 'latin1')} >>\nstream\n${stream}\nendstream`,
  ];
  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  oggetti.forEach((o, i) => {
    offsets.push(Buffer.byteLength(pdf, 'latin1'));
    pdf += `${i + 1} 0 obj\n${o}\nendobj\n`;
  });
  const startxref = Buffer.byteLength(pdf, 'latin1');
  pdf += `xref\n0 ${oggetti.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= oggetti.length; i++) pdf += String(offsets[i]).padStart(10, '0') + ' 00000 n \n';
  pdf += `trailer\n<< /Size ${oggetti.length + 1} /Root 1 0 R >>\nstartxref\n${startxref}\n%%EOF\n`;
  return Buffer.from(pdf, 'latin1');
}

/** FormData pronto per POST /api/certificati (v1.4: ore, esame, area). */
function uploadFormData({ corso, ente, data, nomeFile = 'certificato.pdf', buffer = null, tipo = 'application/pdf',
                          ore = '8', esame = '1', area = 'Transizione digitale' }) {
  const fd = new FormData();
  fd.append('nome_corso', corso);
  fd.append('ente_erogatore', ente);
  fd.append('data_conseguimento', data);
  fd.append('numero_ore', ore);
  fd.append('esame_finale', esame);
  fd.append('area_tematica', area);
  fd.append('file', new Blob([buffer || pdfBuffer()], { type: tipo }), nomeFile);
  return fd;
}

/** Cerca l'id di un dipendente dalla matricola. */
async function idDi(matricola) {
  const [righe] = await pool.query('SELECT id FROM dipendenti WHERE matricola = ?', [matricola]);
  return righe[0] ? righe[0].id : null;
}

module.exports = {
  assert,
  BASE, JWT_SECRET_TEST, DIR_CERT, ADMIN, DIP1, DIP2,
  avvia, resetDati, chiudi, login, chiedi, pdfBuffer, uploadFormData, idDi, pool,
};

/**
 * importazione.test.js — v1.3: test del motore di importazione massiva.
 *  - unit: parser CSV (separatori, virgolette, BOM, alias intestazione,
 *    errori di riga, duplicati nel file, colonne mancanti);
 *  - integrazione via API: dry-run (nessuna scrittura), importazione reale
 *    (bcrypt + cartelle matricola + must_change_password), gestione duplicati
 *    in modalità ignora e aggiorna, file con estensione non ammessa,
 *    intestazione incompleta, permessi di ruolo.
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const bcrypt = require('bcryptjs');
const { test, before, after } = require('node:test');
const h = require('./helper');
const { parseCsv, analizzaCsv } = require('../src/utils/importazione');

before(async () => { await h.avvia(); await h.resetDati(); });
after(async () => { await h.chiudi(); });

async function adminCookie() {
  const { cookie } = await h.login(h.ADMIN.matricola, h.ADMIN.password);
  return cookie;
}

/** Costruisce il CSV di prova nel FORMATO v1.4 (separatore ';'). */
function csvProva() {
  return [
    'nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale;email;ruolo;password_temporanea',
    'Anna;Importata;imp101;MRINNA80A01H501U;F;Istruttore direttivo;anna.importata@test.local;DIPENDENTE;Importa2026',
    'Bruno;Importato;imp102;BRNMRO85M20H501V;M;Agente di polizia locale;;DIPENDENTE;',        // password vuota → predefinita
    'Carla;Importata;imp103;CRLCRL90C45H501Z;F;Dirigente;carla@test.local;;MiaPass123',
    'Dup;Esistente;qa001;VRDLGU80M01H501B;M;Funzionario amministrativo;dup@test.local;DIPENDENTE;', // duplicato a DB
    'Matricola;Corta;a;CRTCRT75T05H501X;F;Assistente amministrativo;x@test.local;DIPENDENTE;',      // matricola corta
    'Mail;Errata;imp104;MLRMLA88H50H501Y;F;Istruttore direttivo;non-e-mail;DIPENDENTE;',            // email non valida
    'Ruolo;Errato;imp105;RLRRRO82P18H501W;X;Istruttore direttivo;;CAPO;',                           // sesso e ruolo errati
  ].join('\r\n');
}

function formDataCsv({ contenuto = csvProva(), nome = 'dipendenti.csv', duplicati = 'ignora', dryRun = '0' } = {}) {
  const fd = new FormData();
  fd.append('file', new Blob([contenuto], { type: 'text/csv' }), nome);
  fd.append('duplicati', duplicati);
  fd.append('dry_run', dryRun);
  return fd;
}
async function contaDipendenti() {
  const [[{ n }]] = await h.pool.query('SELECT COUNT(*) AS n FROM dipendenti');
  return n;
}

/* ---------------------- UNIT: parser e analisi ---------------------- */

test('parseCsv: riconosce il separatore ";" e le virgolette (inclusi "" letterali e ; dentro i campi)', () => {
  const righe = parseCsv('\uFEFFmatricola;nome;cognome\r\nimp001;"Rossi; Mario";"Doppi""A"""\r\n');
  h.assert.equal(righe.length, 2);
  h.assert.deepEqual(righe[0], ['matricola', 'nome', 'cognome']); // BOM rimosso
  h.assert.deepEqual(righe[1], ['imp001', 'Rossi; Mario', 'Doppi"A"']);
});

test('parseCsv: gestisce separatore virgola, TAB, fine riga solo \\n e righe vuote', () => {
  h.assert.deepEqual(parseCsv('a,b,c\n1,2,3\n\n'), [['a', 'b', 'c'], ['1', '2', '3']]);
  h.assert.deepEqual(parseCsv('a\tb\tc\n1\t2\t3'), [['a', 'b', 'c'], ['1', '2', '3']]);
});

test('analizzaCsv: alias intestazione (password_provvisoria), righe vuote ignorate, errori di riga e duplicati nel file', () => {
  const csv = [
    'Matricola;CF;Nome;Cognome;Sesso;Qualifica_Professionale;E-Mail;Ruolo;password_provvisoria',
    'ok001;BNNAZA80A01H501U;Anna;Bianchi;F;Dirigente;;DIPENDENTE;',
    'ok001;BNNAZA80A01H501U;Dup;NelFile;M;Dirigente;;DIPENDENTE;',  // duplicata nel file (matricola e CF)
    'x;CRTCRT75T05H501X;Troppo;Corta;F;Dirigente;;DIPENDENTE;',     // matricola corta
    ';;;;;;;;',                                      // riga tutta vuota → ignorata
  ].join('\n');
  const analisi = analizzaCsv(csv);
  h.assert.equal(analisi.ok, true);
  h.assert.equal(analisi.totaleRighe, 3);
  h.assert.equal(analisi.righeVuoteIgnorate, 1);
  const dup = analisi.record.find((r) => r.numeroRiga === 3);
  h.assert.ok(dup.errori.some((e) => /duplicata nel file/.test(e)));
  const corta = analisi.record.find((r) => r.numeroRiga === 4);
  h.assert.ok(corta.errori.some((e) => /matricola non valida/.test(e)));
});

test('analizzaCsv: intestazione senza colonne obbligatorie (incluse codice_fiscale) → ok:false', () => {
  const analisi = analizzaCsv('id;nome;email\n1;A;a@b.it\n');
  h.assert.equal(analisi.ok, false);
  h.assert.match(analisi.errore, /codice_fiscale/); // v2.0: tra le colonne obbligatorie
});

test('v1.4: sesso fuori elenco e qualifica mancante → errori di riga dedicati', () => {
  const analisi = analizzaCsv(
    'nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale\n' +
    'Alfa;Beta;ok010;XBXBXB80A01H501U;X;Dirigente\n' +          // sesso non ammesso
    'Gamma;Delta;ok011;GDGGMM85C15H501V;F;\n'                   // qualifica vuota
  );
  h.assert.ok(analisi.record[0].errori.some((e) => /sesso non valido/.test(e)));
  h.assert.ok(analisi.record[1].errori.some((e) => /qualifica_professionale non valida/.test(e)));
});

test('[v2.0] codice fiscale malformato → riga in errore, il resto del file prosegue', () => {
  const analisi = analizzaCsv(
    'nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale\n' +
    'Malo;Fiscale;ok020;RSSMRA80A01H501;M;Dirigente\n' +        // 15 caratteri
    'Buono;Fiscale;ok021;RSSMRA80A01H501U;M;Dirigente\n'        // valido
  );
  h.assert.ok(analisi.record[0].errori.some((e) => /codice_fiscale non valido/.test(e)));
  h.assert.equal(analisi.record[1].errori.length, 0);
});

test('[v2.0] codice fiscale duplicato DENTRO il file → seconda riga in errore', () => {
  const analisi = analizzaCsv(
    'nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale\n' +
    'Prima;Volta;ok030;RSSMRA80A01H501U;M;Dirigente\n' +
    'Seconda;Volta;ok031;rssmra80a01h501u;F;Dirigente\n'        // anche in minuscolo → normalizzato
  );
  h.assert.ok(analisi.record[1].errori.some((e) => /codice_fiscale duplicato nel file/.test(e)));
});

test('analizzaCsv: password debole indicata nel file → riga in errore (policy applicata)', () => {
  const analisi = analizzaCsv('nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale;password_temporanea\nAlfa;Beta;ok009;BXLXRA80A01H501U;M;Dirigente;corta\n');
  h.assert.equal(analisi.record[0].errori.length, 1);
  h.assert.match(analisi.record[0].errori[0], /password_temporanea/);
});

/* ------------------- INTEGRAZIONE: POST /utenti/import ------------------- */

test('dry-run: report corretto e NESSUNA scrittura (DB e cartelle invariati)', async () => {
  const prima = await contaDipendenti();
  const { status, dati } = await h.chiedi('/api/admin/utenti/import', {
    method: 'POST', cookie: await adminCookie(), formData: formDataCsv({ dryRun: '1' }),
  });
  h.assert.equal(status, 200);
  h.assert.equal(dati.dryRun, true);
  h.assert.equal(dati.esito.creati.length, 3);
  h.assert.equal(dati.esito.saltati.length, 1);
  h.assert.equal(dati.esito.saltati[0].matricola, 'qa001');
  h.assert.equal(dati.esito.errori.length, 3);
  h.assert.equal(dati.esito.creati.find((c) => c.matricola === 'imp102').predefinita, true);
  h.assert.equal(await contaDipendenti(), prima, 'il numero di dipendenti non è cambiato');
  h.assert.ok(!fs.existsSync(path.join(h.DIR_CERT, 'imp101')), 'nessuna cartella creata in dry-run');
});

test('import reale (ignora): 3 creati con bcrypt + cartelle + cambio password obbligatorio; duplicato saltato; 3 errori', async () => {
  const { status, dati } = await h.chiedi('/api/admin/utenti/import', {
    method: 'POST', cookie: await adminCookie(), formData: formDataCsv({}),
  });
  h.assert.equal(status, 200);
  h.assert.equal(dati.dryRun, false);
  h.assert.equal(dati.esito.creati.length, 3);
  h.assert.equal(dati.esito.saltati.length, 1);
  h.assert.equal(dati.esito.errori.length, 3);

  // v2.0: CF salvato a DB (normalizzato maiuscolo) e cartella nominata col CF
  const [cfRow] = await h.pool.query("SELECT codice_fiscale FROM dipendenti WHERE matricola = 'imp101'");
  const cfRiga = cfRow[0];
  h.assert.equal(cfRiga.codice_fiscale, 'MRINNA80A01H501U');
  h.assert.ok(fs.existsSync(path.join(h.DIR_CERT, 'MRINNA80A01H501U')), 'cartella {CF} creata');

  // password dal file → hash bcrypt verificabile; password vuota → PREDEFINITA 'Benvenuto@2026' (v1.4)
  h.assert.equal(dati.esito.creati.find((c) => c.matricola === 'imp101').password, 'Importa2026');
  const predef = dati.esito.creati.find((c) => c.matricola === 'imp102').password;
  h.assert.equal(predef, 'Benvenuto@2026');
  h.assert.equal(dati.esito.creati.find((c) => c.matricola === 'imp102').predefinita, true);

  const [riga] = await h.pool.query("SELECT password_hash, must_change_password, attivo, sesso, qualifica FROM dipendenti WHERE matricola='imp101'");
  h.assert.equal(await bcrypt.compare('Importa2026', riga[0].password_hash), true, 'hash bcrypt corretto');
  h.assert.equal(riga[0].must_change_password, 1);
  h.assert.equal(riga[0].attivo, 1);
  h.assert.equal(riga[0].sesso, 'F');                        // v1.4
  h.assert.equal(riga[0].qualifica, 'Istruttore direttivo'); // v1.4

  // v2.0: le cartelle sono nominate con il CODICE FISCALE (non la matricola)
  for (const cf of ['MRINNA80A01H501U', 'BRNMRO85M20H501V', 'CRLCRL90C45H501Z']) {
    h.assert.ok(fs.existsSync(path.join(h.DIR_CERT, cf)), `cartella {CF} creata: ${cf}`);
  }

  // gli errori riportano il numero di riga del file
  const numeri = dati.esito.errori.map((e) => e.riga).sort((a, b) => a - b);
  h.assert.deepEqual(numeri, [6, 7, 8]);
});

test('import ripetuto con duplicati=aggiorna: anagrafica aggiornata, password invariata', async () => {
  const hashPrima = (await h.pool.query("SELECT password_hash FROM dipendenti WHERE matricola='imp101'"))[0][0].password_hash;

  // cambia il cognome di imp101 nel file per verificare l'aggiornamento
  const csvAgg = csvProva().replace('Anna;Importata;imp101', 'Anna;Rinominata;imp101'); // il CF resta invariato
  const { status, dati } = await h.chiedi('/api/admin/utenti/import', {
    method: 'POST', cookie: await adminCookie(),
    formData: formDataCsv({ contenuto: csvAgg, duplicati: 'aggiorna' }),
  });
  h.assert.equal(status, 200);
  h.assert.equal(dati.esito.creati.length, 0);
  h.assert.equal(dati.esito.aggiornati.length, 4); // imp101..103 + qa001
  h.assert.equal(dati.esito.errori.length, 3);

  const [riga] = await h.pool.query("SELECT cognome, nome, password_hash FROM dipendenti WHERE matricola='imp101'");
  h.assert.equal(riga[0].nome, 'Anna');
  h.assert.equal(riga[0].cognome, 'Rinominata');
  h.assert.equal(riga[0].password_hash, hashPrima, 'la password NON viene toccata in modalità aggiorna');
});

test('file con estensione non ammessa (.xlsx) → 400 con messaggio dedicato', async () => {
  const { status, dati } = await h.chiedi('/api/admin/utenti/import', {
    method: 'POST', cookie: await adminCookie(),
    formData: formDataCsv({ nome: 'elenco.xlsx' }),
  });
  h.assert.equal(status, 400);
  h.assert.match(dati.errore, /CSV/i);
});

test('intestazione incompleta → 400 con elenco delle colonne mancanti', async () => {
  const { status, dati } = await h.chiedi('/api/admin/utenti/import', {
    method: 'POST', cookie: await adminCookie(),
    formData: formDataCsv({ contenuto: 'id;nome\n1;Mario\n' }),
  });
  h.assert.equal(status, 400);
  h.assert.match(dati.errore, /matricola, codice_fiscale, cognome/); // v2.0
});

test('un DIPENDENTE non può importare → 403', async () => {
  const { cookie } = await h.login(h.DIP1.matricola, h.DIP1.password);
  const { status } = await h.chiedi('/api/admin/utenti/import', {
    method: 'POST', cookie, formData: formDataCsv({}),
  });
  h.assert.equal(status, 403);
});

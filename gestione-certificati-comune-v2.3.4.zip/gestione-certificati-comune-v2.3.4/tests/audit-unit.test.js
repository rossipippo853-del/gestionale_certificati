/**
 * ============================================================================
 *  audit-unit.test.js — SUITE DI AUDITORIA QA (unit test PURI dei moduli)
 * ============================================================================
 *  [Audit QA v2.1.1] I 78 test di regressione coprivano i moduli solo in modo
 *  TRANSITIVO (attraverso le API). Questa suite testa le funzioni PURE di
 *  src/utils/ direttamente, con casi limite e input ostili:
 *    · validazione.js  → policy password, regex CF/matricola, normalizzazioni,
 *                        confini di tutti i campi (certificati e dipendenti);
 *    · sessioni.js     → registro di revoca: roundtrip, scadenze, auto-pulizia;
 *    · file.js         → magic bytes, sanificazione nomi, ANTI PATH TRAVERSAL;
 *    · importazione.js → parser CSV: BOM/CRLF, separatori, virgolette, alias,
 *                        duplicati, tetti di riga.
 *
 *  NOTA TECNICA: UPLOAD_DIR viene impostato PRIMA di richiedere i moduli, così
 *  ogni eventuale cartella creata finisce in uploads-test/ (mai in uploads/).
 * ============================================================================
 */
'use strict';

process.env.UPLOAD_DIR = 'uploads-test'; // PRIMA di qualsiasi require di src/

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { test } = require('node:test');

const V = require('../src/utils/validazione');
const S = require('../src/utils/sessioni');
const F = require('../src/utils/file');
const I = require('../src/utils/importazione');

/* ------------------------------------------------------------------ *
 *  validazione.js — validaNuovaPassword
 * ------------------------------------------------------------------ */

test('[unit] validaNuovaPassword: confini di lunghezza 7/8/72/73', () => {
  assert.match(V.validaNuovaPassword('corta12'), /almeno 8/);            // 7 → errore
  assert.equal(V.validaNuovaPassword('Lunga123'), null);                 // 8 → ok
  assert.equal(V.validaNuovaPassword('A'.repeat(71) + '1'), null);       // 72 → ok
  assert.match(V.validaNuovaPassword('A'.repeat(72) + '1'), /max 72/);   // 73 → errore
});

test('[unit] validaNuovaPassword: servono lettera E numero', () => {
  assert.match(V.validaNuovaPassword('sololettere'), /lettera e almeno un numero/);
  assert.match(V.validaNuovaPassword('12345678'), /lettera e almeno un numero/);
  // lettere NON ASCII da sole non contano come "lettera" (policy documentata)
  assert.match(V.validaNuovaPassword('ÀÈÌÒÙ12345'), /lettera e almeno un numero/);
  assert.equal(V.validaNuovaPassword('Pàssword1'), null);  // lettera ASCII presente → ok
  assert.equal(V.validaNuovaPassword('spazi dentro 1'), null); // gli spazi sono ammessi
});

test('[unit] validaNuovaPassword: input non stringa o vuoto → sempre errore', () => {
  for (const cattivo of [null, undefined, 42, {}, true, [], '']) {
    assert.equal(typeof V.validaNuovaPassword(cattivo), 'string', `deve rifiutare: ${String(cattivo)}`);
  }
});

/* ------------------------------------------------------------------ *
 *  validazione.js — RE_CODICE_FISCALE / RE_MATRICOLA / RE_EMAIL
 * ------------------------------------------------------------------ */

test('[unit] RE_CODICE_FISCALE: formati validi e invalidi (v2.0)', () => {
  for (const ok of ['RSSMRA80A01H501U', 'GLLANN85C15G822C', 'ZZZZZZ90B12X999Z']) {
    assert.ok(V.RE_CODICE_FISCALE.test(ok), `valido: ${ok}`);
  }
  for (const no of [
    'rssmra80a01h501u',       // minuscolo (la normalizzazione è a monte, la regex no)
    'RSSMRA80A01H501',        // 15 caratteri
    'RSSMRA80A01H501UX',      // 17 caratteri
    'RSSMR80A01H501UA',       // gruppo cifre/lettere spostato
    'RSSMRA80AO1H501U',       // lettera O al posto della cifra 0
    'RSSMRA80A01H5O1U',       // idem in posizione di cifra
    ' RSSMRA80A01H501U',      // spazio iniziale
    'RSSMRA80A01H501U ',      // spazio finale
    'RSSMRA80A01H501Ü',       // carattere non ASCII
    '12345678A01H501U',       // cifre al posto delle 6 lettere iniziali
  ]) {
    assert.ok(!V.RE_CODICE_FISCALE.test(no), `deve rifiutare: ${JSON.stringify(no)}`);
  }
});

test('[unit] RE_MATRICOLA: 2-20 alfanumerici con _ e - (v2.3.1: minimo 2)', () => {
  for (const ok of ['abc', '10001', 'ab_-1', 'ab', '12', 'a'.repeat(20)]) {
    assert.ok(V.RE_MATRICOLA.test(ok), `valida: ${ok}`);
  }
  for (const no of ['a', 'a'.repeat(21), 'con spazio', 'mat/1', '../etc', '', 'matricola;drop']) {
    assert.ok(!V.RE_MATRICOLA.test(no), `deve rifiutare: ${JSON.stringify(no)}`);
  }
});

/* ------------------------------------------------------------------ *
 *  validazione.js — pulisci (normalizzatore input)
 * ------------------------------------------------------------------ */

test('[unit] pulisci: trim, array ripetuti, non-stringa → stringa vuota', () => {
  assert.equal(V.pulisci('  ciao  '), 'ciao');
  assert.equal(V.pulisci(['a', 'b']), 'a');                 // ?q=a&q=b → primo valore
  assert.equal(V.pulisci(['  a  ']), 'a');
  assert.equal(V.pulisci(42), '');
  assert.equal(V.pulisci(null), '');
  assert.equal(V.pulisci(undefined), '');
  assert.equal(V.pulisci({ a: 1 }), '');
  assert.equal(V.pulisci(true), '');
});

/* ------------------------------------------------------------------ *
 *  validazione.js — validaDatiCertificato (confini dei campi v1.4)
 * ------------------------------------------------------------------ */

const BASE_CERT = {
  nome_corso: 'Corso QA', ente_erogatore: 'Ente QA', data_conseguimento: '2025-01-10',
  numero_ore: '8', esame_finale: '1', area_tematica: 'Transizione digitale',
};

test('[unit] validaDatiCertificato: caso valido e mappa dei valori', () => {
  const { errori, valori } = V.validaDatiCertificato({ ...BASE_CERT });
  assert.deepEqual(errori, []);
  assert.equal(valori.numeroOre, 8);
  assert.equal(valori.esameFinale, 1);
  assert.equal(valori.areaTematica, 'Transizione digitale');
  assert.equal(valori.nomeCorso, 'Corso QA');
});

test('[unit] validaDatiCertificato: numero_ore fuori dai confini', () => {
  for (const cattivo of ['0', '10000', '12.5', 'abc', '-3', '', '8 ore', '1e3']) {
    const { errori } = V.validaDatiCertificato({ ...BASE_CERT, numero_ore: cattivo });
    assert.ok(errori.some((e) => /ore/.test(e)), `ore "${cattivo}" deve essere rifiutato`);
  }
  for (const buono of ['1', '9999', '0008', '  5  ']) {
    const { errori, valori } = V.validaDatiCertificato({ ...BASE_CERT, numero_ore: buono });
    assert.deepEqual(errori, [], `ore "${buono}" deve passare`);
    assert.equal(valori.numeroOre, Number.parseInt(buono.trim(), 10));
  }
});

test('[unit] validaDatiCertificato: esame_finale booleano permissivo ma chiuso', () => {
  for (const si of ['1', 'true', 'TRUE', 'on', 'si', 'sì', true]) {
    assert.equal(V.validaDatiCertificato({ ...BASE_CERT, esame_finale: si }).valori.esameFinale, 1, String(si));
  }
  for (const no of ['0', 'no', '', 'forse', '2', false, null, undefined]) {
    assert.equal(V.validaDatiCertificato({ ...BASE_CERT, esame_finale: no }).valori.esameFinale, 0, String(no));
  }
});

test('[unit] validaDatiCertificato: area tematica a elenco chiuso', () => {
  assert.ok(V.validaDatiCertificato({ ...BASE_CERT, area_tematica: '' }).errori.length > 0);
  assert.ok(V.validaDatiCertificato({ ...BASE_CERT, area_tematica: 'Area inventata' }).errori.length > 0);
  assert.ok(V.validaDatiCertificato({ ...BASE_CERT, area_tematica: 'transizione digitale' }).errori.length > 0, // case-sensitive
    'l\u2019area deve corrispondere ESATTAMENTE a una delle 6 voci');
});

test('[unit] validaDatiCertificato: confini di lunghezza nome corso (3/200) ed ente (2/150)', () => {
  assert.ok(V.validaDatiCertificato({ ...BASE_CERT, nome_corso: 'ab' }).errori.some((e) => /corso/.test(e)));
  assert.deepEqual(V.validaDatiCertificato({ ...BASE_CERT, nome_corso: 'abc' }).errori, []);
  assert.deepEqual(V.validaDatiCertificato({ ...BASE_CERT, nome_corso: 'N'.repeat(200) }).errori, []);
  assert.ok(V.validaDatiCertificato({ ...BASE_CERT, nome_corso: 'N'.repeat(201) }).errori.some((e) => /corso/.test(e)));

  assert.ok(V.validaDatiCertificato({ ...BASE_CERT, ente_erogatore: 'a' }).errori.some((e) => /ente/i.test(e)));
  assert.deepEqual(V.validaDatiCertificato({ ...BASE_CERT, ente_erogatore: 'ab' }).errori, []);
  assert.deepEqual(V.validaDatiCertificato({ ...BASE_CERT, ente_erogatore: 'E'.repeat(150) }).errori, []);
  assert.ok(V.validaDatiCertificato({ ...BASE_CERT, ente_erogatore: 'E'.repeat(151) }).errori.some((e) => /ente/i.test(e)));
});

test('[unit] validaDatiCertificato: date — ISO reale, calendario, futuro, oggi', () => {
  assert.ok(V.validaDatiCertificato({ ...BASE_CERT, data_conseguimento: '15/09/2026' }).errori.some((e) => /data/i.test(e)),
    'formato non ISO rifiutato');
  assert.ok(V.validaDatiCertificato({ ...BASE_CERT, data_conseguimento: '2026-02-30' }).errori.some((e) => /data/i.test(e)),
    'data inesistente nel calendario rifiutata');
  assert.ok(V.validaDatiCertificato({ ...BASE_CERT, data_conseguimento: '2099-01-01' }).errori.some((e) => /futuro/i.test(e)),
    'data futura rifiutata');
  const oggi = new Date();
  const isoOggi = `${oggi.getFullYear()}-${String(oggi.getMonth() + 1).padStart(2, '0')}-${String(oggi.getDate()).padStart(2, '0')}`;
  assert.deepEqual(V.validaDatiCertificato({ ...BASE_CERT, data_conseguimento: isoOggi }).errori, [],
    'la data di OGGI è tollerata (finché fine giornata)');
  assert.deepEqual(V.validaDatiCertificato({ ...BASE_CERT, data_conseguimento: '2020-02-29' }).errori, [],
    '29 febbraio anno bisestile accettato');
});

/* ------------------------------------------------------------------ *
 *  validazione.js — validaDatiDipendente (normalizzazioni e confini)
 * ------------------------------------------------------------------ */

const BASE_DIP = {
  matricola: 'aud01', codice_fiscale: 'RSSMRA80A01H501U', nome: 'Mario',
  cognome: 'Rossi', sesso: 'm', qualifica: 'Funzionario', email: 'mario.rossi@comune.it', ruolo: '',
};

test('[unit] validaDatiDipendente: normalizzazioni (CF maiuscolo, sesso, ruolo predefinito)', () => {
  const { errori, valori } = V.validaDatiDipendente(BASE_DIP);
  assert.deepEqual(errori, []);
  assert.equal(valori.codiceFiscale, 'RSSMRA80A01H501U'); // era minuscolo
  assert.equal(valori.sesso, 'M');
  assert.equal(valori.ruolo, 'DIPENDENTE');               // predefinito
});

test('[unit] validaDatiDipendente: confini di ogni campo', () => {
  const verifica = (override, pezzo) =>
    V.validaDatiDipendente({ ...BASE_DIP, ...override }).errori.some((e) => pezzo.test(e));

  /* [v2.3.1] da 2 caratteri è valida: il confine invalido è 1 carattere. */
  assert.ok(verifica({ matricola: 'a' }, /Matricola/), 'matricola 1 carattere');
  assert.ok(!verifica({ matricola: 'ab' }, /Matricola/), 'matricola 2 caratteri ora valida');
  assert.ok(verifica({ matricola: 'a'.repeat(21) }, /Matricola/), 'matricola 21 caratteri');
  assert.ok(verifica({ codice_fiscale: 'RSSMRA80A01H501' }, /Codice Fiscale/), 'CF 15 caratteri');
  assert.ok(verifica({ nome: 'A' }, /Nome/), 'nome 1 carattere');
  assert.ok(verifica({ nome: 'N'.repeat(101) }, /Nome/), 'nome 101 caratteri');
  assert.ok(verifica({ cognome: 'C' }, /Cognome/), 'cognome 1 carattere');
  assert.ok(verifica({ sesso: 'X' }, /Sesso/), 'sesso fuori elenco');
  assert.ok(verifica({ qualifica: 'Q' }, /Qualifica/), 'qualifica 1 carattere');
  assert.ok(verifica({ qualifica: 'Q'.repeat(121) }, /Qualifica/), 'qualifica 121 caratteri');
  assert.ok(verifica({ email: 'pino' }, /Email/), 'email senza @ e dominio');
  assert.ok(verifica({ email: 'e'.repeat(150) + '@x.it' }, /Email/), 'email oltre 150');
  assert.ok(verifica({ ruolo: 'CAPO' }, /Ruolo/), 'ruolo fuori elenco');

  // valori al confine SUPERIORE valido: nessun errore
  assert.deepEqual(V.validaDatiDipendente({
    ...BASE_DIP, nome: 'N'.repeat(100), qualifica: 'Q'.repeat(120), email: 'x@y.it',
  }).errori, []);
  // email facoltativa
  assert.deepEqual(V.validaDatiDipendente({ ...BASE_DIP, email: '' }).errori, []);
});

/* ------------------------------------------------------------------ *
 *  sessioni.js — registro di revoca
 * ------------------------------------------------------------------ */

test('[unit] sessioni: roundtrip revoca/eRevocato e casi triviali', () => {
  S.revoca('j-1', Date.now() + 60_000);
  assert.equal(S.eRevocato('j-1'), true);
  assert.equal(S.eRevocato('mai-visto'), false);
  assert.equal(S.eRevocato(''), false);        // jti assente → false (nessun crash)
  S.revoca('', Date.now() + 60_000);           // revoca senza jti → no-op
  assert.equal(S.eRevocato(''), false);
});

test('[unit] sessioni: scadenza predefinita (24h) e token scaduto resta revocato', () => {
  S.revoca('j-default');                                 // senza scadenza → 24h
  assert.equal(S.eRevocato('j-default'), true);
  S.revoca('j-scaduto', Date.now() - 1000);              // già scaduto al momento della revoca
  assert.equal(S.eRevocato('j-scaduto'), true,
    'finché non avviene la pulizia, un jti revocato resta rifiutato (verso sicuro)');
});

test('[unit] sessioni: auto-pulizia degli entry scaduti (anti memory-leak)', () => {
  // Percorso deterministico: la soglia LIMITE (10.000) forza ripulisci() alla
  // prima revoca successiva. Riempiamo il registro di entry SCADUTE + una valida.
  S.revoca('audit-valida', Date.now() + 3_600_000);
  for (let i = 0; i < 10_000; i++) S.revoca(`audit-scaduta-${i}`, Date.now() - 1);
  S.revoca('audit-grilletto', Date.now() + 3_600_000); // supera LIMITE → ripulisci()
  assert.equal(S.eRevocato('audit-scaduta-0'), false,
    'le entry scadute devono lasciare il registro (nessun memory leak)');
  assert.equal(S.eRevocato('audit-valida'), true,
    'le revoche ancora in corso di validità NON devono essere dimenticate');
  assert.equal(S.eRevocato('audit-grilletto'), true);
});

/* ------------------------------------------------------------------ *
 *  file.js — magic bytes, nomi sicuri, path traversal
 * ------------------------------------------------------------------ */

test('[unit] file.ePdf: riconosce solo PDF veri (magic bytes)', () => {
  assert.equal(F.ePdf(Buffer.from('%PDF-1.7\ncorpo')), true);
  assert.equal(F.ePdf(Buffer.from('%PDF-x')), true);          // minimo 5 byte
  assert.equal(F.ePdf(Buffer.from(' %PDF-1.4')), false);      // spazio iniziale
  assert.equal(F.ePdf(Buffer.from('%PDF')), false);           // troppo corto
  assert.equal(F.ePdf(Buffer.alloc(0)), false);               // vuoto
  assert.equal(F.ePdf(Buffer.from('XXXXX')), false);          // header sbagliato
  assert.equal(F.ePdf('non sono un buffer'), false);          // tipo sbagliato
  assert.equal(F.ePdf(null), false);
});

test('[unit] file.nomeFileUnivoco: formato, univocità nello stesso ms, sanificazione', () => {
  const a = F.nomeFileUnivoco('attestato corso.pdf');
  assert.match(a, /^\d{13}-[0-9a-f]{8}_.+\.pdf$/);
  const b = F.nomeFileUnivoco('attestato corso.pdf');          // stesso input, stesso ms
  assert.notEqual(a, b, 'due upload nello stesso ms non si sovrascrivono mai [FIX QA-B3]');

  const ostile = F.nomeFileUnivoco('../../etc/passwd.pdf');
  assert.ok(!ostile.includes('/'), 'nessun separatore di percorso');
  assert.ok(!ostile.includes('..'), 'nessun path traversal');

  const emoji = F.nomeFileUnivoco('Corso 🎓 sicurezza; DROP TABLE.pdf');
  assert.match(emoji, /^[0-9a-zA-Z._-]+$/, 'solo caratteri sicuri');

  const lungo = F.nomeFileUnivoco(`${'x'.repeat(200)}.pdf`);
  assert.ok(F.nomeFileUnivoco(lungo).length <= 23 + 80, 'nome finale limitato (base ≤ 80)');
});

test('[unit] file.percorsoAssoluto: anti path traversal totale', () => {
  const dentro = F.percorsoAssoluto('certificati/RSSMRA80A01H501U/x.pdf');
  assert.ok(dentro && dentro.startsWith(path.resolve(F.DIR_CERTIFICATI) + path.sep));

  for (const fuga of ['../fuga.pdf', 'certificati/../../fuga.pdf', '/etc/passwd',
    'certificati/CF/sub/../../fuori.pdf', '..', 'certificati/..']) {
    assert.equal(F.percorsoAssoluto(fuga), null, `deve rifiutare: ${fuga}`);
  }
  assert.equal(F.percorsoAssoluto(null), null);
  assert.equal(F.percorsoAssoluto(42), null);
});

test('[unit] file.cartellaDipendente: chiave sanificata, mai fuori dalla radice', () => {
  const dir = F.cartellaDipendente('RSSMRA80A01H501U');
  assert.ok(dir.startsWith(path.resolve(F.DIR_CERTIFICATI) + path.sep));
  assert.ok(fs.existsSync(dir), 'la cartella CF viene creata (self-healing)');

  const ostile = F.cartellaDipendente('../../pippo');
  assert.ok(!ostile.includes('..'), 'il traversal viene neutralizzato');
  assert.ok(ostile.startsWith(path.resolve(F.DIR_CERTIFICATI) + path.sep));
});

/* ------------------------------------------------------------------ *
 *  importazione.js — parser CSV (parseCsv + analizzaCsv)
 * ------------------------------------------------------------------ */

test('[unit] import.parseCsv: BOM Excel, CRLF/CR/LF e virgolette', () => {
  const righe = I.parseCsv('\uFEFFnome;cognome\r\nMario;Rossi\r\nAnna;Bianchi\nCarla;Neri');
  assert.deepEqual(righe, [['nome', 'cognome'], ['Mario', 'Rossi'], ['Anna', 'Bianchi'], ['Carla', 'Neri']]);

  const virgolettate = I.parseCsv('"a;b";c\n"d""e";f'); // ; e "" dentro le virgolette
  assert.deepEqual(virgolettate, [['a;b', 'c'], ['d"e', 'f']]);
});

test('[unit] import.parseCsv: rilevamento separatore punto e virgola, virgola e tab', () => {
  assert.deepEqual(I.parseCsv('a;b\nc;d')[0], ['a', 'b']);
  assert.deepEqual(I.parseCsv('a,b\nc,d')[0], ['a', 'b']);
  assert.deepEqual(I.parseCsv('a\tb\nc\td')[0], ['a', 'b']);
});

test('[unit] import.analizzaCsv: file vuoto e intestazione da sola', () => {
  assert.equal(I.analizzaCsv('').ok, false);
  assert.equal(I.analizzaCsv('   \n  ').ok, false);
  const solo = I.analizzaCsv('nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale');
  assert.equal(solo.ok, true);
  assert.equal(solo.totaleRighe, 0);
});

test('[unit] import.analizzaCsv: colonne obbligatorie mancanti → errore esplicito con elenco', () => {
  const r = I.analizzaCsv('nome;cognome;matricola;email;ruolo;password_temporanea\nA;B;30100;;DIPENDENTE;');
  assert.equal(r.ok, false);
  assert.match(r.errore, /Colonne obbligatorie mancanti/);
  assert.match(r.errore, /codice_fiscale/); // v2.0
  assert.match(r.errore, /sesso/);
  assert.match(r.errore, /qualifica/);
});

test('[unit] import.analizzaCsv: riga valida → dati normalizzati; riga invalida → errori di riga', () => {
  const head = 'Nome;Cognome;Matricola;CF;Sesso;Qualifica_Professionale;E-Mail;Ruolo;password_provvisoria';
  const r = I.analizzaCsv([
    head,
    'Maria;Carta;30100;rssmra80a01h501u;f;Istruttore;;DIPENDENTE;Benvenuto2026', // CF e sesso minuscoli
    'Gino;Di Gino;X;CF-SBAGLIATO;M;Impiegato;;',                                  // matricola e CF errati
  ].join('\n'));
  assert.equal(r.ok, true);
  assert.equal(r.totaleRighe, 2);

  const buona = r.record[0];
  assert.deepEqual(buona.errori, []);
  assert.equal(buona.dati.codice_fiscale, 'RSSMRA80A01H501U', 'CF portato in maiuscolo');
  assert.equal(buona.dati.sesso, 'F');
  assert.equal(buona.dati.ruolo, 'DIPENDENTE');

  const cattiva = r.record[1];
  assert.ok(cattiva.errori.some((e) => /matricola/.test(e)));
  assert.ok(cattiva.errori.some((e) => /codice_fiscale/.test(e)));
});

test('[unit] import.analizzaCsv: le righe vuote non generano record né errori', () => {
  const head = 'nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale';
  // riga vuota e riga di soli spazi: parseCsv/analizzaCsv le scartano del tutto
  const r = I.analizzaCsv([head, 'A;B;aud10;RSSMRA80A01H501U;M;Impiegato', '', '   '].join('\n'));
  assert.equal(r.ok, true);
  assert.equal(r.totaleRighe, 1, 'solo la riga con dati diventa un record');
  assert.equal(r.righeVuoteIgnorate, 0, 'le righe vuote vengono filtrate a monte dal parser');
});

test('[unit] import.analizzaCsv: matricole o CF duplicati NEL FILE → errore di riga', () => {
  const head = 'nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale';
  const r = I.analizzaCsv([
    head,
    'A;B;aud20;RSSMRA80A01H501U;M;Impiegato',
    'C;D;aud20;GLLANN85C15G822C;M;Impiegato',  // stessa matricola
    'E;F;aud21;RSSMRA80A01H501U;F;Impiegato',  // stesso CF
  ].join('\n'));
  assert.equal(r.ok, true);
  assert.ok(r.record[1].errori.some((e) => /duplicat/i.test(e)), 'matricola duplicata nel file');
  assert.ok(r.record[2].errori.some((e) => /duplicat/i.test(e)), 'CF duplicato nel file');
});

test('[unit] import.analizzaCsv: tetto di righe (MAX_RIGHE_IMPORT) → rifiuto esplicito', () => {
  const head = 'nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale';
  const riga = 'X;Y;mX;CF;M;Impiegato';
  const corpo = Array(I.MAX_RIGHE_IMPORT + 1).fill(riga);
  const r = I.analizzaCsv([head, ...corpo].join('\n'));
  assert.equal(r.ok, false);
  assert.match(r.errore, /troppe righe/);
});

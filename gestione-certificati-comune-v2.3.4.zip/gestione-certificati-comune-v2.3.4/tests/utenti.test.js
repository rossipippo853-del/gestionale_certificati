/**
 * utenti.test.js — CRUD utenti lato admin: creazione (con cartella matricola,
 * BUG#3), duplicati, reset password, abilita/disabilita (BUG#2 lato server),
 * applicazione del cambio password obbligatorio.
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { test, before, after } = require('node:test');
const h = require('./helper');

before(async () => { await h.avvia(); await h.resetDati(); });
after(async () => { await h.chiudi(); });

async function adminCookie() {
  const { cookie } = await h.login(h.ADMIN.matricola, h.ADMIN.password);
  return cookie;
}

/* ------------------------- CREAZIONE UTENTI ------------------------- */

test('BUG#3 (regressione): creazione dipendente → cartella matricola creata SUBITO', async () => {
  const { status, dati } = await h.chiedi('/api/admin/utenti', {
    method: 'POST', cookie: await adminCookie(),
    body: { matricola: 'nu999', codice_fiscale: 'RRVNVO88A01H501D', nome: 'Nuovo', cognome: 'Arrivato', sesso: 'M', qualifica: 'Istruttore direttivo' },
  });
  h.assert.equal(status, 201);
  h.assert.ok(dati.passwordProvvisoria, 'deve restituire la password provvisoria');
  h.assert.match(dati.passwordProvvisoria, /^.{8,72}$/);
  h.assert.match(dati.passwordProvvisoria, /[A-Za-z]/);
  h.assert.match(dati.passwordProvvisoria, /\d/);

  const cartella = path.join(h.DIR_CERT, 'RRVNVO88A01H501D'); // v2.0: cartella col CODICE FISCALE
  h.assert.ok(fs.existsSync(cartella), 'uploads-test/certificati/{CF} deve esistere subito');
  h.assert.ok(fs.statSync(cartella).isDirectory());

  // lo stato iniziale impone il cambio password
  const [righe] = await h.pool.query("SELECT must_change_password, ruolo, sesso, qualifica FROM dipendenti WHERE matricola='nu999'");
  h.assert.equal(righe[0].must_change_password, 1);
  h.assert.equal(righe[0].ruolo, 'DIPENDENTE');
  h.assert.equal(righe[0].sesso, 'M');                          // v1.4
  h.assert.equal(righe[0].qualifica, 'Istruttore direttivo');   // v1.4
});

test('matricola duplicata → 409 e NESSUNA cartella orfana', async () => {
  const { status, dati } = await h.chiedi('/api/admin/utenti', {
    method: 'POST', cookie: await adminCookie(),
    body: { matricola: 'nu999', codice_fiscale: 'TSTDPL90B02H501E', nome: 'Duplicato', cognome: 'Test', sesso: 'F', qualifica: 'Dirigente' },
  });
  h.assert.equal(status, 409);
  h.assert.match(dati.errore, /già esistente/i);
  h.assert.ok(!fs.existsSync(path.join(h.DIR_CERT, 'nu999')) || fs.readdirSync(path.join(h.DIR_CERT, 'nu999')).length >= 0,
    'la cartella non viene ricreata dal tentativo duplicato');
});

test('creazione con dati non validi → 400 (matricola corta, nome mancante, ruolo assurdo)', async () => {
  const c = await adminCookie();
  h.assert.equal((await h.chiedi('/api/admin/utenti', {
    method: 'POST', cookie: c, body: { matricola: 'a', codice_fiscale: 'XYXYXY80A01H501F', nome: 'X', cognome: 'Y' },
  })).status, 400);
  h.assert.equal((await h.chiedi('/api/admin/utenti', {
    method: 'POST', cookie: c, body: { matricola: 'ok123', codice_fiscale: 'YOK12385C15G822H', nome: '', cognome: 'Y' },
  })).status, 400);
  h.assert.equal((await h.chiedi('/api/admin/utenti', {
    method: 'POST', cookie: c, body: { matricola: 'ok124', codice_fiscale: 'BAOK12490D20H501L', nome: 'A', cognome: 'B', ruolo: 'CAPO', sesso: 'M', qualifica: 'Funzionario' },
  })).status, 400);
  // v1.4: sesso e qualifica sono ORA obbligatori
  h.assert.equal((await h.chiedi('/api/admin/utenti', {
    method: 'POST', cookie: c, body: { matricola: 'ok125', codice_fiscale: 'SSOK12595E30H501M', nome: 'Senza', cognome: 'Sesso' },
  })).status, 400);
  h.assert.equal((await h.chiedi('/api/admin/utenti', {
    method: 'POST', cookie: c, body: { matricola: 'ok126', codice_fiscale: 'QSOK12699F12H501N', nome: 'Senza', cognome: 'Qualifica', sesso: 'ALTRO' },
  })).status, 400);
});

test('creazione con password esplicita troppo debole → 400', async () => {
  const { status } = await h.chiedi('/api/admin/utenti', {
    method: 'POST', cookie: await adminCookie(),
    body: { matricola: 'nu998', codice_fiscale: 'PSSWKA92G40H501P', nome: 'Weak', cognome: 'Pass', sesso: 'M', qualifica: 'Collaboratore', password: 'corta' },
  });
  h.assert.equal(status, 400);
});

/* ------------------------ RICERCA / ELENCO -------------------------- */

test('ricerca admin: corrispondenze corrette e LIKE letterale', async () => {
  const c = await adminCookie();
  const trovati = await h.chiedi('/api/admin/utenti?q=qa', { cookie: c });
  h.assert.ok(trovati.dati.totale >= 3, 'almeno le 2 fixture + admin');
  h.assert.ok(trovati.dati.utenti.every((u) => 'matricola' in u && !('password_hash' in u)),
    'mai il campo password_hash');

  // [FIX QA] i metacaratteri LIKE sono letterali: "qa%" NON deve matchare nulla
  const literal = await h.chiedi('/api/admin/utenti?q=' + encodeURIComponent('qa%'), { cookie: c });
  h.assert.equal(literal.dati.totale, 0);

  // i parametri ripetuti (?q=a&q=b) non rompono il filtro
  const doppio = await h.chiedi('/api/admin/utenti?q=qa001&q=qa002', { cookie: c });
  h.assert.equal(doppio.dati.totale, 1);
});

test('paginazione utenti: 8 utenti + perPagina=5 → pagina 2 con i restanti', async () => {
  // perPagina ha un minimo di 5 (anti-abuso): creiamo abbastanza utenti reali
  const c = await adminCookie();
  for (let i = 1; i <= 5; i++) {
    const { status } = await h.chiedi('/api/admin/utenti', {
      method: 'POST', cookie: c,
      body: { matricola: `pg00${i}`, codice_fiscale: `PGCNNM80A${String(i).padStart(2, '0')}H501U`, nome: `Nome${i}`, cognome: `Cognome${i}`, sesso: 'F', qualifica: 'Assistente amministrativo' },
    });
    h.assert.equal(status, 201);
  }
  const { dati } = await h.chiedi('/api/admin/utenti?perPagina=5&pagina=2', { cookie: c });
  h.assert.equal(dati.pagina, 2);
  h.assert.equal(dati.pagineTotali, 2);
  h.assert.ok(dati.utenti.length >= 1 && dati.utenti.length <= 5);
  h.assert.equal(dati.totale, 9);
});

test('options utente → elenco compatto senza dati sensibili', async () => {
  const { dati } = await h.chiedi('/api/admin/utenti/options', { cookie: await adminCookie() });
  h.assert.ok(Array.isArray(dati.opzioni));
  const prima = dati.opzioni.find((o) => o.matricola === h.DIP1.matricola);
  h.assert.ok(prima);
  h.assert.ok(!('password_hash' in prima));
});

/* --------------------------- RESET PASSWORD ------------------------- */

test('reset password admin: genera provvisoria e OBBLIGA il cambio al login (v2.1)', async () => {
  const id = await h.idDi(h.DIP2.matricola);
  const { status, dati } = await h.chiedi(`/api/admin/utenti/${id}/password`, {
    method: 'PUT', cookie: await adminCookie(), body: {},
  });
  h.assert.equal(status, 200);
  h.assert.ok(/^[A-Za-z\d]{10}$/.test(dati.passwordProvvisoria), 'provvisoria di 10 caratteri');

  const [righe] = await h.pool.query('SELECT must_change_password FROM dipendenti WHERE id = ?', [id]);
  h.assert.equal(righe[0].must_change_password, 1);

  // Il login NON apre più la sessione: restituisce il segnale per la modale
  // di cambio obbligatorio e il cookie monouso `token_cambio`.
  const accesso = await h.login(h.DIP2.matricola, dati.passwordProvvisoria);
  h.assert.equal(accesso.status, 200);
  h.assert.equal(accesso.dati.primoAccesso, true, 'il backend impone il cambio in modale');
  h.assert.ok(accesso.cookie.startsWith('token_cambio='), 'cookie di cambio monouso');

  // La modale si completa con la nuova password: usiamo quella definitiva
  // nota della fixture, così i test successivi restano coerenti.
  const cambio = await h.chiedi('/api/auth/primo-accesso', {
    method: 'POST', cookie: accesso.cookie,
    body: { nuovaPassword: h.DIP2.password, confermaPassword: h.DIP2.password },
  });
  h.assert.equal(cambio.status, 200);
  h.assert.equal(cambio.dati.utente.mustChangePassword, false, 'flag azzerato');

  // A regime: la provvisoria non funziona più, la nuova sì e senza modale.
  h.assert.equal((await h.login(h.DIP2.matricola, dati.passwordProvvisoria)).status, 401);
  const regime = await h.login(h.DIP2.matricola, h.DIP2.password);
  h.assert.equal(regime.status, 200);
  h.assert.ok(!regime.dati.primoAccesso, 'accesso diretto, nessun cambio richiesto');
});

test('reset con password manuale debole → 400', async () => {
  const id = await h.idDi(h.DIP2.matricola);
  const { status } = await h.chiedi(`/api/admin/utenti/${id}/password`, {
    method: 'PUT', cookie: await adminCookie(), body: { nuovaPassword: '123' },
  });
  h.assert.equal(status, 400);
});

test('reset su utente inesistente → 404; id non numerico → 400', async () => {
  const c = await adminCookie();
  h.assert.equal((await h.chiedi('/api/admin/utenti/99999/password', { method: 'PUT', cookie: c, body: {} })).status, 404);
  h.assert.equal((await h.chiedi('/api/admin/utenti/abc/password', { method: 'PUT', cookie: c, body: {} })).status, 400);
});

/* --------- [v2.1] PRIMO ACCESSO: MODALE BLOCCANTE SULLA PAGINA DI LOGIN --------- */

test('[v2.1] primo accesso: nessuna sessione, cambio obbligatorio, ingresso immediato', async () => {
  // nu999 (creato dall'admin, must_change_password=1): portiamo la
  // provvisoria a un valore noto con un reset.
  const id = await h.idDi('nu999');
  const reset = await h.chiedi(`/api/admin/utenti/${id}/password`, { method: 'PUT', cookie: await adminCookie(), body: {} });
  const provvisoria = reset.dati.passwordProvvisoria;

  // 1) Il login rileva la provvisoria e NON emette la sessione
  const accesso = await h.login('nu999', provvisoria);
  h.assert.equal(accesso.status, 200);
  h.assert.equal(accesso.dati.primoAccesso, true, 'il frontend deve aprire la modale');
  h.assert.equal(accesso.dati.utente.matricola, 'nu999');
  h.assert.ok(accesso.cookie.startsWith('token_cambio='), 'solo il cookie di cambio');

  // 2) Il cookie di cambio NON vale come sessione, nemmeno travestito da `token`
  h.assert.equal((await h.chiedi('/api/auth/me', { cookie: accesso.cookie })).status, 401);
  const valoreCambio = accesso.cookie.split(';')[0].replace(/^token_cambio=/, '');
  h.assert.equal((await h.chiedi('/api/auth/me', { cookie: `token=${valoreCambio}` })).status, 401,
    'il token "scopito" primo-accesso è rifiutato dal middleware di sessione');

  // 3) Senza cookie di cambio l\'endpoint della modale è irraggiungibile
  h.assert.equal((await h.chiedi('/api/auth/primo-accesso', {
    method: 'POST', body: { nuovaPassword: 'Xyz12345', confermaPassword: 'Xyz12345' },
  })).status, 401);

  // 4) Validazioni mostrate DENTRO la modale
  const cambia = (body) => h.chiedi('/api/auth/primo-accesso', { method: 'POST', cookie: accesso.cookie, body });
  h.assert.equal((await cambia({ nuovaPassword: 'Diversa123', confermaPassword: 'Altro12345' })).status, 400, 'non coincidono');
  h.assert.equal((await cambia({ nuovaPassword: 'corta', confermaPassword: 'corta' })).status, 400, 'policy');
  h.assert.equal((await cambia({ nuovaPassword: provvisoria, confermaPassword: provvisoria })).status, 400,
    'uguale alla provvisoria');

  // 5) Cambio valido → flag azzerato e SESSIONE emessa: dashboard raggiunta
  const ok = await cambia({ nuovaPassword: 'Cambiata123', confermaPassword: 'Cambiata123' });
  h.assert.equal(ok.status, 200);
  const cookieSessione = (ok.headers.getSetCookie().find((c) => c.startsWith('token=')) || '');
  h.assert.ok(cookieSessione.startsWith('token='), 'sessione ufficiale dopo il cambio');
  h.assert.equal(ok.dati.utente.mustChangePassword, false);

  // 6) Il cookie di cambio era MONOUSO: riutilizzo → 401
  h.assert.equal((await cambia({ nuovaPassword: 'Ancora123', confermaPassword: 'Ancora123' })).status, 401);

  // 7) La provvisoria è morta; la nuova entra senza alcuna modale
  h.assert.equal((await h.login('nu999', provvisoria)).status, 401);
  const finale = await h.login('nu999', 'Cambiata123');
  h.assert.equal(finale.status, 200);
  h.assert.ok(!finale.dati.primoAccesso);
  h.assert.ok(finale.cookie.startsWith('token='));

  // 8) Con la sessione nuova l'upload funziona subito (nessun vincolo residuo)
  const caricato = await h.chiedi('/api/certificati', {
    method: 'POST', cookie: cookieSessione,
    formData: h.uploadFormData({ corso: 'Dopo il cambio in modale', ente: 'Ente', data: '2026-02-01' }),
  });
  h.assert.equal(caricato.status, 201);
});

/* ---------------------- ABILITA / DISABILITA ------------------------ */

test('BUG#2 (lato server): disable → attivo=0 a DB → enable → attivo=1', async () => {
  const c = await adminCookie();
  const id = await h.idDi(h.DIP2.matricola);

  const off = await h.chiedi(`/api/admin/utenti/${id}/stato`, { method: 'PUT', cookie: c, body: { attivo: false } });
  h.assert.equal(off.status, 200);
  const [dopo0] = await h.pool.query('SELECT attivo FROM dipendenti WHERE id = ?', [id]);
  h.assert.equal(dopo0[0].attivo, 0);

  const on = await h.chiedi(`/api/admin/utenti/${id}/stato`, { method: 'PUT', cookie: c, body: { attivo: true } });
  h.assert.equal(on.status, 200);
  const [dopo1] = await h.pool.query('SELECT attivo FROM dipendenti WHERE id = ?', [id]);
  h.assert.equal(dopo1[0].attivo, 1);
});

test('stato con body non booleano → 400', async () => {
  const id = await h.idDi(h.DIP2.matricola);
  const { status } = await h.chiedi(`/api/admin/utenti/${id}/stato`, {
    method: 'PUT', cookie: await adminCookie(), body: { attivo: 'sì' },
  });
  h.assert.equal(status, 400);
});

test("l'admin non può disabilitare se stesso → 400", async () => {
  const id = await h.idDi(h.ADMIN.matricola);
  const { status, dati } = await h.chiedi(`/api/admin/utenti/${id}/stato`, {
    method: 'PUT', cookie: await adminCookie(), body: { attivo: false },
  });
  h.assert.equal(status, 400);
  h.assert.match(dati.errore, /tuo stesso account/i);
});

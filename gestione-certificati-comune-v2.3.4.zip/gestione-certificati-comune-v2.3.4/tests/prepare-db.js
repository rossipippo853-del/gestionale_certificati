/**
 * prepare-db.js — Ricrea il database di TEST partendo dallo schema ufficiale.
 * Il file db/schema.sql resta l'unica fonte di verità: viene riscritto
 * sostituendo il nome del database con quello di test e applicato come root.
 */
const { execSync } = require('child_process');
const path = require('path');

const radice = path.resolve(__dirname, '..');

try {
  execSync(
    'bash -c "sed \'s/certificati_comune\\b/certificati_comune_test/g\' db/schema.sql | sudo mysql"',
    { cwd: radice, stdio: 'inherit' }
  );
  console.log('[OK] Database di test "certificati_comune_test" pronto (schema applicato).');
} catch (err) {
  console.error('[FATALE] Impossibile preparare il database di test:', err.message);
  console.error('Serve MySQL/MariaDB attivo e i permessi per eseguire lo schema (sudo mysql).');
  process.exit(1);
}

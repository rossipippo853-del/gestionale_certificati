# 🏛️ Gestione Certificati — Ente Comunale

Web app per la gestione dei **certificati di formazione di ~250 dipendenti comunali**:
caricamento dei PDF da parte dei dipendenti, revisione/approvazione da parte
dell'amministratore, gestione degli account ed esportazione dei report.

- **Backend**: Node.js (Express) + MySQL/MariaDB + JWT (cookie httpOnly) + Multer
- **Frontend**: HTML/CSS/JS vanilla — nessun build step, nessuna dipendenza CDN (ideale per intranet)
- **Storage**: i PDF risiedono **sul file system del server**, nel DB solo il percorso

---

## 1. Requisiti di sistema

| Componente | Versione consigliata |
|---|---|
| Node.js | ≥ 18 LTS |
| MySQL | ≥ 8.0 **oppure** MariaDB ≥ 10.6 |
| Sistema operativo | qualsiasi Linux/macOS/Windows con Node e MySQL |
| Spazio su disco | ~50 MB/app + ~1 MB per ogni PDF caricato |

## 2. Installazione rapida (server locale)

> 🖥️ **Guida passo-passo per Windows/prova a casa:** apri [GUIDA-INSTALLAZIONE.md](GUIDA-INSTALLAZIONE.md)
>
> 🆔 **v2.0 — Codice Fiscale:** le cartelle PDF sono `uploads/certificati/{CODICE_FISCALE}/`; il CF è obbligatorio in creazione e import CSV (colonna `codice_fiscale`); nuovo **«⬆ Carica per dipendente»** nell'area admin. Migrazione: `db/migrazione-v2.0.sql` · Report: [docs/REPORT-TEST-v2.0.md](docs/REPORT-TEST-v2.0.md)
>
> 🖥 **Server Intranet con IP fisso (v1.5):** [docs/GUIDA-SERVER-INTRANET.md](docs/GUIDA-SERVER-INTRANET.md) (Windows/Linux, firewall, avvio automatico)
>
> 📎 **v2.2.8 — modifica anagrafica dipendente (✏️ nell'area admin), tabella compatta, filtro Durata:**
> ogni corso può avere fino a **5 documenti PDF/JPEG/PNG**; la durata si inserisce in
> **un'unica cella** nel formato `ore:minuti` (es. `8:30`, `0:45`, `8`); «Esame finale» è
> un **menù a tendina Sì/No** in ogni form di caricamento (filtro Sì/No anche nel
> pannello admin); nel profilo dipendente: **ore formative totali dei corsi validi e
> in attesa** — i corsi **rifiutati** dall'amministratore **non contano** e le loro ore
> escono subito dal totale — con **spunta verde** oltre le 40 ore (40:00 esatte non
> bastano); la **tabella admin** mostra **tutti** i certificati senza paginazione
> (i rifiutati restano visibili in lista); nella colonna FILE delle tabelle di
> riepilogo il download avviene con un **pulsante «⬇ Scarica»** (numerato se un
> corso ha più allegati, nome completo nel suggerimento); **nuove aree tematiche**
> (17 voci) nei form di caricamento, con le 6 aree precedenti conservate in
> archivio e filtrabili. Migrazioni: `db/migrazione-v2.2.sql`, `db/migrazione-v2.2.5.sql`.
>
> 🔐 **Onboarding v2.1 — cambio password obbligatorio in modale:** al primo accesso con la password provvisoria, il login NON apre la sessione: la pagina di accesso mostra un pop-up bloccante «Primo Accesso — Cambio Password Obbligatorio» e solo dopo il cambio si entra in dashboard. (Resta garantito v1.5: con sessione già attiva il caricamento non è mai bloccato.) Report: [docs/REPORT-TEST-v2.0.md](docs/REPORT-TEST-v2.0.md)
>
> 📗 **Guida Operativa v1.4 (migrazioni, import CSV, nuovi campi, export):** [docs/GUIDA-OPERATIVA.md](docs/GUIDA-OPERATIVA.md)
>
> 📥 **Importazione massiva dei dipendenti:** [docs/IMPORT-DIPENDENTI.md](docs/IMPORT-DIPENDENTI.md) (pannello web + CLI, formato file, modello CSV)
>
> 📘 **Documentazione completa:** [docs/ANALISI-TECNICA.md](docs/ANALISI-TECNICA.md) (per gli sviluppatori/IT) ·
> [docs/DOCUMENTO-DIREZIONE.md](docs/DOCUMENTO-DIREZIONE.md) (presentazione per la Dirigenza) ·
> [QA-REPORT.md](QA-REPORT.md) (verifiche) · [BUGFIX.md](BUGFIX.md) (storico correzioni)

```bash
# 1) dipendenze
cd certificati-comune
npm install

# 2) database — prima apri db/schema.sql e sostituisci la password
#    dell'utente 'cert_app', poi:
mysql -u root -p < db/schema.sql

# 3) configurazione
cp .env.example .env
#   → imposta DB_USER/DB_PASSWORD (come nello schema.sql), DB_NAME,
#     e JWT_SECRET (genera con: openssl rand -hex 32)

# 4) crea l'admin e i dipendenti demo (idempotente)
node db/seed.js --dipendenti=250    # o senza parametri per solo 12 demo

# 5) avvio
npm start
# → http://localhost:3000
```

**Credenziali iniziali** (create da `db/seed.js`):

| Ruolo | Matricola | Password |
|---|---|---|
| AMMINISTRATORE | `admin` | `Admin@2026` |
| DIPENDENTI demo | `10001` … `1NNNN` | `Benvenuto@2026` (cambio obbligatorio al primo accesso) |

> ⚠️ Cambia subito la password dell'admin dopo il primo accesso (sezione Profilo).

## 3. Avvio come servizio (produzione)

### systemd (Linux)

```bash
sudo cp deploy/certificati.service /etc/systemd/system/
# adatta User= e WorkingDirectory= al tuo server, poi:
sudo systemctl daemon-reload
sudo systemctl enable --now certificati
```

### PM2 (alternativa)

```bash
npm install -g pm2
pm2 start server.js --name certificati && pm2 save
```

### Dietro nginx (opzionale, HTTPS + porta 80)

```nginx
server {
  listen 443 ssl http2;
  server_name certificati.comune.local;
  # ssl_certificate … ssl_certificate_key …

  client_max_body_size 6m;   # sopra il limite dei 5 MB per upload

  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```

Se attivi HTTPS, imposta `COOKIE_SECURE=true` nel `.env`.

## 4. Struttura del progetto

```
certificati-comune/
├── server.js                    # entry point Express
├── package.json
├── .env                         # configurazione (NON versionare)
├── .env.example
├── db/
│   ├── schema.sql               # CREATE DATABASE + tabelle + utente applicativo
│   ├── seed.js                  # admin + dipendenti/certificati demo
│   ├── import-dipendenti.js     # IMPORT MASSIVO da CLI: node db/import-dipendenti.js file.csv
│   └── modello-dipendenti.csv   # modello CSV per l'importazione
├── src/
│   ├── config.js                # lettura .env centralizzata
│   ├── db.js                    # pool mysql2 (query parametriche)
│   ├── middleware/
│   │   ├── auth.js              # JWT da cookie httpOnly + ruolo AMMINISTRATORE
│   │   └── errori.js            # gestore errori centrale (multer, 500…)
│   ├── routes/
│   │   ├── auth.routes.js       # login/logout/me/cambio password + anti brute-force
│   │   ├── certificati.routes.js# upload/lista/download del dipendente
│   │   └── admin.routes.js      # utenti, certificati globali, CSV, approvazioni
│   └── utils/
│       ├── file.js              # storage sicuro, nomi univoci, magic bytes PDF
│       ├── validazione.js       # validazioni input lato server
│       ├── importazione.js      # motore import massivo CSV (web + CLI)
│       ├── password.js          # generazione password provvisorie (CSPRNG)
│       └── sessioni.js          # revoca dei token (logout reale)
├── public/                      # frontend statico servito da Express
│   ├── index.html               # login
│   ├── dipendente.html          # area dipendente
│   ├── admin.html               # area amministratore
│   ├── css/stile.css
│   └── js/{common,dipendente,admin}.js
├── deploy/certificati.service   # unit systemd
└── uploads/                     # ← PDF reali (creata automaticamente)
    └── certificati/{matricola}/{timestamp}_{nome}.pdf
```

## 5. API RESTful

| Metodo | Endpoint | Ruolo | Descrizione |
|---|---|---|---|
| POST | `/api/auth/login` | pubblico | login (matricola + password) |
| POST | `/api/auth/logout` | autenticato | logout, invalida cookie |
| GET | `/api/auth/me` | autenticato | profilo corrente |
| PUT | `/api/auth/password` | autenticato | cambio password (richiede quella attuale) |
| GET | `/api/certificati` | autenticato | elenco dei propri certificati |
| POST | `/api/certificati` | autenticato | upload (multipart: `nome_corso`, `ente_erogatore`, `data_conseguimento`, `file`) |
| GET | `/api/certificati/:id/file` | proprietario o admin | PDF (`?modo=visualizza` per inline) |
| GET | `/api/admin/stats` | admin | contatori dashboard |
| GET | `/api/admin/utenti` | admin | lista utenti (ricerca `q`, `attivo`, paginazione) |
| GET | `/api/admin/utenti/options` | admin | elenco compatto per filtri |
| POST | `/api/admin/utenti` | admin | crea dipendente |
| POST | `/api/admin/utenti/import` | admin | **import massivo da CSV** (`duplicati=ignora\|aggiorna`, `dry_run=1`) |
| PUT | `/api/admin/utenti/:id/password` | admin | reset password (genera provvisoria se vuota) |
| PUT | `/api/admin/utenti/:id/stato` | admin | abilita/disabilita account |
| GET | `/api/admin/certificati` | admin | vista globale (`q`, `stato`, `dipendenteId`, `dal`, `al`) |
| GET | `/api/admin/certificati/export` | admin | export CSV (stessi filtri) |
| PUT | `/api/admin/certificati/:id/stato` | admin | approva/rifiuta (+ nota) |
| GET | `/api/admin/certificati?area=…` | admin | filtro **area tematica** (v1.4, 6 aree) |
| DELETE | `/api/admin/certificati/:id` | admin | elimina record + PDF |
| GET | `/api/salute` | pubblico | health check |

## 6. Test automatici (QA)

```bash
npm test
```

290 test (115 regressione/unit + 175 collaudo/audit Jest/Supertest) (runner nativo `node --test`) su database e
cartella upload **dedicati**: flusso di autenticazione e sessione, cambio
password, CRUD utenti, permessi per ruolo, upload/download PDF, creazione e
self-healing delle cartelle, race condition, export CSV, **importazione
massiva da CSV**. Dettagli completi nel report [QA-REPORT.md](QA-REPORT.md).

## 7. Sicurezza — checklist implementata

- ✅ Password con **bcrypt** (costo 10) — mai in chiaro nel DB
- ✅ **JWT firmato** in cookie **httpOnly** (non leggibile da JS → anti-XSS), scadenza 8 h
- ✅ Ogni richiesta ricarica l'utente dal DB: **account disabilitato = accesso immediatamente negato**
- ✅ Rotte admin protette da middleware di **ruolo**; 403 per i dipendenti
- ✅ Download PDF consentito **solo al proprietario o all'admin** (403 altrimenti)
- ✅ Anti **path traversal**: percorso relativo verificato dentro la cartella upload
- ✅ Upload: solo estensione `.pdf` **e** MIME `application/pdf` **e** magic bytes `%PDF-`, max **5 MB**
- ✅ Nome file univoco `{timestamp}_{nome_sanificato}.pdf` (niente sovrascritture)
- ✅ Query SQL **100% parametriche** (anti SQL injection)
- ✅ Rate limit sul login (5 tentativi / 15 minuti per matricola) + messaggi di errore generici
- ✅ Output HTML sempre escapato nel frontend (anti XSS)

## 7. Manutenzione e backup

```bash
# backup completo (DB + PDF), da pianificare con cron:
mysqldump -u root -p certificati_comune > backup_$(date +%F).sql
tar czf uploads_$(date +%F).tar.gz uploads/
```

Log del servizio: `journalctl -u certificati -f` (systemd) oppure PM2 logs.

## 9. Risoluzione problemi

| Problema | Causa probabile |
|---|---|
| `[FATALE] Database non raggiungibile` | MySQL non avviato o `.env` errato |
| `ER_ACCESS_DENIED_ERROR` | credenziali DB_USER/DB_PASSWORD errate rispetto a schema.sql |
| Upload rifiutato pur essendo PDF | dimensione > 5 MB o MIME alterato (rinominare il file, non comprimerlo) |
| `Matricola già esistente` (409) | tentata creazione di un utente con matricola duplicata |

## 10. Novità v2.2.9 — «Città di Milazzo»

- **Brand istituzionale**: palette blu/azzurro + rosso/oro araldico, stemma SVG
  nel header e nella pagina di login, dicitura «Città di Milazzo — Portale
  Formazione e Certificati».
- **Sessione senza persistenza**: il cookie «token» è ora un cookie di
  SESSIONE (nessun Max-Age/Expires): chiuso il browser → re-login obbligatorio
  (il JWT interno resta valido 8h; «token_cambio» conserva 15 minuti).
- **Area «Procedimenti amministrativi»**: 18ª area tematica, prima di «Altro»,
  in form utente, filtri admin e dialog di modifica.
- **Bottone «💾 Salva»** sul form di caricamento del dipendente (l'upload per
  conto admin resta «Carica certificato»).
- **Ricerca autocompletante dipendenti** nel dialog «Carica per dipendente»:
  filtra in tempo reale per nome, cognome, matricola o CF.
- **Modifica certificati (admin)**: pulsante ✏️ nella tabella globale →
  correzione metadati (titolo, ente, data, durata hh:mm, esame, area); stato e
  file invariati; ogni modifica finisce nello storico.
- **Storico modifiche (audit log)**: pulsante «📜 Storico modifiche» — ultime
  100 operazioni (modifica/approvazione/rifiuto/eliminazione) con autore.
- **Impaginazione utenti server-side**: selettore 10/25/50 righe, controlli
  Precedente/Successivo (niente più scroll lunghi).
- **Esporta Anagrafica CSV**: Nome;Cognome;Matricola;CF;Sesso;Qualifica;Stato
  (BOM UTF-8 + separatore «;», apribile in Excel).
- **Dashboard analytics**: «Ore formative approvate per area tematica»
  (grafico a barre, solo corsi APPROVATI).
- **NGINX reverse proxy**: `deploy/nginx.conf` (80→3000) e
  `docs/GUIDA-DOMINIO-LOCALE-v2.2.9.md` per `http://portale.certificati`.

## 11. Novità v2.3.0 — Dashboard formazione + tabelle zero-scroll

- **Dashboard formazione per dipendente** (sostituisce il grafico globale
  v2.2.9): ricerca autocompletante per nome/cognome/matricola/CF e schede KPI
  scure — certificati caricati (approvati/in attesa/rifiutati), ore svolte
  approvate, **ore mancanti al target delle 40 ore obbligatorie** con barra di
  avanzamento percentuale, ripartizione ore/certificati per area tematica e
  badge di stato («In regola con il target 40h» / «In corso» / «Sotto la soglia»).
- **Nuovo endpoint** `GET /api/admin/utenti/:id/formazione` (RBAC admin,
  guardie 400/404): metriche calcolate lato server, target 2400 minuti.
- **Tabelle zero-scroll** (admin «Gestione Dipendenti» e dipendente «I Miei
  Certificati»): `table-layout: fixed`, larghezze per colonna, testo lungo a
  capo (overflow-wrap), padding ridotto, badge più piccoli e azioni compatte a
  icone con tooltip: tutte le colonne visibili a 1024px+ senza scrollbar
  orizzontale.

## 12. Novità v2.3.1 — Sessione di scheda, ore conteggiate, matricola 2-20

- **«✕ Chiudi scheda»** nella dashboard formazione per dipendente: nasconde i
  KPI e azzera la ricerca.
- **Ore conteggiate**: il target delle 40 ore considera ora `approvate + in
  attesa` (i rifiuti restano esclusi); nuove KPI «Ore approvate» e «Ore totali
  inviate» con dettaglio delle ore in attesa; le chip di area mostrano
  «(⏳ h:mm in attesa)». Nuovi campi API: `oreInAttesaMinuti`,
  `oreConteggiateMinuti`, `minutiAttesa` per area.
- **Sessione di scheda**: il token vive anche in `sessionStorage` e viaggia
  nell'header `Authorization: Bearer` (il middleware lo accetta accanto al
  cookie): chiusa la scheda → re-login obbligatorio. Il cookie httpOnly di
  sessione resta per i download diretti.
- **Matricola**: lunghezza minima 2 (regex 2-20 alfanumerici) su creazione,
  modifica, import CSV, validazione client e messaggi d'errore.
- Prove manuali rapide: `docs/PROVE-RAPIDE-v2.3.1.md`.

## 13. Novità v2.3.2 — Tab «Monitoraggio»

- La **Dashboard formazione per dipendente** si sposta dalla schermata
  principale nella nuova tab **📊 Monitoraggio** (tra Certificati e Profilo).
- **Grafico Target 40 ore** (ciambella): percentuale e numero di dipendenti al
  target, calcolato sulle ore CONTEGGIATE = **approvate + in attesa**.
- **Grafico Aree tematiche** (barre %): distribuzione di tutti i certificati
  caricati per area, con percentuale e numero assoluto.
- **KPI di sintesi**: media ore per dipendente, totale certificati in attesa,
  top 3 aree più frequentate.
- Nuovo endpoint `GET /api/admin/monitoraggio` (RBAC admin). La tab si
  aggiorna all'apertura e all'avvio.

## 14. Novità v2.3.3 — Modalità rigida sulla sessione

- Il cookie httpOnly è ora accettato **SOLO sui download diretti** (Scarica /
  Visualizza / Export CSV): per ogni altra richiesta l'autenticazione passa
  **solo** per il token di scheda (header `Authorization: Bearer` da
  sessionStorage). Effetto: **chiusa la scheda → re-login obbligatorio**,
  anche se il cookie sopravvive nel browser.
- Il logout revoca il token anche quando arriva via Bearer.
- Allowlist estendibile: `PERCORSI_DOWNLOAD_CON_COOKIE` in
  `src/middleware/auth.js`.

## 15. Novità v2.3.4 — Storico con azioni specifiche

La tabella «📜 Storico modifiche amministrative» mostra ora l'operazione ESATTA
nella colonna AZIONE, con badge colorati per famiglia:

| Codice nel log | Etichetta mostrata | Colore |
|---|---|---|
| `MODIFICA_TITOLO_CORSO` / `MODIFICA_ENTE_EROGATORE` / `MODIFICA_DATA_CONSEGUIMENTO` / `MODIFICA_DURATA` / `MODIFICA_ESAME_FINALE` / `MODIFICA_AREA_TEMATICA` | «Modifica Titolo Corso», «Modifica Ente Erogatore», … (una riga per campo realmente cambiato) | blu |
| `ELIMINAZIONE_<CAMPO>` | «Eliminazione Metadato» / «Eliminazione <campo>» | ambra |
| `APPROVAZIONE_CERTIFICATO` / `RIFIUTO_CERTIFICATO` | «Approvazione Certificato» / «Rifiuto Certificato» con «Stato: X → Y» | verde / rosso |
| `ELIMINAZIONE_CERTIFICATO` | «Eliminazione Certificato» con corso e matricola (ora l'eliminazione è tracciata) | rosso |
| `CAMBIO_STATO` (riservato) | «Cambio Stato» | ambra |
| codici pre-v2.3.4 | «… (storico)» | invariati |

La traduzione è **dinamica** (`etichettaAzione()` in `public/js/admin.js`):
regole per prefisso + mappa dei campi → anche codici futuri ottengono
etichetta e colore corretti senza toccare il rendering. I DETTAGLI mostrano i
valori «prima → dopo» (durata in h:mm, esame Sì/No, nota dell'approvazione).
Una PUT senza variazioni non scrive nessuna riga.

## 16. Novità v2.3.5 — Impaginazione certificati (admin e dipendente)

Anche l'elenco dei CERTIFICATI è ora impaginato lato server, con lo stesso
modello della tabella Dipendenti (v2.2.9):

| Vista | Selettore «Righe per pagina» | Default | Pager |
|---|---|---|---|
| Admin → Certificati | 10 / 25 / 50 | 25 | «← Precedente · Pagina X di Y — N risultati · Successiva →» |
| Dipendente → Elenco dei tuoi certificati | 10 / 25 / 50 | 10 | idem |

- I filtri (ricerca, stato, area, durata…) si combinano con la paginazione e
  riportano alla pagina 1; «Azzera» non tocca la preferenza righe/pagina.
- Le card statistiche del dipendente e i totali (ore valide, badge 40h)
  restano GLOBALI: contano sempre tutti i corsi, non solo la pagina a schermo.
- API: `GET /api/certificati?pagina=2&perPagina=25` → metadati `totale`,
  `pagina`, `perPagina`, `pagineTotali`, `conteggi`; senza parametri l'elenco
  resta completo (compatibilità). L'admin usa `GET /api/admin/certificati`
  con gli stessi parametri (già dalla v2.2.3).

## 17. Novità v2.3.6 — Filtri certificati «a flusso»

Nella sezione **Certificati** dell'area amministratore i campi filtro non
stanno più a blocchi di 3 per riga: scorrono **uno dopo l'altro** su una riga
unica e vanno a capo solo quando lo spazio orizzontale finisce (flex-wrap).
Larghezze calibrate per campo (ricerca, dipendente, area, date, righe per
pagina, «Azzera»). La tabella Dipendenti conserva la disposizione a griglia.

## 18. Novità v2.3.7 — Filtri certificati su due righe

Le larghezze dei filtri «a flusso» della sezione Certificati sono state
compresse (ricerca 230px, dipendente 185px, stato 120px, esame 110px,
area 210px, date 140px): i campi ora stanno in **due righe ordinate** alla
larghezza utile standard (riga 1: ricerca, dipendente, stato, esame, «dal» ·
riga 2: area, «al», durata, righe/pagina, «Azzera»), con a capo naturale
sugli schermi stretti e nessuno scroll orizzontale.

## 19. Novità v2.3.8 — Filtri certificati su due righe garantite

I filtri della sezione Certificati ora usano una griglia fissa a 5 colonne:
**esattamente due righe** (1ª: ricerca, dipendente, stato, esame finale,
area tematica · 2ª: conseguimento dal/al, durata, righe per pagina, Azzera)
indipendentemente dalla larghezza della finestra; i pulsanti Export CSV,
Storico modifiche e Carica per dipendente stanno su una riga sotto i filtri,
allineati a destra. Su schermi ≤900px la griglia passa a 2 colonne con a capo
naturale (zero scroll orizzontale, requisito 1024px+ presidiato).

## 20. Novità v2.3.10 — Frecce di paginazione sempre presenti

La pagina dipendente ora funziona con ENTRAMBE le versioni del backend:
- backend aggiornato (v2.3.5+): impaginazione lato server (consigliata);
- backend non aggiornato: la risposta contiene l'elenco completo → il browser
  lo impagina in LOCALE con le stesse frecce, e le card statistiche restano
  calcolate sull'intera lista. In nessun caso compare più «Pagina undefined».
Resta comunque raccomandato aggiornare e riavviare il backend per la
paginazione vera lato server (leggerezza con molte righe).

## 21. Novità v2.3.11 — Siti di formazione nella scheda Profilo

Nuova card «🎓 Siti di formazione» nel Profilo di dipendente e amministratore:
elenco delle piattaforme esterne con icona, descrizione e pulsante «Apri ↗»
(apertura in NUOVA scheda, `noopener noreferrer`). L'elenco si personalizza
in un UNICO punto — array `SITI_FORMAZIONE` in `public/js/common.js`:
per aggiungere o togliere una piattaforma basta una voce dell'array, entrambe
le pagine si aggiornano automaticamente. Configurazione iniziale: Syllabus
(piattaforma PA) + 2 placeholder.

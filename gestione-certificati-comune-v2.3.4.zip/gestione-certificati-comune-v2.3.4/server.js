/**
 * ============================================================================
 *  server.js — PUNTO DI INGRESSO DELL'APPLICAZIONE
 * ============================================================================
 *  Responsabilità (deliberatamente limitate, la configurazione Express vive
 *  in src/app.js per essere testabile):
 *    1. preparare le cartelle di storage;
 *    2. verificare la connessione al database (fail-fast se manca MySQL);
 *    3. mettersi in ascolto su 0.0.0.0:PORT;
 *    4. gestire lo spegnimento ordinato (SIGTERM/SIGINT).
 *
 *  Avvio:  npm start            (produzione, dietro systemd/PM2)
 *          npm run dev          (sviluppo, reload automatico)
 * ============================================================================
 */
require('dotenv').config();

const fs = require('fs');
const config = require('./src/config');
const { testConnection, pool } = require('./src/db');
const { DIR_CERTIFICATI } = require('./src/utils/file');
const { app } = require('./src/app');

async function avvia() {
  /* 1) Storage: creazione della radice uploads/certificati se assente
   *    (mkdirSync recursive è idempotente → sicuro rilanciarlo sempre). */
  fs.mkdirSync(DIR_CERTIFICATI, { recursive: true });

  /* 2) Fail-fast: se il DB non è raggiungibile ha poco senso partire.
   *    Il messaggio guida l'operatore verso le cause tipiche. */
  try {
    await testConnection();
    console.log('[OK] Connessione al database stabilita.');
  } catch (err) {
    console.error('[FATALE] Database non raggiungibile:', err.message);
    console.error('       Verifica che MySQL/MariaDB sia attivo e che il file .env sia corretto.');
    process.exit(1);
  }

  /* 3) Ascolto sull'interfaccia configurata (HOST, predefinito 0.0.0.0 =
   *    tutte le schede di rete): necessario perché i client della intranet
   *    raggiungano il server con http://IP-DEL-SERVER:PORTA. */
  const server = app.listen(config.port, config.host, () => {
    console.log(`[OK] Server avviato su http://${config.host}:${config.port}`);
    console.log('     Accesso dalla rete locale: http://<IP-DEL-SERVER>:' + config.port);
    console.log(`     Storage PDF: ${config.uploadRoot}`);
  });

  /* 4) Spegnimento ordinato [FIX QA-B7]: su SIGTERM (systemd/PM2/docker stop)
   *    o CTRL+C si smette di accettare connessioni, si chiude il pool MySQL
   *    e si esce. Un timer di sicurezza forza l'uscita dopo 8 s. */
  let inChiusura = false;
  async function spegni(segnale) {
    if (inChiusura) return;
    inChiusura = true;
    console.log(`\n[Ricevuto ${segnale}] chiusura in corso…`);
    server.close(() => pool.end().then(() => process.exit(0)));
    setTimeout(() => process.exit(1), 8000).unref();
  }
  process.on('SIGTERM', () => spegni('SIGTERM'));
  process.on('SIGINT', () => spegni('SIGINT'));

  /* Rete di sicurezza: un rifiuto di promessa non gestito viene registrato
   * (con traccia) invece di perdersi in silenzio; il processo resta vivo. */
  process.on('unhandledRejection', (motivo) => {
    console.error('[unhandledRejection]', motivo);
  });
}

avvia();

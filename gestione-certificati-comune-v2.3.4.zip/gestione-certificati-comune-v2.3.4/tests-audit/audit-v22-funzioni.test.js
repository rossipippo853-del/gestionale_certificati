/**
 * ============================================================================
 *  audit-v22-funzioni.test.js — COLLAUDO INTEGRAZIONE DELLE NOVITÀ v2.2
 * ============================================================================
 *  A. Filtro «Esame finale» a tendina nel pannello admin (lista + export).
 *  B. Upload MULTIFILE (PDF/JPEG/PNG) per lo stesso corso — area dipendente
 *     e «Carica per dipendente» dell'admin: allegati a DB, download per
 *     allegato, permessi, pulizia a cancellazione.
 *  C. Durata Ore:Minuti end-to-end (0 ore 45 minuti valida, 0:00 rifiutata).
 *  D. Ore formative totali (rifiutati ESCLUSI, v2.2.3) + spunta verde (> 40 ore).
 *  F. [v2.2.3] Tabella admin: elenco COMPLETO senza paginazione (perPagina=tutti).
 *  E. Export CSV: cella durata «8:30» e compatibilità v1.x («8»).
 * ============================================================================
 */
'use strict';

const h = require('../tests-qa/qahelper');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

/* Buffer minimi con le firme binarie corrette (la verifica del server è sui magic bytes). */
const pngBuf = () => Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D]);
const jpgBuf = () => Buffer.from([0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01]);

/* ════════════════ A. FILTRO ESAME FINALE ════════════════ */

describe('A · [v2.2] Filtro «Esame finale» (pannello admin)', () => {
  test('A1 · ?esame=si / ?esame=no filtrano la lista; valore non valido → 400', async () => {
    const { a } = await h.loginDip1();
    await h.caricaCertificato(a, { nome_corso: 'Con esame', esame_finale: '1' });
    await h.caricaCertificato(a, { nome_corso: 'Senza esame', esame_finale: '0' });

    const { a: admin } = await h.loginAdmin();

    const si = await admin.get('/api/admin/certificati?esame=si');
    expect(si.status).toBe(200);
    expect(si.body.certificati.map((c) => c.nome_corso)).toEqual(['Con esame']);
    expect(si.body.certificati.every((c) => c.esame_finale === 1)).toBe(true);

    const no = await admin.get('/api/admin/certificati?esame=no');
    expect(no.body.certificati.map((c) => c.nome_corso)).toEqual(['Senza esame']);

    const tutti = await admin.get('/api/admin/certificati');
    expect(tutti.body.certificati).toHaveLength(2);

    const brutto = await admin.get('/api/admin/certificati?esame=forse');
    expect(brutto.status).toBe(400);
    expect(brutto.body.errore).toMatch(/esame finale/i);
  });

  test('A2 · l\u2019export rispetta il filtro esame', async () => {
    const { a } = await h.loginDip1();
    await h.caricaCertificato(a, { nome_corso: 'Con esame', esame_finale: '1' });
    await h.caricaCertificato(a, { nome_corso: 'Senza esame', esame_finale: '0' });

    const { a: admin } = await h.loginAdmin();
    const testo = (await admin.get('/api/admin/certificati/export?esame=si')).text;
    expect(testo).toContain('Con esame');
    expect(testo).not.toContain('Senza esame');
  });
});

/* ════════════════ B. UPLOAD MULTIFILE PDF/JPEG/PNG ════════════════ */

describe('B · [v2.2] Upload multifile (PDF/JPEG/PNG) per lo stesso corso', () => {
  test('B1 · dipendente: 3 file (2 PDF + 1 PNG) → 201, 3 allegati a DB, download per allegato', async () => {
    const { a } = await h.loginDip1();
    const r = await a.post('/api/certificati')
      .field('nome_corso', 'Corso con 3 documenti')
      .field('ente_erogatore', 'Ente multi')
      .field('data_conseguimento', '2026-01-15')
      .field('numero_ore', '2')
      .field('numero_minuti', '30')
      .field('esame_finale', '1')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer('principale'), { filename: 'attestato.pdf', contentType: 'application/pdf' })
      .attach('file', h.pdfBuffer('allegato'), { filename: 'programma.pdf', contentType: 'application/pdf' })
      .attach('file', pngBuf(), { filename: 'scanner.png', contentType: 'image/png' });
    expect(r.status).toBe(201);
    expect(r.body.allegati).toBe(3);

    // 3 righe in tabella allegati, tutte nella cartella CF del dipendente
    const righe = await h.query(
      `SELECT a.*, c.dipendente_id FROM allegati a JOIN certificati c ON c.id = a.certificato_id
       WHERE c.nome_corso = 'Corso con 3 documenti'`
    );
    expect(righe).toHaveLength(3);
    expect(righe.map((x) => x.tipo_file).sort()).toEqual(['pdf', 'pdf', 'png']); // tipi REALI rilevati dalla firma
    for (const riga of righe) {
      expect(riga.percorso_file).toContain(`certificati/${h.DIP1.codice_fiscale}/`);
    }

    // l'elenco del dipendente mostra i 3 allegati
    const lista = await a.get('/api/certificati');
    const corso = lista.body.certificati.find((c) => c.nome_corso === 'Corso con 3 documenti');
    expect(corso.allegati).toHaveLength(3);

    // il download di OGNI allegato funziona, con il tipo MIME giusto
    const png = corso.allegati.find((x) => x.tipo === 'png');
    const scarico = await a.get(`/api/certificati/allegati/${png.id}/file`);
    expect(scarico.status).toBe(200);
    expect(scarico.headers['content-type']).toBe('image/png');
  });

  test('B2 · un dipendente NON può scaricare gli allegati altrui (403); l\u2019admin sì', async () => {
    const { a: dip1 } = await h.loginDip1();
    const r = await h.caricaCertificato(dip1, { nome_corso: 'Solo mio' });
    const id = r.body.id;
    const [allegato] = await h.query('SELECT id FROM allegati WHERE certificato_id = ?', [id]);

    const { a: dip2 } = await h.loginDip2();
    await dip2.get(`/api/certificati/allegati/${allegato.id}/file`).expect(403);

    const { a: admin } = await h.loginAdmin();
    const ok = await admin.get(`/api/certificati/allegati/${allegato.id}/file`);
    expect(ok.status).toBe(200);
  });

  test('B3 · file non riconosciuto (exe rinominato .jpg) → 400, zero scritture', async () => {
    const { a } = await h.loginDip1();
    const finto = Buffer.from('MZ\x90\x00questo non è un\u2019immagine');
    const r = await a.post('/api/certificati')
      .field('nome_corso', 'Falso JPG')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-01-15')
      .field('numero_ore', '1')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', finto, { filename: 'finto.jpg', contentType: 'image/jpeg' });
    expect(r.status).toBe(400);
    expect(JSON.stringify(r.body)).toMatch(/non è un file PDF, JPG o PNG valido/);
    expect(h.fileSuDisco(h.DIP1.codice_fiscale)).toEqual([]); // nessun orfano
    const n = await h.query("SELECT COUNT(*) AS n FROM allegati");
    expect(n[0].n).toBe(0);
  });

  test('B4 · admin «Carica per dipendente»: 2 file → cartella CF del dipendente + 2 allegati', async () => {
    const { a: admin } = await h.loginAdmin();
    const dip = (await h.query("SELECT id, codice_fiscale FROM dipendenti WHERE matricola = 'qa001'"))[0];

    const r = await admin.post('/api/admin/certificati')
      .field('dipendenteId', String(dip.id))
      .field('nome_corso', 'Caricato dall\u2019admin con 2 file')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-02-01')
      .field('numero_ore', '8')
      .field('numero_minuti', '0')
      .field('esame_finale', '0')
      .field('area_tematica', 'Leadership e soft skills')
      .attach('file', h.pdfBuffer('a'), { filename: 'a.pdf', contentType: 'application/pdf' })
      .attach('file', jpgBuf(), { filename: 'b.jpg', contentType: 'image/jpeg' });
    expect(r.status).toBe(201);

    const file = h.fileSuDisco(dip.codice_fiscale);
    expect(file).toHaveLength(2); // entrambi nella cartella CF del dipendente scelto
    const righe = await h.query(
      `SELECT a.tipo_file FROM allegati a JOIN certificati c ON c.id = a.certificato_id
       WHERE c.nome_corso = 'Caricato dall\u2019admin con 2 file'`
    );
    expect(righe.map((x) => x.tipo_file).sort()).toEqual(['jpeg', 'pdf']);

    // il dipendente vede e scarica anche gli allegati caricati per lui
    const { a: dip1 } = await h.loginDip1();
    const lista = await dip1.get('/api/certificati');
    const corso = lista.body.certificati.find((c) => c.nome_corso === 'Caricato dall\u2019admin con 2 file');
    expect(corso.allegati).toHaveLength(2);
    await dip1.get(`/api/certificati/allegati/${corso.allegati[1].id}/file`).expect(200);
  });

  test('B5 · DELETE del corso rimuove TUTTI i file degli allegati dal disco', async () => {
    const { a: dip1 } = await h.loginDip1();
    const r = await dip1.post('/api/certificati')
      .field('nome_corso', 'Da cancellare')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-03-01')
      .field('numero_ore', '1')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer('1'), { filename: '1.pdf', contentType: 'application/pdf' })
      .attach('file', pngBuf(), { filename: '2.png', contentType: 'image/png' });
    expect(r.status).toBe(201);
    expect(h.fileSuDisco(h.DIP1.codice_fiscale)).toHaveLength(2);

    const id = r.body.id;
    const { a: admin } = await h.loginAdmin();
    const del = await admin.delete(`/api/admin/certificati/${id}`);
    expect(del.status).toBe(200);

    expect(h.fileSuDisco(h.DIP1.codice_fiscale)).toEqual([]); // disco pulito
    const n = await h.query('SELECT COUNT(*) AS n FROM allegati WHERE certificato_id = ?', [id]);
    expect(n[0].n).toBe(0); // righe sparite (FK CASCADE)
  });

  test('B6 · più di 5 file → 400 (limite Multer gestito)', async () => {
    const { a } = await h.loginDip1();
    let req = a.post('/api/certificati')
      .field('nome_corso', 'Troppi file')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-01-15')
      .field('numero_ore', '1')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale');
    for (let i = 0; i < 6; i++) req = req.attach('file', h.pdfBuffer(`f${i}`), { filename: `f${i}.pdf`, contentType: 'application/pdf' });
    const r = await req;
    expect(r.status).toBe(400);
  });
});

/* ════════════════ C. DURATA ORE:MINUTI ════════════════ */

describe('C · [v2.2] Durata in ore e minuti', () => {
  test('C1 · 0 ore + 45 minuti → 201 e durata salvata; 0:00 → 400', async () => {
    const { a } = await h.loginDip1();
    const breve = await h.caricaCertificato(a, { nome_corso: 'Webinar breve', numero_ore: '1' });
    // compatibilità v1.x: un client che NON invia i minuti continua a funzionare
    expect(breve.status).toBe(201);

    const r = await a.post('/api/certificati')
      .field('nome_corso', 'Webinar 45 minuti')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-04-01')
      .field('numero_ore', '0')
      .field('numero_minuti', '45')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer('breve'), { filename: 'breve.pdf', contentType: 'application/pdf' });
    expect(r.status).toBe(201);

    const [riga] = await h.query("SELECT numero_ore, numero_minuti FROM certificati WHERE nome_corso = 'Webinar 45 minuti'");
    expect(riga.numero_ore).toBe(0);
    expect(riga.numero_minuti).toBe(45);

    const zero = await a.post('/api/certificati')
      .field('nome_corso', 'Durata nulla')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-04-01')
      .field('numero_ore', '0')
      .field('numero_minuti', '0')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer('zero'), { filename: 'zero.pdf', contentType: 'application/pdf' });
    expect(zero.status).toBe(400);
    expect(zero.body.errore).toMatch(/almeno 1 minuto/);
  });

  test('C2 · minuti 61 → 400', async () => {
    const { a } = await h.loginDip1();
    const r = await a.post('/api/certificati')
      .field('nome_corso', 'Minuti assurdi')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-04-01')
      .field('numero_ore', '8')
      .field('numero_minuti', '61')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer('x'), { filename: 'x.pdf', contentType: 'application/pdf' });
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/minuti/);
  });
});

/* ════════════════ D. ORE TOTALI + BADGE ≥ 40 ORE ════════════════ */

describe('D · [v2.2] Ore formative totali e badge di verifica', () => {
  test('D1 · [v2.2.3] il RIFIUTO sottrae le ore dal totale; la ri-approvazione le ridà', async () => {
    const { a: dip1 } = await h.loginDip1();

    // 30 ore + 8:30 + 2h = 40 ore e 30 minuti (2.430 minuti)
    const corsi = [
      { nome_corso: 'A 30h', numero_ore: '30' },
      { nome_corso: 'B 8h30', numero_ore: '8', numero_minuti: '30' },
      { nome_corso: 'C 2h', numero_ore: '2' },
    ];
    const ids = [];
    for (const corso of corsi) {
      const r = await dip1.post('/api/certificati')
        .field('nome_corso', corso.nome_corso)
        .field('ente_erogatore', 'Ente')
        .field('data_conseguimento', '2026-05-01')
        .field('numero_ore', corso.numero_ore)
        .field('numero_minuti', corso.numero_minuti || '0')
        .field('esame_finale', '0')
        .field('area_tematica', 'Transizione digitale')
        .attach('file', h.pdfBuffer(corso.nome_corso), { filename: `${corso.nome_corso}.pdf`, contentType: 'application/pdf' });
      expect(r.status).toBe(201);
      ids.push(r.body.id);
    }

    // in attesa = VALIDO: il totale li conta subito, prima della validazione,
    // e 40h30 > 40h accende la spunta verde
    let vista = await dip1.get('/api/certificati');
    expect(vista.body.oreTotali.minuti).toBe(30 * 60 + 8 * 60 + 30 + 2 * 60); // 2430
    expect(vista.body.oreTotali.ore).toBe(40);
    expect(vista.body.oreTotali.restoMinuti).toBe(30);
    expect(vista.body.oreTotali.badge).toBe(true);

    // l'approvazione NON cambia il totale (i corsi contavano già)
    const { a: admin } = await h.loginAdmin();
    for (const id of ids) {
      await admin.put(`/api/admin/certificati/${id}/stato`).send({ stato: 'APPROVATO' });
    }
    vista = await dip1.get('/api/certificati');
    expect(vista.body.oreTotali.minuti).toBe(2430);
    expect(vista.body.oreTotali.badge).toBe(true);

    // [v2.2.3] il RIFIUTO TOGLIE le ore del corso dal totale: 2h in meno →
    // 38h30 (2.310 min) e la spunta si SPEGNE (sotto la soglia delle 40 ore)
    await admin.put(`/api/admin/certificati/${ids[2]}/stato`).send({ stato: 'RIFIUTATO', note: ' illeggibile' });
    vista = await dip1.get('/api/certificati');
    expect(vista.body.oreTotali.minuti).toBe(2430 - 2 * 60);          // 2310
    expect(vista.body.oreTotali.ore).toBe(38);
    expect(vista.body.oreTotali.restoMinuti).toBe(30);
    expect(vista.body.oreTotali.badge).toBe(false, 'il rifiuto ha portato il totale sotto le 40 ore');

    // il corso rifiutato resta però VISIBILE al dipendente (col suo badge di stato)
    vista = await dip1.get('/api/certificati');
    const rifiutato = vista.body.certificati.find((c) => c.id === ids[2]);
    expect(rifiutato.stato).toBe('RIFIUTATO');

    // ri-approvare il corso rifiutato lo fa rientrare nel totale
    await admin.put(`/api/admin/certificati/${ids[2]}/stato`).send({ stato: 'APPROVATO' });
    vista = await dip1.get('/api/certificati');
    expect(vista.body.oreTotali.minuti).toBe(2430);
    expect(vista.body.oreTotali.badge).toBe(true);
  });

  test('D2 · [v2.2.2] sotto la soglia (anche esattamente 40:00) il badge NON è attivo', async () => {
    const { a: dip1 } = await h.loginDip1();
    const r = await dip1.post('/api/certificati')
      .field('nome_corso', 'Esattamente 40 ore')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-05-01')
      .field('numero_ore', '40')
      .field('numero_minuti', '0')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer('40h'), { filename: '40h.pdf', contentType: 'application/pdf' });
    expect(r.status).toBe(201);

    const vista = await dip1.get('/api/certificati');
    expect(vista.body.oreTotali.minuti).toBe(2400);
    expect(vista.body.oreTotali.ore).toBe(40);
    expect(vista.body.oreTotali.badge).toBe(false, '40:00 NON basta: serve più di 40 ore');
  });
});

/* ════════════════ E. EXPORT CON DURATA ORE:MINUTI ════════════════ */

describe('E · [v2.2] Export CSV con durata formattata', () => {
  test('E1 · corso 8:30 → cella «8:30»; corso a ore intere → resta «8» (compat. v1.x)', async () => {
    const { a: dip1 } = await h.loginDip1();
    await dip1.post('/api/certificati')
      .field('nome_corso', 'Corso frazionario')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-06-01')
      .field('numero_ore', '8')
      .field('numero_minuti', '30')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer('fraz'), { filename: 'fraz.pdf', contentType: 'application/pdf' });
    await h.caricaCertificato(dip1, { nome_corso: 'Corso intero' });

    const { a: admin } = await h.loginAdmin();
    const testo = (await admin.get('/api/admin/certificati/export')).text;
    const rigaFraz = testo.split('\r\n').find((r) => r.includes('Corso frazionario'));
    const rigaIntero = testo.split('\r\n').find((r) => r.includes('Corso intero'));
    expect(rigaFraz).toContain('8:30');
    expect(rigaIntero).toContain(';8;'); // colonna ore invariata per le ore intere
    const colonne = intestazione(testo);
    expect(colonne).toHaveLength(19); // stesso numero di colonne di v2.0
  });
});

/** estrae l'intestazione (prima riga) dal CSV export */
function intestazione(testo) {
  return testo.replace(/^\uFEFF/, '').split('\r\n')[0].split(';');
}

describe('F · [v2.2.3] Tabella admin: elenco COMPLETO (perPagina=tutti)', () => {
  test('F1 · oltre le 25 righe: perPagina=tutti le restituisce TUTTE; la paginazione classica resta disponibile', async () => {
    const { a: dip1 } = await h.loginDip1();
    const TOTALE = 26; // supera il default perPagina=25
    for (let i = 1; i <= TOTALE; i++) {
      const r = await h.caricaCertificato(dip1, { nome_corso: `Corso n.${i}` });
      expect(r.status).toBe(201);
    }

    const { a: admin } = await h.loginAdmin();

    // elenco completo: tutte le righe in un'unica risposta, nessun taglio
    const tutti = await admin.get('/api/admin/certificati?perPagina=tutti');
    expect(tutti.status).toBe(200);
    expect(tutti.body.totale).toBe(TOTALE);
    expect(tutti.body.certificati.length).toBe(TOTALE);
    expect(tutti.body.pagineTotali).toBe(1);

    // retrocompatibilità: la paginazione numerica continua a funzionare
    const pag2 = await admin.get('/api/admin/certificati?perPagina=5&pagina=2');
    expect(pag2.status).toBe(200);
    expect(pag2.body.certificati.length).toBe(5);
    expect(pag2.body.pagineTotali).toBe(Math.ceil(TOTALE / 5));
    expect(pag2.body.totale).toBe(TOTALE);

    // la modalità «tutti» vale SOLO per i certificati: sugli utenti resta la
    // normalizzazione anti-abuso (perPagina=25)
    const utenti = await admin.get('/api/admin/utenti?perPagina=tutti');
    expect(utenti.status).toBe(200);
    expect(utenti.body.perPagina).toBe(25);
  });

  test('F2 · i rifiutati restano VISIBILI nella tabella admin (esclusi solo dal totale del profilo)', async () => {
    const { a: dip1 } = await h.loginDip1();
    const r1 = await h.caricaCertificato(dip1, { nome_corso: 'Approvabile' });
    const r2 = await h.caricaCertificato(dip1, { nome_corso: 'Destinato al rifiuto' });
    const { a: admin } = await h.loginAdmin();
    await admin.put(`/api/admin/certificati/${r1.body.id}/stato`).send({ stato: 'APPROVATO' });
    await admin.put(`/api/admin/certificati/${r2.body.id}/stato`).send({ stato: 'RIFIUTATO', note: ' illeggibile' });

    const tutti = await admin.get('/api/admin/certificati?perPagina=tutti');
    expect(tutti.body.totale).toBe(2);                       // la lista li mostra ENTRAMBI
    const stati = tutti.body.certificati.map((c) => c.stato).sort();
    expect(stati).toEqual(['APPROVATO', 'RIFIUTATO']);

    // ma il profilo del dipendente conta solo il non rifiutato
    const vista = await dip1.get('/api/certificati');
    expect(vista.body.certificati.length).toBe(2);
    expect(vista.body.oreTotali.minuti).toBe(8 * 60);        // solo il corso approvato (8h)
    expect(vista.body.oreTotali.badge).toBe(false);
  });
});

describe('G · [v2.2.5] Nuove aree tematiche (17 voci, DB VARCHAR)', () => {
  test('G1 · upload con le aree nuove (virgole, parentesi, slash) → 201; filtro esatto; fuori elenco → 400', async () => {
    const { a: dip1 } = await h.loginDip1();
    const aree = [
      'Privacy,anticorruzione,antiriciclaggio,trasparenza',   // virgole
      'Corsi obbligatori(Salute e sicurezza sul lavoro)',      // parentesi
      'Salvaguardia/Impatto ambientale',                       // slash
      'Attività Produttive e Sviluppo Economico',              // accenti
      'Altro',
    ];
    for (const area of aree) {
      const r = await h.caricaCertificato(dip1, { nome_corso: `Area nuova: ${area}`, area_tematica: area });
      expect(r.status).toBe(201);
      const salvata = (await h.query('SELECT area_tematica FROM certificati WHERE id = ?', [r.body.id]))[0];
      expect(salvata.area_tematica).toBe(area);   // salvata VERBATIM
    }

    // filtro admin: corrispondenza esatta su un'area nuova (URL-encoded)
    const { a: admin } = await h.loginAdmin();
    const q = encodeURIComponent('Privacy,anticorruzione,antiriciclaggio,trasparenza');
    const lista = await admin.get(`/api/admin/certificati?area=${q}`);
    expect(lista.status).toBe(200);
    expect(lista.body.totale).toBe(1);
    expect(lista.body.certificati[0].area_tematica).toBe('Privacy,anticorruzione,antiriciclaggio,trasparenza');

    // l'elenco resta chiuso: area inesistente → 400 sia sul filtro sia sull'upload
    expect((await admin.get(`/api/admin/certificati?area=${encodeURIComponent('Filosofia')}`)).status).toBe(400);
    expect((await h.caricaCertificato(dip1, { area_tematica: 'Filosofia' })).status).toBe(400);

    // retrocompatibilità: un'area STORICA resta ammessa in upload e filtro
    const rStorica = await h.caricaCertificato(dip1, { nome_corso: 'Area storica', area_tematica: 'Transizione digitale' });
    expect(rStorica.status).toBe(201);
    const filtroStorico = await admin.get(`/api/admin/certificati?area=${encodeURIComponent('Transizione digitale')}`);
    expect(filtroStorico.status).toBe(200);
    expect(filtroStorico.body.totale).toBe(1);
  });
});

describe('H · [v2.2.7] Filtro durata (min/max in minuti) + dettaglio documenti', () => {
  test('H1 · durataMin/durataMax sulla durata TOTALE (45 / 510 / 1245 min); export coerente; non validi → 400', async () => {
    const { a: dip1 } = await h.loginDip1();
    const upload = async (nome, ore, minuti) => {
      /* numero_minuti non è nel base di campiCertificato: lo si aggiunge a
       * mano sulla request (0 minuti = default, nessun campo da aggiungere). */
      let req = h.caricaCertificato(dip1, { nome_corso: nome, numero_ore: String(ore) });
      if (minuti > 0) req = req.field('numero_minuti', String(minuti));
      const r = await req;
      expect(r.status).toBe(201);
    };
    await upload('Corto 0:45', 0, 45);    // 45 min: il caso critico «sotto l'ora»
    await upload('Medio 8:30', 8, 30);    // 510 min
    await upload('Lungo 20:45', 20, 45);  // 1245 min
    const { a: admin } = await h.loginAdmin();

    const conta = async (qs) => (await admin.get(`/api/admin/certificati?${qs}`)).body.totale;
    expect(await conta('durataMin=510')).toBe(2);               // 510 e 1245
    expect(await conta('durataMax=510')).toBe(2);               // 45 e 510
    expect(await conta('durataMin=100&durataMax=600')).toBe(1); // solo il 510
    expect(await conta('durataMin=0')).toBe(3);
    expect(await conta('durataMin=510&durataMax=509')).toBe(0); // intervallo incoerente → vuoto

    // guardie: solo cifre (minuti), altrimenti 400 esplicito
    expect((await admin.get('/api/admin/certificati?durataMin=abc')).status).toBe(400);
    expect((await admin.get('/api/admin/certificati?durataMax=-5')).status).toBe(400);
    expect((await admin.get('/api/admin/certificati?durataMin=1;DROP')).status).toBe(400);

    // l'export CSV usa gli stessi filtri: esclude il corso sotto soglia
    const csv = await admin.get('/api/admin/certificati/export?durataMin=510');
    expect(csv.status).toBe(200);
    expect(csv.text).toContain('Lungo 20:45');
    expect(csv.text).toContain('Medio 8:30');
    expect(csv.text).not.toContain('Corto 0:45');
  });

  test('H2 · il payload allegati espone dimensione_file (dettaglio: nome + dimensione + download)', async () => {
    const { a: dip1 } = await h.loginDip1();
    const pngBuf = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D]);
    const r = await dip1.post('/api/certificati')
      .field('nome_corso', 'Con allegati')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-09-17')
      .field('numero_ore', '1')
      .field('numero_minuti', '0')
      .field('esame_finale', '0')
      .field('area_tematica', 'Altro')
      .attach('file', h.pdfBuffer('primo'), { filename: 'primo.pdf', contentType: 'application/pdf' })
      .attach('file', pngBuf, { filename: 'secondo.png', contentType: 'image/png' });
    expect(r.status).toBe(201);

    const { a: admin } = await h.loginAdmin();
    const lista = await admin.get('/api/admin/certificati?perPagina=tutti');
    const corso = lista.body.certificati.find((c) => c.id === r.body.id);
    expect(corso.allegati.length).toBe(2);
    expect(corso.allegati[0].nome).toBe('primo.pdf');
    for (const a of corso.allegati) {
      expect(typeof a.dimensione_file).toBe('number');
      expect(a.dimensione_file).toBeGreaterThan(0);
    }
  });
});


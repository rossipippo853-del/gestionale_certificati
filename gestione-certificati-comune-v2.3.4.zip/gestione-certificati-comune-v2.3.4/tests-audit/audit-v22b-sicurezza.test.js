/**
 * ============================================================================
 *  audit-v22b-sicurezza.test.js — AUDITORIA QA ROUND 2 (integrazione/sicurezza)
 * ============================================================================
 *  Copertura dei rischi INTRODOTTI dalle novità v2.2 e non ancora testati:
 *    A. filtro esame: normalizzazione maiuscole, combinazione con altri filtri,
 *       export su insieme vuoto;
 *    B. allegati: batch misto con un file corrotto (cleanup TOTALE), nomi
 *       duplicati nello stesso upload, allegato inesistente/non numerico,
 *       campi file estranei ignorati, contenuto che vince sull'estensione,
 *       filename ostili resi sicuri dal rendering (escapeHtml nei chip);
 *    C. ore totali: confine ESATTO delle 40 ore; aritmetica dei minuti mista;
 *    D. upload admin per un dipendente DISABILITATO (comportamento fissato);
 *    E. gara: upload paralleli misti PDF+PNG dello stesso dipendente.
 * ============================================================================
 */
'use strict';

const h = require('../tests-qa/qahelper');
const fs = require('node:fs');
const path = require('node:path');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

const pngBuf = () => Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00]);
const jpgBuf = () => Buffer.from([0xFF, 0xD8, 0xFF, 0xE0, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01]);

/* ════════════════ A. FILTRO ESAME ════════════════ */

describe('A2 · [v2.2] Filtro esame: robustezza e combinazioni', () => {
  test('A2.1 · maiuscole normalizzate (SI/No) e combinazione additiva con stato', async () => {
    const { a } = await h.loginDip1();
    await h.caricaCertificato(a, { nome_corso: 'Con esame', esame_finale: '1' });
    await h.caricaCertificato(a, { nome_corso: 'Senza', esame_finale: '0' });

    const { a: admin } = await h.loginAdmin();
    const maiuscolo = await admin.get('/api/admin/certificati?esame=SI');
    expect(maiuscolo.status).toBe(200);
    expect(maiuscolo.body.certificati.map((c) => c.nome_corso)).toEqual(['Con esame']);

    const combinato = await admin.get('/api/admin/certificati?esame=si&stato=IN_ATTESA&q=esame');
    expect(combinato.status).toBe(200);
    expect(combinato.body.certificati.map((c) => c.nome_corso)).toEqual(['Con esame']);

    const incoerente = await admin.get('/api/admin/certificati?esame=no&stato=APPROVATO');
    expect(incoerente.body.certificati).toHaveLength(0); // nessun corso con entrambe le condizioni
  });

  test('A2.2 · export con filtro su insieme vuoto → solo intestazione (19 colonne)', async () => {
    const { a: admin } = await h.loginAdmin();
    const testo = (await admin.get('/api/admin/certificati/export?esame=si')).text;
    const righe = testo.replace(/^\uFEFF/, '').trim().split('\r\n');
    expect(righe).toHaveLength(1);                    // nessun dato
    expect(righe[0].split(';')).toHaveLength(19);     // ma header completo
  });
});

/* ════════════════ B. ALLEGATI ════════════════ */

describe('B2 · [v2.2] Allegati: cleanup, duplicati, permessi, robustezza', () => {
  test('B2.1 · batch misto con un file corrotto → 400 e NESSUN file/riga salvato', async () => {
    const { a } = await h.loginDip1();
    const corrotto = Buffer.from('MZ\x90\x00non sono un immagine');
    const r = await a.post('/api/certificati')
      .field('nome_corso', 'Batch misto')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-01-15')
      .field('numero_ore', '1')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer('buono'), { filename: 'buono.pdf', contentType: 'application/pdf' })
      .attach('file', corrotto, { filename: 'corrotto.png', contentType: 'image/png' });
    expect(r.status).toBe(400);
    expect(h.fileSuDisco(h.DIP1.codice_fiscale)).toEqual([]);      // ZERO orfani (nemmeno il buono)
    const n = await h.query('SELECT COUNT(*) AS n FROM allegati');
    expect(n[0].n).toBe(0);
    const c = await h.query("SELECT COUNT(*) AS n FROM certificati WHERE nome_corso = 'Batch misto'");
    expect(c[0].n).toBe(0);                                        // nemmeno la riga del corso
  });

  test('B2.2 · due allegati con lo STESSO nome nello stesso upload → 2 file distinti', async () => {
    const { a } = await h.loginDip1();
    const r = await a.post('/api/certificati')
      .field('nome_corso', 'Nomi duplicati')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-01-15')
      .field('numero_ore', '1')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer('prima copia'), { filename: 'documento.pdf', contentType: 'application/pdf' })
      .attach('file', h.pdfBuffer('seconda copia'), { filename: 'documento.pdf', contentType: 'application/pdf' });
    expect(r.status).toBe(201);
    const file = h.fileSuDisco(h.DIP1.codice_fiscale);
    expect(file).toHaveLength(2);
    expect(new Set(file).size).toBe(2); // nessuna sovrascrittura

    const righe = await h.query(
      `SELECT percorso_file FROM allegati ORDER BY id`);
    expect(new Set(righe.map((x) => x.percorso_file)).size).toBe(2); // percorsi DB distinti
  });

  test('B2.3 · allegato inesistente → 404; identificativo non numerico → 400', async () => {
    const { a } = await h.loginDip1();
    await a.get('/api/certificati/allegati/99999/file').expect(404);
    await a.get('/api/certificati/allegati/abc/file').expect(400);
    await a.get('/api/certificati/allegati/1;DROP/file').expect(400);
  });

  test('B2.4 · file in un campo estraneo ("altro") → RIFIUTATO (LIMIT_UNEXPECTED_FILE)', async () => {
    const { a } = await h.loginDip1();
    const r = await a.post('/api/certificati')
      .field('nome_corso', 'Campo estraneo')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-01-15')
      .field('numero_ore', '2')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer('giusto'), { filename: 'giusto.pdf', contentType: 'application/pdf' })
      .attach('altro', h.pdfBuffer('strano'), { filename: 'nascosto.pdf', contentType: 'application/pdf' });
    // Comportamento fissato dall'audit: i campi file NON previsti sono
    // RIFIUTATI (multer LIMIT_UNEXPECTED_FILE: più sicuro che ignorarli).
    // Nessuna scrittura: né file né righe.
    expect(r.status).toBe(400);
    expect(h.fileSuDisco(h.DIP1.codice_fiscale) || []).toHaveLength(0);
    const n = await h.query('SELECT COUNT(*) AS n FROM allegati');
    expect(n[0].n).toBe(0);
  });

  test('B2.5 · il CONTENUTO vince sull\u2019estensione: PNG con nome .pdf → tipo_file "png"', async () => {
    const { a } = await h.loginDip1();
    const r = await a.post('/api/certificati')
      .field('nome_corso', 'Contenuto vs estensione')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-01-15')
      .field('numero_ore', '1')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', pngBuf(), { filename: 'immagine.pdf', contentType: 'application/pdf' });
    expect(r.status).toBe(201);
    const [riga] = await h.query('SELECT tipo_file, percorso_file FROM allegati');
    expect(riga.tipo_file).toBe('png');                        // la firma reale determina il tipo…
    expect(riga.percorso_file).toMatch(/\.pdf$/);              // …il nome server conserva l'estensione richiesta
    // e il download serve comunque il MIME corretto (dal tipo reale registrato)
    const id = (await h.query('SELECT id FROM allegati'))[0].id;
    const scarico = await a.get(`/api/certificati/allegati/${id}/file`);
    expect(scarico.headers['content-type']).toBe('image/png');
  });

  test('B2.6 · filename ostile (payload HTML) salvato; il RENDERING usa escapeHtml', async () => {
    const { a } = await h.loginDip1();
    const ostile = '<img src=x onerror=alert(1)>.png';
    const r = await a.post('/api/certificati')
      .field('nome_corso', 'Nome ostile')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-01-15')
      .field('numero_ore', '1')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', pngBuf(), { filename: ostile, contentType: 'image/png' });
    expect(r.status).toBe(201);
    // l'API restituisce il nome ORIGINALE (serve per il download)…
    const lista = await a.get('/api/certificati');
    const corso = lista.body.certificati.find((c) => c.nome_corso === 'Nome ostile');
    expect(corso.allegati[0].nome).toBe(ostile);
    // …ma i template dei chip lo passano SEMPRE in escapeHtml (anti XSS a rendering)
    for (const fileJs of ['public/js/admin.js', 'public/js/dipendente.js']) {
      const js = fs.readFileSync(path.resolve(__dirname, '..', fileJs), 'utf8');
      expect(js).toMatch(/escapeHtml\(a\.nome/);
    }
    // il nome su disco è sanificato: nessun carattere pericoloso
    const file = h.fileSuDisco(h.DIP1.codice_fiscale)[0];
    expect(file).not.toMatch(/[<>"'();]/);
  });

  test('B2.7 · dopo il DELETE del corso, gli allegati rispondono 404', async () => {
    const { a: dip1 } = await h.loginDip1();
    const r = await h.caricaCertificato(dip1, { nome_corso: 'Da eliminare' });
    const id = r.body.id;
    const [allegato] = await h.query('SELECT id FROM allegati WHERE certificato_id = ?', [id]);
    expect(allegato).toBeTruthy();

    const { a: admin } = await h.loginAdmin();
    await admin.delete(`/api/admin/certificati/${id}`).expect(200);
    await dip1.get(`/api/certificati/allegati/${allegato.id}/file`).expect(404);
  });
});

/* ════════════════ C. ORE TOTALI: CONFINE 40 ORE ════════════════ */

describe('C2 · [v2.2] Ore totali: confine esatto e aritmetica dei minuti', () => {
  const carica = async (a, nomeCorso, ore, minuti) => {
    const r = await a.post('/api/certificati')
      .field('nome_corso', nomeCorso)
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-05-01')
      .field('numero_ore', String(ore))
      .field('numero_minuti', String(minuti))
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer(nomeCorso), { filename: `${nomeCorso}.pdf`, contentType: 'application/pdf' });
    expect(r.status).toBe(201);
    return r.body.id;
  };

  test('C2.1 · [v2.2.3] confine 40h con rifiutati ESCLUSI: 39:59 no · 40:00 no · 40:01 sì · il rifiuto spegne', async () => {
    const { a: dip1 } = await h.loginDip1();
    const idA = await carica(dip1, 'Blocco 39:59', 39, 59);
    const { a: admin } = await h.loginAdmin();

    let vista = await dip1.get('/api/certificati');
    expect(vista.body.oreTotali.minuti).toBe(39 * 60 + 59);
    expect(vista.body.oreTotali.badge).toBe(false);

    const idB = await carica(dip1, 'Minuto che porta a 40:00', 0, 1);
    vista = await dip1.get('/api/certificati');
    expect(vista.body.oreTotali.minuti).toBe(2400);   // esattamente 40 ore
    expect(vista.body.oreTotali.badge).toBe(false,    // serve PIÙ di 40 ore
      'esattamente 40:00 non basta (soglia strettamente maggiore)');

    const idC = await carica(dip1, 'Minuto decisivo', 0, 1);
    await admin.put(`/api/admin/certificati/${idC}/stato`).send({ stato: 'APPROVATO' });
    vista = await dip1.get('/api/certificati');
    expect(vista.body.oreTotali.minuti).toBe(2401);   // 40 ore e 1 minuto
    expect(vista.body.oreTotali.badge).toBe(true);    // la spunta verde si accende

    // [v2.2.3] il rifiuto del blocco da 39:59 LO TOGLIE dal totale: restano
    // solo i 2 minuti validi e la spunta si spegne
    await admin.put(`/api/admin/certificati/${idA}/stato`).send({ stato: 'RIFIUTATO', note: ' illeggibile' });
    vista = await dip1.get('/api/certificati');
    expect(vista.body.oreTotali.minuti).toBe(2);
    expect(vista.body.oreTotali.badge).toBe(false, 'il rifiuto ha svuotato il totale sotto la soglia');
  });

  test('C2.2 · aritmetica mista: 8:59 + 1:01 = 10h esatte (riporti di minuto corretti)', async () => {
    const { a: dip1 } = await h.loginDip1();
    const idA = await carica(dip1, 'Parte lunga', 8, 59);
    const idB = await carica(dip1, 'Parte corta', 1, 1);
    const { a: admin } = await h.loginAdmin();
    await admin.put(`/api/admin/certificati/${idA}/stato`).send({ stato: 'APPROVATO' });
    await admin.put(`/api/admin/certificati/${idB}/stato`).send({ stato: 'APPROVATO' });

    const vista = await dip1.get('/api/certificati');
    expect(vista.body.oreTotali.minuti).toBe(600);
    expect(vista.body.oreTotali.ore).toBe(10);
    expect(vista.body.oreTotali.restoMinuti).toBe(0);
  });
});

/* ════════════════ D. ADMIN: UPLOAD PER DIPENDENTE DISABILITATO ════════════════ */

describe('D2 · [v2.2] Upload admin per dipendente disabilitato (comportamento fissato)', () => {
  test('D2.1 · l\u2019admin PUÒ caricare per un account disabilitato (decisione amministrativa); ' +
    'il dipendente non può accedere finché non viene riabilitato', async () => {
    const { a: admin } = await h.loginAdmin();
    const dip = (await h.query("SELECT id, codice_fiscale FROM dipendenti WHERE matricola = 'qa002'"))[0];
    await admin.put(`/api/admin/utenti/${dip.id}/stato`).send({ attivo: false });

    const r = await admin.post('/api/admin/certificati')
      .field('dipendenteId', String(dip.id))
      .field('nome_corso', 'Per account sospeso')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-07-01')
      .field('numero_ore', '4')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer('sospeso'), { filename: 's.pdf', contentType: 'application/pdf' });
    expect(r.status).toBe(201);                    // l'admin decide: documentato così
    expect(h.fileSuDisco(dip.codice_fiscale)).toHaveLength(1);

    // l'account disabilitato NON può comunque vedere nulla (login 403)
    const { r: accesso } = await h.login('qa002', h.DIP2.password);
    expect(accesso.status).toBe(403);
  });
});

/* ════════════════ E. GARA: UPLOAD PARALLELI MISTI ════════════════ */

describe('E2 · [v2.2] Upload paralleli misti (PDF+PNG) dello stesso dipendente', () => {
  test('E2.1 · 4 richieste parallele × 2 file → 8 file distinti, tipi corretti', async () => {
    const { a } = await h.loginDip1();
    const richieste = [0, 1, 2, 3].map((i) =>
      a.post('/api/certificati')
        .field('nome_corso', `Parallelo misto ${i + 1}`)
        .field('ente_erogatore', 'Ente')
        .field('data_conseguimento', '2026-08-01')
        .field('numero_ore', '1')
        .field('esame_finale', '0')
        .field('area_tematica', 'Transizione digitale')
        .attach('file', h.pdfBuffer(`p${i}`), { filename: `p${i}.pdf`, contentType: 'application/pdf' })
        .attach('file', pngBuf(), { filename: `q${i}.png`, contentType: 'image/png' })
    );
    const risposte = await Promise.all(richieste);
    for (const r of risposte) {
      expect(r.status).toBe(201);
      expect(r.body.allegati).toBe(2);
    }
    const file = h.fileSuDisco(h.DIP1.codice_fiscale);
    expect(file).toHaveLength(8);
    expect(new Set(file).size).toBe(8);            // nessuna sovrascrittura sotto gara
    const tipi = await h.query(
      `SELECT a.tipo_file FROM allegati a JOIN certificati c ON c.id = a.certificato_id
       WHERE c.nome_corso LIKE 'Parallelo misto%'`);
    expect(tipi.filter((x) => x.tipo_file === 'png')).toHaveLength(4);
    expect(tipi.filter((x) => x.tipo_file === 'pdf')).toHaveLength(4);
  });
});

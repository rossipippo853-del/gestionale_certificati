/**
 * ============================================================================
 *  audit-integrazione-sicurezza.test.js — AUDITORIA QA SU APP REALE
 * ============================================================================
 *  [Audit QA v2.1.1] Test di integrazione end-to-end su Express+MariaDB+FS,
 *  dedicati ai casi che la suite di collaudo non copre:
 *    A. robustezza del livello HTTP (payload malformati, metodi sbagliati);
 *    B. sicurezza di token/cookie (falsificazione JWT, monouso, abilitazione);
 *    C. RACE CONDITION reali (creazioni parallele, upload paralleli, doppio
 *       consumo del cookie di primo accesso);
 *    D. confini dell'upload (5 MB esatti, 0 byte, MIME falso, nomi ostili);
 *    E. confini dei campi v1.4 via API (ore, date, lunghezze);
 *    F. paginazione estrema, ricerca ostile, Codice Fiscale minuscolo.
 *
 *  L'infrastruttura è la stessa della suite di collaudo (qahelper): DB di test
 *  ricreato ad ogni test, Supertest senza porta fissa, uploads-qa/ isolata.
 * ============================================================================
 */
'use strict';

const h = require('../tests-qa/qahelper');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

/* ════════════════ A. ROBUSTEZZA DEL LIVELLO HTTP ════════════════ */

describe('A · Livello HTTP: payload malformati e metodi errati', () => {
  test('A1 · body JSON malformato → 400 in formato JSON (mai HTML/crash)', async () => {
    const r = await h.agente()
      .post('/api/auth/login')
      .set('Content-Type', 'application/json')
      .send('{"matricola": "qa000",'); // JSON troncato
    expect(r.status).toBe(400);
    expect(r.headers['content-type']).toContain('application/json');
  });

  test('A2 · metodo HTTP errato su endpoint esistente → 404 JSON', async () => {
    const r = await h.agente().get('/api/auth/login');
    expect(r.status).toBe(404);
    expect(r.body.errore).toBe('Endpoint non trovato.');
    expect(r.headers['content-type']).toContain('application/json');
  });

  test('A3 · login senza Content-Type JSON (body assente) → 400 con messaggio', async () => {
    const r = await h.agente().post('/api/auth/login').send('matricola=qa000&password=x');
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/matricola e password/i);
  });
});

/* ════════════════ B. TOKEN, COOKIE E SESSIONI ════════════════ */

describe('B · Sicurezza di token e cookie', () => {
  test('B1 · cookie HttpOnly+SameSite=Lax; [v2.3.1] token nel body per la sessione di scheda', async () => {
    const r = await h.agente().post('/api/auth/login')
      .send({ matricola: h.ADMIN.matricola, password: h.ADMIN.password });
    expect(r.status).toBe(200);

    const cookie = (r.headers['set-cookie'] || []).find((c) => c.startsWith('token='));
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Lax/i);
    expect(cookie).toMatch(/Path=\//);

    /* [v2.3.1] il token ORA è nel body per DESIGN (sessione di scheda:
     * il frontend lo custodisce in sessionStorage e lo rispedisce via header
     * Authorization — requisito «re-login alla chiusura della scheda»).
     * Le difese restano: cookie httpOnly+SameSite, revoca jti, CSP 'self'. */
    expect(Object.keys(r.body)).toContain('token');
    expect(typeof r.body.token).toBe('string');
  });

  test('B2 · JWT con payload manomesso → 401 (firma HMAC invalidata)', async () => {
    const r = await h.agente().post('/api/auth/login')
      .send({ matricola: h.ADMIN.matricola, password: h.ADMIN.password });
    const cookie = (r.headers['set-cookie'] || []).find((c) => c.startsWith('token='));
    const valore = cookie.split(';')[0].slice('token='.length);
    const [testa, carico, firma] = valore.split('.');

    // sostituiamo il payload con uno "privilegiato" mantenendo la firma originale
    const falso = Buffer.from(JSON.stringify({ id: 999, matricola: 'hacker', jti: 'x' }))
      .toString('base64url');
    const manomesso = `${testa}.${falso}.${firma}`;

    const attacco = await h.agente().get('/api/auth/me').set('Cookie', `token=${manomesso}`);
    expect(attacco.status).toBe(401);
    expect(carico).toBeTruthy(); // il token originale era ben formato
  });

  test('B3 · token forgiato con alg "none" → 401', async () => {
    const header = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url');
    const carico = Buffer.from(JSON.stringify({ id: 1, matricola: 'qa000', jti: 'falso' })).toString('base64url');
    const r = await h.agente().get('/api/auth/me').set('Cookie', `token=${header}.${carico}.`);
    expect(r.status).toBe(401);
  });

  test('B4 · cookie di primo accesso SCADUTO → 401 con messaggio di scadenza', async () => {
    await h.query("UPDATE dipendenti SET must_change_password = 1 WHERE matricola = 'qa002'");
    const id = (await h.query("SELECT id FROM dipendenti WHERE matricola = 'qa002'"))[0].id;
    const token = jwt.sign(
      { id, matricola: 'qa002', jti: 'audit-scaduto', scopo: 'primo-accesso' },
      process.env.JWT_SECRET,
      { expiresIn: '1ms' }
    );
    await new Promise((risolvi) => setTimeout(risolvi, 50)); // lascia passare la scadenza

    const r = await h.agente().post('/api/auth/primo-accesso')
      .set('Cookie', `token_cambio=${token}`)
      .send({ nuovaPassword: 'Audit2026x', confermaPassword: 'Audit2026x' });
    expect(r.status).toBe(401);
    expect(r.body.errore).toMatch(/scaduta/i);
  });

  test('B5 · account disabilitato TRA login e primo-accesso → il cambio viene rifiutato', async () => {
    await h.query("UPDATE dipendenti SET must_change_password = 1 WHERE matricola = 'qa002'");
    const { a: admin } = await h.loginAdmin();
    const id = (await h.query("SELECT id FROM dipendenti WHERE matricola = 'qa002'"))[0].id;

    const { r: accesso } = await h.login('qa002', h.DIP2.password); // niente sessione, solo token_cambio
    expect(accesso.body.primoAccesso).toBe(true);
    const tc = (accesso.headers['set-cookie'] || []).find((c) => c.startsWith('token_cambio='));
    const valore = tc.split(';')[0];

    await admin.put(`/api/admin/utenti/${id}/stato`).send({ attivo: false });

    const r = await h.agente().post('/api/auth/primo-accesso')
      .set('Cookie', valore)
      .send({ nuovaPassword: 'Audit2026x', confermaPassword: 'Audit2026x' });
    expect(r.status).toBe(401);
    expect(r.body.errore).toMatch(/Account non disponibile/i);
  });
});

/* ════════════════ C. RACE CONDITION E CONCORRENZA ════════════════ */

describe('C · Race condition (richieste realmente parallele)', () => {
  test('C1 · due POST /utenti paralleli con la STESSA matricola → un solo 201, zero cartelle orfane', async () => {
    const { a } = await h.loginAdmin();
    const base = {
      nome: 'Corsa', cognome: 'Concorrenza', sesso: 'M', qualifica: 'Impiegato',
    };
    const u1 = { ...base, matricola: 'race01', codice_fiscale: 'RSSMRA80A01H501U', password: 'CorsaPwd2026' };
    const u2 = { ...base, matricola: 'race01', codice_fiscale: 'GLLANN85C15G822C', password: 'CorsaPwd2026' };

    const [r1, r2] = await Promise.all([
      a.post('/api/admin/utenti').send(u1),
      a.post('/api/admin/utenti').send(u2),
    ]);
    const stati = [r1.status, r2.status].sort();
    expect(stati).toEqual([201, 409]); // esattamente un vincitore

    const n = await h.query("SELECT COUNT(*) AS n FROM dipendenti WHERE matricola = 'race01'");
    expect(n[0].n).toBe(1);

    // [AUDIT F2] il "perdente" non deve lasciare la sua cartella CF sul disco
    const vincitore = r1.status === 201 ? u1.codice_fiscale : u2.codice_fiscale;
    const perdente = r1.status === 201 ? u2.codice_fiscale : u1.codice_fiscale;
    expect(h.fileSuDisco(perdente)).toBeNull();  // cartella del perdente: rimossa
    expect(h.fileSuDisco(vincitore)).toEqual([]); // cartella del vincitore: presente e vuota
  });

  test('C2 · tre upload paralleli dello stesso dipendente → tutti 201, tre file distinti', async () => {
    const { a } = await h.loginDip1();
    const risposte = await Promise.all([
      h.caricaCertificato(a, { nome_corso: 'Parallelo 1' }),
      h.caricaCertificato(a, { nome_corso: 'Parallelo 2' }),
      h.caricaCertificato(a, { nome_corso: 'Parallelo 3' }),
    ]);
    for (const r of risposte) expect(r.status).toBe(201);
    const file = h.fileSuDisco(h.DIP1.codice_fiscale);
    expect(file).toHaveLength(3);
    expect(new Set(file).size).toBe(3); // nomi tutti diversi (nessuna sovrascrittura)
  });

  test('C3 · DOPPIO consumo parallelo dello stesso cookie di primo accesso → un solo 200', async () => {
    await h.query("UPDATE dipendenti SET must_change_password = 1 WHERE matricola = 'qa002'");

    const { r: accesso } = await h.login('qa002', h.DIP2.password);
    expect(accesso.body.primoAccesso).toBe(true);
    const tc = (accesso.headers['set-cookie'] || []).find((c) => c.startsWith('token_cambio='));
    const valoreCambio = tc.split(';')[0];

    const pA = 'CorsaPwd2026';
    const pB = 'CorsaPwd3333';
    const [r1, r2] = await Promise.all([
      h.agente().post('/api/auth/primo-accesso').set('Cookie', valoreCambio)
        .send({ nuovaPassword: pA, confermaPassword: pA }),
      h.agente().post('/api/auth/primo-accesso').set('Cookie', valoreCambio)
        .send({ nuovaPassword: pB, confermaPassword: pB }),
    ]);
    const stati = [r1.status, r2.status].sort();
    expect(stati).toEqual([200, 401]); // il cookie è MONOUSO anche sotto concorrenza

    // la password finale coincide con UNA SOLA delle due richieste (quella vincente)
    const hash = (await h.query("SELECT password_hash, must_change_password AS flag FROM dipendenti WHERE matricola = 'qa002'"))[0];
    const confronti = [await bcrypt.compare(pA, hash.password_hash), await bcrypt.compare(pB, hash.password_hash)];
    expect(confronti.filter(Boolean)).toHaveLength(1);
    expect(hash.flag).toBe(0);
  });
});

/* ════════════════ D. UPLOAD: CONFINI E FILE OSTILI ════════════════ */

describe('D · Upload PDF: confini di dimensione e file ostili', () => {
  const MB = 1024 * 1024;

  test('D1 · PDF di ESATTAMENTE 5 MB → accettato (201) [regressione FIX QA-C3]', async () => {
    const { a } = await h.loginDip1();
    const piccolo = h.pdfBuffer('base');
    const esatto = Buffer.concat([piccolo, Buffer.alloc(5 * MB - piccolo.length)]);
    const r = await h.caricaCertificato(a, { nome_corso: 'Al limite' }, { buffer: esatto, nome: 'esatto.pdf', mime: 'application/pdf' });
    expect(r.status).toBe(201);
  });

  test('D2 · PDF oltre il limite (5 MB + 2 KB) → 400, nessun file orfano', async () => {
    const { a } = await h.loginDip1();
    const piccolo = h.pdfBuffer('base');
    const enorme = Buffer.concat([piccolo, Buffer.alloc(5 * MB + 2 * 1024 - piccolo.length)]);
    const r = await h.caricaCertificato(a, { nome_corso: 'Troppo grande' }, { buffer: enorme, nome: 'enorme.pdf', mime: 'application/pdf' });
    expect(r.status).toBe(400);
    expect(h.fileSuDisco(h.DIP1.codice_fiscale)).toEqual([]); // nessun orfano sul disco
  });

  test('D3 · file di 0 byte con estensione .pdf → 400 (magic bytes), nessun orfano', async () => {
    const { a } = await h.loginDip1();
    const r = await h.caricaCertificato(a, { nome_corso: 'Vuoto' }, { buffer: Buffer.alloc(0), nome: 'vuoto.pdf', mime: 'application/pdf' });
    expect(r.status).toBe(400);
    expect(h.fileSuDisco(h.DIP1.codice_fiscale)).toEqual([]);
  });

  test('D4 · PDF valido seguito da 1 MB di spazzatura → accettato (il magic bytes basta)', async () => {
    const { a } = await h.loginDip1();
    const sporco = Buffer.concat([h.pdfBuffer('sporco'), Buffer.alloc(MB, 0x41)]);
    const r = await h.caricaCertificato(a, { nome_corso: 'Con coda di spazzatura' }, { buffer: sporco, nome: 'sporco.pdf', mime: 'application/pdf' });
    expect(r.status).toBe(201);
  });

  test('D5 · MIME dichiarato falso (application/x-msdownload) → 400 pre-scrittura', async () => {
    const { a } = await h.loginDip1();
    const r = await h.caricaCertificato(a, { nome_corso: 'Mime falso' }, { buffer: h.pdfBuffer('ok'), nome: 'ok.pdf', mime: 'application/x-msdownload' });
    expect(r.status).toBe(400);
    expect(JSON.stringify(r.body)).toMatch(/MIME/i);
  });

  test('D6 · estensione non PDF (trick con doppia estensione) → 400', async () => {
    const { a } = await h.loginDip1();
    const r = await h.caricaCertificato(a, { nome_corso: 'Estensione truffa' }, { buffer: h.pdfBuffer('x'), nome: 'corso.pdf.txt', mime: 'application/pdf' });
    expect(r.status).toBe(400);
    expect(JSON.stringify(r.body)).toMatch(/PDF/i);
  });

  test('D7 · nomi file ostili → salvati sanificati, percorsi DB senza traversal', async () => {
    const { a } = await h.loginDip1();
    const nomi = [
      '../../.env.pdf',
      '💥corso;<iframe>alert(1)</iframe>.pdf',
      "corso'; DROP TABLE certificati;--.pdf",
    ];
    for (const [i, nome] of nomi.entries()) {
      const r = await h.caricaCertificato(a, { nome_corso: `Nomi ostili ${i + 1}` }, { buffer: h.pdfBuffer(nome), nome, mime: 'application/pdf' });
      expect(r.status).toBe(201);
    }
    const file = h.fileSuDisco(h.DIP1.codice_fiscale);
    expect(file).toHaveLength(3);
    for (const f of file) {
      expect(f).toMatch(/^\d{13}-[0-9a-f]{8}_[A-Za-z0-9._-]{1,80}\.pdf$/); // formato sanificato
      expect(f).not.toMatch(/[/\\]|\.\./);
    }
    const percorsi = await h.query(
      'SELECT percorso_file FROM certificati WHERE dipendente_id = (SELECT id FROM dipendenti WHERE matricola = ?)',
      [h.DIP1.matricola]
    );
    for (const p of percorsi) {
      expect(p.percorso_file).not.toMatch(/\.\./);
      expect(p.percorso_file).toContain(`certificati/${h.DIP1.codice_fiscale}/`); // v2.0: sempre nella cartella CF
    }
  });
});

/* ════════════════ E. CONFINI DEI CAMPI v1.4 VIA API ════════════════ */

describe('E · Confini dei campi del certificato (via API reale)', () => {
  test('E1 · numero_ore: rifiuta 0 / 10000 / decimali / testo; accetta 1 e 9999', async () => {
    const { a } = await h.loginDip1();
    for (const [ore, atteso] of [['0', 400], ['1', 201], ['9999', 201], ['10000', 400], ['12.5', 400], ['abc', 400], ['-3', 400]]) {
      const r = await h.caricaCertificato(a, { nome_corso: `Ore ${ore}`, numero_ore: ore });
      expect(`ore=${ore} → ${r.status}`).toBe(`ore=${ore} → ${atteso}`);
    }
  });

  test('E2 · data_conseguimento: futura / calendario / formato / oggi', async () => {
    const { a } = await h.loginDip1();
    const casi = [
      ['2099-01-01', 400],   // futura
      ['2026-02-30', 400],   // inesistente nel calendario
      ['15/09/2026', 400],   // formato non ISO
      ['2026-13-01', 400],   // mese 13
    ];
    for (const [data, atteso] of casi) {
      const r = await h.caricaCertificato(a, { nome_corso: `Data ${data}`, data_conseguimento: data });
      expect(`data=${data} → ${r.status}`).toBe(`data=${data} → ${atteso}`);
    }
    const oggi = new Date();
    const isoOggi = `${oggi.getFullYear()}-${String(oggi.getMonth() + 1).padStart(2, '0')}-${String(oggi.getDate()).padStart(2, '0')}`;
    const r = await h.caricaCertificato(a, { nome_corso: 'Data di oggi', data_conseguimento: isoOggi });
    expect(r.status).toBe(201);
  });

  test('E3 · nome_corso e ente: solo al confine esatto cambiano esito', async () => {
    const { a } = await h.loginDip1();
    expect((await h.caricaCertificato(a, { nome_corso: 'ab' })).status).toBe(400);      // 2 → no
    expect((await h.caricaCertificato(a, { nome_corso: 'abc' })).status).toBe(201);     // 3 → sì
    expect((await h.caricaCertificato(a, { nome_corso: 'C'.repeat(201) })).status).toBe(400); // 201 → no
    expect((await h.caricaCertificato(a, { ente_erogatore: 'E' })).status).toBe(400);   // 1 → no
    expect((await h.caricaCertificato(a, { ente_erogatore: 'EE' })).status).toBe(201);  // 2 → sì
  });
});

/* ════════════════ F. PAGINAZIONE, RICERCA E CODICE FISCALE ════════════════ */

describe('F · Paginazione estrema, ricerca ostile, CF minuscolo', () => {
  test('F1 · perPagina/pagina fuori range → valori normalizzati (5..100, pagina ≥ 1)', async () => {
    const { a } = await h.loginAdmin();
    const bassa = await a.get('/api/admin/utenti?perPagina=1');
    expect(bassa.status).toBe(200);
    expect(bassa.body.perPagina).toBe(5);         // minimo 5

    const alta = await a.get('/api/admin/utenti?perPagina=100000');
    expect(alta.body.perPagina).toBe(100);        // massimo 100

    const paginaZero = await a.get('/api/admin/utenti?pagina=-5');
    expect(paginaZero.body.pagina).toBe(1);       // mai sotto 1

    const paginaTesto = await a.get('/api/admin/utenti?pagina=abc&perPagina=xyz');
    expect(paginaTesto.body.pagina).toBe(1);      // non numeriche → predefinite
    expect(paginaTesto.body.perPagina).toBe(25);
    expect(paginaTesto.body.pagineTotali).toBeGreaterThanOrEqual(1);
  });

  test('F2 · ricerca con payload XSS o metacaratteri → 200, zero risultati, nessun errore', async () => {
    const { a } = await h.loginAdmin();
    for (const q of ['<script>alert(1)</script>', "' OR '1'='1", '%_%%_', 'a"b;c']) {
      const r = await a.get(`/api/admin/utenti?q=${encodeURIComponent(q)}`);
      expect(r.status).toBe(200);
      expect(`${q} → totale ${r.body.totale}`).toBe(`${q} → totale 0`);
    }
  });

  test('F3 · CF inviato in MINUSCOLO → normalizzato a DB e cartella maiuscola (v2.0)', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.post('/api/admin/utenti').send({
      matricola: 'cflow01', codice_fiscale: 'rssmra80a01h501u', nome: 'Maiuscolo',
      cognome: 'Fiscale', sesso: 'M', qualifica: 'Impiegato', password: 'Minuscolo2026',
    });
    expect(r.status).toBe(201);

    const riga = (await h.query("SELECT codice_fiscale FROM dipendenti WHERE matricola = 'cflow01'"))[0];
    expect(riga.codice_fiscale).toBe('RSSMRA80A01H501U');          // a DB sempre canonico
    expect(h.fileSuDisco('RSSMRA80A01H501U')).toEqual([]);         // cartella CF (maiuscola) creata
    expect(h.fileSuDisco('rssmra80a01h501u')).toBeNull();          // nessuna cartella minuscola

    // e il duplicato minuscolo viene comunque intercettato come CF già registrato
    const doppio = await a.post('/api/admin/utenti').send({
      matricola: 'cflow02', codice_fiscale: 'RSSMRA80A01H501U', nome: 'Secondo',
      cognome: 'Uguale', sesso: 'F', qualifica: 'Impiegata',
    });
    expect(doppio.status).toBe(409);
    expect(doppio.body.errore).toMatch(/Codice Fiscale già registrato/i);
  });
});

/**
 * ============================================================================
 *  02-rbac.test.js — FASE 1: AUTORIZZAZIONI E ROLE-BASED ACCESS CONTROL
 * ============================================================================
 *  Cosa verifica (piano di collaudo §1):
 *   · un DIPENDENTE NON può accedere a NESSUN endpoint /api/admin/* (matrice
 *     completa: utenti, import, reset password, stato, certificati, export…);
 *   · senza autenticazione tutto l'area privata risponde 401;
 *   · un dipendente vede SOLO i propri certificati (elenco e download);
 *   · tentativo di path traversal sul file PDF → 404 senza fuoriuscite;
 *   · l'admin invece può scaricare i PDF di tutti (funzione richiesta).
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

describe('Matrice RBAC: DIPENDENTE → API amministrative (tutte negate)', () => {
  let dip; // agente autenticato come DIPENDENTE (qa001)

  beforeEach(async () => {
    ({ a: dip } = await h.loginDip1());
  });

  const matrice = [
    ['GET', '/api/admin/utenti', 'elenco utenti'],
    ['GET', '/api/admin/utenti/options', 'menu a tendina dipendenti'],
    ['GET', '/api/admin/stats', 'statistiche'],
    ['GET', '/api/admin/certificati', 'elenco certificati'],
    ['GET', '/api/admin/certificati/export', 'export CSV'],
    ['GET', '/api/admin/certificati/export?area=Transizione%20digitale', 'export CSV filtrato'],
    ['POST', '/api/admin/utenti', 'creazione utente'],
    ['POST', '/api/admin/certificati', 'caricamento certificato per un dipendente (v2.0)'],
    ['PUT', '/api/admin/utenti/1/password', 'reset password'],
    ['PUT', '/api/admin/utenti/1/stato', 'abilita/disabilita'],
    ['PUT', '/api/admin/certificati/1/stato', 'approva/rifiuta'],
    ['DELETE', '/api/admin/certificati/1', 'eliminazione certificato'],
  ];

  for (const [metodo, url, descrizione] of matrice) {
    test(`${metodo} ${descrizione} → 403`, async () => {
      const r = await dip[metodo.toLowerCase()](url).send({ qualunque: 'corpo' });
      expect(r.status).toBe(403);
      expect(r.body.errore).toMatch(/amministratori/i);
    });
  }

  test('import CSV massivo → 403 (endpoint multipart)', async () => {
    const r = await dip.post('/api/admin/utenti/import')
      .field('duplicati', 'ignora')
      .attach('file', Buffer.from('nome;cognome;matricola;sesso;qualifica_professionale\nA;B;xx999;M;Qualifica'), { filename: 'x.csv' });
    expect(r.status).toBe(403);
  });

  test('SENZA autenticazione le API admin rispondono 401 (non 403: niente indizi)', async () => {
    await h.agente().get('/api/admin/utenti').expect(401);
    await h.agente().get('/api/admin/certificati/export').expect(401);
  });
});

describe('Isolamento tra dipendenti (certificati altrui)', () => {
  let idCertDip1;

  beforeEach(async () => {
    const { a: dip1 } = await h.loginDip1();
    const r = await h.caricaCertificato(dip1);
    expect(r.status).toBe(201);
    idCertDip1 = r.body.id;
  });

  test('l\'elenco di qa001 contiene SOLO i propri certificati', async () => {
    // qa002 carica un proprio certificato
    const { a: dip2 } = await h.loginDip2();
    await h.caricaCertificato(dip2).expect(201);

    const r = await h.agente() // NON autenticato → 401 (controllo di confine)
      .get('/api/certificati');
    expect(r.status).toBe(401);

    const { a: dip1 } = await h.loginDip1();
    const lista = await dip1.get('/api/certificati');
    expect(lista.status).toBe(200);
    expect(lista.body.certificati).toHaveLength(1);
    expect(lista.body.certificati[0].id).toBe(idCertDip1);
  });

  test('qa002 NON può scaricare il PDF di qa001 → 403', async () => {
    const { a: dip2 } = await h.loginDip2();
    const r = await dip2.get(`/api/certificati/${idCertDip1}/file`);
    expect(r.status).toBe(403);
    expect(r.body.errore).toMatch(/solo ai tuoi/i);
  });

  test('qa002 NON può nemmeno APRIRLO inline (modo=visualizza) → 403', async () => {
    const { a: dip2 } = await h.loginDip2();
    await dip2.get(`/api/certificati/${idCertDip1}/file?modo=visualizza`).expect(403);
  });

  test('manomissione dell\'id (enumerazione) resta inutile: il server controlla il proprietario', async () => {
    const { a: dip2 } = await h.loginDip2();
    // prova id NOTI: quello di dip1 e id inesistenti vicini
    await dip2.get(`/api/certificati/${idCertDip1}/file`).expect(403);
    await dip2.get(`/api/certificati/${idCertDip1 + 1000}/file`).expect(404);
  });

  test('l\'AMMINISTRATORE può scaricare il PDF di qualunque dipendente (verifica documenti)', async () => {
    const { a: admin } = await h.loginAdmin();
    const r = await admin.get(`/api/certificati/${idCertDip1}/file`);
    expect(r.status).toBe(200);
    expect(r.headers['content-type']).toContain('application/pdf');
  });

  test('identificativi non validi → 400 (mai 500)', async () => {
    const { a: dip1 } = await h.loginDip1();
    await dip1.get('/api/certificati/abc/file').expect(400);
    await dip1.get('/api/certificati/0/file').expect(400);
    await dip1.get('/api/certificati/-1/file').expect(400);
  });

  test('path traversal sul percorso salvato a DB → 404, nessun file fuori dallo storage', async () => {
    await h.query("UPDATE certificati SET percorso_file = 'certificati/../../.env' WHERE id = ?", [idCertDip1]);
    const { a: admin } = await h.loginAdmin();
    const r = await admin.get(`/api/certificati/${idCertDip1}/file`);
    expect(r.status).toBe(404);
    expect(r.text).not.toContain('DB_'); // nessun contenuto del file .env trapelato
  });
});

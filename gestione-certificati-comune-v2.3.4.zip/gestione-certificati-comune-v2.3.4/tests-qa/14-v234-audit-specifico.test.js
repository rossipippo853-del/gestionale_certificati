/**
 * ============================================================================
 *  14-v234-audit-specifico.test.js — ROUND v2.3.4 «storico puntuale»
 * ============================================================================
 *  Cosa verifica (piano di collaudo v2.3.4):
 *   · PUT /api/admin/certificati/:id → UNA riga di audit per OGNI campo
 *     realmente modificato, con codice specifico:
 *     MODIFICA_TITOLO_CORSO, MODIFICA_ENTE_EROGATORE, MODIFICA_DATA_CONSEGUIMENTO,
 *     MODIFICA_DURATA, MODIFICA_ESAME_FINALE, MODIFICA_AREA_TEMATICA;
 *   · dettagli sempre in forma ««prima» → «dopo»» (durata in formato h:mm,
 *     esame come Sì/No);
 *   · PUT senza variazioni → NESSUNA riga di audit;
 *   · PUT /certificati/:id/stato → APPROVAZIONE_CERTIFICATO / RIFIUTO_CERTIFICATO
 *     con transizione «Stato: X → Y» (e nota) nei dettagli;
 *   · DELETE /certificati/:id → ELIMINAZIONE_CERTIFICATO con certificato_id
 *     NULL e dettagli «Corso «...» · dipendente MATRICOLA»;
 *   · RBAC: le scritture restano riservate agli admin.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

/* Certificato di partenza (default helper): titolo «Corso di collaudo QA»,
 * 8 ore, esame attivo, area «Transizione digitale». */
async function preparaCertificato() {
  const { a } = await h.loginDip1();
  const up = await h.caricaCertificato(a, { area_tematica: 'Transizione digitale' });
  expect(up.status).toBe(201);
  return up.body.id;
}

const righeAuditPer = async (a, id) => {
  const r = await a.get('/api/admin/audit');
  expect(r.status).toBe(200);
  return r.body.righe.filter((x) => x.certificato_id === id);
};

describe('v2.3.4 — azioni SPECIFICHE per i metadati', () => {
  test('cambio SOLO del titolo → esattamente 1 riga MODIFICA_TITOLO_CORSO', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginAdmin();
    const correnti = (await h.query('SELECT * FROM certificati WHERE id = ?', [id]))[0];

    const r = await a.put(`/api/admin/certificati/${id}`).send({
      nome_corso: 'Sicurezza avanzata sui cantieri',
      ente_erogatore: correnti.ente_erogatore,
      data_conseguimento: correnti.data_conseguimento,
      numero_ore: String(correnti.numero_ore),
      numero_minuti: String(correnti.numero_minuti),
      esame_finale: correnti.esame_finale ? '1' : '0',
      area_tematica: correnti.area_tematica,
    });
    expect(r.status).toBe(200);

    const righe = await righeAuditPer(a, id);
    expect(righe).toHaveLength(1);
    expect(righe[0].azione).toBe('MODIFICA_TITOLO_CORSO');
    expect(righe[0].dettagli).toBe('«Corso di collaudo QA» → «Sicurezza avanzata sui cantieri»');
  });

  test('cambio di titolo + ente + area → 3 righe specifiche distinte', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginAdmin();
    const correnti = (await h.query('SELECT * FROM certificati WHERE id = ?', [id]))[0];

    await a.put(`/api/admin/certificati/${id}`).send({
      nome_corso: 'Corso rettificato QA',
      ente_erogatore: 'Nuovo ente erogatore QA',
      data_conseguimento: correnti.data_conseguimento,
      numero_ore: String(correnti.numero_ore),
      numero_minuti: String(correnti.numero_minuti),
      esame_finale: correnti.esame_finale ? '1' : '0',
      area_tematica: 'Privacy,anticorruzione,antiriciclaggio,trasparenza',
    });

    const codici = (await righeAuditPer(a, id)).map((x) => x.azione).sort();
    expect(codici).toEqual(['MODIFICA_AREA_TEMATICA', 'MODIFICA_ENTE_EROGATORE', 'MODIFICA_TITOLO_CORSO']);
  });

  test('cambio durata → MODIFICA_DURATA con dettagli in formato h:mm', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginAdmin();
    const correnti = (await h.query('SELECT * FROM certificati WHERE id = ?', [id]))[0];

    await a.put(`/api/admin/certificati/${id}`).send({
      nome_corso: correnti.nome_corso,
      ente_erogatore: correnti.ente_erogatore,
      data_conseguimento: correnti.data_conseguimento,
      numero_ore: '12',
      numero_minuti: '30',
      esame_finale: correnti.esame_finale ? '1' : '0',
      area_tematica: correnti.area_tematica,
    });

    const [riga] = await righeAuditPer(a, id);
    expect(riga.azione).toBe('MODIFICA_DURATA');
    expect(riga.dettagli).toBe('«8» → «12:30»');
  });

  test('cambio esame finale → MODIFICA_ESAME_FINALE con dettagli Sì/No', async () => {
    const id = await preparaCertificato(); // esame_finale = 1 (attivo)
    const { a } = await h.loginAdmin();
    const correnti = (await h.query('SELECT * FROM certificati WHERE id = ?', [id]))[0];

    await a.put(`/api/admin/certificati/${id}`).send({
      nome_corso: correnti.nome_corso,
      ente_erogatore: correnti.ente_erogatore,
      data_conseguimento: correnti.data_conseguimento,
      numero_ore: String(correnti.numero_ore),
      numero_minuti: String(correnti.numero_minuti),
      esame_finale: '0',
      area_tematica: correnti.area_tematica,
    });

    const [riga] = await righeAuditPer(a, id);
    expect(riga.azione).toBe('MODIFICA_ESAME_FINALE');
    expect(riga.dettagli).toBe('«Sì» → «No»');
  });

  test('PUT identico (nessun campo cambiato) → NESSUNA riga di audit', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginAdmin();
    const correnti = (await h.query('SELECT * FROM certificati WHERE id = ?', [id]))[0];

    const r = await a.put(`/api/admin/certificati/${id}`).send({
      nome_corso: correnti.nome_corso,
      ente_erogatore: correnti.ente_erogatore,
      data_conseguimento: correnti.data_conseguimento,
      numero_ore: String(correnti.numero_ore),
      numero_minuti: String(correnti.numero_minuti),
      esame_finale: correnti.esame_finale ? '1' : '0',
      area_tematica: correnti.area_tematica,
    });
    expect(r.status).toBe(200);
    expect(await righeAuditPer(a, id)).toHaveLength(0);
  });
});

describe('v2.3.4 — azioni SPECIFICHE per lo stato', () => {
  test('approvazione → APPROVAZIONE_CERTIFICATO con transizione nei dettagli', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginAdmin();
    await a.put(`/api/admin/certificati/${id}/stato`)
      .send({ stato: 'APPROVATO', note: 'Conforme al piano formativo.' });

    const [riga] = await righeAuditPer(a, id);
    expect(riga.azione).toBe('APPROVAZIONE_CERTIFICATO');
    expect(riga.dettagli).toBe('Stato: IN_ATTESA → APPROVATO · Nota: Conforme al piano formativo.');
  });

  test('rifiuto → RIFIUTO_CERTIFICATO con transizione nei dettagli', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginAdmin();
    await a.put(`/api/admin/certificati/${id}/stato`).send({ stato: 'RIFIUTATO' });

    const [riga] = await righeAuditPer(a, id);
    expect(riga.azione).toBe('RIFIUTO_CERTIFICATO');
    expect(riga.dettagli).toBe('Stato: IN_ATTESA → RIFIUTATO');
  });
});

describe('v2.3.4 — eliminazione certificato nello storico', () => {
  test('DELETE → ELIMINAZIONE_CERTIFICATO con certificato_id NULL e corso+matricola nei dettagli', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginAdmin();

    const del = await a.delete(`/api/admin/certificati/${id}`);
    expect(del.status).toBe(200);

    const r = await a.get('/api/admin/audit');
    const riga = r.body.righe.find((x) => x.azione === 'ELIMINAZIONE_CERTIFICATO');
    expect(riga).toBeTruthy();
    expect(riga.certificato_id).toBeNull(); // la riga certificato non esiste più
    expect(riga.dettagli).toContain('Corso «Corso di collaudo QA»');
    expect(riga.dettagli).toContain('dipendente qa001');
  });
});

describe('v2.3.4 — RBAC invariato', () => {
  test('dipendente NON può modificare metadati (403) né approvare (403)', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginDip2();
    expect((await a.put(`/api/admin/certificati/${id}`).send({ nome_corso: 'x' })).status).toBe(403);
    expect((await a.put(`/api/admin/certificati/${id}/stato`).send({ stato: 'APPROVATO' })).status).toBe(403);
  });
});

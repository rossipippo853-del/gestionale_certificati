/**
 * ============================================================================
 *  03-upload-sicurezza.test.js — FASE 1: SICUREZZA DEGLI UPLOAD
 * ============================================================================
 *  Cosa verifica (piano di collaudo §1):
 *   · file NON-PDF rifiutati (.js, .exe, .jpg, .html) a prescindere dal MIME;
 *   · file RINOMINATI (.exe con estensione .pdf o MIME falsificato) bloccati
 *     dai magic bytes "%PDF-";
 *   · limite dimensione: >5 MB rifiutato, 5 MB esatti accettati (boundary);
 *   · nessun file "orfano" resta sul disco dopo un rifiuto;
 *   · nome file sul server SEMPRE univoco (timestamp+random): no sovrascritture;
 *   · il percorso salvato a DB è RELATIVO.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');
const fs = require('node:fs');
const path = require('node:path');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

function pdfValido() { return h.pdfBuffer(); }

describe('Filtro dei tipi di file (extension + MIME + contenuto)', () => {
  const casi = [
    ['script JavaScript', 'payload.js', 'text/javascript', 'console.log("pwn")'],
    ['eseguibile Windows', 'virus.exe', 'application/x-msdownload', 'MZÿÿ\x00\x00PAYLOAD'],
    ['pagina HTML con script', 'trappola.html', 'text/html', '<script>alert(1)</script>'],
    ['archivio zip', "shell.zip", 'application/zip', 'PK\x03\x04'],
  ];

  for (const [descrizione, nome, mime, contenuto] of casi) {
    test(`rifiuta ${descrizione} (${nome}) → 400`, async () => {
      const { a } = await h.loginDip1();
      const r = await h.caricaCertificato(a, {}, {
        buffer: Buffer.from(contenuto, 'latin1'), nome, mime,
      });
      expect(r.status).toBe(400);
      expect(r.body.errore).toBeDefined();
      // NESSUN file orfano nella cartella dell'utente
      const file = h.fileSuDisco(h.DIP1.codice_fiscale);
      expect(file === null || file.length === 0).toBe(true);
    });
  }

  test('[v2.2] accetta un\'immagine JPEG genuina (foto.jpg) → 201', async () => {
    const { a } = await h.loginDip1();
    const jpeg = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.from('JFIF-scan', 'latin1')]);
    const r = await h.caricaCertificato(a, { nome_corso: 'Scan JPEG' }, {
      buffer: jpeg, nome: 'foto.jpg', mime: 'image/jpeg',
    });
    expect(r.status).toBe(201);
    const file = h.fileSuDisco(h.DIP1.codice_fiscale);
    expect(file).toHaveLength(1);
    expect(file[0]).toMatch(/\.jpg$/);
  });

  test('rifiuta un .exe RINOMINATO in .pdf con MIME falsificato (magic bytes)', async () => {
    const { a } = await h.loginDip1();
    const r = await h.caricaCertificato(a, {}, {
      buffer: Buffer.from('MZ\x90\x00 questo NON è un pdf', 'latin1'),
      nome: 'sotto copertura.pdf', mime: 'application/pdf',
    });
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/non è un file PDF, JPG o PNG valido/i); // [v2.2]
    expect(h.fileSuDisco(h.DIP1.codice_fiscale) || []).toHaveLength(0); // cleanup automatico
  });

  test('rifiuta un PDF GENUINO con estensione sbagliata (.txt)', async () => {
    const { a } = await h.loginDip1();
    const r = await h.caricaCertificato(a, {}, {
      buffer: pdfValido(), nome: 'attestato.txt', mime: 'application/pdf',
    });
    expect(r.status).toBe(400);
  });

  test('un PDF vero con contenuto binario arbitrario DOPO il magic bytes è accettato', async () => {
    const { a } = await h.loginDip1();
    const buf = Buffer.concat([pdfValido(), Buffer.from('binar.io'.repeat(10))]);
    const r = await h.caricaCertificato(a, {}, { buffer: buf, nome: 'attestato.pdf', mime: 'application/pdf' });
    expect(r.status).toBe(201);
  });
});

describe('Limite di dimensione (5 MB)', () => {
  test('file oltre 5 MB → 400 "File troppo grande" e nessun file residuo', async () => {
    const { a } = await h.loginDip1();
    const grande = Buffer.concat([pdfValido(), Buffer.alloc(5 * 1024 * 1024, 0x41)]); // 5 MB + base
    const r = await h.caricaCertificato(a, {}, { buffer: grande, nome: 'grosso.pdf', mime: 'application/pdf' });
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/limite di 5 MB|troppo grande/i); // [v2.2] messaggio per file
  });

  test('BOUNDARY: un PDF di ESATTAMENTE 5 MB è accettato (201)', async () => {
    const base = pdfValido();
    const giusto = 5 * 1024 * 1024 - base.length;
    const esatto = Buffer.concat([base, Buffer.alloc(giusto, 0x20)]);
    expect(esatto.length).toBe(5 * 1024 * 1024);

    const { a } = await h.loginDip1();
    const r = await h.caricaCertificato(a, {}, { buffer: esatto, nome: 'al-limite.pdf', mime: 'application/pdf' });
    expect(r.status).toBe(201);
    expect(h.fileSuDisco(h.DIP1.codice_fiscale)).toHaveLength(1);
  });

  test('richiesta senza file → 400 "Il file PDF è obbligatorio"', async () => {
    const { a } = await h.loginDip1();
    const r = await a.post('/api/certificati').field(h.campiCertificato());
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/obbligatorio/i);
  });

  test('[v2.2] due file nel campo "file" → 201 (più documenti per lo stesso corso)', async () => {
    const { a } = await h.loginDip1();
    const r = await a.post('/api/certificati')
      .field(h.campiCertificato())
      .attach('file', pdfValido(), { filename: 'uno.pdf', contentType: 'application/pdf' })
      .attach('file', pdfValido(), { filename: 'due.pdf', contentType: 'application/pdf' });
    expect(r.status).toBe(201);
    expect(r.body.allegati).toBe(2);
    const file = h.fileSuDisco(h.DIP1.codice_fiscale);
    expect(file).toHaveLength(2); // entrambi salvati, nessuno scartato
  });
});

describe('Integrità dello storage: nomi univoci e percorsi relativi', () => {
  test('due upload con lo STESSO nome originale → DUE file distinti (nessuna sovrascrittura)', async () => {
    const { a } = await h.loginDip1();
    const r1 = await h.caricaCertificato(a, { nome_corso: 'Primo corso' }, { buffer: pdfValido(), nome: 'attestato.pdf', mime: 'application/pdf' });
    const r2 = await h.caricaCertificato(a, { nome_corso: 'Secondo corso' }, { buffer: pdfValido(), nome: 'attestato.pdf', mime: 'application/pdf' });
    expect(r1.status).toBe(201);
    expect(r2.status).toBe(201);
    expect(r1.body.id).not.toBe(r2.body.id);

    const file = h.fileSuDisco(h.DIP1.codice_fiscale);
    expect(file).toHaveLength(2);
    expect(new Set(file).size).toBe(2); // nomi TUTTI diversi
    // formato {timestamp}-{8hex}_{nome}.pdf
    for (const f of file) expect(f).toMatch(/^\d{13}-[0-9a-f]{8}_attestato\.pdf$/);
  });

  test('caratteri ostili nel nome originale → sanificati (nessun path traversal)', async () => {
    const { a } = await h.loginDip1();
    const r = await h.caricaCertificato(a, {}, {
      buffer: pdfValido(),
      nome: '../../à è#1)_report "2026".pdf',
      mime: 'application/pdf',
    });
    expect(r.status).toBe(201);
    const file = h.fileSuDisco(h.DIP1.codice_fiscale);
    expect(file).toHaveLength(1);
    expect(file[0]).not.toContain('..');
    expect(file[0]).toMatch(/\.pdf$/);
  });

  test('nel DB è salvato SOLO il percorso RELATIVO (certificati/{matricola}/{file})', async () => {
    const { a } = await h.loginDip1();
    const r = await h.caricaCertificato(a);
    expect(r.status).toBe(201);
    const righe = await h.query('SELECT percorso_file FROM certificati WHERE id = ?', [r.body.id]);
    expect(righe[0].percorso_file).toMatch(new RegExp(`^certificati\\/${h.DIP1.codice_fiscale}\\/\\d{13}-[0-9a-f]{8}_[a-z0-9._-]+\\.pdf$`));
    expect(path.isAbsolute(righe[0].percorso_file)).toBe(false);
    expect(fs.existsSync(path.join(h.DIR_CERT, '..', righe[0].percorso_file))).toBe(true);
  });
});

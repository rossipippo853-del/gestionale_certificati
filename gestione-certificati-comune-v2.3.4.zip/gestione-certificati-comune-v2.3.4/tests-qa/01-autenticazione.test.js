/**
 * ============================================================================
 *  01-autenticazione.test.js — FASE 1: LOGIN, SESSIONI E SICUREZZA
 * ============================================================================
 *  Cosa verifica (piano di collaudo §1):
 *   · nessun loop di reindirizzamento su / (login) con e senza sessione;
 *   · alias /login → / (FIX QA-C1, prima: 404 HTML "Cannot GET");
 *   · cookie di sessione con gli attributi di sicurezza corretti;
 *   · token assente/manomesso/scaduto/revocato → 401 coerenti;
 *   · anti-enumerazione (stesso messaggio per matricola o password errata);
 *   · rate-limiting anti brute-force (429 dopo 5 fallimenti);
 *   · SQL injection sul login trattata come testo letterale;
 *   · header di sicurezza globali e assenza di x-powered-by;
 *   · nessun leak di password_hash in /api/auth/me.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');
const jwt = require('jsonwebtoken');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

const jwtSecret = process.env.JWT_SECRET || require('../src/config').jwtSecret;

/* ---------------------- Loop di redirect sulla pagina di login ---------------------- */

describe('Pagina di login /: nessun loop di reindirizzamento', () => {
  test('SENZA sessione: GET / risponde 200 HTML (il form resta utilizzabile)', async () => {
    const r = await h.agente().get('/');
    expect(r.status).toBe(200);
    expect(r.headers['content-type']).toContain('text/html');
    expect(r.text).toContain('form-login');
    expect(r.headers.location).toBeUndefined(); // NESSUN redirect lato server
  });

  test('SENZA sessione: /api/auth/me risponde 401 JSON (mai un redirect HTML)', async () => {
    const r = await h.agente().get('/api/auth/me');
    expect(r.status).toBe(401);
    expect(r.headers['content-type']).toContain('application/json');
  });

  test('CON sessione valida: GET / resta 200 (il salto è solo client-side → nessun ping-pong)', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.get('/');
    expect(r.status).toBe(200);
    expect(r.headers.location).toBeUndefined();
  });

  test('FIX QA-C1: GET /login reindirizza 302 verso / (prima: 404 "Cannot GET")', async () => {
    const r = await h.agente().get('/login');
    expect(r.status).toBe(302);
    expect(r.headers.location).toBe('/');
  });
});

/* ------------------------------ Cookie e token ------------------------------ */

describe('Cookie di sessione e ciclo di vita del token', () => {
  test('login OK → cookie httpOnly SameSite=Lax + profilo completo senza hash', async () => {
    const { a, r } = await h.loginAdmin();
    expect(r.status).toBe(200);
    const cookie = Array.isArray(r.headers['set-cookie']) ? r.headers['set-cookie'].join(' ') : String(r.headers['set-cookie']);
    expect(cookie).toMatch(/token=/);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Lax/i);
    expect(r.body.utente.matricola).toBe('qa000');
    expect(r.body.utente.sesso).toBe('M');
    expect(r.body.utente.qualifica).toBe('Impiegato');
    expect(JSON.stringify(r.body)).not.toContain('password_hash');
  });

  /* [v2.3.3] I token (validi, manomessi, scaduti, revocati) viaggiano ora via
   * header Authorization Bearer (sessione di scheda). Il cookie, sui path non
   * di download, NON viene nemmeno letto → 401 «Non autenticato.». */
  test('token manomesso (firma invalida) → 401 + cookie di sessione ripulito', async () => {
    const falso = jwt.sign({ id: 1, matricola: 'qa000', jti: 'x' }, 'segreto-SBAGLIATO');
    const r = await h.agente().get('/api/auth/me').set('Authorization', `Bearer ${falso}`);
    expect(r.status).toBe(401);
    expect(r.body.errore).toMatch(/scaduta|login/i);
    const pulizia = Array.isArray(r.headers['set-cookie']) ? r.headers['set-cookie'].join('|') : '';
    expect(pulizia).toMatch(/token=;/); // il cookie scaduto viene cancellato dal browser

    /* Modalità rigida: lo stesso token in COOKIE (path non download) → 401 generico. */
    const viaCookie = await h.agente().get('/api/auth/me').set('Cookie', `token=${falso}`);
    expect(viaCookie.status).toBe(401);
    expect(viaCookie.body.errore).toBe('Non autenticato.');
  });

  test('token scaduto → 401 "Sessione scaduta"', async () => {
    const id = (await h.query('SELECT id FROM dipendenti WHERE matricola = ?', ['qa000']))[0].id;
    const scaduto = jwt.sign({ id, matricola: 'qa000', jti: 'jti-scaduto' }, jwtSecret, { expiresIn: '-10s' });
    const r = await h.agente().get('/api/auth/me').set('Authorization', `Bearer ${scaduto}`);
    expect(r.status).toBe(401);
    expect(r.body.errore).toMatch(/scaduta/i);
  });

  test('logout → il token revocato NON è più riutilizzabile (401 "Sessione terminata")', async () => {
    const { a, r: loginRes } = await h.loginAdmin();
    const token = loginRes.body.token;
    await a.post('/api/auth/logout').expect(200);

    const riuso = await h.agente().get('/api/auth/me').set('Authorization', `Bearer ${token}`);
    expect(riuso.status).toBe(401);
    expect(riuso.body.errore).toMatch(/terminata/i);
  });

  test('account disabilitato: la sessione esistente muore ALLA RICHIESTA SUCCESSIVA', async () => {
    const idDip1 = (await h.query('SELECT id FROM dipendenti WHERE matricola = ?', ['qa001']))[0].id;
    const { a } = await h.loginDip1();
    const { a: admin } = await h.loginAdmin();

    await admin.put(`/api/admin/utenti/${idDip1}/stato`).send({ attivo: false }).expect(200);

    const r = await a.get('/api/auth/me'); // stessa sessione, utente ora spento
    expect(r.status).toBe(401);
  });

  test('login di un account disabilitato → 403 "Account disabilitato"', async () => {
    await h.query("UPDATE dipendenti SET attivo = 0 WHERE matricola = 'qa001'");
    const { r } = await h.login('qa001', 'DipQa2026');
    expect(r.status).toBe(403);
    expect(r.body.errore).toMatch(/disabilitato/i);
  });
});

/* --------------------------- Anti-attacco credenziali --------------------------- */

describe('Robustezza del login', () => {
  test('anti-enumerazione: matricola inesistente e password errata danno lo STESSO messaggio', async () => {
    const r1 = await h.agente().post('/api/auth/login').send({ matricola: 'inesistente99', password: 'qualsiasi1' });
    const r2 = await h.agente().post('/api/auth/login').send({ matricola: 'qa000', password: 'Sbagliata1' });
    expect(r1.status).toBe(401);
    expect(r2.status).toBe(401);
    expect(r1.body.errore).toBe(r2.body.errore);
  });

  test('SQL injection nel campo matricola: trattata come testo (401, mai 500/200)', async () => {
    const r = await h.agente().post('/api/auth/login')
      .send({ matricola: "' OR '1'='1' --", password: 'x' });
    expect([400, 401]).toContain(r.status); // 400 se il formato matricola è violato, 401 altrimenti
    expect(r.status).not.toBe(200);
  });

  test('rate-limiting: 5 fallimenti consecutivi → 429 anche con credenziali CORRETTE', async () => {
    for (let i = 0; i < 5; i++) {
      await h.agente().post('/api/auth/login').send({ matricola: 'qa001', password: `Errata${i}x` });
    }
    const r = await h.agente().post('/api/auth/login').send({ matricola: 'qa001', password: 'DipQa2026' });
    expect(r.status).toBe(429);
    expect(r.body.errore).toMatch(/troppi tentativi/i);
    // Le ALTRE matricole non sono bloccate (il limite è per matricola)
    await h.agente().post('/api/auth/login').send({ matricola: 'qa002', password: 'DipQa2026' }).expect(200);
  });

  test('campi mancanti/vuoti → 400 con messaggio chiaro', async () => {
    await h.agente().post('/api/auth/login').send({ matricola: '', password: '' }).expect(400);
    await h.agente().post('/api/auth/login').send({}).expect(400);
  });
});

/* ---------------- [v2.1] Primo accesso: cambio obbligatorio in modale ---------------- */

describe('[v2.1] Primo accesso con password provvisoria (modale bloccante sul login)', () => {
  test('login con flag attivo → primoAccesso, NESSUN cookie di sessione, solo token_cambio', async () => {
    await h.query("UPDATE dipendenti SET must_change_password = 1 WHERE matricola = 'qa002'");
    try {
      const r = await h.agente().post('/api/auth/login').send({ matricola: 'qa002', password: 'DipQa2026' });
      expect(r.status).toBe(200);
      expect(r.body.primoAccesso).toBe(true);
      expect(r.body.utente.matricola).toBe('qa002');
      const cookie = r.headers['set-cookie'] || [];
      expect(cookie.some((c) => c.startsWith('token_cambio='))).toBe(true);
      expect(cookie.some((c) => /^token=eyJ/.test(c))).toBe(false); // nessuna sessione emessa
    } finally {
      await h.query("UPDATE dipendenti SET must_change_password = 0 WHERE matricola = 'qa002'");
    }
  });

  test('il cookie token_cambio NON autentica come sessione (token "scopito", defense in depth)', async () => {
    const jwt = require('jsonwebtoken');
    const scopito = jwt.sign(
      { id: 1, matricola: 'qa000', jti: 'solo-cambio', scopo: 'primo-accesso' },
      process.env.JWT_SECRET,
      { expiresIn: '10m' }
    );
    const r = await h.agente().get('/api/auth/me').set('Cookie', `token=${scopito}`);
    expect(r.status).toBe(401);
  });

  test('flusso completo: login → modale → cambio valido → sessione attiva senza riloggarsi', async () => {
    await h.query("UPDATE dipendenti SET must_change_password = 1 WHERE matricola = 'qa002'");
    const { a } = await h.login('qa002', 'DipQa2026');
    // nessuna sessione: l'area riservata è irraggiungibile finché non cambia
    await a.get('/api/auth/me').expect(401);
    // validazioni mostrate dentro la modale
    await a.post('/api/auth/primo-accesso')
      .send({ nuovaPassword: 'Una12345', confermaPassword: 'Diversa2' }).expect(400);
    await a.post('/api/auth/primo-accesso')
      .send({ nuovaPassword: 'corta1', confermaPassword: 'corta1' }).expect(400);
    await a.post('/api/auth/primo-accesso')
      .send({ nuovaPassword: 'DipQa2026', confermaPassword: 'DipQa2026' }).expect(400); // = provvisoria
    // cambio valido → flag azzerato e sessione IMMEDIATA
    const ok = await a.post('/api/auth/primo-accesso')
      .send({ nuovaPassword: 'NuovaForte1', confermaPassword: 'NuovaForte1' });
    expect(ok.status).toBe(200);
    expect(ok.body.utente.mustChangePassword).toBe(false);
    /* [v2.3.3] la sessione è una sessione di SCHEDA: /me risponde col token
     * emesso dal cambio (come fa il frontend da sessionStorage). */
    expect(typeof ok.body.token).toBe('string');
    const me = await a.get('/api/auth/me').set('Authorization', `Bearer ${ok.body.token}`);
    expect(me.status).toBe(200);
    expect(me.body.utente.matricola).toBe('qa002');
    // la provvisoria non funziona più
    await h.agente().post('/api/auth/login').send({ matricola: 'qa002', password: 'DipQa2026' }).expect(401);
  });
});

/* ------------------------------ Hardening globale ------------------------------ */

describe('Header di sicurezza e hardening', () => {
  test('tutte le risposte portano CSP, nosniff, X-Frame-Options e Referrer-Policy', async () => {
    const r = await h.agente().get('/');
    expect(r.headers['content-security-policy']).toContain("script-src 'self'");
    expect(r.headers['x-content-type-options']).toBe('nosniff');
    expect(r.headers['x-frame-options']).toBe('SAMEORIGIN');
    expect(r.headers['referrer-policy']).toBe('same-origin');
    expect(r.headers['x-powered-by']).toBeUndefined();
  });

  test('le risposte API non sono cachabili (Cache-Control: no-store)', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.get('/api/admin/utenti');
    expect(r.headers['cache-control']).toBe('no-store');
  });

  test('endpoint API inesistente → 404 JSON (mai HTML di Express)', async () => {
    const r = await h.agente().get('/api/non-esiste');
    expect(r.status).toBe(404);
    expect(r.headers['content-type']).toContain('application/json');
  });

  test('token firmato con un segreto "indovinabile" NON è accettato (nessun segreto predefinito)', async () => {
    for (const tentativo of ['', 'segreto', 'SOSTITUISCI-QUESTO-SEGRETO', 'cambia-questo-segreto']) {
      let token;
      try {
        token = jwt.sign({ id: 1, matricola: 'qa000', jti: 'y' }, tentativo || 'vuoto');
      } catch { continue; } // jsonwebtoken rifiuta già le chiavi vuote: bene così
      const r = await h.agente().get('/api/auth/me').set('Cookie', `token=${token}`);
      expect(r.status).toBe(401); // nessun segreto noto produce token validi
    }
  });
});

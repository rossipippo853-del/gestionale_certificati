/**
 * ============================================================================
 *  06-certificati.test.js — FASE 3: CARICAMENTO CERTIFICATI (lato dipendente)
 * ============================================================================
 *  Cosa verifica (piano di collaudo §3):
 *   · validazione del form: ogni campo obbligatorio mancante → 400
 *     (titolo, ente, data, numero ore, area tematica); esame_finale è un
 *     booleano (checkbox assente = non superato) e NON blocca la richiesta;
 *   · numero ore: solo interi 1..9999 (0, 7.5, 10000, "otto" → 400);
 *   · date future → 400;
 *   · INTEGRITÀ FILE SYSTEM: se la cartella {matricola} viene cancellata
 *     manualmente, l'upload la RICREA al volo (201, mai 500) [self-healing];
 *   · lo stato iniziale è IN_ATTESA e l'elenco mostra i campi v1.4.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');
const fs = require('node:fs');
const path = require('node:path');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

describe('Validazione del form certificato (campi obbligatori)', () => {
  const mancaTitolo = { nome_corso: null };
  const casi = [
    ['titolo del corso', { nome_corso: null }],
    ['titolo troppo corto', { nome_corso: 'Ab' }],
    ['ente erogatore', { ente_erogatore: null }],
    ['data di conseguimento', { data_conseguimento: null }],
    ['data malformata', { data_conseguimento: '10/05/2026' }],
    ['data FUTURA', { data_conseguimento: '2027-01-01' }],
    ['numero ore', { numero_ore: null }],
    ['ore = 0', { numero_ore: '0' }],
    ['ore decimali (7.5)', { numero_ore: '7.5' }],
    ['ore oltre il massimo (10000)', { numero_ore: '10000' }],
    ['ore testuali ("otto")', { numero_ore: 'otto' }],
    ['area tematica', { area_tematica: null }],
    ['area tematica inventata', { area_tematica: 'Area fantasiosa' }],
  ];

  for (const [descrizione, override] of casi) {
    test(`manca/viziato: ${descrizione} → 400, nessun file salvato`, async () => {
      const { a } = await h.loginDip1();
      const r = await h.caricaCertificato(a, override);
      expect(r.status).toBe(400);
      expect(r.body.errore).toBeDefined();
      expect(h.fileSuDisco(h.DIP1.codice_fiscale) || []).toHaveLength(0); // nessun orfano
    });
  }

  test('esame_finale ASSNTE (checkbox non spuntato) → accettato come "No" (comportamento checkbox)', async () => {
    const { a } = await h.loginDip1();
    const r = await h.caricaCertificato(a, { esame_finale: null });
    expect(r.status).toBe(201);
    const u = (await h.query('SELECT esame_finale FROM certificati WHERE id = ?', [r.body.id]))[0];
    expect(u.esame_finale).toBe(0);
  });

  test('upload valido completo → 201 con tutti i campi v1.4 salvati correttamente', async () => {
    const { a } = await h.loginDip1();
    const r = await h.caricaCertificato(a, {
      nome_corso: 'Corso completo di verifica',
      ente_erogatore: 'Scuola Superiore della P.A.',
      data_conseguimento: '2026-03-15',
      numero_ore: '24',
      esame_finale: '1',
      area_tematica: 'Transizione amministrativa',
    });
    expect(r.status).toBe(201);

    const c = (await h.query('SELECT * FROM certificati WHERE id = ?', [r.body.id]))[0];
    expect(c.nome_corso).toBe('Corso completo di verifica');
    expect(c.ente_erogatore).toBe('Scuola Superiore della P.A.');
    expect(c.data_conseguimento).toBe('2026-03-15');
    expect(c.numero_ore).toBe(24);
    expect(c.esame_finale).toBe(1);
    expect(c.area_tematica).toBe('Transizione amministrativa');
    expect(c.stato).toBe('IN_ATTESA'); // sempre lo stato iniziale
    expect(c.dipendente_id).toBe((await h.query("SELECT id FROM dipendenti WHERE matricola='qa001'"))[0].id);
  });

  test('[v2.2.5] le 6 aree STORICHE restano ammesse (retrocompatibilità archivio)', async () => {
    const aree = [
      'Competenze linguistiche', 'Leadership e soft skills', 'Principi e valori della PA',
      'Transizione digitale', 'Transizione ecologica', 'Transizione amministrativa',
    ];
    const { a } = await h.loginDip1();
    let id = 0;
    for (const area of aree) {
      const r = await h.caricaCertificato(a, { nome_corso: `Corso area ${++id}`, area_tematica: area });
      expect(r.status).toBe(201);
      const salvata = (await h.query('SELECT area_tematica FROM certificati WHERE id = ?', [r.body.id]))[0];
      expect(salvata.area_tematica).toBe(area);
    }
  });
});

describe('Integrità del file system (self-healing e univocità)', () => {
  test('cartella utente CANCELLATA manualmente → l\'upload la ricrea al volo (201, mai 500)', async () => {
    // 1) un primo upload per creare la cartella, poi la si cancella dal disco
    const { a } = await h.loginDip1();
    await h.caricaCertificato(a, { nome_corso: 'Prima del guasto' }).expect(201);
    const cartella = path.join(h.DIR_CERT, h.DIP1.codice_fiscale); // v2.0: cartella CF
    expect(fs.existsSync(cartella)).toBe(true);
    fs.rmSync(cartella, { recursive: true, force: true });
    expect(fs.existsSync(cartella)).toBe(false);

    // 2) il server NON deve andare in errore: la cartella torna al primo upload
    const r = await h.caricaCertificato(a, { nome_corso: 'Dopo il guasto' });
    expect(r.status).toBe(201); // NON 500
    expect(fs.existsSync(cartella)).toBe(true);
    expect(h.fileSuDisco(h.DIP1.codice_fiscale)).toHaveLength(1);
  });

  test('anche l\'intera radice uploads-qa cancellata → l\'upload ricrea tutto il percorso', async () => {
    fs.rmSync(path.resolve(__dirname, '..', 'uploads-qa'), { recursive: true, force: true });
    const { a } = await h.loginDip1();
    const r = await h.caricaCertificato(a, { nome_corso: 'Ricostruzione completa' });
    expect(r.status).toBe(201);
    expect(fs.existsSync(path.join(h.DIR_CERT, h.DIP1.codice_fiscale))).toBe(true); // v2.0
  });

  test('due upload ravvicinati dello stesso file → nomi DIVERSI (nessuna sovrascrittura)', async () => {
    const { a } = await h.loginDip1();
    const r1 = await h.caricaCertificato(a, { nome_corso: 'Copia 1' });
    const r2 = await h.caricaCertificato(a, { nome_corso: 'Copia 2' });
    expect(r1.status).toBe(201);
    expect(r2.status).toBe(201);
    const file = h.fileSuDisco(h.DIP1.codice_fiscale);
    expect(file).toHaveLength(2);
    expect(file[0]).not.toBe(file[1]);
  });

  test('il dipendente vede i propri certificati con i campi v1.4 nell\'elenco', async () => {
    const { a } = await h.loginDip1();
    await h.caricaCertificato(a, { numero_ore: '12', esame_finale: '1', area_tematica: 'Transizione digitale' }).expect(201);

    const r = await a.get('/api/certificati');
    expect(r.status).toBe(200);
    const c = r.body.certificati[0];
    for (const campo of ['nome_corso', 'ente_erogatore', 'data_conseguimento', 'numero_ore', 'esame_finale', 'area_tematica', 'stato', 'caricato_il']) {
      expect(c).toHaveProperty(campo);
    }
    expect(c.numero_ore).toBe(12);
    expect(c.area_tematica).toBe('Transizione digitale');
    expect(c).not.toHaveProperty('percorso_file'); // mai esposto al client
  });

  test('[v1.5] reset a sessione attiva: banner attivo e upload NON bloccato; il prossimo login passa dalla modale', async () => {
    // qa002 ha must_change=0 nelle fixture: login NORMALE (sessione piena)…
    const { a } = await h.loginDip2();
    // …poi le credenziali vengono azzerate MENTRE la sessione è aperta (flag=1)
    await h.query("UPDATE dipendenti SET must_change_password = 1 WHERE matricola = 'qa002'");

    // il frontend sa dove mostrare il banner: /me espone mustChangePassword
    const me = await a.get('/api/auth/me');
    expect(me.status).toBe(200);
    expect(me.body.utente.mustChangePassword).toBe(true);

    // l'upload NON è più bloccato (v1.5): 201 e file salvato
    const r = await h.caricaCertificato(a, { nome_corso: 'Caricato con provvisoria' });
    expect(r.status).toBe(201);
    expect(h.fileSuDisco(h.DIP2.codice_fiscale)).toHaveLength(1);

    // il record è in elenco, il percorso DB punta alla cartella CF e il flag di avviso resta attivo
    const lista = await a.get('/api/certificati');
    expect(lista.body.certificati).toHaveLength(1);
    const riga = (await h.query('SELECT percorso_file FROM certificati WHERE id = ?', [lista.body.certificati[0].id]))[0];
    expect(riga.percorso_file).toContain(`certificati/${h.DIP2.codice_fiscale}/`); // v2.0
    const dopo = await a.get('/api/auth/me');
    expect(dopo.body.utente.mustChangePassword).toBe(true);

    // [v2.1] il PROSSIMO login, invece, passerà dalla modale obbligatoria
    const { r: riloggato } = await h.login(h.DIP2.matricola, h.DIP2.password);
    expect(riloggato.status).toBe(200);
    expect(riloggato.body.primoAccesso).toBe(true);
    // ripristino del flag per i test successivi del file
    await h.query("UPDATE dipendenti SET must_change_password = 0 WHERE matricola = 'qa002'");
  });
});

describe('[v2.0] UPLOAD CERTIFICATO PER CONTO DI UN DIPENDENTE (admin)', () => {
  test('l’admin carica per qa001: 201, file nella cartella CF di qa001, record associato a qa001', async () => {
    const { a } = await h.loginAdmin();
    const idDip1 = (await h.query("SELECT id, codice_fiscale FROM dipendenti WHERE matricola = 'qa001'"))[0];

    const r = await a.post('/api/admin/certificati')
      .field('dipendenteId', String(idDip1.id))
      .field('nome_corso', 'Caricato dall’amministratore')
      .field('ente_erogatore', 'Scuola Superiore della P.A.')
      .field('data_conseguimento', '2026-04-10')
      .field('numero_ore', '16')
      .field('esame_finale', '1')
      .field('area_tematica', 'Transizione amministrativa')
      .attach('file', h.pdfBuffer('upload admin'), { filename: 'admin-upload.pdf', contentType: 'application/pdf' });
    expect(r.status).toBe(201);
    expect(r.body.messaggio).toMatch(/qa001/);

    // file FISICAMENTE nella cartella {CF} del dipendente scelto
    const file = h.fileSuDisco(h.DIP1.codice_fiscale);
    expect(file).toHaveLength(1);

    // percorso a DB coerente + associazione al dipendente giusto
    const riga = (await h.query('SELECT * FROM certificati WHERE id = ?', [r.body.id]))[0];
    expect(riga.percorso_file).toBe(`certificati/${h.DIP1.codice_fiscale}/${file[0]}`);
    expect(riga.dipendente_id).toBe(idDip1.id);
    expect(riga.numero_ore).toBe(16);
    expect(riga.area_tematica).toBe('Transizione amministrativa');
    expect(riga.stato).toBe('IN_ATTESA'); // come un upload normale

    // il DIPENDENTE lo vede nel proprio elenco e può scaricarlo
    const { a: dip1 } = await h.loginDip1();
    const elenco = await dip1.get('/api/certificati');
    expect(elenco.body.certificati.map((c) => c.nome_corso)).toContain('Caricato dall’amministratore');
    await dip1.get(`/api/certificati/${r.body.id}/file`).expect(200);
  });

  test('senza dipendenteId → 400; dipendente inesistente → 404', async () => {
    const { a } = await h.loginAdmin();
    const r1 = await a.post('/api/admin/certificati')
      .field('nome_corso', 'Corso senza destinatario')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-04-10')
      .field('numero_ore', '8')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer(), { filename: 'x.pdf', contentType: 'application/pdf' });
    expect(r1.status).toBe(400);
    expect(r1.body.errore).toMatch(/Seleziona il dipendente/i);

    const r2 = await a.post('/api/admin/certificati')
      .field('dipendenteId', '987654')
      .field('nome_corso', 'Corso fantasma')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-04-10')
      .field('numero_ore', '8')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer(), { filename: 'x.pdf', contentType: 'application/pdf' });
    expect(r2.status).toBe(404);
  });

  test('file non-PDF o campo mancante → 400 e NESSUN file scritto', async () => {
    const idDip2 = (await h.query("SELECT id FROM dipendenti WHERE matricola = 'qa002'"))[0].id;
    const { a } = await h.loginAdmin();

    const r1 = await a.post('/api/admin/certificati')
      .field('dipendenteId', String(idDip2))
      .field('nome_corso', 'Corso con eseguibile')
      .field('ente_erogatore', 'Ente')
      .field('data_conseguimento', '2026-04-10')
      .field('numero_ore', '8')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', Buffer.from('MZ non un pdf'), { filename: 'malizioso.pdf', contentType: 'application/pdf' });
    expect(r1.status).toBe(400);
    expect(h.fileSuDisco(h.DIP2.codice_fiscale) || []).toHaveLength(0); // niente scritture

    const r2 = await a.post('/api/admin/certificati')
      .field('dipendenteId', String(idDip2))
      .field('ente_erogatore', 'Ente')            // manca nome_corso → validazione
      .field('data_conseguimento', '2026-04-10')
      .field('numero_ore', '8')
      .field('esame_finale', '0')
      .field('area_tematica', 'Transizione digitale')
      .attach('file', h.pdfBuffer(), { filename: 'ok.pdf', contentType: 'application/pdf' });
    expect(r2.status).toBe(400);
    expect(r2.body.errore).toMatch(/corso/i);
    expect(h.fileSuDisco(h.DIP2.codice_fiscale) || []).toHaveLength(0);
  });

  test('wiring frontend: il dialog admin contiene il menu dipendenti con CF e i campi del corso', () => {
    const html = fs.readFileSync(path.resolve(__dirname, '..', 'public', 'admin.html'), 'utf8');
    const js = fs.readFileSync(path.resolve(__dirname, '..', 'public', 'js', 'admin.js'), 'utf8');
    // [v2.2.2] 'cc-ore'/'cc-minuti' sono stati unificati in 'cc-durata' (hh:mm)
    for (const id of ['dlg-carica-cert', 'cc-dipendente', 'cc-corso', 'cc-ente', 'cc-data', 'cc-durata', 'cc-esame', 'cc-area', 'cc-file']) {
      expect(html).toContain(`id="${id}"`);
    }
    expect(html).toContain('btn-carica-per');
    expect(js).toContain('/api/admin/certificati');        // chiamata alla nuova rotta
    expect(js).toMatch(/codice_fiscale/);                  // il menu mostra il CF
  });
});

describe('Frontend onboarding (v1.5): avviso non bloccante', () => {
  const js = fs.readFileSync(path.resolve(__dirname, '..', 'public', 'js', 'dipendente.js'), 'utf8');
  const html = fs.readFileSync(path.resolve(__dirname, '..', 'public', 'dipendente.html'), 'utf8');

  test('nessun blocco client-side: il form upload non viene disabilitato dal flag provvisoria', () => {
    // il vecchio ramo operativo (if sul codice d'errore + messaggio di blocco) NON esiste più
    expect(js).not.toMatch(/codice\s*===?\s*['"]PASSWORD_TEMPORANEA/);
    expect(js).not.toContain('Operazione bloccata');
    expect(js).not.toMatch(/mustChangePassword[^\n]*(disabled|block|nascondi)/i);
    // il bottone di upload viene disabilitato SOLO durante l'invio (finally lo riabilita)
    expect(js).toMatch(/bottone\.disabled = false/);
  });

  test('il banner è informativo: visibile su mustChangePassword, sparirà dopo il cambio', () => {
    expect(js).toMatch(/mustChangePassword[^\n]*\n?[^\n]*banner-password/);
    expect(html).toMatch(/id="banner-password"/);
    expect(html).toContain('nascosto'); // parte nascosto
    expect(html).toMatch(/cambiarla ora|Cambiala ora/i); // invito al cambio
    expect(html).toMatch(/incluso il caricamento|tutte le funzioni/i); // esplicita non-blocco
  });

  test('dopo il cambio password il banner viene nascosto dalla pagina', () => {
    const blocco = js.slice(js.indexOf('async function cambiaPassword'));
    expect(blocco).toMatch(/banner-password/);
    expect(blocco).toMatch(/classList\.add\('nascosto'\)/);
  });
});

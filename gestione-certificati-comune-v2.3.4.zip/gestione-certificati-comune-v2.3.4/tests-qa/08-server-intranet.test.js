/**
 * ============================================================================
 *  08-server-intranet.test.js — FASE 5 [v1.5]: SERVER PER INTRANET (IP FISSO)
 * ============================================================================
 *  Cosa verifica (piano di deployment su PC server dedicato):
 *   · l'app si mette in ascolto su 0.0.0.0 (tutte le schede di rete): le
 *     richieste sono servite su 127.0.0.1 E su ogni IP IPv4 non-internal
 *     della macchina (simula il client remoto della intranet);
 *   · la configurazione HOST è parametrica (HOST env → config.host);
 *   · il cookie di sessione è valido su HTTP di rete locale (SameSite=Lax,
 *     secure=false): login + chiamata autenticata attraverso l'interfaccia
 *     di rete (non loopback) funziona;
 *   · nessun middleware CORS: il frontend è servito STESSA ORIGINE (le
 *     risposte non dichiarano Access-Control-Allow-Origin e non serve).
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');
const os = require('node:os');
const config = require('../src/config');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

/** IPv4 non-internal della macchina (= gli "IP fissi" del server in rete). */
function ipDiRete() {
  const risultati = [];
  for (const elenco of Object.values(os.networkInterfaces())) {
    for (const i of elenco || []) {
      if (i.family === 'IPv4' && !i.internal) risultati.push(i.address);
    }
  }
  return risultati;
}

describe('Configurazione di ascolto per la intranet', () => {
  test('default HOST = 0.0.0.0 (tutte le interfacce, raggiungibile da http://IP:3000)', () => {
    expect(config.host).toBe('0.0.0.0');
  });

  test('.env.example documenta HOST, COOKIE_SECURE=false su http e la porta', () => {
    const env = require('node:fs').readFileSync(
      require('node:path').resolve(__dirname, '..', '.env.example'), 'utf8');
    expect(env).toMatch(/HOST=0\.0\.0\.0/);
    expect(env).toMatch(/COOKIE_SECURE=false/);
    expect(env).toMatch(/PORT=3000/);
  });
});

describe('Ascolto reale su tutte le interfacce (server montato su porta effimera)', () => {
  let server;
  let porta;

  beforeAll((fine) => {
    server = h.app.listen(0, '0.0.0.0', () => {
      porta = server.address().port;
      fine();
    });
  });

  afterAll(() => new Promise((risolvi) => server.close(risolvi)));

  test('risponde su 127.0.0.1 (loopback)', async () => {
    const r = await fetch(`http://127.0.0.1:${porta}/api/salute`);
    expect(r.status).toBe(200);
    expect((await r.json()).stato).toBe('ok');
  });

  test('risponde su OGNI IP IPv4 non-internal della macchina (client remoto della rete)', async () => {
    const ip = ipDiRete();
    // In un PC server reale c'è sempre almeno una scheda di rete; nel dubbio il
    // test è informativo ma non resta "muto": segnala l'assenza di interfacce.
    expect(Array.isArray(ip)).toBe(true);

    for (const indirizzo of ip) {
      const r = await fetch(`http://${indirizzo}:${porta}/api/salute`);
      expect(r.status).toBe(200);
      expect((await r.json()).stato).toBe('ok');
    }
  });

  test('login + chiamata autenticata ATTRAVERSO l\'interfaccia di rete (cookie SameSite=Lax su http)', async () => {
    const ip = ipDiRete()[0] || '127.0.0.1'; // sull'IP reale se esiste, altrimenti loopback
    const rLogin = await fetch(`http://${ip}:${porta}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ matricola: h.ADMIN.matricola, password: h.ADMIN.password }),
    });
    expect(rLogin.status).toBe(200);

    const cookie = (rLogin.headers.get('set-cookie') || '').split(';')[0];
    expect(cookie).toMatch(/^token=/);
    const { token } = await rLogin.json();

    /* [v2.3.3] sessione di scheda: la chiamata autenticata porta l'header
     * Authorization (il cookie resta emesso per i download diretti). */
    const rMe = await fetch(`http://${ip}:${porta}/api/auth/me`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    expect(rMe.status).toBe(200);
    expect((await rMe.json()).utente.matricola).toBe(h.ADMIN.matricola);
  });

  test('frontend servito sull\'IP di rete: le pagine non dipendono da host/origini esterni', async () => {
    const ip = ipDiRete()[0] || '127.0.0.1';
    const r = await fetch(`http://${ip}:${porta}/dipendente`);
    expect(r.status).toBe(200);
    const html = await r.text();
    // niente CDN/font/script/immagini esterni: l'intranet può essere senza Internet
    expect(html).not.toMatch(/<(script|link|img)[^>]+(src|href)=["']https?:\/\//i);
    // gli script usati sono tutti locali ("self")
    expect(html).toMatch(/<script src="\/js\//);
  });

  test('nessun Access-Control-Allow-Origin: frontend a STESSA ORIGINE (CORS non necessario)', async () => {
    const r = await fetch(`http://127.0.0.1:${porta}/api/salute`);
    expect(r.headers.get('access-control-allow-origin')).toBeNull();
  });
});

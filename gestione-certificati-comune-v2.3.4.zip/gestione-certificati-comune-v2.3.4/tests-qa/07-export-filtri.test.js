/**
 * ============================================================================
 *  07-export-filtri.test.js — FASE 4: EXPORT CSV/EXCEL E FILTRI DI RICERCA
 * ============================================================================
 *  Cosa verifica (piano di collaudo §4):
 *   · export con TUTTI i dati aggregati (18 colonne: anagrafica completa
 *     matricola/nome/cognome/sesso/qualifica + dettagli corso ore/esame/area
 *     + stato PDF e link);
 *   · nessun carattere corrotto (UTF-8 con BOM, accenti e apostrofi intact);
 *   · campi contenenti «;», virgolette o ritorni a capo NON rompono il file
 *     (quoting RFC-4180) e i valori pericolosi non sono interpretabili come
 *     formule Excel (anti CSV-injection);
 *   · filtri Area tematica / Dipendente / intervallo Date (estremi INCLUSI),
 *     anche COMBINATI, restituiscono ESATTAMENTE i record attesi;
 *   · FIX QA-C2: valori di filtro non validi → 400 (prima venivano ignorati
 *     e la tabella sembrava "non filtrata").
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

const HEADER_19 = [ // v2.0: aggiunta la colonna «Codice Fiscale»
  'ID', 'Matricola', 'Codice Fiscale', 'Cognome', 'Nome', 'Sesso', 'Qualifica',
  'Corso', 'Ente erogatore', 'Data conseguimento', 'Numero ore', 'Esame finale',
  'Area tematica', 'Stato certificato', 'Caricato il', 'File originale',
  'Link PDF', 'Dimensione (KB)', 'Note',
];

/** Fixture di 3 dipendenti con certificati noti (date/aree diverse). */
async function preparaFixture() {
  const { a: dip1 } = await h.loginDip1(); // qa001
  const { a: dip2 } = await h.loginDip2(); // qa002

  // qa001: 2 certificati (Transizione digitale e Principi e valori della PA)
  const c1 = await h.caricaCertificato(dip1, {
    nome_corso: 'Excel avanzato; livello 2', // contiene ";" → quoting obbligatorio
    data_conseguimento: '2026-03-01',
    numero_ore: '16', esame_finale: '1',
    area_tematica: 'Transizione digitale',
  });
  const c2 = await h.caricaCertificato(dip1, {
    nome_corso: 'Etica pubblica e valori "istituzionali"', // contiene virgolette
    data_conseguimento: '2026-03-31',
    numero_ore: '8', esame_finale: '0',
    area_tematica: 'Principi e valori della PA',
  });
  // qa002: 1 certificato (Leadership, data fuori dall'intervallo di marzo)
  const c3 = await h.caricaCertificato(dip2, {
    nome_corso: 'Note con accenti àèéìòù e apostrofo d\'tribunale',
    data_conseguimento: '2026-07-20',
    numero_ore: '4', esame_finale: '0',
    area_tematica: 'Leadership e soft skills',
  });

  for (const r of [c1, c2, c3]) expect(r.status).toBe(201);
  const idqa001 = (await h.query("SELECT id FROM dipendenti WHERE matricola='qa001'"))[0].id;
  const idqa002 = (await h.query("SELECT id FROM dipendenti WHERE matricola='qa002'"))[0].id;
  return { ids: [c1.body.id, c2.body.id, c3.body.id], idqa001, idqa002 };
}

describe('Export CSV/Excel: completezza e correttezza del file', () => {
  test('il file parte con BOM UTF-8, header a 18 colonne e TUTTI i dati aggregati', async () => {
    const { ids, idqa001 } = await preparaFixture();
    const { a } = await h.loginAdmin();

    const r = await a.get('/api/admin/certificati/export');
    expect(r.status).toBe(200);
    expect(r.headers['content-type']).toContain('text/csv');
    expect(r.headers['content-disposition']).toMatch(/attachment/);

    const testo = r.text;
    expect(testo.charCodeAt(0)).toBe(0xfeff); // BOM per Excel
    const righe = h.parseCsvRighe(testo.slice(1));
    expect(righe[0]).toEqual(HEADER_19);
    expect(righe).toHaveLength(1 + 3); // header + 3 certificati

    // La riga del primo certificato porta TUTTI i dati aggregati
    const rigaExcel = righe.find((x) => x[0] === String(ids[0]));
    expect(rigaExcel[1]).toBe('qa001');
    expect(rigaExcel[2]).toBe(h.DIP1.codice_fiscale);    // v2.0: Codice Fiscale
    expect(rigaExcel[3]).toBe('Verde');
    expect(rigaExcel[4]).toBe('Luigi');
    expect(rigaExcel[5]).toBe('M');
    expect(rigaExcel[6]).toBe('Impiegato');              // qualifica
    expect(rigaExcel[7]).toBe('Excel avanzato; livello 2'); // separatore DENTRO il campo
    expect(rigaExcel[9]).toBe('2026-03-01');
    expect(rigaExcel[10]).toBe('16');                     // ore
    expect(rigaExcel[11]).toBe('Si');                     // esame finale
    expect(rigaExcel[12]).toBe('Transizione digitale');
    expect(rigaExcel[13]).toBe('IN_ATTESA');
    expect(rigaExcel[16]).toBe(`/api/certificati/${ids[0]}/file`); // link PDF

    // Esame = No per il secondo
    const riga2 = righe.find((x) => x[0] === String(ids[1]));
    expect(riga2[11]).toBe('No');
    expect(riga2[7]).toBe('Etica pubblica e valori "istituzionali"'); // virgolette intact
    void idqa001;
  });

  test('nessun carattere corrotto: accenti, apostrofi e caratteri speciali passano intatti (UTF-8)', async () => {
    await preparaFixture();
    const { a } = await h.loginAdmin();
    const testo = (await a.get('/api/admin/certificati/export')).text;
    expect(testo).toContain("àèéìòù");
    expect(testo).toContain("d'tribunale");
    // nessun sostituto Unicode (U+FFFD) → nessun byte decodificato male
    expect(testo.includes('\uFFFD')).toBe(false);
  });

  test('anti CSV-injection: un valore che inizia con "=" o "-" viene neutralizzato', async () => {
    const { a: dip1 } = await h.loginDip1();
    await h.caricaCertificato(dip1, { nome_corso: '=IPERCASO()| -1+1 COMANDO' }).expect(201);

    const { a } = await h.loginAdmin();
    const testo = (await a.get('/api/admin/certificati/export')).text;
    const riga = h.parseCsvRighe(testo.slice(1)).find((x) => x[7] && x[7].length > 5 && /IPERCASO/.test(x[7]));
    expect(riga).toBeDefined();
    expect(riga[7].startsWith("'=")).toBe(true); // prefisso anti-formula
  });

  test('export VUOTO (nessun certificato) → solo header, 200', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.get('/api/admin/certificati/export');
    expect(r.status).toBe(200);
    const righe = h.parseCsvRighe(r.text.slice(1));
    expect(righe).toHaveLength(1);
    expect(righe[0]).toEqual(HEADER_19);
  });
});

describe('Filtri di ricerca: risultati ESATTI', () => {
  test('filtro Area tematica → solo i certificati di quell\'area', async () => {
    const { ids } = await preparaFixture();
    const { a } = await h.loginAdmin();

    const r = await a.get('/api/admin/certificati/export?area=Transizione%20digitale');
    const righe = h.parseCsvRighe(r.text.slice(1)).slice(1);
    expect(righe.map((x) => x[0])).toEqual([String(ids[0])]);
    expect(righe[0][12]).toBe('Transizione digitale');
  });

  test('filtro Dipendente → solo i certificati di quella matricola', async () => {
    const { ids, idqa002 } = await preparaFixture();
    const { a } = await h.loginAdmin();

    const r = await a.get(`/api/admin/certificati/export?dipendenteId=${idqa002}`);
    const righe = h.parseCsvRighe(r.text.slice(1)).slice(1);
    expect(righe.map((x) => x[0])).toEqual([String(ids[2])]);
  });

  test('intervallo di date: estremi INCLUSI (1 marzo e 31 marzo compresi)', async () => {
    const { ids } = await preparaFixture();
    const { a } = await h.loginAdmin();

    const marzo = await a.get('/api/admin/certificati/export?dal=2026-03-01&al=2026-03-31');
    let righe = h.parseCsvRighe(marzo.text.slice(1)).slice(1);
    expect(new Set(righe.map((x) => x[0]))).toEqual(new Set([String(ids[0]), String(ids[1])]));

    // restringendo l'estremo superiore, il certificato del 31 ESCE
    const marzoFino30 = await a.get('/api/admin/certificati/export?dal=2026-03-01&al=2026-03-30');
    righe = h.parseCsvRighe(marzoFino30.text.slice(1)).slice(1);
    expect(righe.map((x) => x[0])).toEqual([String(ids[0])]);
  });

  test('filtri COMBINATI (area + dipendente + date) → intersezione esatta', async () => {
    const { ids, idqa001 } = await preparaFixture();
    const { a } = await h.loginAdmin();

    const r = await a.get(`/api/admin/certificati/export?area=Transizione%20digitale&dipendenteId=${idqa001}&dal=2026-01-01&al=2026-12-31`);
    const righe = h.parseCsvRighe(r.text.slice(1)).slice(1);
    expect(righe.map((x) => x[0])).toEqual([String(ids[0])]);

    // aggiungo il filtro stato: IN_ATTESA combacia ancora
    const conStato = await a.get(`/api/admin/certificati/export?area=Transizione%20digitale&stato=IN_ATTESA`);
    expect(h.parseCsvRighe(conStato.text.slice(1))).toHaveLength(1 + 1);
  });

  test('ricerca a testo libero (q) su matricola/corso → solo corrispondenze esatte', async () => {
    await preparaFixture();
    const { a } = await h.loginAdmin();

    const r = await a.get('/api/admin/certificati/export?q=qa002');
    const righe = h.parseCsvRighe(r.text.slice(1)).slice(1);
    expect(righe).toHaveLength(1);
    expect(righe[0][1]).toBe('qa002');

    // i metacaratteri LIKE sono trattati letteralmente: "100%" non fa match "%"
    const r2 = await a.get('/api/admin/certificati/export?q=Excel%20avanzato;');
    const righe2 = h.parseCsvRighe(r2.text.slice(1)).slice(1);
    expect(righe2).toHaveLength(1);
  });

  test('intervallo senza risultati (dal > al) → file con SOLO header (non un errore)', async () => {
    await preparaFixture();
    const { a } = await h.loginAdmin();
    const r = await a.get('/api/admin/certificati/export?dal=2026-12-31&al=2026-01-01');
    expect(r.status).toBe(200);
    expect(h.parseCsvRighe(r.text.slice(1))).toHaveLength(1);
  });

  /* ---- FIX QA-C2: filtri NON validi ora rispondono 400 invece di ignorarsi ---- */
  test('FIX QA-C2: area tematica inesistente → 400 (prima: tutto l\'archivio senza filtro)', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.get('/api/admin/certificati/export?area=Area%20fantasiosa');
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/area/i);
  });

  test('FIX QA-C2: dipendenteId non numerico, date malformate, stato inventato → 400', async () => {
    const { a } = await h.loginAdmin();
    await a.get('/api/admin/certificati?dipendenteId=abc').expect(400);
    await a.get('/api/admin/certificati?dipendenteId=1%3BDROP').expect(400);
    await a.get('/api/admin/certificati/export?dal=ieri').expect(400);
    await a.get('/api/admin/certificati/export?al=2026-13-99').expect(400);
    await a.get('/api/admin/certificati?stato=INVENTATO').expect(400);
  });

  test('i filtri valgono IDENTICI per la vista paginata e per l\'export', async () => {
    const { ids } = await preparaFixture();
    const { a } = await h.loginAdmin();

    const vista = await a.get('/api/admin/certificati?area=Leadership%20e%20soft%20skills');
    expect(vista.status).toBe(200);
    expect(vista.body.totale).toBe(1);
    expect(vista.body.certificati[0].id).toBe(ids[2]);
    expect(vista.body.certificati[0].matricola).toBe('qa002');
    expect(vista.body.certificati[0].qualifica).toBe('Impiegato');

    const esportato = await a.get('/api/admin/certificati/export?area=Leadership%20e%20soft%20skills');
    const righe = h.parseCsvRighe(esportato.text.slice(1)).slice(1);
    expect(righe.map((x) => x[0])).toEqual([String(ids[2])]);
  });
});

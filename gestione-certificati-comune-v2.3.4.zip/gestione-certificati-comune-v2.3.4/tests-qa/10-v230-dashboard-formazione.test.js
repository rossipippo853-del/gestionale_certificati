/**
 * ============================================================================
 *  10-v230-dashboard-formazione.test.js — ROUND v2.3.0
 * ============================================================================
 *  Cosa verifica (piano di collaudo v2.3.0):
 *   · GET /api/admin/utenti/:id/formazione — dashboard di formazione del
 *     singolo dipendente: contatori per stato (totale/approvati/attesa/
 *     rifiutati), ore approvate in minuti, ore mancanti al TARGET di 40 ore,
 *     percentuale e stato sintetico, ripartizione per area (SOLO APPROVATI);
 *   · soglie dello stato: 0h → SOTTO_SOGLIA, 0<h<40 → IN_CORSO, ≥40 → IN_REGOLA;
 *   · guardie: id non numerico → 400, dipendente inesistente → 404, RBAC
 *     dipendente → 403.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

async function idDi(matricola) {
  const righe = await h.query('SELECT id FROM dipendenti WHERE matricola = ?', [matricola]);
  return righe[0].id;
}

async function caricaEapprova({ area, ore, minuti = '0', stato }) {
  const { a } = await h.loginDip1();
  const up = await h.caricaCertificato(a, { area_tematica: area, numero_ore: ore, numero_minuti: minuti });
  expect(up.status).toBe(201);
  const idCert = up.body.id;
  if (stato) {
    const admin = (await h.loginAdmin()).a;
    const r = await admin.put(`/api/admin/certificati/${idCert}/stato`).send({ stato });
    expect(r.status).toBe(200);
  }
  return idCert;
}

describe('GET /api/admin/utenti/:id/formazione — dashboard per dipendente (v2.3.0)', () => {
  test('contatori per stato + ore approvate + mancanti al target + ripartizione aree', async () => {
    /* 8h approvate (Transizione digitale) + 2h in attesa (Altro: nessuna
     * decisione, i certificati nascono IN_ATTESA) + 4h rifiutata (Risorse umane). */
    await caricaEapprova({ area: 'Transizione digitale', ore: '8', stato: 'APPROVATO' });
    await caricaEapprova({ area: 'Altro', ore: '2' });
    await caricaEapprova({ area: 'Risorse umane', ore: '4', stato: 'RIFIUTATO' });

    const id = await idDi('qa001');
    const { a } = await h.loginAdmin();
    const r = await a.get(`/api/admin/utenti/${id}/formazione`);

    expect(r.status).toBe(200);
    expect(r.body.dipendente).toMatchObject({ matricola: 'qa001', nome: 'Luigi', cognome: 'Verde' });
    expect(r.body.certificati).toEqual({ totale: 3, approvati: 1, inAttesa: 1, rifiutati: 1 });
    expect(r.body.targetMinuti).toBe(2400);
    expect(r.body.oreApprovateMinuti).toBe(480);
    expect(r.body.oreInAttesaMinuti).toBe(120);
    /* [v2.3.1] il target considera APPROVATE + IN ATTESA: 8h+2h = 10h. */
    expect(r.body.oreConteggiateMinuti).toBe(600);
    expect(r.body.oreMancantiMinuti).toBe(1800);          /* 40h − 10h */
    expect(r.body.percentuale).toBe(25);
    expect(r.body.stato).toBe('IN_CORSO');
    /* La rifiutata è ESCLUSA ovunque; l'attesa è visibile per area. */
    expect(r.body.perArea).toEqual([
      { area: 'Transizione digitale', certificati: 1, minuti: 480, minutiAttesa: 0 },
      { area: 'Altro', certificati: 1, minuti: 120, minutiAttesa: 120 },
    ]);
  });

  test('soglia 0 ore → SOTTO_SOGLIA (dipendente senza certificati)', async () => {
    const id = await idDi('qa002');
    const { a } = await h.loginAdmin();
    const r = await a.get(`/api/admin/utenti/${id}/formazione`);
    expect(r.status).toBe(200);
    expect(r.body.certificati).toEqual({ totale: 0, approvati: 0, inAttesa: 0, rifiutati: 0 });
    expect(r.body.oreApprovateMinuti).toBe(0);
    expect(r.body.oreInAttesaMinuti).toBe(0);
    expect(r.body.oreConteggiateMinuti).toBe(0);
    expect(r.body.oreMancantiMinuti).toBe(2400);
    expect(r.body.percentuale).toBe(0);
    expect(r.body.stato).toBe('SOTTO_SOGLIA');
    expect(r.body.perArea).toEqual([]);
  });

  test('raggiunto il target: 40h approvate → IN_REGOLA, mancanti 0, percentuale 100', async () => {
    await caricaEapprova({ area: 'Corsi obbligatori(Salute e sicurezza sul lavoro)', ore: '32', stato: 'APPROVATO' });
    await caricaEapprova({ area: 'Procedimenti amministrativi', ore: '8', minuti: '0', stato: 'APPROVATO' });

    const id = await idDi('qa001');
    const { a } = await h.loginAdmin();
    const r = await a.get(`/api/admin/utenti/${id}/formazione`);
    expect(r.body.oreApprovateMinuti).toBe(2400);
    expect(r.body.oreInAttesaMinuti).toBe(0);
    expect(r.body.oreConteggiateMinuti).toBe(2400);
    expect(r.body.oreMancantiMinuti).toBe(0);
    expect(r.body.percentuale).toBe(100);
    expect(r.body.stato).toBe('IN_REGOLA');
    expect(r.body.perArea).toEqual([
      { area: 'Corsi obbligatori(Salute e sicurezza sul lavoro)', certificati: 1, minuti: 1920, minutiAttesa: 0 },
      { area: 'Procedimenti amministrativi', certificati: 1, minuti: 480, minutiAttesa: 0 },
    ]);
  });

  test('sopra il target: percentuale fermata a 100 e mancanti a 0', async () => {
    await caricaEapprova({ area: 'Ambiente', ore: '45', stato: 'APPROVATO' });
    const id = await idDi('qa001');
    const r = await (await h.loginAdmin()).a.get(`/api/admin/utenti/${id}/formazione`);
    expect(r.body.oreApprovateMinuti).toBe(2700);
    expect(r.body.oreConteggiateMinuti).toBe(2700);
    expect(r.body.oreMancantiMinuti).toBe(0);
    expect(r.body.percentuale).toBe(100);
    expect(r.body.stato).toBe('IN_REGOLA');
  });

  test('guardie: id «abc» → 400, inesistente → 999999 → 404, dipendente → 403', async () => {
    const { a } = await h.loginAdmin();
    expect((await a.get('/api/admin/utenti/abc/formazione')).status).toBe(400);
    expect((await a.get('/api/admin/utenti/999999/formazione')).status).toBe(404);
    expect((await a.get('/api/admin/utenti/999999/formazione')).body.errore)
      .toBe('Dipendente non trovato.');

    const { a: dip } = await h.loginDip1();
    const r = await dip.get('/api/admin/utenti/1/formazione');
    expect(r.status).toBe(403);
  });
});

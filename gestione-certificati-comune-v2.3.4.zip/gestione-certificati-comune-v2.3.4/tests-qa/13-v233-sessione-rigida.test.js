/**
 * ============================================================================
 *  13-v233-sessione-rigida.test.js — ROUND v2.3.3
 * ============================================================================
 *  Cosa verifica (piano di collaudo v2.3.3):
 *   · MODALITÀ RIGIDA: il cookie httpOnly è accettato SOLO sui download
 *     diretti (file certificato, allegato, export CSV); per ogni altra
 *     richiesta serve il token di scheda via header Authorization Bearer.
 *   · Scenario «chiusura scheda»: nuovo agente con SOLO il cookie sopravvissuto
 *     → /api/auth/me → 401 (il controllo automatico della pagina di login NON
 *     fa più il rientro automatico).
 *   · I download continuano a funzionare col solo cookie (link <a href>).
 *   · Logout revoca anche il token inviato via Bearer.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');
const supertest = require('supertest');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

/** Un agente che porta SOLO il cookie indicato (nessun header Bearer). */
function agenteSoloCookie(headerCookie) {
  const a = supertest.agent(h.app);
  const originale = a.get.bind(a);
  a.get = (...argomenti) => originale(...argomenti).set('Cookie', headerCookie);
  return a;
}

describe('[v2.3.3] Modalità rigida: il cookie non basta più per autenticarsi', () => {
  test('chiusura scheda simulata: SOLO cookie su /api/auth/me → 401', async () => {
    const { a, r } = await h.loginDip1();
    expect(r.status).toBe(200);

    /* Il cookie sopravvive alla chiusura della scheda; il sessionStorage no. */
    const headerCookie = (r.headers['set-cookie'] || []).find((c) => c.startsWith('token='));
    expect(headerCookie).toBeTruthy();

    const rientro = await supertest(h.app).get('/api/auth/me').set('Cookie', headerCookie);
    expect(rientro.status).toBe(401);
    expect(rientro.body.errore).toBe('Non autenticato.');
  });

  test('SOLO cookie su endpoint di scrittura → 401 (anche admin)', async () => {
    const { r } = await h.loginAdmin();
    const headerCookie = (r.headers['set-cookie'] || []).find((c) => c.startsWith('token='));
    const rr = await supertest(h.app).put('/api/admin/utenti/999999/stato')
      .set('Cookie', headerCookie).send({ attivo: false });
    expect(rr.status).toBe(401);
  });

  test('Bearer SENZA cookie su endpoint normale → 200 (il token di scheda basta)', async () => {
    const { r } = await h.loginDip1();
    const me = await supertest(h.app).get('/api/auth/me')
      .set('Authorization', `Bearer ${r.body.token}`);
    expect(me.status).toBe(200);
    expect(me.body.utente.matricola).toBe('qa001');
  });

  test('i download funzionano ancora col SOLO cookie (link <a href>)', async () => {
    /* certificato caricato dal dipendente: PDF genuino già pronto nell'helper. */
    const { a } = await h.loginDip1();
    const up = await h.caricaCertificato(a, {});
    expect(up.status).toBe(201);

    const { r } = await h.loginDip1();
    const headerCookie = (r.headers['set-cookie'] || []).find((c) => c.startsWith('token='));

    /* 1) file del certificato, col solo cookie (nessun header). */
    const file = await supertest(h.app).get(`/api/certificati/${up.body.id}/file`)
      .set('Cookie', headerCookie);
    expect(file.status).toBe(200);

    /* 2) export CSV anagrafica, col solo cookie. */
    const { r: ra } = await h.loginAdmin();
    const headerAdmin = (ra.headers['set-cookie'] || []).find((c) => c.startsWith('token='));
    const csv = await supertest(h.app).get('/api/admin/utenti/export')
      .set('Cookie', headerAdmin);
    expect(csv.status).toBe(200);
    expect(csv.headers['content-type']).toMatch(/text\/csv/);
  });

  test('logout revoca il token inviato via Bearer: dopo il logout → 401', async () => {
    const { r } = await h.loginDip1();
    const token = r.body.token;

    const out = await supertest(h.app).post('/api/auth/logout')
      .set('Authorization', `Bearer ${token}`);
    expect(out.status).toBe(200);

    const me = await supertest(h.app).get('/api/auth/me')
      .set('Authorization', `Bearer ${token}`);
    expect(me.status).toBe(401);
    expect(me.body.errore).toMatch(/terminata|scaduta/i);
  });
});

/**
 * ============================================================================
 *  15-v235-impaginazione-certificati.test.js — ROUND v2.3.5
 * ============================================================================
 *  Cosa verifica (piano di collaudo v2.3.5):
 *   · GET /api/certificati (DIPENDENTE):
 *       - senza parametri → elenco COMPLETO (compatibilità storica) + conteggi;
 *       - perPagina=5 → pagine corrette (ordine per caricamento DESC),
 *         totale/pagina/perPagina/pagineTotali coerenti;
 *       - oreTotali e conteggi IDENTICI su ogni pagina (calcolati su TUTTI
 *         i corsi, non sulla pagina — contratto v2.3.1 invariato);
 *       - normalizzazione input (perPagina 999 → 50, 1 → 5, pagina 0 → 1);
 *       - pagina oltre l'ultima → elenco vuoto ma risposta valida;
 *   · GET /api/admin/certificati (ADMIN): pagina+perPagina combinati con i
 *     filtri (stato) e pagineTotali coerente;
 *   · RBAC invariato su entrambi gli endpoint.
 *  Nota: perPagina viene NORMALIZZATO a [5..50] (dipendente) e [5..100]
 *  (admin), stessa difesa difensiva di parametriPagina storico.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

/* Crea «n» certificati per il dipendente qa001 (il più recente è il primo). */
async function caricaNCertificati(n) {
  const { a } = await h.loginDip1();
  for (let i = 0; i < n; i += 1) {
    const up = await h.caricaCertificato(a, { nome_corso: `Corso progressivo ${i + 1}` });
    expect(up.status).toBe(201);
  }
  return a;
}

describe('GET /api/certificati — impaginazione dipendente (v2.3.5)', () => {
  test('senza perPagina → ELENCO COMPLETO (compatibilità storica) + conteggi globali', async () => {
    await caricaNCertificati(3);
    const { a } = await h.loginDip1();

    const r = await a.get('/api/certificati');
    expect(r.status).toBe(200);
    expect(r.body.certificati).toHaveLength(3);
    expect(r.body.pagineTotali).toBe(1);
    expect(r.body.conteggi).toEqual({ TOTALE: 3, APPROVATO: 0, IN_ATTESA: 3, RIFIUTATO: 0 });
    expect(r.body.oreTotali.minuti).toBe(3 * 480); // 3 corsi da 8h (nessun rifiutato)
  });

  test('perPagina=5 → pagina 1 e 2 con le righe giuste e metadati coerenti', async () => {
    await caricaNCertificati(7);
    const { a } = await h.loginDip1();

    const p1 = await a.get('/api/certificati?perPagina=5&pagina=1');
    expect(p1.body.certificati.map((c) => c.nome_corso)).toEqual([
      'Corso progressivo 7', 'Corso progressivo 6', 'Corso progressivo 5',
      'Corso progressivo 4', 'Corso progressivo 3',
    ]);
    expect(p1.body.totale).toBe(7);
    expect(p1.body.perPagina).toBe(5);
    expect(p1.body.pagineTotali).toBe(2);

    const p2 = await a.get('/api/certificati?perPagina=5&pagina=2');
    expect(p2.body.certificati.map((c) => c.nome_corso)).toEqual(['Corso progressivo 2', 'Corso progressivo 1']);
    expect(p2.body.pagina).toBe(2);
  });

  test('oreTotali e conteggi sono GLOBALI e identici su ogni pagina', async () => {
    await caricaNCertificati(7);
    const { a: dip } = await h.loginDip1();
    const { a: adm } = await h.loginAdmin();
    // il più recente viene APPROVATO, il più vecchio RIFIUTATO (stati misti)
    const elenco = await dip.get('/api/certificati');
    const ids = elenco.body.certificati.map((c) => c.id);
    await adm.put(`/api/admin/certificati/${ids[0]}/stato`).send({ stato: 'APPROVATO' });
    await adm.put(`/api/admin/certificati/${ids[6]}/stato`).send({ stato: 'RIFIUTATO', note: 'Non valido' });

    const p1 = await dip.get('/api/certificati?perPagina=5&pagina=1');
    const p2 = await dip.get('/api/certificati?perPagina=5&pagina=2');
    expect(p1.body.conteggi).toEqual({ TOTALE: 7, APPROVATO: 1, IN_ATTESA: 5, RIFIUTATO: 1 });
    expect(p2.body.conteggi).toEqual(p1.body.conteggi);
    // ore globali: 1 approvato + 5 in attesa = 6 × 480 (il RIFIUTATO NON conta, v2.3.1)
    expect(p1.body.oreTotali.minuti).toBe(6 * 480);
    expect(p2.body.oreTotali.minuti).toBe(6 * 480);
  });

  test('normalizzazione degli input: perPagina 999→50, 1→5, pagina 0→1', async () => {
    const { a } = await h.loginDip1();

    const max = await a.get('/api/certificati?perPagina=999');
    expect(max.body.perPagina).toBe(50);
    const min = await a.get('/api/certificati?perPagina=1');
    expect(min.body.perPagina).toBe(5);
    const pag = await a.get('/api/certificati?perPagina=5&pagina=0');
    expect(pag.body.pagina).toBe(1);
    const spazzatura = await a.get('/api/certificati?perPagina=abc&pagina=xyz');
    expect(spazzatura.body.perPagina).toBe(10); // default
    expect(spazzatura.body.pagina).toBe(1);
  });

  test('pagina oltre l\'ultima → lista vuota e risposta valida', async () => {
    await caricaNCertificati(2);
    const { a } = await h.loginDip1();
    const r = await a.get('/api/certificati?perPagina=10&pagina=7');
    expect(r.status).toBe(200);
    expect(r.body.certificati).toEqual([]);
    expect(r.body.totale).toBe(2);
    expect(r.body.pagineTotali).toBe(1);
  });
});

describe('GET /api/admin/certificati — impaginazione+filtri (v2.3.5)', () => {
  test('perPagina=5 su 8 corsi: 2 pagine; filtro stato combinato coerente', async () => {
    await caricaNCertificati(8);
    const { a: dip } = await h.loginDip1();
    const { a: adm } = await h.loginAdmin();
    const elenco = await dip.get('/api/certificati');
    await adm.put(`/api/admin/certificati/${elenco.body.certificati[0].id}/stato`).send({ stato: 'APPROVATO' });
    await adm.put(`/api/admin/certificati/${elenco.body.certificati[1].id}/stato`).send({ stato: 'APPROVATO' });

    const tutti = await adm.get('/api/admin/certificati?perPagina=5&pagina=2');
    expect(tutti.status).toBe(200);
    expect(tutti.body.totale).toBe(8);
    expect(tutti.body.pagineTotali).toBe(2);
    expect(tutti.body.certificati).toHaveLength(3); // 8 - 5 = 3 in seconda pagina

    const attesa = await adm.get('/api/admin/certificati?perPagina=5&pagina=1&stato=IN_ATTESA');
    expect(attesa.body.totale).toBe(6);
    expect(attesa.body.pagineTotali).toBe(2);
    expect(attesa.body.certificati).toHaveLength(5);
    expect(attesa.body.certificati.every((c) => c.stato === 'IN_ATTESA')).toBe(true);
  });
});

describe('RBAC invariato (v2.3.5)', () => {
  test('token assente → 401 su entrambi gli endpoint', async () => {
    expect((await h.agente().get('/api/certificati')).status).toBe(401);
    expect((await h.agente().get('/api/admin/certificati?perPagina=10')).status).toBe(401);
  });
});

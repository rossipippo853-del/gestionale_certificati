/**
 * ============================================================================
 *  05-crud-admin.test.js — FASE 2: GESTIONE UTENTI (CRUD admin) + WIRING UI
 * ============================================================================
 *  Cosa verifica (piano di collaudo §2):
 *   · creazione utente singolo: 201, hash bcrypt, cartella, must_change=1,
 *     password provvisoria mostrata UNA sola volta;
 *   · duplicato → 409 senza bloccare l'interfaccia (l'errore è mostrato);
 *   · validazioni (sesso/qualifica obbligatori, password debole) → 400;
 *   · reset password: nuova provvisoria, login, cambio obbligatorio;
 *   · abilita/disabilita: boolean rigoroso, anti auto-lockout, 404 su id assente;
 *   · WIRING frontend: i gestori di admin.html/admin.js chiudono il modale e
 *     ricaricano la tabella SOLO su successo, mostrano l'errore in caso contrario.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');
const fs = require('node:fs');
const path = require('node:path');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

const UTENTE = {
  matricola: 'nu001', codice_fiscale: 'NVNNNO88A01H501D', nome: 'Nino', cognome: 'Nuovo', sesso: 'M',
  qualifica: 'Istruttore direttivo', email: 'nino.nuovo@comune.it',
  ruolo: 'DIPENDENTE', password: 'Provvisoria1',
};

describe('POST /api/admin/utenti — creazione utente singolo', () => {
  test('creazione completa → 201, hash bcrypt, cartella creata, cambio pwd obbligatorio', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.post('/api/admin/utenti').send(UTENTE);
    expect(r.status).toBe(201);
    // La password fornita dall'admin NON viene restituita (già la conosce):
    // il campo compare solo quando è il SERVER a generarla.
    expect(r.body.passwordProvvisoria).toBeUndefined();

    const u = (await h.query('SELECT * FROM dipendenti WHERE matricola = ?', ['nu001']))[0];
    expect(u.nome).toBe('Nino');
    expect(u.sesso).toBe('M');
    expect(u.qualifica).toBe('Istruttore direttivo');
    expect(u.password_hash.startsWith('$2')).toBe(true);
    expect(u.password_hash).not.toContain('Provvisoria1');
    expect(u.must_change_password).toBe(1);
    expect(u.codice_fiscale).toBe('NVNNNO88A01H501D');
    // v2.0: la cartella è nominata col CODICE FISCALE (non la matricola)
    expect(h.fileSuDisco('NVNNNO88A01H501D')).toEqual([]);
    expect(h.fileSuDisco('nu001')).toBeNull();

    // il primo login con la provvisoria NON apre la sessione (v2.1): il
    // backend impone la modale di cambio obbligatorio sulla pagina di login
    const { r: rLogin } = await h.login('nu001', 'Provvisoria1');
    expect(rLogin.status).toBe(200);
    expect(rLogin.body.primoAccesso).toBe(true);

    // il cambio in modale porta dritti in dashboard (nuova sessione emessa)
    const { a: agenteNuovo } = await h.login('nu001', 'Provvisoria1');
    const fine = await agenteNuovo.post('/api/auth/primo-accesso')
      .send({ nuovaPassword: 'Definitiva2026', confermaPassword: 'Definitiva2026' });
    expect(fine.status).toBe(200);
    expect(fine.body.utente.mustChangePassword).toBe(false);
    /* [v2.3.3] sessione di scheda: /me col Bearer del token appena emesso. */
    await agenteNuovo.get('/api/auth/me')
      .set('Authorization', `Bearer ${fine.body.token}`).expect(200);
  });

  test('password NON fornita → il server ne genera una robusta e la restituisce', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.post('/api/admin/utenti').send({ ...UTENTE, matricola: 'nu002', password: '' });
    expect(r.status).toBe(201);
    const generata = r.body.passwordProvvisoria;
    expect(generata).toMatch(/^[A-Za-z0-9@#$%!?]{8,72}$/);
    expect(generata).toMatch(/[A-Za-z]/);
    expect(generata).toMatch(/\d/);
  });

  test('matricola duplicata → 409, l\'utente originale resta intatto', async () => {
    const { a } = await h.loginAdmin();
    await a.post('/api/admin/utenti').send(UTENTE).expect(201);
    const r = await a.post('/api/admin/utenti').send({ ...UTENTE, nome: 'Altro' });
    expect(r.status).toBe(409);
    expect(r.body.errore).toMatch(/già esistente/i);
    const n = await h.query("SELECT COUNT(*) AS n FROM dipendenti WHERE matricola = 'nu001'");
    expect(n[0].n).toBe(1);
  });

  test('sesso o qualifica mancanti → 400 (obbligatori in v1.4)', async () => {
    const { a } = await h.loginAdmin();
    const r1 = await a.post('/api/admin/utenti').send({ ...UTENTE, matricola: 'nu003', sesso: undefined });
    expect(r1.status).toBe(400);
    expect(r1.body.errore).toMatch(/sesso/i);

    const r2 = await a.post('/api/admin/utenti').send({ ...UTENTE, matricola: 'nu004', qualifica: '' });
    expect(r2.status).toBe(400);
    expect(r2.body.errore).toMatch(/qualifica/i);
  });

  test('[v2.0] CF mancante o malformato → 400 con messaggio dedicato', async () => {
    const { a } = await h.loginAdmin();
    const r1 = await a.post('/api/admin/utenti').send({ ...UTENTE, matricola: 'nu005', codice_fiscale: undefined });
    expect(r1.status).toBe(400);
    expect(r1.body.errore).toMatch(/Codice Fiscale/i);

    const r2 = await a.post('/api/admin/utenti').send({ ...UTENTE, matricola: 'nu006', codice_fiscale: 'RSSMRA80A01H501' }); // 15 caratteri
    expect(r2.status).toBe(400);
    expect(r2.body.errore).toMatch(/Codice Fiscale non valido/i);

    const r3 = await a.post('/api/admin/utenti').send({ ...UTENTE, matricola: 'nu007', codice_fiscale: '12345678A01H501U' }); // cifre al posto delle lettere
    expect(r3.status).toBe(400);
  });

  test('[v2.0] CF duplicato (altro dipendente) → 409 con messaggio dedicato, cartella non creata', async () => {
    const { a } = await h.loginAdmin();
    // il CF di qa001 esiste già a DB
    const r = await a.post('/api/admin/utenti').send({ ...UTENTE, matricola: 'nu008', codice_fiscale: h.DIP1.codice_fiscale });
    expect(r.status).toBe(409);
    expect(r.body.errore).toMatch(/Codice Fiscale già registrato/i);
    expect(h.fileSuDisco(h.DIP1.codice_fiscale)).toBeNull(); // nessuna cartella nueva per la richiesta rifiutata
    const n = await h.query("SELECT COUNT(*) AS n FROM dipendenti WHERE matricola = 'nu008'");
    expect(n[0].n).toBe(0);
  });

  test('password debole fornita dall\'admin → 400 con policy esplicita', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.post('/api/admin/utenti').send({ ...UTENTE, password: 'corta' });
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/almeno 8 caratteri/i);
  });
});

describe('PUT /api/admin/utenti/:id/password — reset credenziali', () => {
  test('reset → login con la nuova password, cambio obbligatorio, la VECCHIA non funziona più', async () => {
    const id = (await h.query('SELECT id FROM dipendenti WHERE matricola = ?', ['qa001']))[0].id;
    const { a } = await h.loginAdmin();
    const r = await a.put(`/api/admin/utenti/${id}/password`).send({ nuovaPassword: 'ResetForte2026' });
    expect(r.status).toBe(200);
    expect(r.body.passwordProvvisoria).toBe('ResetForte2026');

    await h.login('qa001', 'DipQa2026').then(({ r: vecchia }) => expect(vecchia.status).toBe(401));
    const { a: agenteQa1, r: nuova } = await h.login('qa001', 'ResetForte2026');
    expect(nuova.status).toBe(200);
    // [v2.1] il login con la provvisoria impone la modale: NESSUNA sessione…
    expect(nuova.body.primoAccesso).toBe(true);
    await agenteQa1.get('/api/auth/me').expect(401);
    // …che si completa col cambio: qa001 torna ad avere la sua password nota
    const fine = await agenteQa1.post('/api/auth/primo-accesso')
      .send({ nuovaPassword: 'DipQa2026', confermaPassword: 'DipQa2026' });
    expect(fine.status).toBe(200);
    expect(fine.body.utente.mustChangePassword).toBe(false);
    /* [v2.3.3] sessione di scheda: /me col Bearer del token appena emesso. */
    await agenteQa1.get('/api/auth/me')
      .set('Authorization', `Bearer ${fine.body.token}`).expect(200);
  });

  test('reset senza password → generata automaticamente (formato robusto)', async () => {
    const id = (await h.query('SELECT id FROM dipendenti WHERE matricola = ?', ['qa002']))[0].id;
    const { a } = await h.loginAdmin();
    const r = await a.put(`/api/admin/utenti/${id}/password`).send({ nuovaPassword: '' });
    expect(r.status).toBe(200);
    expect(r.body.passwordProvvisoria).toMatch(/^(?=.*[A-Za-z])(?=.*\d).{8,}$/);
  });

  test('reset di un utente inesistente → 404', async () => {
    const { a } = await h.loginAdmin();
    await a.put('/api/admin/utenti/999999/password').send({ nuovaPassword: 'ResetForte2026' }).expect(404);
  });
});

describe('PUT /api/admin/utenti/:id/stato — abilita/disabilita', () => {
  test('disabilita → 200, login 403, riabilita → login OK (l\'interfaccia non resta bloccata)', async () => {
    const id = (await h.query('SELECT id FROM dipendenti WHERE matricola = ?', ['qa002']))[0].id;
    const { a } = await h.loginAdmin();

    await a.put(`/api/admin/utenti/${id}/stato`).send({ attivo: false }).expect(200);
    const { r: spento } = await h.login('qa002', 'DipQa2026');
    expect(spento.status).toBe(403);

    await a.put(`/api/admin/utenti/${id}/stato`).send({ attivo: true }).expect(200);
    const { r: acceso } = await h.login('qa002', 'DipQa2026');
    expect(acceso.status).toBe(200);
  });

  test('attivo NON booleano (stringa "false") → 400 (contratto rigoroso)', async () => {
    const id = (await h.query('SELECT id FROM dipendenti WHERE matricola = ?', ['qa002']))[0].id;
    const { a } = await h.loginAdmin();
    const r = await a.put(`/api/admin/utenti/${id}/stato`).send({ attivo: 'false' });
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/true\/false/i);
  });

  test('l\'admin NON può disabilitare se stesso (anti lock-out) → 400', async () => {
    const idAdmin = (await h.query("SELECT id FROM dipendenti WHERE matricola = 'qa000'"))[0].id;
    const { a } = await h.loginAdmin();
    const r = await a.put(`/api/admin/utenti/${idAdmin}/stato`).send({ attivo: false });
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/non puoi disabilitare/i);
  });

  test('id inesistente → 404', async () => {
    const { a } = await h.loginAdmin();
    await a.put('/api/admin/utenti/424242/stato').send({ attivo: false }).expect(404);
  });
});

describe('WIRING frontend admin (modale si chiude, tabella si aggiorna)', () => {
  const js = fs.readFileSync(path.resolve(__dirname, '..', 'public', 'js', 'admin.js'), 'utf8');
  const html = fs.readFileSync(path.resolve(__dirname, '..', 'public', 'admin.html'), 'utf8');

  test('salvaNuovoUtente: su successo chiude il modale, mostra toast e ricarica tabella+statistiche', () => {
    const corpo = js.slice(js.indexOf('async function salvaNuovoUtente'), js.indexOf('async function eseguiResetPassword'));
    expect(corpo).toContain("chiudi('dlg-nuovo-utente')");
    expect(corpo).toContain('caricaDipendenti()');
    expect(corpo).toContain('caricaStatistiche()');
    expect(corpo.indexOf('chiudi')).toBeLessThan(corpo.indexOf('caricaDipendenti')); // prima chiude, poi ricarica
    expect(corpo).toMatch(/passwordProvvisoria/); // unica occasione per la credenziale
    expect(corpo).toContain('nu-codice-fiscale');  // v2.0: il form invia il CF
  });

  test('salvaNuovoUtente: su ERRORE il modale resta APERTO e il messaggio è nel dialog', () => {
    const corpo = js.slice(js.indexOf('async function salvaNuovoUtente'), js.indexOf('async function eseguiResetPassword'));
    const parteCatch = corpo.slice(corpo.indexOf('} catch'));
    expect(parteCatch).not.toContain('chiudi(');                 // il dialog NON si chiude
    expect(parteCatch).toContain('erroreEl.textContent');        // l'errore appare nel modale
    expect(corpo).toContain("getElementById('nu-errore')");      // ed è il blocco del dialog
  });

  test('eseguiResetPassword: chiude il dialog e ricarica la tabella (nessun blocco UI)', () => {
    const corpo = js.slice(js.indexOf('async function eseguiResetPassword'), js.indexOf('function mostraCredenziale'));
    expect(corpo).toContain("chiudi('dlg-reset-password')");
    expect(corpo).toContain('caricaDipendenti()');
  });

  test('cambio stato (abilita/disabilita): dopo il PUT la tabella viene ricaricata', () => {
    const inizio = js.indexOf("btn.dataset.azione === 'disabilita'");
    const fine = js.indexOf('caricaStatistiche()', js.indexOf("btn.dataset.azione === 'abilita'"));
    const corpo = js.slice(inizio, fine);
    expect(corpo).toContain('/stato');
    expect(corpo.split('/stato').length - 1).toBeGreaterThanOrEqual(2); // branch disabilita + abilita
    expect(corpo).toContain('caricaDipendenti()'); // refresh senza blocchi in entrambi i rami
  });

  test('admin.html: il modale nuovo utente contiene i campi v1.4 (sesso con ALTRO, qualifica)', () => {
    for (const id of ['dlg-nuovo-utente', 'form-nuovo-utente', 'nu-matricola', 'nu-codice-fiscale', 'nu-sesso', 'nu-qualifica', 'nu-ruolo', 'nu-password']) {
      expect(html).toContain(`id="${id}"`);
    }
    const blocco = html.slice(html.indexOf('id="nu-sesso"') - 200, html.indexOf('id="nu-sesso"') + 400);
    expect(blocco).toContain('ALTRO');
  });

  test('CSP friendly: nessun gestore inline (onclick=…) e nessuno script inline in admin.html', () => {
    expect(html).not.toMatch(/\son\w+\s*=/i); // attributi on* vietati da script-src 'self'
    expect(html).not.toMatch(/<script(?![^>]*\bsrc=)[^>]*>[^<]/i);
  });
});

describe('[v2.2.8] PUT /api/admin/utenti/:id — modifica anagrafica e dati lavorativi', () => {
  const idDi = async (matricola) =>
    (await h.query('SELECT id FROM dipendenti WHERE matricola = ?', [matricola]))[0].id;

  const payloadValido = {
    matricola: 'qa001', codice_fiscale: 'VRDLGU80M01H501B',
    nome: 'Luigi', cognome: 'Verde', sesso: 'M',
    qualifica: 'Impiegato', email: 'luigi.verde@comune.test',
  };

  test('modifica completa → 200, DB aggiornato; ruolo/stato/password intatti', async () => {
    const { a } = await h.loginAdmin();
    const id = await idDi('qa001');
    const r = await a.put(`/api/admin/utenti/${id}`).send({
      ...payloadValido, nome: 'Luigia', qualifica: 'Istruttore direttivo',
    });
    expect(r.status).toBe(200);

    const riga = (await h.query('SELECT * FROM dipendenti WHERE id = ?', [id]))[0];
    expect(riga.nome).toBe('Luigia');
    expect(riga.qualifica).toBe('Istruttore direttivo');
    expect(riga.email).toBe('luigi.verde@comune.test');
    expect(riga.ruolo).toBe('DIPENDENTE');        // non modificabile da qui
    expect(riga.attivo).toBe(1);
    expect(riga.must_change_password).toBe(0);
  });

  test('ri-salvataggio dei propri dati (nessun cambio) → 200, nessun aut-conflitto', async () => {
    const { a } = await h.loginAdmin();
    const id = await idDi('qa001');
    expect((await a.put(`/api/admin/utenti/${id}`).send(payloadValido)).status).toBe(200);
  });

  test('matricola o CF di un ALTRO dipendente → 409 con messaggio dedicato', async () => {
    const { a } = await h.loginAdmin();
    const id = await idDi('qa001');
    expect((await a.put(`/api/admin/utenti/${id}`).send({ ...payloadValido, matricola: 'qa002' })).status).toBe(409);
    expect((await a.put(`/api/admin/utenti/${id}`).send({ ...payloadValido, codice_fiscale: 'GLLANN85C15G822C' })).status).toBe(409);
  });

  test('email duplicata su altro account → 409 (unicità applicativa)', async () => {
    const { a } = await h.loginAdmin();
    const id2 = await idDi('qa002');
    expect((await a.put(`/api/admin/utenti/${id2}`).send({
      matricola: 'qa002', codice_fiscale: 'GLLANN85C15G822C', nome: 'Anna', cognome: 'Gialli',
      sesso: 'F', qualifica: 'Impiegato', email: 'anna.gialli@comune.test',
    })).status).toBe(200);
    const id1 = await idDi('qa001');
    const r = await a.put(`/api/admin/utenti/${id1}`).send({ ...payloadValido, email: 'anna.gialli@comune.test' });
    expect(r.status).toBe(409);
    expect(r.body.errore).toMatch(/Email gi/);
  });

  test('dati non validi → 400 (CF, email, matricola corta, sesso, nome vuoto)', async () => {
    const { a } = await h.loginAdmin();
    const id = await idDi('qa001');
    expect((await a.put(`/api/admin/utenti/${id}`).send({ ...payloadValido, codice_fiscale: 'RSSMRA80A01H' })).status).toBe(400);
    expect((await a.put(`/api/admin/utenti/${id}`).send({ ...payloadValido, email: 'pippo@' })).status).toBe(400);
    /* [v2.3.1] da 2 caratteri la matricola è valida: il 400 è con 1 carattere. */
    expect((await a.put(`/api/admin/utenti/${id}`).send({ ...payloadValido, matricola: 'a' })).status).toBe(400);
    expect((await a.put(`/api/admin/utenti/${id}`).send({ ...payloadValido, sesso: 'X' })).status).toBe(400);
    expect((await a.put(`/api/admin/utenti/${id}`).send({ ...payloadValido, nome: '' })).status).toBe(400);
  });

  test('email vuota → salvata a NULL; id inesistente → 404; id non cifre → 400', async () => {
    const { a } = await h.loginAdmin();
    const id = await idDi('qa001');
    await a.put(`/api/admin/utenti/${id}`).send({ ...payloadValido, email: '' });
    expect((await h.query('SELECT email FROM dipendenti WHERE id = ?', [id]))[0].email).toBeNull();

    expect((await a.put('/api/admin/utenti/999999').send(payloadValido)).status).toBe(404);
    expect((await a.put('/api/admin/utenti/5abc').send(payloadValido)).status).toBe(400);
    expect((await a.put('/api/admin/utenti/1;DROP').send(payloadValido)).status).toBe(400);
  });

  test('RBAC: il dipendente NON può modificare (403); senza sessione → 401', async () => {
    const { a: dip } = await h.loginDip1();
    const id = await idDi('qa002');
    expect((await dip.put(`/api/admin/utenti/${id}`).send(payloadValido)).status).toBe(403);

    const request = require('supertest');
    expect((await request(h.app).put(`/api/admin/utenti/${id}`).send(payloadValido)).status).toBe(401);
  });

  test('cambio MATRICOLA: la vecchia non accede più, la nuova sì (stessa password)', async () => {
    const { a } = await h.loginAdmin();
    const id = await idDi('qa001');
    expect((await a.put(`/api/admin/utenti/${id}`).send({ ...payloadValido, matricola: 'qa001bis' })).status).toBe(200);

    const { r: vecchia } = await h.login('qa001', 'DipQa2026');
    expect(vecchia.status).toBe(401);
    const { r: nuova } = await h.login('qa001bis', 'DipQa2026');
    expect(nuova.status).toBe(200);
  });
});


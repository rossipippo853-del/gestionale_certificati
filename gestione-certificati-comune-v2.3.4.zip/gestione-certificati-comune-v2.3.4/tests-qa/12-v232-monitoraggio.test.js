/**
 * ============================================================================
 *  12-v232-monitoraggio.test.js — ROUND v2.3.2 — Tab «Monitoraggio»
 * ============================================================================
 *  Cosa verifica (piano di collaudo v2.3.2):
 *   · GET /api/admin/monitoraggio — analytics aggregate della tab:
 *       - Target 40h: persone raggiunte considerando TUTTI i certificati
 *         caricati (approvati + IN ATTESA; rifiuti esclusi);
 *       - aree tematiche: distribuzione di TUTTI i certificati caricati;
 *       - KPI: media ore conteggiate per dipendente, totale in attesa, top 3 aree.
 *   · RBAC: 403 per i dipendenti.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

async function carica({ area, ore, stato }) {
  const { a } = await h.loginDip1();
  const up = await h.caricaCertificato(a, { area_tematica: area, numero_ore: ore, numero_minuti: '0' });
  expect(up.status).toBe(201);
  if (stato) {
    const admin = (await h.loginAdmin()).a;
    const r = await admin.put(`/api/admin/certificati/${up.body.id}/stato`).send({ stato });
    expect(r.status).toBe(200);
  }
}

describe('GET /api/admin/monitoraggio — analytics aggregate (v2.3.2)', () => {
  test('target 40h CON le ore in attesa; aree su tutti i caricamenti; KPI', async () => {
    /* qa001: 30h approvate + 12h IN ATTESA = 42h conteggiate → TARGET RAGGIUNTO. */
    await carica({ area: 'Risorse umane', ore: '30', stato: 'APPROVATO' });
    await carica({ area: 'Ambiente', ore: '12' });

    const { a } = await h.loginAdmin();
    const r = await a.get('/api/admin/monitoraggio');

    expect(r.status).toBe(200);
    /* 3 account (admin + 2 dipendenti): solo qa001 ha ≥ 40h conteggiate. */
    expect(r.body.target).toEqual({ totaleDipendenti: 3, raggiunti: 1, nonRaggiunti: 2, percentuale: 33 });
    /* media = round(2520 / 3) = 840 minuti = 14:00. */
    expect(r.body.mediaOreMinuti).toBe(840);
    expect(r.body.certificatiInAttesa).toBe(1);
    /* Aree: TUTTI i caricamenti (ordine: certificati DESC, area ASC). */
    expect(r.body.aree).toEqual([
      { area: 'Ambiente', certificati: 1 },
      { area: 'Risorse umane', certificati: 1 },
    ]);
    expect(r.body.topAree).toEqual([
      { area: 'Ambiente', certificati: 1 },
      { area: 'Risorse umane', certificati: 1 },
    ]);
  });

  test('un rifiuto NON conta nel target (le ore restano fuori)', async () => {
    await carica({ area: 'Ambiente', ore: '45', stato: 'RIFIUTATO' });
    await carica({ area: 'Altro', ore: '5', stato: 'APPROVATO' });

    const { a } = await h.loginAdmin();
    const r = await a.get('/api/admin/monitoraggio');
    expect(r.body.target.raggiunti).toBe(0);           /* 5h < 40h */
    expect(r.body.mediaOreMinuti).toBe(Math.round(300 / 3));
    expect(r.body.aree).toEqual([
      { area: 'Altro', certificati: 1 },
      { area: 'Ambiente', certificati: 1 },             /* il rifiuto è comunque un caricamento */
    ]);
    expect(r.body.certificatiInAttesa).toBe(0);
  });

  test('nessun dato: zero tutto, nessuna divisione per zero', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.get('/api/admin/monitoraggio');
    expect(r.body.target).toEqual({ totaleDipendenti: 3, raggiunti: 0, nonRaggiunti: 3, percentuale: 0 });
    expect(r.body.mediaOreMinuti).toBe(0);
    expect(r.body.certificatiInAttesa).toBe(0);
    expect(r.body.aree).toEqual([]);
    expect(r.body.topAree).toEqual([]);
  });

  test('RBAC: la tab non espone dati ai dipendenti (403)', async () => {
    const { a } = await h.loginDip1();
    expect((await a.get('/api/admin/monitoraggio')).status).toBe(403);
  });
});

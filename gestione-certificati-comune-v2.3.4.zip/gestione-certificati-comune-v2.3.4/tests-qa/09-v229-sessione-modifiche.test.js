/**
 * ============================================================================
 *  09-v229-sessione-modifiche.test.js — ROUND v2.2.9 «Città di Milazzo»
 * ============================================================================
 *  Cosa verifica (piano di collaudo v2.2.9):
 *   · PUT /api/admin/certificati/:id — modifica METADATI (titolo, ente, data,
 *     durata hh:mm, esame, area) con PERSISTENZA su DB; stato e allegati
 *     intatti; guardie 400/404; RBAC (dipendente → 403);
 *   · audit log: la modifica e le decisioni lasciano traccia (GET /audit) e
 *     sono precluse ai dipendenti;
 *   · dashboard analytics: GET /stats espone orePerArea (solo APPROVATI);
 *   · filtro dinamico dipendenti: GET /utenti/options fornisce nome, cognome,
 *     matricola e CF (alimenti della ricerca autocompletante lato client);
 *   · impaginazione SERVER-SIDE degli utenti: perPagina 10/25/50 con COUNT e
 *     pagineTotali coerenti;
 *   · cookie di SESSIONE: «token» SENZA Max-Age/Expires (muore con il
 *     browser), «token_cambio» conserva Max-Age 900000 (15 minuti);
 *   · «Esporta Anagrafica CSV»: BOM, CRLF, separatore ';', intestazione e
 *     colonna Stato Attivo/Disabilitato; RBAC.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

/* Payload di modifica: tutti i campi del dialog «Modifica certificato». */
const MODIFICA = {
  nome_corso: 'Corso rettificato QA',
  ente_erogatore: 'Ente di formazione rettificato',
  data_conseguimento: '2026-04-02',
  numero_ore: '7',
  numero_minuti: '45',
  esame_finale: '0',
  area_tematica: 'Procedimenti amministrativi',
};

async function preparaCertificato() {
  const { a } = await h.loginDip1();
  const up = await h.caricaCertificato(a, { area_tematica: 'Transizione digitale' });
  expect(up.status).toBe(201);
  return up.body.id;
}

describe('PUT /api/admin/certificati/:id — modifica metadati (v2.2.9)', () => {
  test('modifica completa → 200 e PERSISTENZA di tutti i 7 campi', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginAdmin();

    const r = await a.put(`/api/admin/certificati/${id}`).send(MODIFICA);
    expect(r.status).toBe(200);
    expect(r.body).toEqual({ ok: true, messaggio: 'Certificato aggiornato.' });

    const c = (await h.query('SELECT * FROM certificati WHERE id = ?', [id]))[0];
    expect(c.nome_corso).toBe('Corso rettificato QA');
    expect(c.ente_erogatore).toBe('Ente di formazione rettificato');
    expect(c.data_conseguimento).toBe('2026-04-02');
    expect(c.numero_ore).toBe(7);
    expect(c.numero_minuti).toBe(45);
    expect(c.esame_finale).toBe(0);
    expect(c.area_tematica).toBe('Procedimenti amministrativi');
  });

  test('stato e allegati NON toccati: IN_ATTESA resta e il download funziona', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginAdmin();

    await a.put(`/api/admin/certificati/${id}`).send(MODIFICA);
    const c = (await h.query('SELECT stato FROM certificati WHERE id = ?', [id]))[0];
    expect(c.stato).toBe('IN_ATTESA');

    const allegati = await h.query('SELECT id FROM allegati WHERE certificato_id = ?', [id]);
    expect(allegati.length).toBe(1);
    /* Il documento resta scaricabile dal TITOLARE (l'endpoint dipendente è
     * riservato al proprietario): la modifica admin non tocca i file. */
    const { a: proprietario } = await h.loginDip1();
    const dl = await proprietario.get(`/api/certificati/allegati/${allegati[0].id}/file`);
    expect(dl.status).toBe(200);
  });

  test('guardie: id non numerico → 400, inesistente → 404, dati invalidi → 400', async () => {
    const { a } = await h.loginAdmin();
    expect((await a.put('/api/admin/certificati/abc').send(MODIFICA)).status).toBe(400);
    expect((await a.put('/api/admin/certificati/999999').send(MODIFICA)).status).toBe(404);

    const id = await preparaCertificato();
    const cattivo = await a.put(`/api/admin/certificati/${id}`)
      .send({ ...MODIFICA, numero_ore: 'moltissime' });
    expect(cattivo.status).toBe(400);
    expect(cattivo.body.errore).toMatch(/ore/i);
  });

  test('RBAC: un dipendente NON può modificare certificati (403)', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginDip2();
    const r = await a.put(`/api/admin/certificati/${id}`).send(MODIFICA);
    expect(r.status).toBe(403);
    expect(r.body.errore).toMatch(/amministratori/i);
  });
});

describe('Audit log + analytics (v2.2.9)', () => {
  test('MODIFICA_TITOLO_CORSO registrata con autore e dettagli prima→dopo [v2.3.4]', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginAdmin();
    await a.put(`/api/admin/certificati/${id}`).send(MODIFICA);

    const r = await a.get('/api/admin/audit');
    expect(r.status).toBe(200);
    const riga = r.body.righe.find((x) => x.azione === 'MODIFICA_TITOLO_CORSO' && x.certificato_id === id);
    expect(riga).toBeTruthy();
    expect(riga.admin_matricola).toBe('qa000');
    expect(riga.dettagli).toBe('«Corso di collaudo QA» → «Corso rettificato QA»');
  });

  test('approvazione e rifiuto lasciano traccia con azione SPECIFICA [v2.3.4]', async () => {
    const id = await preparaCertificato();
    const { a } = await h.loginAdmin();
    await a.put(`/api/admin/certificati/${id}/stato`).send({ stato: 'APPROVATO' });

    const r = await a.get('/api/admin/audit');
    const riga = r.body.righe.find((x) => x.azione === 'APPROVAZIONE_CERTIFICATO' && x.certificato_id === id);
    expect(riga).toBeTruthy();
    expect(riga.dettagli).toContain('Stato: IN_ATTESA → APPROVATO');
  });

  test('GET /audit riservato agli admin (dipendente → 403)', async () => {
    const { a } = await h.loginDip1();
    expect((await a.get('/api/admin/audit')).status).toBe(403);
  });

  test('GET /stats espone orePerArea con SOLO i corsi APPROVATI', async () => {
    const id = await preparaCertificato(); // 8 ore = 480 minuti, area «Transizione digitale»
    const { a } = await h.loginAdmin();

    let r = await a.get('/api/admin/stats');
    expect(r.status).toBe(200);
    expect(r.body.orePerArea.find((x) => x.area === 'Transizione digitale')).toBeUndefined();

    await a.put(`/api/admin/certificati/${id}/stato`).send({ stato: 'APPROVATO' });
    r = await a.get('/api/admin/stats');
    const voce = r.body.orePerArea.find((x) => x.area === 'Transizione digitale');
    expect(voce).toEqual({ area: 'Transizione digitale', minuti: 480, corsi: 1 });
    expect(Number.isFinite(voce.minuti)).toBe(true);
  });
});

describe('Filtro dinamico dipendenti — GET /utenti/options (v2.2.9)', () => {
  test('espone id, nome, cognome, matricola e CF per la ricerca autocompletante', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.get('/api/admin/utenti/options');
    expect(r.status).toBe(200);
    expect(r.body.opzioni.length).toBeGreaterThanOrEqual(2);

    const qa1 = r.body.opzioni.find((o) => o.matricola === 'qa001');
    expect(qa1).toMatchObject({ id: expect.any(Number), nome: 'Luigi', cognome: 'Verde', codice_fiscale: 'VRDLGU80M01H501B' });
  });

  test('il filtro combobox (client) trova per nome, cognome, matricola e CF', async () => {
    const { a } = await h.loginAdmin();
    const { opzioni } = (await a.get('/api/admin/utenti/options')).body;

    /* Stessa logica di filtraDipendenti() in admin.js: includes case-insensitive. */
    const filtra = (t) => {
      const q = t.trim().toLowerCase();
      return opzioni.filter((o) =>
        o.nome.toLowerCase().includes(q) || o.cognome.toLowerCase().includes(q) ||
        o.matricola.toLowerCase().includes(q) || (o.codice_fiscale || '').toLowerCase().includes(q));
    };
    expect(filtra('luigi').map((o) => o.matricola)).toEqual(['qa001']);
    expect(filtra('verde').map((o) => o.matricola)).toEqual(['qa001']);
    expect(filtra('qa002').map((o) => o.matricola)).toEqual(['qa002']);
    expect(filtra('VRDLGU80M01H501B').map((o) => o.matricola)).toEqual(['qa001']);
    expect(filtra('zzzz')).toEqual([]);
  });
});

describe('Impaginazione server-side utenti — GET /utenti (v2.2.9)', () => {
  test('perPagina=10 → 10 righe e pagineTotali coerenti; perPagina=50 → tutto', async () => {
    /* 12 dipendenti extra oltre le 3 fixture → 15 in totale. */
    const hash = await require('bcryptjs').hash('Paginazione1', 4);
    for (let i = 13; i <= 24; i += 1) {
      await h.query(
        `INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, sesso, qualifica, password_hash, ruolo, attivo, must_change_password)
         VALUES (?, ?, 'Pag', 'Inato', 'M', 'Istruttore', ?, 'DIPENDENTE', 1, 0)`,
        [`pg${i}`, `PGRSST85M${String(i).padStart(2, '0')}H501Y`, hash]);
    }

    const { a } = await h.loginAdmin();
    const p10 = await a.get('/api/admin/utenti?perPagina=10&pagina=1');
    expect(p10.status).toBe(200);
    expect(p10.body.utenti.length).toBe(10);
    expect(p10.body.perPagina).toBe(10);
    expect(p10.body.totale).toBe(15);
    expect(p10.body.pagineTotali).toBe(2);

    const p2 = await a.get('/api/admin/utenti?perPagina=10&pagina=2');
    expect(p2.body.utenti.length).toBe(5);

    const p50 = await a.get('/api/admin/utenti?perPagina=50');
    expect(p50.body.utenti.length).toBe(15);
    expect(p50.body.pagineTotali).toBe(1);
  });
});

describe('Cookie di sessione (v2.2.9) — chiuso il browser, re-login', () => {
  test('login normale → Set-Cookie «token» SENZA Max-Age e SENZA Expires', async () => {
    const { r } = await h.loginDip1();
    expect(r.status).toBe(200);

    const cookie = r.headers['set-cookie'].find((c) => c.startsWith('token='));
    expect(cookie).toBeTruthy();
    expect(/max-age/i.test(cookie)).toBe(false);
    expect(/expires/i.test(cookie)).toBe(false);
  });

  test('primo accesso → «token_cambio» conserva Max-Age 900000 (15 min)', async () => {
    /* Fixture con must_change_password=1, come un account appena creato. */
    const hash = await require('bcryptjs').hash('Provvisoria1', 4);
    await h.query(
      `INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, sesso, qualifica, password_hash, ruolo, attivo, must_change_password)
       VALUES ('qa009', 'QARSSN90D11H501Z', 'Primo', 'Accesso', 'F', 'Assistente', ?, 'DIPENDENTE', 1, 1)`,
      [hash]);

    const { r } = await h.login('qa009', 'Provvisoria1');
    expect(r.status).toBe(200);
    expect(r.body.primoAccesso).toBe(true);

    const cambio = r.headers['set-cookie'].find((c) => c.startsWith('token_cambio='));
    expect(cambio).toBeTruthy();
    /* Express converte i ms in secondi: 15 min = 900 s (900000 ms lato codice). */
    expect(cambio).toMatch(/max-age=900(?!\d)/i);

    const token = r.headers['set-cookie'].find((c) => c.startsWith('token='));
    expect(token === undefined || /max-age/i.test(token)).toBe(false);
  });

  test('dopo il cambio password la sessione è un cookie SENZA Max-Age', async () => {
    const hash = await require('bcryptjs').hash('Provvisoria1', 4);
    await h.query(
      `INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, sesso, qualifica, password_hash, ruolo, attivo, must_change_password)
       VALUES ('qa010', 'QARSSN90D12H501Z', 'Secondo', 'Accesso', 'M', 'Assistente', ?, 'DIPENDENTE', 1, 1)`,
      [hash]);

    const primo = await h.login('qa010', 'Provvisoria1');
    expect(primo.r.body.primoAccesso).toBe(true);

    const r = await primo.a.post('/api/auth/primo-accesso')
      .send({ nuovaPassword: 'NuovaPassa1', confermaPassword: 'NuovaPassa1' });
    expect(r.status).toBe(200);

    const cookie = r.headers['set-cookie'].find((c) => c.startsWith('token='));
    expect(cookie).toBeTruthy();
    expect(/max-age/i.test(cookie)).toBe(false);
    expect(/expires/i.test(cookie)).toBe(false);
  });
});

describe('Esporta Anagrafica CSV — GET /utenti/export (v2.2.9)', () => {
  test('header esatto, BOM, CRLF, separatore «;» e colonna Stato', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.get('/api/admin/utenti/export');
    expect(r.status).toBe(200);
    expect(r.headers['content-type']).toMatch(/text\/csv;\s*charset=utf-8/);
    expect(r.headers['content-disposition']).toContain('anagrafica-dipendenti.csv');

    const csv = r.text;
    expect(csv.charCodeAt(0)).toBe(0xFEFF);            // BOM UTF-8 (Excel friendly)
    const righe = csv.slice(1).split('\r\n');          // CRLF ovunque
    expect(righe[0]).toBe('Nome;Cognome;Matricola;Codice Fiscale;Sesso;Qualifica;Stato');
    const qa1 = righe.find((x) => x.startsWith('Luigi;Verde;qa001;'));
    expect(qa1).toBe('Luigi;Verde;qa001;VRDLGU80M01H501B;M;Impiegato;Attivo');
  });

  test('un account disabilitato compare come «Disabilitato»', async () => {
    const { a } = await h.loginAdmin();
    const idQa2 = (await h.query("SELECT id FROM dipendenti WHERE matricola = 'qa002'"))[0].id;
    await a.put(`/api/admin/utenti/${idQa2}/stato`).send({ attivo: false });

    const csv = (await a.get('/api/admin/utenti/export')).text;
    expect(csv).toContain(`Anna;Gialli;qa002;GLLANN85C15G822C;M;Impiegato;Disabilitato`);
  });

  test('RBAC: export riservato agli admin (dipendente → 403)', async () => {
    const { a } = await h.loginDip1();
    expect((await a.get('/api/admin/utenti/export')).status).toBe(403);
  });
});

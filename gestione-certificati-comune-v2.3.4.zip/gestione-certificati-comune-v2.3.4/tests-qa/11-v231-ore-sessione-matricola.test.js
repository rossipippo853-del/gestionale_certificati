/**
 * ============================================================================
 *  11-v231-ore-sessione-matricola.test.js — ROUND v2.3.1
 * ============================================================================
 *  Cosa verifica (piano di collaudo v2.3.1):
 *   · /formazione: le ore IN ATTESA contano per il target (conteggiate =
 *     approvate + attesa); se l'admin RIFIUTA, le ore escono dal conteggio e
 *     le mancanti aumentano (la barra si riduce);
 *   · sessione di SCHEDA: login e primo-accesso restituiscono `token` nel
 *     body; il middleware accetta `Authorization: Bearer` SENZA cookie e
 *     rifiuta token alterati;
 *   · matricola: lunghezza minima 2 (2-20 alfanumerici) su creazione singola
 *     e import CSV; 1 carattere resta rifiutato.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');

beforeEach(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

async function idDi(matricola) {
  const righe = await h.query('SELECT id FROM dipendenti WHERE matricola = ?', [matricola]);
  return righe[0].id;
}

async function caricaEapprova({ area, ore, stato }) {
  const { a } = await h.loginDip1();
  const up = await h.caricaCertificato(a, { area_tematica: area, numero_ore: ore, numero_minuti: '0' });
  expect(up.status).toBe(201);
  const idCert = up.body.id;
  if (stato) {
    const admin = (await h.loginAdmin()).a;
    const r = await admin.put(`/api/admin/certificati/${idCert}/stato`).send({ stato });
    expect(r.status).toBe(200);
  }
  return idCert;
}

describe('[v2.3.1] Ore conteggiate = approvate + in attesa (target 40h)', () => {
  test('12h in attesa contano: 30h approvate + 12h attesa → target raggiunto', async () => {
    await caricaEapprova({ area: 'Risorse umane', ore: '30', stato: 'APPROVATO' });
    await caricaEapprova({ area: 'Ambiente', ore: '12' }); // resta IN_ATTESA

    const id = await idDi('qa001');
    const { a } = await h.loginAdmin();
    const r = await a.get(`/api/admin/utenti/${id}/formazione`);

    expect(r.status).toBe(200);
    expect(r.body.oreApprovateMinuti).toBe(1800);
    expect(r.body.oreInAttesaMinuti).toBe(720);
    expect(r.body.oreConteggiateMinuti).toBe(2520);
    expect(r.body.oreMancantiMinuti).toBe(0);
    expect(r.body.percentuale).toBe(100);
    expect(r.body.stato).toBe('IN_REGOLA');
    expect(r.body.perArea).toEqual([
      { area: 'Risorse umane', certificati: 1, minuti: 1800, minutiAttesa: 0 },
      { area: 'Ambiente', certificati: 1, minuti: 720, minutiAttesa: 720 },
    ]);
  });

  test('il RIFIUTO toglie ore dal conteggio: la barra si riduce da sola', async () => {
    await caricaEapprova({ area: 'Ambiente', ore: '45' }); // sopra il target finché è in attesa…
    const id = await idDi('qa001');

    const admin = (await h.loginAdmin()).a;
    let r = await admin.get(`/api/admin/utenti/${id}/formazione`);
    expect(r.body.oreConteggiateMinuti).toBe(2700);
    expect(r.body.stato).toBe('IN_REGOLA');

    /* …l'admin rifiuta: le 45h escono dal conteggio → sotto la soglia. */
    const idCert = (await h.query('SELECT id FROM certificati WHERE dipendente_id = ? ORDER BY id', [id]))[0].id;
    const rr = await admin.put(`/api/admin/certificati/${idCert}/stato`)
      .send({ stato: 'RIFIUTATO', nota: 'Documento non leggibile.' });
    expect(rr.status).toBe(200);

    r = await admin.get(`/api/admin/utenti/${id}/formazione`);
    expect(r.body.oreApprovateMinuti).toBe(0);
    expect(r.body.oreInAttesaMinuti).toBe(0);
    expect(r.body.oreConteggiateMinuti).toBe(0);
    expect(r.body.oreMancantiMinuti).toBe(2400);
    expect(r.body.percentuale).toBe(0);
    expect(r.body.stato).toBe('SOTTO_SOGLIA');
    expect(r.body.perArea).toEqual([]);
  });
});

describe('[v2.3.1] Sessione di scheda: token nel body + Authorization Bearer', () => {
  test('login → `token` nel body, valido su /me con Bearer e NESSUN cookie', async () => {
    const { r } = await h.loginDip1();
    expect(r.status).toBe(200);
    expect(typeof r.body.token).toBe('string');
    expect(r.body.token.split('.').length).toBe(3); // JWT

    /* Chiamata SENZA cookie (supertest puro) ma CON header Bearer. */
    const supertest = require('supertest');
    const me = await supertest(h.app).get('/api/auth/me')
      .set('Authorization', `Bearer ${r.body.token}`);
    expect(me.status).toBe(200);
    expect(me.body.utente.matricola).toBe('qa001');
  });

  test('token alterato → 401 anche con header Bearer', async () => {
    const { r } = await h.loginDip1();
    const falso = r.body.token.slice(0, -3) + 'xyz';
    const supertest = require('supertest');
    const me = await supertest(h.app).get('/api/auth/me')
      .set('Authorization', `Bearer ${falso}`);
    expect(me.status).toBe(401);
  });

  test('primo accesso → il token di sessione è nel body del cambio password', async () => {
    const hash = await require('bcryptjs').hash('Provvisoria1', 4);
    await h.query(
      `INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, sesso, qualifica, password_hash, ruolo, attivo, must_change_password)
       VALUES ('qa011', 'QARSSN90D13H501Z', 'Terzo', 'Accesso', 'F', 'Assistente', ?, 'DIPENDENTE', 1, 1)`,
      [hash]);

    const primo = await h.login('qa011', 'Provvisoria1');
    expect(primo.r.body.primoAccesso).toBe(true);

    const r = await primo.a.post('/api/auth/primo-accesso')
      .send({ nuovaPassword: 'NuovaPassa1', confermaPassword: 'NuovaPassa1' });
    expect(r.status).toBe(200);
    expect(typeof r.body.token).toBe('string');

    const supertest = require('supertest');
    const me = await supertest(h.app).get('/api/auth/me')
      .set('Authorization', `Bearer ${r.body.token}`);
    expect(me.status).toBe(200);
    expect(me.body.utente.matricola).toBe('qa011');
  });
});

describe('[v2.3.1] Matricola: lunghezza minima 2 (2-20 alfanumerici)', () => {
  /* password NON fornita: il server la genera e la restituisce una sola volta. */
  const NUOVO = {
    nome: 'Due', cognome: 'Cifre', codice_fiscale: 'DUECFR88A01H501D',
    sesso: 'M', qualifica: 'Istruttore direttivo', ruolo: 'DIPENDENTE',
  };

  test('matricola «12» (2 caratteri) → creazione 201 e login OK', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.post('/api/admin/utenti').send({ ...NUOVO, matricola: '12' });
    expect(r.status).toBe(201);
    expect(r.body.passwordProvvisoria).toMatch(/^[A-Za-z0-9@#$%!?]{8,72}$/);

    const righe = await h.query("SELECT id FROM dipendenti WHERE matricola = '12'");
    expect(righe.length).toBe(1);

    const login = await h.login('12', r.body.passwordProvvisoria);
    expect(login.r.status).toBe(200);
    expect(login.r.body.primoAccesso).toBe(true);
  });

  test('matricola «ab» (2 alfanumerici) → 201', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.post('/api/admin/utenti').send({ ...NUOVO, matricola: 'ab' });
    expect(r.status).toBe(201);
  });

  test('matricola di 1 carattere → 400 con messaggio 2-20', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.post('/api/admin/utenti').send({ ...NUOVO, matricola: 'x' });
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/2-20 caratteri alfanumerici/);
  });

  test('import CSV: matricola «12» accettata, «x» rifiutata con messaggio 2-20', () => {
    const { analizzaCsv } = require('../src/utils/importazione');
    const csv = [
      'Matricola;CF;Nome;Cognome;Sesso;Qualifica_Professionale;E-Mail;Ruolo;password_provvisoria',
      '12;BNNAZA80A01H501U;Anna;Due;F;Dirigente;;DIPENDENTE;',
      'x;BNNAZA80A01H501X;Uno;Solo;F;Dirigente;;DIPENDENTE;',
    ].join('\r\n');
    /* analisi.ok resta true se il FILE è leggibile: gli errori sono per riga. */
    const analisi = analizzaCsv(csv);
    const r12 = analisi.record.find((x) => x.dati.matricola === '12');
    const rx = analisi.record.find((x) => x.dati.matricola === 'x');
    expect(r12.errori).toEqual([]);
    expect(rx.errori.some((e) => /2-20 caratteri alfanumerici/.test(e))).toBe(true);
  });
});

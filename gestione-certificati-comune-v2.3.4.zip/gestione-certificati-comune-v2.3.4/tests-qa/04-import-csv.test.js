/**
 * ============================================================================
 *  04-import-csv.test.js — FASE 2: IMPORTAZIONE MASSIVA CSV (fino a 250 utenti)
 * ============================================================================
 *  Cosa verifica (piano di collaudo §2):
 *   · CSV valido con 250 utenti reali → 250 account nel DB, password cifrate
 *     con bcrypt (Benvenuto@2026 quando la colonna è vuota), 250 cartelle
 *     /uploads/certificati/{matricola}, cambio password obbligatorio;
 *   · re-import dello stesso file (duplicati=ignora) → nessun blocco, tutto
 *     segnalato come "saltato";
 *   · righe malformate (mancano nome/matricola/qualifica/sesso) → errori per
 *     riga, le righe buone vengono comunque importate;
 *   · duplicati=aggiorna → anagrafica aggiornata, password INVARIATA;
 *   · matricola ripetuta DENTRO il file → segnalata;
 *   · intestazione sbagliata, file vuoto, estensione errata, nessun file → 400;
 *   · nel DB non esiste alcuna password in chiaro.
 * ============================================================================
 */
'use strict';
const h = require('./qahelper');
const bcrypt = require('bcryptjs');

beforeAll(async () => { await h.resetDati(); });
afterAll(async () => { await h.chiudi(); });

/** v2.0: genera un CF di prova valido e univoco a partire da un prefisso
 *  letterale e un indice (le cifre codificano l'indice → nessuna collisione). */
function cfDiProva(prefisso, i) {
  const lettere = ((prefisso.replace(/[^A-Za-z]/g, '').toUpperCase() + 'XXXXXX').slice(0, 6));
  return `${lettere}${String(50 + (i % 50)).padStart(2, '0')}A${String(1 + (i % 28)).padStart(2, '0')}M${String(100 + (i % 900)).padStart(3, '0')}Z`;
}

/** Righe CSV di prova con prefisso matricola parametrico (evita collisioni tra test). */
function righeMassive(prefisso, quanti) {
  const nomi = ['Mario', 'Luigi', 'Anna', 'Sara', 'Paolo', 'Giulia', 'Marco', 'Elena'];
  const cognomi = ['Rossi', 'Bianchi', 'Verdi', 'Neri', 'Marroni', 'Azzurri', 'Gialli', 'Viola'];
  const qualifiche = ['Istruttore direttivo', 'Agente di polizia locale', 'Assistente amministrativo', 'Funzionario tecnico'];
  const out = [];
  for (let i = 1; i <= quanti; i++) {
    const n = nomi[i % nomi.length];
    const c = cognomi[(i * 3) % cognomi.length];
    const q = qualifiche[i % qualifiche.length];
    const sesso = i % 2 ? 'F' : 'M';
    const pwd = i % 3 === 0 ? 'PasswordSpecifica1' : ''; // 1 su 3 con password dedicata
    out.push(`${n};${c};${prefisso}${String(i).padStart(3, '0')};${cfDiProva(prefisso, i)};${sesso};${q};;;${pwd}`);
  }
  return out;
}

describe('Import CSV valido: carico massivo di 250 utenti', () => {
  test('250 righe → 250 account, bcrypt, 250 cartelle, cambio pwd obbligatorio', async () => {
    const { a } = await h.loginAdmin();
    const csv = h.csvDipendenti(righeMassive('imp', 250));

    const r = await h.importaCsv(a, csv);
    expect(r.status).toBe(200);
    expect(r.body.dryRun).toBe(false);
    expect(r.body.esito.elaborati).toBe(250);
    expect(r.body.esito.creati).toHaveLength(250);
    expect(r.body.esito.errori).toHaveLength(0);

    /* 1) TUTTI e 250 nel database, con anagrafica e ruoli corretti. */
    const righe = await h.query("SELECT * FROM dipendenti WHERE matricola LIKE 'imp%'");
    expect(righe).toHaveLength(250);
    expect(righe.every((u) => u.attivo === 1)).toBe(true);
    expect(righe.every((u) => u.must_change_password === 1)).toBe(true); // cambio forzato al 1° accesso
    expect(righe.every((u) => ['M', 'F', 'ALTRO'].includes(u.sesso))).toBe(true);
    expect(righe.every((u) => u.qualifica.length >= 2)).toBe(true);

    /* v2.0: TUTTI i 250 hanno un codice fiscale ben formato e univoco. */
    expect(righe.every((u) => /^[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]$/.test(u.codice_fiscale))).toBe(true);
    expect(new Set(righe.map((u) => u.codice_fiscale)).size).toBe(250);

    /* 2) Password: SEMPRE hash bcrypt; nessuna password in chiaro. */
    expect(righe.every((u) => /^\$2[aby]\$/.test(u.password_hash))).toBe(true);
    const senzaHash = righe.filter((u) => u.password_hash.toLowerCase().includes('benvenuto'));
    expect(senzaHash).toHaveLength(0);

    /* 3) La password predefinita funziona SOLO dove la colonna era vuota
     *    (righe con i % 3 == 0 hanno "PasswordSpecifica1"). */
    const conPredefinita = righe.find((u) => u.matricola === 'imp002'); // 2 % 3 ≠ 0 → predefinita
    const conSpecifica = righe.find((u) => u.matricola === 'imp003'); // 3 % 3 == 0 → dedicata
    expect(await bcrypt.compare('Benvenuto@2026', conPredefinita.password_hash)).toBe(true);
    expect(await bcrypt.compare('PasswordSpecifica1', conSpecifica.password_hash)).toBe(true);
    expect(await bcrypt.compare('Benvenuto@2026', conSpecifica.password_hash)).toBe(false);

    /* 4) Il report indica per ogni creato la password e se è quella predefinita. */
    const creatoPredefinito = r.body.esito.creati.find((c) => c.matricola === 'imp002');
    expect(creatoPredefinito.password).toBe('Benvenuto@2026');
    expect(creatoPredefinito.predefinita).toBe(true);
    expect(creatoPredefinito.codice_fiscale).toBe(cfDiProva('imp', 2)); // v2.0: CF nel report

    /* 5) v2.0: 250 cartelle create, UNA PER CODICE FISCALE. */
    const fs = require('node:fs');
    const cartelle = fs.readdirSync(h.DIR_CERT).filter((d) => /^[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]$/.test(d));
    expect(cartelle).toHaveLength(250);
    expect(cartelle).toContain(cfDiProva('imp', 250));
  }, 180000);

  test('re-import dello stesso file con duplicati=ignora → 250 saltati, NESSUN blocco', async () => {
    const { a } = await h.loginAdmin();
    const csv = h.csvDipendenti(righeMassive('imp', 250));

    const r = await h.importaCsv(a, csv);
    expect(r.status).toBe(200);
    expect(r.body.esito.creati).toHaveLength(0);
    expect(r.body.esito.saltati).toHaveLength(250);
    expect(r.body.esito.errori).toHaveLength(0);

    // Il DB è rimasto a 250 utenti imp* e le password sono INVARIATE
    const righe = await h.query("SELECT COUNT(*) AS n FROM dipendenti WHERE matricola LIKE 'imp%'");
    expect(righe[0].n).toBe(250);
  }, 120000);
});

describe('Righe malformate e casi limite del CSV', () => {
  const HEAD = 'nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale;email;ruolo;password_temporanea';

  test('righe incomplete (manca nome / matricola / CF / qualifica / sesso) → errori per riga, le buone importate', async () => {
    const { a } = await h.loginAdmin();
    const csv = h.csvDipendenti([
      'Bruno;Sani;mal001;SNIBRN80A01H501U;M;Istruttore direttivo;;DIPENDENTE;', // OK
      ';;mal002;MLSMLO85B02H501V;M;Istruttore;;DIPENDENTE;',                    // mancano nome e cognome
      'Carla;Melo;mal003;MLCRL90C03H501W;F;;',                                   // manca la qualifica
      'Dario;Neri;;NRIDRI95D04H501X;M;Funzionario;;DIPENDENTE;',                 // manca la matricola
      'Elena;Piu;mal005;PIELN98E05H501Y;X;Assistente;;DIPENDENTE;',              // sesso non ammesso
      'Franco;Sala;SLAFRN86F06H501Z;SLAFRN86F06H501Z;M;Agente;;DIPENDENTE;corta',// CF malformato (ripete il cognome) + pwd debole
    ]);
    const r = await h.importaCsv(a, csv);
    expect(r.status).toBe(200);

    const e = r.body.esito;
    expect(e.elaborati).toBe(6);
    expect(e.creati.map((c) => c.matricola)).toEqual(['mal001']); // SOLO la riga valida
    expect(e.errori).toHaveLength(5);
    const testi = JSON.stringify(e.errori);
    expect(testi).toMatch(/"riga":3/); // il report cita il numero di riga del FILE (intestazione = 1)
    expect(testi).toMatch(/"matricola":"mal002"/);
    expect(testi).toMatch(/codice_fiscale non valido/); // v2.0: riga 6 malformata
    expect(testi).toMatch(/nome non valido/);
    expect(testi).toMatch(/qualifica/);
    expect(testi).toMatch(/matricola non valida/);
    expect(testi).toMatch(/sesso non valido/);
    expect(testi).toMatch(/password_temporanea/);

    // Le righe in errore NON sono state salvate
    const righe = await h.query("SELECT matricola FROM dipendenti WHERE matricola LIKE 'mal%'");
    expect(righe.map((x) => x.matricola)).toEqual(['mal001']);
  });

  test('matricola ripetuta DENTRO lo stesso file → la seconda viene segnalata', async () => {
    const { a } = await h.loginAdmin();
    const csv = h.csvDipendenti([
      'Prima;Volta;dup001;DPDMRA80A01H501U;M;Istruttore;;DIPENDENTE;',
      'Seconda;Volta;dup001;DCDMRA85B02H501V;M;Istruttore;;DIPENDENTE;',
    ]);
    const r = await h.importaCsv(a, csv);
    expect(r.status).toBe(200);
    expect(r.body.esito.creati).toHaveLength(1);
    expect(JSON.stringify(r.body.esito.errori)).toMatch(/matricola duplicata nel file/);
    const n = await h.query("SELECT COUNT(*) AS n FROM dipendenti WHERE matricola = 'dup001'");
    expect(n[0].n).toBe(1);
  });

  test('[v2.0] codice fiscale GIÀ PRESENTE a DB (altro dipendente) → riga in errore, nessuna creazione', async () => {
    const { a } = await h.loginAdmin();
    const csv = h.csvDipendenti([
      'Rubo;Fiscale;dupcf001;VRDLGU80M01H501B;M;Istruttore;;DIPENDENTE;', // CF di qa001 (fixture)
      'Regolare;Fiscale;dupcf002;RGLMRA80A01H501U;M;Istruttore;;DIPENDENTE;',
    ]);
    const r = await h.importaCsv(a, csv);
    expect(r.status).toBe(200);
    expect(r.body.esito.creati.map((c) => c.matricola)).toEqual(['dupcf002']); // solo la 2ª
    expect(JSON.stringify(r.body.esito.errori)).toMatch(/codice_fiscale già registrato per la matricola qa001/);
    const n = await h.query("SELECT COUNT(*) AS n FROM dipendenti WHERE matricola = 'dupcf001'");
    expect(n[0].n).toBe(0);
  });

  test('[v2.0] duplicati=aggiorna con CF DIVERSO dal DB → riga in errore (CF non modificabile)', async () => {
    const { a } = await h.loginAdmin();
    const hashVecchia = await bcrypt.hash('Vecchia@2026', 4);
    await h.query(
      "INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, sesso, qualifica, password_hash, ruolo, attivo, must_change_password) VALUES ('agg002','AGGMRA80A01H501U','Vera','Stanza','F','Impiegato',?, 'DIPENDENTE',1,0)",
      [hashVecchia]
    );
    const csv = h.csvDipendenti(['Vera;Rinnovata;agg002;ATRCFM80A01H501U;F;Dirigente;;DIPENDENTE;']);
    const r = await h.importaCsv(a, csv, { duplicati: 'aggiorna' });
    expect(r.status).toBe(200);
    expect(r.body.esito.aggiornati).toHaveLength(0);
    expect(JSON.stringify(r.body.esito.errori)).toMatch(/codice_fiscale non corrispondente/);
    const u = (await h.query("SELECT * FROM dipendenti WHERE matricola = 'agg002'"))[0];
    expect(u.cognome).toBe('Stanza');            // niente aggiornamento
    expect(u.codice_fiscale).toBe('AGGMRA80A01H501U'); // CF invariato
  });

  test('duplicati=aggiorna: anagrafica aggiornata MA password invariata', async () => {
    const { a } = await h.loginAdmin();

    // 1) utente pre-esistente con password NOTA e CF noto
    const hashVecchia = await bcrypt.hash('Vecchia@2026', 4);
    await h.query(
      "INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, sesso, qualifica, password_hash, ruolo, attivo, must_change_password) VALUES ('agg001','VRAAAA80A01H501U','Vera','Stanza','F','Impiegato',?, 'DIPENDENTE',1,0)",
      [hashVecchia]
    );

    // 2) import con cognome/qualifica DIVERSI ma STESSO CF (coerente)
    const csv = h.csvDipendenti(['Vera;Rinnovata;agg001;VRAAAA80A01H501U;F;Dirigente;;DIPENDENTE;']);
    const r = await h.importaCsv(a, csv, { duplicati: 'aggiorna' });
    expect(r.status).toBe(200);
    expect(r.body.esito.aggiornati).toHaveLength(1);

    const u = (await h.query("SELECT * FROM dipendenti WHERE matricola = 'agg001'"))[0];
    expect(u.cognome).toBe('Rinnovata');
    expect(u.qualifica).toBe('Dirigente');
    // La vecchia password FUNZIONA ANCORA (l'import non la tocca mai)
    expect(await bcrypt.compare('Vecchia@2026', u.password_hash)).toBe(true);

    // 3) il login continua con la password originale
    const { r: rLogin } = await h.login('agg001', 'Vecchia@2026');
    expect(rLogin.status).toBe(200);
  });

  test('intestazione del vecchio formato v1.3 (senza sesso/qualifica) → 400 esplicito', async () => {
    const { a } = await h.loginAdmin();
    const csv = Buffer.from('\uFEFFmatricola;nome;cognome;email;ruolo;password_temporanea\r\n30100;Maria;Carta;;DIPENDENTE;\r\n', 'utf8');
    const r = await h.importaCsv(a, csv);
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/colonne obbligatorie mancanti/i);
    expect(r.body.errore).toMatch(/codice_fiscale/); // v2.0
    expect(r.body.errore).toMatch(/sesso/);
    expect(r.body.errore).toMatch(/qualifica/);
  });

  test('file vuoto → 400; solo intestazione → 200 con 0 righe elaborate', async () => {
    const { a } = await h.loginAdmin();
    const vuoto = await h.importaCsv(a, Buffer.from('', 'utf8'));
    expect(vuoto.status).toBe(400);

    const soloHead = await h.importaCsv(a, h.csvDipendenti([]));
    expect(soloHead.status).toBe(200);
    expect(soloHead.body.esito.elaborati).toBe(0);
  });

  test('estensione non CSV (.exe) → 400 con messaggio di formato', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.post('/api/admin/utenti/import')
      .field('duplicati', 'ignora')
      .attach('file', Buffer.from('MZqualcosa'), { filename: 'elenco.exe', contentType: 'application/octet-stream' });
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/csv/i);
  });

  test('file CSV oltre 2 MB → 400', async () => {
    const { a } = await h.loginAdmin();
    const righeTante = righeMassive('big', 2000).concat(righeMassive('big2', 2000));
    let csv = h.csvDipendenti(righeTante);
    // portiamo il file oltre i 2 MB con UNA sola concat (costruzione O(n))
    const rigaExtra = Buffer.from('\r\nXxx;Yyy;bigx0;BGXXXX80A01H501U;M;Qualifica lunga sufficiente;;DIPENDENTE;', 'utf8');
    const ripetizioni = Math.ceil((2 * 1024 * 1024 + 100 - csv.length) / rigaExtra.length);
    csv = Buffer.concat([csv, ...Array(ripetizioni).fill(rigaExtra)]);
    const r = await h.importaCsv(a, csv, { nome: 'grosso.csv' });
    expect(r.status).toBe(400);
    expect(r.body.errore).toMatch(/troppo grande/i);
  }, 60000);

  test('nessun file allegato → 400', async () => {
    const { a } = await h.loginAdmin();
    const r = await a.post('/api/admin/utenti/import').field('duplicati', 'ignora');
    expect(r.status).toBe(400);
  });

  test('DRY RUN (prova generale): nessun utente creato, nessuna cartella, password predefinita preannunciata', async () => {
    const { a } = await h.loginAdmin();
    const csv = h.csvDipendenti(['Gino;Prova;dry001;DRYMRA80A01H501U;M;Istruttore;;DIPENDENTE;']);
    const r = await h.importaCsv(a, csv, { dryRun: true });
    expect(r.status).toBe(200);
    expect(r.body.dryRun).toBe(true);
    expect(r.body.esito.creati).toHaveLength(1);
    // In PROVA GENERALE la password NON viene esposta (nessun account creato):
    // il flag "predefinita" anticipa chi riceverà Benvenuto@2026 al momento reale.
    expect(r.body.esito.creati[0].password).toBeNull();
    expect(r.body.esito.creati[0].predefinita).toBe(true);
    expect(r.body.esito.creati[0].codice_fiscale).toBe('DRYMRA80A01H501U'); // v2.0

    const n = await h.query("SELECT COUNT(*) AS n FROM dipendenti WHERE matricola = 'dry001'");
    expect(n[0].n).toBe(0);
    expect(h.fileSuDisco('dry001')).toBeNull(); // cartella MAI creata in dry-run
  });
});

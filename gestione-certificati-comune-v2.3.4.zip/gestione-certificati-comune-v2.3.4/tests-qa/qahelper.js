/**
 * ============================================================================
 *  tests-qa/qahelper.js — INFRASTRUTTURA DELLA SUITE DI COLLAUDO (Jest + Supertest)
 * ============================================================================
 *  Ambiente ISOLATO dalla produzione e dalla suite di regressione (tests/):
 *    · database  : certificati_comune_test (stesso schema ufficiale)
 *    · upload    : uploads-qa/ (mai in uploads/ reale)
 *    · processo  : Jest lanciato con --runInBand (i test toccano lo stesso DB)
 *
 *  L'app Express viene importata SENZA metterla in ascolto: Supertest la
 *  monta su una porta effimera ad ogni richiesta (nessuna interferenza con
 *  l'eventuale server di produzione su :3000).
 * ============================================================================
 */
'use strict';

/* Le variabili d'ambiente vanno impostate PRIMA di importare app/config/db. */
process.env.NODE_ENV = 'test';
process.env.DB_HOST = '127.0.0.1';
process.env.DB_PORT = '3306';
process.env.DB_USER = 'cert_app';
process.env.DB_PASSWORD = 'C3rt!2026Demo';
process.env.DB_NAME = 'certificati_comune_test';
process.env.JWT_SECRET = 'segreto-di-collaudo-qa-jest-non-usare-in-prod';
process.env.JWT_SCADENZA = '8h';
process.env.COOKIE_SECURE = 'false';
process.env.UPLOAD_DIR = 'uploads-qa';

const fs = require('node:fs');
const path = require('node:path');
const bcrypt = require('bcryptjs');
const supertest = require('supertest');

const { app } = require('../src/app');
const { pool } = require('../src/db');

const DIR_CERT = path.resolve(__dirname, '..', 'uploads-qa', 'certificati');

/* Fixture note: 1 amministratore + 2 dipendenti (cambio password già fatto). */
/* v2.0: ogni fixture ha un Codice Fiscale (formato italiano valido, univoco):
 * è la chiave delle cartelle uploads/certificati/{cf}/. */
const ADMIN = { matricola: 'qa000', codice_fiscale: 'ZNCMNA70A01H501A', nome: 'Amministra', cognome: 'Zione', password: 'AdminQa2026' };
const DIP1 = { matricola: 'qa001', codice_fiscale: 'VRDLGU80M01H501B', nome: 'Luigi', cognome: 'Verde', password: 'DipQa2026' };
const DIP2 = { matricola: 'qa002', codice_fiscale: 'GLLANN85C15G822C', nome: 'Anna', cognome: 'Gialli', password: 'DipQa2026' };

/** Svuota tabelle + cartelle upload e ricrea le fixture note. */
async function resetDati() {
  const conn = await pool.getConnection();
  try {
    await conn.query('SET FOREIGN_KEY_CHECKS = 0');
    await conn.query('DELETE FROM allegati');
    await conn.query('DELETE FROM certificati');
    await conn.query('DELETE FROM dipendenti');
    await conn.query('SET FOREIGN_KEY_CHECKS = 1');
  } finally {
    conn.release();
  }

  fs.rmSync(path.resolve(__dirname, '..', 'uploads-qa'), { recursive: true, force: true });
  fs.mkdirSync(DIR_CERT, { recursive: true });

  const hashAdmin = await bcrypt.hash(ADMIN.password, 4);
  const hashDip = await bcrypt.hash(DIP1.password, 4);
  const ins = `INSERT INTO dipendenti (matricola, codice_fiscale, nome, cognome, sesso, qualifica, password_hash, ruolo, attivo, must_change_password)
               VALUES (?, ?, ?, ?, 'M', 'Impiegato', ?, ?, 1, 0)`;
  await pool.query(ins, [ADMIN.matricola, ADMIN.codice_fiscale, ADMIN.nome, ADMIN.cognome, hashAdmin, 'AMMINISTRATORE']);
  await pool.query(ins, [DIP1.matricola, DIP1.codice_fiscale, DIP1.nome, DIP1.cognome, hashDip, 'DIPENDENTE']);
  await pool.query(ins, [DIP2.matricola, DIP2.codice_fiscale, DIP2.nome, DIP2.cognome, hashDip, 'DIPENDENTE']);
}

/** Chiusura pulita a fine file di test (Jest --runInBand: un pool per file). */
async function chiudi() {
  await pool.end();
}

/** Agente Supertest con cookie-persistence: dopo login() mantiene la sessione. */
function agente() {
  return supertest.agent(app);
}

/** [v2.3.3] Modalità rigida: le chiamate autenticate devono portare il token
 *  di scheda nell'header Authorization (come fa il frontend da sessionStorage).
 *  Si avvolge l'agente injectando il Bearer su ogni verbo HTTP; il cookie
 *  resta nella giara e continua a servire per i download diretti. */
function agenteConToken(agente, token) {
  if (!token) return agente;
  for (const verbo of ['get', 'post', 'put', 'delete', 'patch']) {
    const originale = agente[verbo].bind(agente);
    agente[verbo] = (...argomenti) => {
      const richiesta = originale(...argomenti);
      richiesta.set('Authorization', `Bearer ${token}`);
      return richiesta;
    };
  }
  return agente;
}

/** Login comodo: restituisce l'agente autenticato + la risposta del login. */
async function login(matricola, password) {
  const a = supertest.agent(app);
  const r = await a.post('/api/auth/login').send({ matricola, password });
  agenteConToken(a, r.body && r.body.token); // [v2.3.3]
  return { a, r };
}

async function loginAdmin() { return login(ADMIN.matricola, ADMIN.password); }
async function loginDip1() { return login(DIP1.matricola, DIP1.password); }
async function loginDip2() { return login(DIP2.matricola, DIP2.password); }

/** PDF minimale ma GENUINO (inizia con "%PDF-", come richiedono i magic bytes). */
function pdfBuffer(etichetta = 'certificato QA') {
  const corpo = [
    '%PDF-1.4',
    '1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj',
    '2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj',
    '3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]>>endobj',
    `% ${etichetta}`,
    'trailer<</Size 4/Root 1 0 R>>',
    '%%EOF',
    '',
  ].join('\n');
  return Buffer.from(corpo, 'latin1');
}

/** Campi predefiniti del form certificato (tutti validi): si passa solo ciò
 *  che il singolo test vuole SOVRASCRIVERE o ELIMINARE (valore null). */
function campiCertificato(override = {}) {
  const base = {
    nome_corso: 'Corso di collaudo QA',
    ente_erogatore: 'Ente di formazione QA',
    data_conseguimento: '2026-05-10',
    numero_ore: '8',
    esame_finale: '1',
    area_tematica: 'Transizione digitale',
  };
  const out = {};
  for (const [k, v] of Object.entries(base)) {
    if (override[k] !== null) out[k] = override[k] !== undefined ? override[k] : v;
  }
  return out;
}

/** Upload di un certificato con Supertest (multipart). */
function caricaCertificato(agenteAuth, override = {}, file) {
  let req = agenteAuth.post('/api/certificati');
  for (const [k, v] of Object.entries(campiCertificato(override))) req = req.field(k, v);
  const f = file || { buffer: pdfBuffer(), nome: 'attestato.pdf', mime: 'application/pdf' };
  if (f !== null) {
    req = req.attach('file', f.buffer, { filename: f.nome, contentType: f.mime });
  }
  return req;
}

/** Builder di righe CSV dipendenti nel formato v1.4 (+ BOM e CRLF come da modello). */
function csvDipendenti(righe, { bom = true, intestazione } = {}) {
  const head = intestazione || 'nome;cognome;matricola;codice_fiscale;sesso;qualifica_professionale;email;ruolo;password_temporanea'; // v2.0
  const corpo = [head, ...righe].join('\r\n');
  return Buffer.from((bom ? '\uFEFF' : '') + corpo, 'utf8');
}

/** POST comodo dell'import CSV (pannello admin). */
function importaCsv(agenteAdmin, buffer, { duplicati = 'ignora', dryRun = false, nome = 'elenco.csv' } = {}) {
  return agenteAdmin
    .post('/api/admin/utenti/import')
    .field('duplicati', duplicati)
    .field('dry_run', dryRun ? '1' : '0')
    .attach('file', buffer, { filename: nome, contentType: 'text/csv' });
}

/** Lettura diretta a DB (per verificare hash, flag, percorsi…). */
async function query(sql, params) {
  const [righe] = await pool.query(sql, params);
  return righe;
}

/** Elenco dei file nella cartella upload di una matricola. */
function fileSuDisco(matricola) {
  const dir = path.join(DIR_CERT, matricola);
  return fs.existsSync(dir) ? fs.readdirSync(dir) : null; // null = cartella ASSENTE
}

/** Piccolo parser CSV RFC-4180 (serve a verificare l'export senza farsi
 *  ingannare da separatori/virgolette DENTRO i campi). */
function parseCsvRighe(testo) {
  const righe = [];
  let riga = [];
  let campo = '';
  let inQ = false;
  for (let i = 0; i < testo.length; i++) {
    const c = testo[i];
    if (inQ) {
      if (c === '"') {
        if (testo[i + 1] === '"') { campo += '"'; i++; } else inQ = false;
      } else campo += c;
    } else if (c === '"') inQ = true;
    else if (c === ';') { riga.push(campo); campo = ''; }
    else if (c === '\n') { riga.push(campo); righe.push(riga); riga = []; campo = ''; }
    else if (c !== '\r') campo += c;
  }
  riga.push(campo);
  righe.push(riga);
  return righe.filter((r) => !(r.length === 1 && r[0] === ''));
}

module.exports = {
  app, pool, DIR_CERT,
  ADMIN, DIP1, DIP2,
  resetDati, chiudi,
  agente, login, loginAdmin, loginDip1, loginDip2,
  pdfBuffer, campiCertificato, caricaCertificato,
  csvDipendenti, importaCsv, query, fileSuDisco, parseCsvRighe,
};

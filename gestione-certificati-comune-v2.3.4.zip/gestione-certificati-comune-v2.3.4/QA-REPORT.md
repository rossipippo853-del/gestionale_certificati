# 🧪 Report QA — Test complete e revisione v1.2.0

## Come eseguire la suite

```bash
npm test
```

Il comando (1) rigenera il database di test `certificati_comune_test` applicando
lo schema ufficiale `db/schema.sql`, (2) esegue **74 test** con il runner nativo
di Node (`node --test`, sequenziali, in processi separati). I test usano un
database e una cartella upload **dedicati** (`uploads-test/`, porta 3100): non
toccano mai i dati reali.

| Area | File | Test |
|---|---|---|
| Autenticazione, sessione, permessi, cambio password | `tests/api.test.js` | 15 |
| CRUD utenti, cartelle matricola, password provvisoria | `tests/utenti.test.js` | 13 |
| Upload/download PDF, race condition, approvazioni, CSV | `tests/certificati.test.js` | 15 |
| Frontend (unit in sandbox VM + smoke pagine + CSP) | `tests/frontend.test.js` | 16 |
| Import massiva da CSV (parser, API, bcrypt, cartelle, duplicati) | `tests/importazione.test.js` | 12 |
| Nuovi campi v1.4 (sesso/qualifica, ore/esame/area, filtri/export) | vari file | +3 |
| **Totale** | | **74 — tutti verdi ✅** |

Copertura dei requisiti: flusso login/token/sessione (incl. token manomesso,
scaduto, revocato, rate-limit, SQL injection) · profilo e cambio password ·
CRUD utenti (creazione con cartella, duplicati, abilita/disabilita, reset) ·
file system (creazione automatica e self-healing della cartella matricola,
upload/download PDF, eliminazione reale dei file) · permessi DIPENDENTE vs
AMMINISTRATORE su ogni endpoint sensibile.

---

## Bug trovati e corretti in questa passata

### B10 — Endpoint `/api/salute` inaccessibile (401) — *routing* 🔴
**Causa:** il router dei certificati era montato su `/api` con
`router.use(autenticazione)` a livello di router: Express esegue quel
middleware per **ogni** percorso che inizia con `/api`, anche dove il router
non ha rotte. `/api/salute` (pubblico, registrato dopo) era quindi sempre 401.
**Fix:** router montato sul prefisso dedicato `/api/certificati` (rotte
`/` e `/:id/file`) e rotte pubbliche registrate prima dei mount. *Scoperto
proprio dalla suite: è il valore dei test di integrazione.*

### B9 — Il logout non invalidava realmente il token 🔴
**Causa:** JWT stateless: `clearCookie` non cancella il token lato server; chi
avesse conservato il cookie sarebbe restato autenticato fino alla scadenza (8 h).
**Fix:** ogni token porta ora un `jti` univoco; il logout lo inserisce in un
registro di revoca in memoria (`src/utils/sessioni.js`, con pulizia automatica
alla scadenza) e il middleware di autenticazione rifiuta i token revocati.
*Limitazione documentata:* lista in memoria = adeguata al server singolo in
intranet; per più istanze usare Redis/tabella dedicata.

### B8 — L'amministratore non poteva cambiare la propria password 🔴
**Causa:** `admin.html` non aveva alcuna sezione Profilo: l'admin a cui veniva
impostata una password provvisoria non aveva modo di sostituirla
dall'interfaccia.
**Fix:** aggiunta tab «Profilo» con dati e form cambio password + banner stato
password provvisoria.

### B2-bis — `must_change_password` non era applicata 🟠
**Causa:** il flag era solo un banner non vincolante: la politica «cambio
obbligatorio al primo accesso» non era in realtà garantita.
**Fix:** nuovo middleware `richiediPasswordAggiornata`: le operazioni di
**scrittura** (upload, gestione utenti/certificati) rispondono
`403 PASSWORD_TEMPORANEA` finché la password provvisoria non è sostituita; la
lettura resta libera (le pagine si caricano e mostrano l'avviso) e
`/api/auth/password` è sempre accessibile. Frontend aggiornato (banner + messaggi).

### B3-bis — Race condition sui nomi file 🟠
**Causa:** `{timestamp}_{nome}.pdf`: due upload nello stesso millisecondo con
lo stesso nome originale si sovrascrivevano a vicenda (una riga DB puntava al
file dell'altro).
**Fix:** nome file `{timestamp}-{random8}_{nome}.pdf`
(`crypto.randomBytes`); test con 5 upload simultanei → 5 file distinti ✅.

### B4-bis — Race condition su creazione utente duplicata 🟡
**Causa:** due create concorrenti della stessa matricola: il perdente poteva
cancellare la cartella del vincitore.
**Fix:** pre-check duplicato prima di creare la cartella + rimozione della
cartella SOLO se la matricola non esiste a DB; l'upload ricrea comunque la
cartella al bisogno (self-healing, testato).

### B1-bis — `uploadRoot` dipendente dalla directory corrente 🟡
**Causa:** `path.resolve(process.cwd(), …)`: avvii con `WorkingDirectory`
diverso (systemd, PM2) mandavano gli upload in una cartella errata.
**Fix:** percorsi risolti rispetto alla radice del progetto (`__dirname/..`).

### B5 — Parametri di ricerca ripetuti (`?q=a&q=b`) 🟡
**Causa:** Express consegna un array: `pulisci()` scartava il valore e il
filtro veniva ignorato. **Fix:** normalizzazione al primo valore (testato).

### B6 — Assenza di Content-Security-Policy 🟠
**Causa:** nessuna CSP + script inline in `index.html` + handler `onclick`
inline nel dialog credenziali.
**Fix:** CSP restrittiva (`script-src 'self'`, `frame-ancestors`, `form-action`,
`base-uri`); script di login spostato in `js/login.js`; `onclick` sostituito da
`addEventListener`. Test che verificano l'assenza di script/handler inline.

### B11 — Il DELETE rispondeva prima che il file fosse davvero cancellato 🟡
**Causa:** la rimozione del PDF era asincrona "fire-and-forget": il server
rispondeva 200 e il file poteva esistere ancora per qualche millisecondo
(la suite l'ha intercettato come test intermittente 1 volta su 8).
**Fix:** nuova funzione `eliminaFileAttesa()` che attende la cancellazione
prima di rispondere: 200 ⇒ record **e** file eliminati. Stabilità verificata
con 6 esecuzioni consecutive della suite (59/59 ciascuna).

### B7 — Nessuno spegnimento ordinato 🟡
**Fix:** gestione SIGTERM/SIGINT in `server.js` (chiusura server + pool MySQL),
utile sotto systemd/PM2; aggiunto log per `unhandledRejection`.

### Nota architetturale (refactoring per la testabilità)
La configurazione Express è stata spostata in **`src/app.js`**; `server.js`
resta il solo avvio/shutdown. È ciò che consente ai test di montare l'app su
una porta di test con ambiente isolato.

---

## I 3 bug già segnalati — confermati, corretti e coperti da test di regressione

| Bug | Stato | Test di regressione |
|---|---|---|
| #1 Loop ricaricamento login | ✅ corretto (v1.1) | `frontend.test.js`: 401 su pagina login → NESSUN redirect; fuori dal login → redirect corretto (eseguiti su common.js reale in sandbox VM) |
| #2 Modale bloccato su abilita/disabilita | ✅ corretto (v1.1) | `common.js`: bottoni in `<form method="dialog">` + reset `returnValue` (tripwire); `api.test.js`/`utenti.test.js`: disabilita → DB `attivo=0` → sessione attiva 401 immediato → riabilita |
| #3 Cartella matricola alla registrazione | ✅ corretto (v1.1) | `utenti.test.js`: creazione utente → cartella esiste SUBITO; duplicato → nessuna cartella orfana; `certificati.test.js`: cartella cancellata → upload la ricrea |

---

## Verifiche di sicurezza incluse nella suite

- ❌ SQL injection su login (`' OR '1'='1' --`) → 401
- ❌ Token con firma sbagliata / scaduto / revocato → 401
- ❌ 6° tentativo di login fallito → 429
- ❌ Dipendente su qualunque API admin → 403; PDF altrui → 403; export → 403
- ❌ Identificatori ostili (`abc`, `0`, `999999`) → 400/404, mai 500
- ❌ PDF falso (testo rinominato) → 400 senza file orfani; `.docx` → 400; >5 MB → 400
- ❌ Formula injection nel CSV (`=1+1 …`) → neutralizzata con apice
- ❌ Ricerca LIKE con metacaratteri (`qa%`) → trattata letteralmente
- ✅ Cookie HttpOnly + SameSite; CSP `script-src 'self'`; mai `password_hash` nelle risposte

## Raccomandazioni residue (fuori dal perimetro attuale)

1. **HTTPS** con reverse proxy + `COOKIE_SECURE=true` prima dell'esposizione reale.
2. **Backup** programmati: `mysqldump` + copia `uploads/` (comandi nel README).
3. Se un giorno si serve l'app da **più istanze**: spostare la lista di revoca
   sessioni su Redis e il rate-limit su un store condiviso.
4. Opzionale: scansione antivirus dei PDF caricati (es. ClamAV) se l'ente la richiede.

---

## v1.4 — Estensione funzionale (nuovi requisiti dirigenziali)

- **Anagrafica completa**: `dipendenti.sesso` (M/F/ALTRO) e `dipendenti.qualifica`
  obbligatori in creazione singola, import CSV e visibili nel profilo.
- **Certificati arricchiti**: `numero_ore` (intero 1-9999), `esame_finale`
  (booleano), `area_tematica` (enum chiuso a 6 aree) obbligatori all'upload.
- **Vista e report admin**: tabella certificati con qualifica/ore/esame/area,
  filtro per area tematica, export CSV completo (anagrafica + dettagli + Link PDF).
- **Import CSV v1.4**: formato con `sesso` e `qualifica_professionale`; password
  predefinita `Benvenuto@2026` quando la colonna è vuota (sempre cifrata bcrypt,
  cambio al primo accesso).
- Migrazione `ALTER` fornita in `db/migrazione-v1.4.sql` (verificata su database
  pre-esistente: dati conservati).

---

## v1.4.1 — Collaudo di sistema pre-rilascio (Principal QA)

- **Nuova suite di collaudo** `tests-qa/` con **Jest 30 + Supertest 7** (116 test):
  autenticazione/sessioni, RBAC, sicurezza upload, import CSV (250 utenti reali),
  CRUD admin + wiring UI, self-healing del file system, export CSV/filtri.
- **4 difetti corretti** (con regressioni dedicate): QA-C1 `/login` 404 → alias 302;
  QA-C2 filtri non validi ignorati → 400 rigorosi; QA-C3 boundary 5 MB (PDF di
  esattamente 5 MB ora accettati); QA-C4 `dipendenteId` tollerante → `/^\d+$/`.
- **Report completo**: [`docs/REPORT-COLLAUDO.md`](docs/REPORT-COLLAUDO.md).
- Esito: **190/190 PASS** (74 regressione + 116 collaudo) → rilascio approvato.

---

## v1.5.0 — Onboarding senza blocchi + preparazione server Intranet

- **Modifica logica**: rimossa ogni barriera al caricamento certificati per chi
  ha la password provvisoria (backend `POST /api/certificati` e frontend);
  resta un **avviso non bloccante** (banner) che invita al cambio password e
  scompare dopo il cambio. Le scritture amministrative conservano il vincolo.
- **Deployment**: nuovo parametro `HOST` (default `0.0.0.0`), guida completa
  `docs/GUIDA-SERVER-INTRANET.md` (Windows/Linux, IP statico, firewall,
  systemd/PM2/Utilità di pianificazione), file `deploy/ecosystem.config.js` per PM2.
- **Test**: nuova suite `tests-qa/08-server-intranet.test.js` (ascolto su tutte
  le interfacce, cookie via IP di rete, nessuna dipendenza esterna) e test
  v1.5 sull'onboarding. Esito **200/200** — `docs/REPORT-TEST-v1.5.md`.

---

## v2.0.0 — Codice Fiscale come chiave dello storage + upload admin

- **DB**: `dipendenti.codice_fiscale VARCHAR(16) NOT NULL UNIQUE` (`db/schema.sql` v2.0;
  migrazione conservativa in `db/migrazione-v2.0.sql` con segnaposto «X+id» per gli storici).
- **Cartelle PDF**: `uploads/certificati/{codice_fiscale}/` (creazione singola, import CSV,
  upload dipendente e nuovo upload admin).
- **Import CSV v2.0**: colonna `codice_fiscale` obbligatoria; righe con CF malformato,
  duplicato nel file o già a DB → errore di riga senza bloccare il resto; l'opzione
  «aggiorna» NON modifica mai il CF (mismatch → errore).
- **Nuovo endpoint `POST /api/admin/certificati`**: l'amministratore carica un
  certificato per conto di un dipendente (PDF nella cartella CF del dipendente,
  record a suo nome, stato IN_ATTESA); dialog «⬆ Carica per dipendente» nel pannello.
- **Export CSV**: 19 colonne con «Codice Fiscale».
- Suite: **211/211 PASS** — `docs/REPORT-TEST-v2.0.md`.

---

## v2.0.1 — Fix UI dashboard (barra filtri/azioni sezione Certificati)

- **Difetto**: «Carica per dipendente» era dentro la griglia dei filtri
  (colonna ~150 px): testo spezzato, pulsante fuori dalla card, non allineato.
- **Fix**: separazione filtri (`.filtro-barra`) da azioni (`.azioni-sezione`)
  dentro `.barra-sezione` (flex, wrap); pulsanti standardizzati
  (min-height 40px, white-space nowrap, icone SVG 16px, hover/active/focus
  uniformi); «Azzera» allineato alla riga degli input; regole responsive 860/560 px.
- Verifica: 211/211 test PASS (wiring e ID invariati).

---

## v2.1.0 — Cambio password obbligatorio in modale al primo accesso

- **Flusso**: login con credenziali corrette ma `must_change_password=1` → NESSUNA
  sessione; risposta `{primoAccesso:true}` + cookie monouso `token_cambio`
  (JWT «scopito» 15 min). La pagina di login apre la modale bloccante
  «Primo Accesso — Cambio Password Obbligatorio» (no X, ESC annullato, nessuna
  chiusura esterna). `POST /api/auth/primo-accesso` valida (coincidenza, policy,
  diversa dalla provvisoria), aggiorna l'hash bcrypt, azzera il flag, revoca il
  cookie consumato ed emette la sessione → ingresso diretto in dashboard.
- **Sicurezza**: il cookie `token_cambio` è rifiutato come sessione dal
  middleware (token «scopiti» → 401) ed è MONOUSO (jti revocato dopo l'uso);
  tutti i percorsi di creazione utente (singolo, CSV, reset) impostano il flag.
- **Compatibilità v1.5**: con sessione già attiva (reset mentre l'utente è
  connesso) restano validi banner non bloccante e upload consentito; il
  successivo login passa dalla modale.
- **Suite**: 216/216 PASS (78 `node --test` + 138 Jest/Supertest, 8 suite):
  nuovo test end-to-end v2.1 (8 passaggi), describe dedicato in 01-autenticazione
  (3 test), aggiorna 05/06 al nuovo contratto, 2 test strutturali del frontend.

---

## v2.1.1 — Auditoria QA principal (unit puri + integrazione + race + sicurezza)

- **Nuove suite**: `tests/audit-unit.test.js` (29 unit test puri di validazione,
  sessioni, file, importazione: confini, input ostili, path traversal) e
  `tests-audit/audit-integrazione-sicurezza.test.js` (24 test Jest/Supertest:
  HTTP robustezza, token/cookie, RACE reali, confini upload, campi, paginazione).
  Totale: 269 test (107 `node --test` + 162 Jest), tutti PASS.
- **Correzioni apportate dall'audit** (app, non test):
  · F1 `utils/file.js` — `cartellaDipendente('')` rifiutata (non più risolta sulla radice);
  · F2 `admin.routes.js` — race su POST /utenti: la cartella CF del "perdente"
    viene rimossa se vuota (zero cartelle orfane, mai documenti cancellati);
  · F3 `validazione.js` — date inesistenti nel calendario ('2026-02-30') ora
    rifiutate (V8 le arrotola al mese successivo e MySQL le respingerebbe a 500);
  · C3 `auth.routes.js` — prenotazione sincrona dei jti di primo accesso
    (CAMBI_IN_CORSO): il cookie monouso non è più consumabile due volte in
    parallelo [200,200 → 200,401].
- Dettagli e matrice di copertura: `docs/REPORT-QA-AUDIT.md`.

---

## v2.2.0 — Allegati multipli, durata ore:minuti, filtro esame, badge ore

- **Allegati multipli (PDF/JPEG/PNG)**: nuova tabella `allegati` (FK a cascata,
  `db/migrazione-v2.2.sql`); upload fino a 5 file per corso sia per il dipendente
  sia per l'admin «Carica per dipendente»; verifica della firma binaria reale
  (`tipoDaFirma`: %PDF- / FF D8 FF / PNG); download per allegato
  `GET /api/certificati/allegati/:id/file` (solo proprietario o admin); DELETE
  del corso rimuove TUTTI i file; il primo file resta in `percorso_file`
  (compatibilità v1.x e colonna «Link PDF» dell'export).
- **Durata Ore:Minuti**: nuova colonna `numero_minuti` (0-59); 0 ore valide solo
  con minuti ≥ 1 (0:00 → 400); display «8:30» nelle tabelle e nell'export
  (19 colonne invariate); la suite v1.x (solo ore) resta valida.
- **Filtro «Esame finale»** a tendina (Sì/No) nel pannello admin: lista e export
  rispettano `?esame=si|no`; valore non valido → 400.
- **Profilo dipendente**: ore formative totali (somma degli APPROVATI) con
  spunta blu di verifica oltre le 40 ore (`oreTotali` in GET /api/certificati).
- **Suite: 290/290 PASS** (115 `node --test` + 175 Jest, 10 suite): 6 nuovi unit
  test v2.2 + 13 test di integrazione dedicati + allineamento di 4 test v1.x al
  nuovo comportamento (JPEG ammesso, 2 file ammessi, messaggi aggiornati).

---

## v2.2.1 — Auditoria QA round 2 sulla superficie v2.2

- **Nuove suite**: `tests/audit-v22b.test.js` (5 unit) e
  `tests-audit/audit-v22b-sicurezza.test.js` (13 test: filtri, allegati, confine
  40 ore, account disabilitato, race parallele miste PDF+PNG).
- **Correzioni apportate dall'audit**:
  · F4 `validazione.js` — i client JSON con ore/minuti NUMERICI venivano
    rifiutati (ore) o AZZERATI in silenzio (minuti: perdita di dato); ora
    accettati (solo numeri finiti; boolean/array/oggetti trattati in sicurezza);
  · F5 routes — parseInt tolleranti su id/campi esterni («1;DROP» → 1):
    aggiunta guardia «solo cifre» su 6 endpoint (file, allegati, stato,
    delete, reset/stato utenti, dipendenteId) coerente con FIX QA-C4;
  · F6 download — Content-Type ora dal TIPO REALE registrato a DB (firma
    binaria), non dall'estensione del nome sul server;
  · B2.4 — comportamento fissato: i campi file estranei sono RIFIUTATI
    (multer LIMIT_UNEXPECTED_FILE → 400, zero scritture).
- **Suite: 309/309 PASS** (121 `node --test` + 188 Jest, 11 suite).

---

# QA v2.2.9 — «Città di Milazzo» (sessione, brand, admin UX, DevOps)

**Ambiente**: MariaDB locale (certificati_comune + certificati_comune_test da
`schema.sql` + `db/migrazione-v2.2.9.sql`), Node 20, prepare-db prima di ogni
runner. App riavviata su :3000 con codice v2.2.9 e smoke live eseguito.

## Esiti della doppia suite (da DB fresco)

| Runner | File | Esito |
|---|---|---|
| `node --test` (regressione + v2.2.9 UI) | tests/ (9 file) | **137/137 PASS** |
| Jest + Supertest (collaudo QA) | tests-qa/ (12 suite) | **218/218 PASS** |
| **TOTALE** | | **355/355 PASS** |

## Test nuovi di questa release

| # | Test | Asseverazione | Esito |
|---|---|---|---|
| 1 | PUT /certificati/:id — modifica completa | 200 `{ok,messaggio}` e PERSISTENZA dei 7 metadati su DB | PASS |
| 2 | PUT — stato e allegati intatti | `IN_ATTESA` resta, 1 allegato presente e scaricabile dal titolare | PASS |
| 3 | PUT — guardie 400/404/400 | id «abc»→400; 999999→404; ore «moltissime»→400 | PASS |
| 4 | PUT — RBAC dipendente | 403 «Operazione riservata agli amministratori.» | PASS |
| 5 | Audit — MODIFICA_CERTIFICATO | riga con autore qa000 e dettagli `Corso «vecchio» → «nuovo»` | PASS |
| 6 | Audit — APPROVAZIONE tracciata | riga `APPROVAZIONE` con certificato_id | PASS |
| 7 | Audit — RBAC lettura | GET /audit dipendente → 403 | PASS |
| 8 | GET /stats — orePerArea | solo APPROVATI; dopo approvazione `{area, minuti:480, corsi:1}` | PASS |
| 9 | Options — campi combobox | id/matricola/CF/nome/cognome dei soli attivi | PASS |
| 10 | Filtro combobox (logica client) | trova per nome, cognome, matricola E CF; «zzzz»→[] | PASS |
| 11 | Impaginazione server-side | perPagina=10 → 10 righe, totale 15, pagineTotali 2; pagina 2 → 5; perPagina=50 → 15 | PASS |
| 12 | Cookie sessione — login | Set-Cookie «token» SENZA Max-Age e SENZA Expires | PASS |
| 13 | Cookie sessione — primo accesso | «token_cambio» conserva `Max-Age=900` (15 min); nessun «token» | PASS |
| 14 | Cookie sessione — post cambio | nuova sessione SENZA Max-Age/Expires | PASS |
| 15 | Export CSV — struttura | BOM, CRLF, «;», header `Nome;Cognome;Matricola;Codice Fiscale;Sesso;Qualifica;Stato`, Content-Type/Disposition | PASS |
| 16 | Export CSV — Stato | account disabilitato → «Disabilitato» | PASS |
| 17 | Export CSV — RBAC | dipendente → 403 | PASS |
| 18–24 | frontend.test.js v2.2.9 (7 test) | brand+stemma+palette in 3 pagine; 18 aree ovunque (prima di «Altro», 24 nel dialog); «💾 Salva» (admin invariato); combobox (4 funzioni+guardia); dialog modifica-cert (10 id+PUT+parserDurata+cache); perPagina/export/audit/grafico (7 id+3 opzioni+wiring); cookie senza maxAge nel codice; nginx.conf (listen 80, proxy 3000, server_name, 25m) | PASS |

## Smoke live (app v2.2.9 su :3000)

| Verifica | Esito |
|---|---|
| `/` brand «Città di Milazzo — Portale Formazione e Certificati» | OK |
| `/admin.html` 9 marker v2.2.9 (combobox, perPagina, export, dialoghi, grafico) | OK |
| Login admin → Set-Cookie «token» senza Max-Age/Expires | OK |
| GET /stats → `orePerArea` (15 aree, top GDPR 2745′) | OK |
| GET /utenti/options → 249 attivi con 5 campi | OK |
| PUT reale su certificato n.1 → 200, DB persistito, APPROVATO intatto | OK |
| Audit → `MODIFICA_CERTIFICATO` «…» → «…» di admin | OK |
| Export CSV → BOM+CRLF+header esatto, filename `anagrafica-dipendenti.csv` | OK |
| Ripristino dati demo (UPDATE originale + svuotamento audit_log) | OK |

## Note di collaudo

- Il cookie di SESSIONE non è verificabile «chiudendo il browser» in Jest:
  l'asseverazione è sull'ASSENZA dei campi `Max-Age`/`Expires` in Set-Cookie
  (semantica RFC 6265: senza scadenza il cookie è di sessione).
- «token_cambio» viaggia in secondi sulla rete: 900 s = 900 000 ms del
  `maxAge` Express (verificato nella suite).
- Suite v2.2.5 aggiornata: 17 → 18 aree (NUOVE_LISTA + slice + AREE_AMMESSE 24).

---

# QA v2.3.0 — Dashboard formazione per dipendente + Tabelle zero-scroll

**Ambiente**: ambiente riprovisionato da zero (npm install, MariaDB server +
schema + seed 250 + prepare-db). Doppia suite da DB fresco; smoke live su :3000.

## Esiti della doppia suite

| Runner | File | Esito |
|---|---|---|
| `node --test` | tests/ (9 file) | **139/139 PASS** |
| Jest + Supertest | tests-qa/ (13 suite) | **223/223 PASS** |
| **TOTALE** | | **362/362 PASS** |

## Test nuovi di questa release

| # | Test | Asseverazione | Esito |
|---|---|---|---|
| 1 | GET formazione — contatori + ore + ripartizione | 3 certificati (1 approvato 8h, 1 attesa, 1 rifiutato) → totale 3, approvati 1, oreApprovateMinuti 480, mancanti 1920, 20%, IN_CORSO, perArea solo area approvata | PASS |
| 2 | Dipendente senza certificati | tutti 0, mancanti 2400, 0%, SOTTO_SOGLIA, perArea [] | PASS |
| 3 | Target raggiunto (32h+8h approvate) | ore 2400, mancanti 0, 100%, IN_REGOLA, perArea ordinata per minuti | PASS |
| 4 | Sopra il target (45h) | ore 2700, mancanti 0, percentuale fermata a 100, IN_REGOLA | PASS |
| 5 | Guardie 400/404/403 | id «abc»→400 «Identificativo non valido.»; 999999→404 «Dipendente non trovato.»; dipendente→403 | PASS |
| 6–7 | frontend.test.js v2.3.0 (2 test) | grafico globale rimosso da html/css/js; 18 id fd-* presenti; funzioni dashboard+wire; endpoint `/formazione`; etichette stato; KPI gradient #1c4d8f→#12315c; table-layout fixed, overflow-wrap anywhere, larghezze colonne (utenti 14% azioni, cert-dip 10%, cert-admin 20%); badge .64rem; .btn-icona; classi tabella-cert-admin/dip; azioni a icona con tooltip «⬇ Scarica il documento» | PASS |
| 8 | Regressione v2.2.9 aggiornata | test «impaginazione» senza più grafico-aree/card-analytics/orePerArea; v2.2.4 azioni dipendente icona+tooltip | PASS |

## Smoke live (app v2.3.0 su :3000, DB demo re-seedato)

| Verifica | Esito |
|---|---|
| /admin.html: 3 marker dashboard, 0 marker grafico v2.2.9 | OK |
| GET /formazione dipendente reale 10001 → 1 approvato, 240′, mancanti 2160′, 10%, IN_CORSO, perArea | OK |
| id «abc» → 400; 999999 → 404 | OK |
| CSS servito: table-layout fixed, .btn-icona, .chip-area | OK |

## Note di collaudo

- Il PUT di stato non accetta «IN_ATTESA» (corretto: si nasce in attesa) — i
  test usano upload senza decisione per lo stato in attesa.
- Ambiente post-reset: node_modules reinstallati e MariaDB riprovisionati
  prima della suite (ricetta standard).

---

# QA v2.3.1 — Chiudi scheda, ore conteggiate, sessione rigida, matricola 2-20

**Ambiente**: riprovisionato (npm install + MariaDB + schema + seed 250 +
prepare-db); doppia suite da DB fresco; smoke live su :3000.

## Esiti della doppia suite

| Runner | File | Esito |
|---|---|---|
| `node --test` | tests/ (9 file) | **143/143 PASS** |
| Jest + Supertest | tests-qa/ + tests-audit/ (14 suite) | **232/232 PASS** |
| **TOTALE** | | **375/375 PASS** |

## Test nuovi/aggiornati di questa release

| # | Test | Asseverazione | Esito |
|---|---|---|---|
| 1 | Ore in attesa contate | 30h approvate + 12h attesa → conteggiate 2520′, mancanti 0, 100%, IN_REGOLA; perArea con minutiAttesa | PASS |
| 2 | Rifiuto toglie ore dal conteggio | 45h attesa → IN_REGOLA; dopo rifiuto → 0′, mancanti 2400, SOTTO_SOGLIA, perArea [] | PASS |
| 3 | Token nel body (login) | `body.token` JWT valido su /me con `Authorization: Bearer` e NESSUN cookie | PASS |
| 4 | Token alterato | Bearer manomesso → 401 | PASS |
| 5 | Token nel body (primo accesso) | risposta cambio password contiene token valido su /me | PASS |
| 6 | Matricola «12» | creazione 201 (password generata), login OK, cambio obbligatorio | PASS |
| 7 | Matricola «ab» | creazione 201 | PASS |
| 8 | Matricola «x» | 400 «2-20 caratteri alfanumerici» | PASS |
| 9 | Import CSV matricole | «12» senza errori; «x» → errore 2-20 | PASS |
| 10–13 | frontend.test v2.3.1 (4) | fd-chiudi + chiudiDashboardFormazione+wire+reset; KPI approvate/inviate/attesa + formula conteggiate (UI+API); sessionStorage CHIAVE_TOKEN+removeItem+Bearer+2 salvaToken; middleware Bearer + token nel body (login e primo-accesso); RE_MATRICOLA {2,20} su validazione/admin.js/importazione; invarianti cookie v2.2.9 intatte | PASS |
| 14 | RE_MATRICOLA unit aggiornato | «ab»/«12» valide; «a» rifiutata (audit-unit) | PASS |
| 15 | validaDatiDipendente confini | 1 carattere → errore; 2 caratteri → valido (audit-unit) | PASS |
| 16 | v2.2.8 aggiornato | PUT anagrafica: «a» → 400 («ab» ora valido, 05-crud-admin) | PASS |
| 17 | B1 suite audit aggiornata | cookie HttpOnly+SameSite=Lax; token nel body PER DESIGN (sessione di scheda) | PASS |
| 18 | v2.3.0 aggiornato | ore conteggiate = approvate+attesa; perArea con minutiAttesa (10-v230) | PASS |

## Smoke live (app v2.3.1 su :3000)

| Verifica | Esito |
|---|---|
| /admin.html: fd-chiudi, fd-ore-approvate/inviate/attesa, testo barra | OK (5 marker) |
| login → token nel body + Set-Cookie senza Max-Age/Expires | OK |
| GET /api/auth/me con Bearer e senza cookie → 200 | OK |
| GET /formazione → nuovi campi conteggiate/attesa + minutiAttesa per area | OK |
| POST /utenti matricola «12» → 201 (poi rimossa dai demo) | OK |

## Decisioni di contratto (da presidiare nelle prossime release)

- **Token nel body**: la suite audit v2.2-b vietava il token nel body (anti
  data-leak XSS). La v2.3.1 lo autorizza PER DESIGN su richiesta utente
  (sessione di scheda in sessionStorage); le difese XSS esistenti restano
  (cookie httpOnly, CSP script-src 'self', escapeHtml sistematico, revoca jti).
- Il cookie httpOnly di sessione NON è stato rimosso: serve ai download
  diretti (export CSV, allegati) e ai client senza sessionStorage.

---

# QA v2.3.2 — Tab «Monitoraggio» (dashboard spostata + analytics aggregate)

**Ambiente**: riprovisionato (npm install + MariaDB + schema + seed 250 +
prepare-db); doppia suite da DB fresco; smoke live su :3000.

## Esiti della doppia suite

| Runner | File | Esito |
|---|---|---|
| `node --test` | tests/ (9 file) | **144/144 PASS** |
| Jest + Supertest | tests-qa/ + tests-audit/ (15 suite) | **236/236 PASS** |
| **TOTALE** | | **380/380 PASS** |

## Test nuovi di questa release

| # | Test | Asseverazione | Esito |
|---|---|---|---|
| 1 | Target 40h CON ore in attesa | 30h approvate + 12h attesa → raggiunti 1/3, 33%, media 840′, in attesa 1, aree su TUTTI i caricamenti, topAree | PASS |
| 2 | Rifiuto escluso dal target | 45h rifiutata + 5h approvata → raggiunti 0, media 100′; il rifiuto resta però un caricamento per le aree | PASS |
| 3 | Zero dati | nessuna divisione per zero: 0/3, 0%, aree [] | PASS |
| 4 | RBAC | dipendente → 403 | PASS |
| 5 | frontend.test v2.3.2 | tab «📊 Monitoraggio» tra Certificati e Profilo; card dashboard DENTRO `sezione-monitoraggio` e NON più sopra i tab; 12 id (donut, legenda, barre-aree, kpi); endpoint `/monitoraggio`; render + refresh all'apertura; CSS donut/griglia/barre | PASS |

## Smoke live (app v2.3.2 su :3000, dati demo 251 dipendenti)

| Verifica | Esito |
|---|---|
| Tab «📊 Monitoraggio» nel menu | OK |
| Card dashboard fuori dai tab, dentro la sezione | OK |
| GET /monitoraggio → target 9/251 (4%), media 206′, 31 in attesa, aree ordinate | OK |
| CSS donut + griglia servito | OK |
| Anonimo → 401 (dipendente autenticato → 403 in suite) | OK |

---

# QA v2.3.3 — Modalità rigida: il cookie non basta più per rientrare

**Problema risolto**: chiudendo la scheda il sessionStorage muore ma il cookie
di sessione sopravvive (RFC 6265: vale per l'intero browser); il controllo
automatico della pagina di login (/me con il solo cookie) riusava il cookie →
rientro senza password. Ora il cookie è accettato SOLO sui download diretti
(link `<a href>` che non possono inviare l'header); per ogni altra richiesta
serve il token di scheda via `Authorization: Bearer`.

## Esiti della doppia suite

| Runner | File | Esito |
|---|---|---|
| `node --test` | tests/ (9 file) | **144/144 PASS** |
| Jest + Supertest | tests-qa/ + tests-audit/ (16 suite) | **241/241 PASS** |
| **TOTALE** | | **385/385 PASS** |

## Test nuovi/aggiornati di questa release

| # | Test | Asseverazione | Esito |
|---|---|---|---|
| 1 | Chiusura scheda simulata | SOLO cookie su /me → 401 «Non autenticato.» (niente rientro automatico) | PASS |
| 2 | Cookie su scrittura | PUT stato con solo cookie → 401 | PASS |
| 3 | Bearer senza cookie | /me → 200 (il token di scheda basta) | PASS |
| 4 | Download col solo cookie | file certificato → 200; export anagrafica → 200 (text/csv) | PASS |
| 5 | Logout via Bearer | revoca jti: il token non è più riutilizzabile → 401 «terminata» | PASS |
| 6–8 | 01 aggiornato | manomesso/scaduto/revocato via Bearer (messaggi specifici) + stesso token via cookie → 401 generico; flusso primo accesso → /me col Bearer emesso | PASS |
| 9–10 | 05 aggiornato | dopo il cambio password /me col Bearer del token emesso (2 punti) | PASS |
| 11 | 08 aggiornato | chiamata autenticata via rete con header Authorization (cookie comunque emesso) | PASS |
| 12 | Helper allineati | qahelper: agente con Bearer automatico; tests/helper.js: chiedi replica il cookie token come Bearer (simula il frontend) | PASS |

## Smoke live (app v2.3.3 su :3000)

| Verifica | Esito |
|---|---|
| Login → token nel body + cookie di sessione | OK |
| /me con SOLO cookie → 401 «Non autenticato.» | OK (il bug è corretto) |
| /me con Bearer → 200 | OK |
| file certificato con SOLO cookie → 200 | OK |
| export certificati con SOLO cookie → 200 | OK |
| export anagrafica con SOLO cookie → 200 | OK |

## Contratto da presidiare

- Allowlist download-con-cookie (GET soltanto): `/api/certificati/:id/file`,
  `/api/certificati/allegati/:id/file`, `/api/admin/utenti/export`,
  `/api/admin/certificati/export`. Nuovi endpoint di download vanno aggiunti a
  `PERCORSI_DOWNLOAD_CON_COOKIE` in `src/middleware/auth.js`.
- Nota residua (browser, non portale): con Chrome «Continua da dove eri» il
  sessionStorage può essere ripristinato al riavvio → rientro automatico anche
  in modalità rigida. È un'impostazione del client.

---

# ROUND v2.3.4 — Storico modifiche con AZIONI SPECIFICHE

Richiesta: nella tabella «📜 Storico modifiche amministrative» la colonna
AZIONE deve mostrare l'operazione ESATTA (es. «Modifica Titolo Corso»,
«Approvazione Certificato», «Eliminazione Metadato», «Cambio Stato») invece
dell'etichetta generica; DETTAGLI conserva il contesto (certificato, prima→dopo).

## Modifiche

| File | Cambiamento |
|---|---|
| `src/routes/admin.routes.js` | PUT metadati: confronto campo per campo → **una riga di audit per OGNI campo realmente modificato** con codice specifico (`MODIFICA_TITOLO_CORSO`, `MODIFICA_ENTE_EROGATORE`, `MODIFICA_DATA_CONSEGUIMENTO`, `MODIFICA_DURATA`, `MODIFICA_ESAME_FINALE`, `MODIFICA_AREA_TEMATICA`) e dettagli `«prima» → «dopo»` (durata h:mm, esame Sì/No); PUT senza variazioni → nessuna riga; /stato → `APPROVAZIONE_CERTIFICATO`/`RIFIUTO_CERTIFICATO` con `Stato: X → Y` (+nota); DELETE → `ELIMINAZIONE_CERTIFICATO` con certificato_id NULL e `Corso «…» · dipendente MATRICOLA`; codice difensivo `ELIMINAZIONE_<CAMPO>` per futuri campi facoltativi |
| `public/js/admin.js` | Traduzione DINAMICA `etichettaAzione()`: regole per prefisso (MODIFICA_→blu, APPROVAZIONE_→verde, RIFIUTO_→rosso, ELIMINAZIONE_→rosso/ambra, CAMBIO_→ambra) + mappa `CAMPI_AUDIT` (funziona anche per codici futuri); etichette fisse contrassegnate «(storico)» per righe pre-v2.3.4; fallback grigio per codici ignoti |
| `public/admin.html` | Hint del dialog storico aggiornato alle azioni specifiche |
| `db/schema.sql` | Commento colonna `audit_log.azione` aggiornato al nuovo contratto |
| `tests-qa/09` | 2 test allineati ai codici specifici |
| `tests-qa/14-v234-audit-specifico.test.js` | NUOVO: 9 test (1 riga per campo, 3 campi→3 righe, durata h:mm, esame Sì/No, PUT identico→0 righe, approvazione/rifiuto con transizione, eliminazione con cert NULL, RBAC 403) |
| `tests/frontend.test.js` | Asserzioni su `etichettaAzione`, `CAMPI_AUDIT`, regola per prefissi |

## Esiti (suite intera rieseguita)

| Verifica | Esito |
|---|---|
| node --test (tests/) | 144/144 PASS |
| Jest (tests-qa/ + tests-audit/) | 250/250 PASS, 17/17 suite |
| **TOTALE** | **394/394 PASS** |
| Smoke live: PUT 3 campi → 3 righe specifiche (#3-#5) | OK |
| Smoke live: PUT identico → 0 righe nuove | OK |
| Smoke live: /stato → APPROVAZIONE_CERTIFICATO «Stato: IN_ATTESA → APPROVATO · Nota…» | OK |
| Smoke live: DELETE → ELIMINAZIONE_CERTIFICATO «Corso «…» · dipendente 10002», cert NULL | OK |
| Etichette dinamiche (test estrazione funzione reale): tutti i 15 codici → etichetta+colore corretti | OK |

## Note

- La colonna AZIONE resta parlante anche per i record più vecchi: le etichette
  pre-v2.3.4 vengono mostrate come «… (storico)».
- La FK `audit_log.certificato_id ON DELETE SET NULL` (di progetto) anonimizza
  le righe di un certificato eliminato: la riga `ELIMINAZIONE_CERTIFICATO`
  conserva corso e matricola nei dettagli.

---

# ROUND v2.3.5 — Impaginazione dei certificati (admin E dipendente)

Richiesta: come per la tabella Dipendenti (v2.2.9), anche l'ELENCO CERTIFICATI
deve avere l'impaginazione lato server, sia nel pannello amministratore sia
nel profilo dipendente.

## Modifiche

| File | Cambiamento |
|---|---|
| `src/routes/certificati.routes.js` | GET /api/certificati: parametri `pagina`/`perPagina` (10/25/50, normalizzati 5–50); risposta con `totale`, `pagina`, `perPagina`, `pagineTotali` e **`conteggi` GLOBALI per stato** (per le card statistiche); `oreTotali` resta calcolata su TUTTI i corsi (contratto v2.3.1 invariato); senza `perPagina` → elenco completo (compatibilità storica/test) |
| `public/js/admin.js` | la tabella certificati NON chiede più `perPagina='tutti'`: usa `filtriCert.perPagina` (default 25); pager `renderPaginazione('paginazione-certificati', …)`; guardia di ribaltamento pagina (se l'ultima riga dell'ultima pagina viene eliminata); selettore `ce-perPagina` |
| `public/admin.html` | selettore «Righe per pagina» 10/25/50 nella barra filtri certificati + contenitore `#paginazione-certificati` |
| `public/js/dipendente.js` | stato `impaginazione` (default 10); chiamata paginata; card statistiche alimentate dai `conteggi` GLOBALI del server (fallback locale per compatibilità); pager `renderPaginazione('paginazione-miei', …)`; guardia di ribaltamento; selettore `dp-perPagina` |
| `public/dipendente.html` | selettore «Righe per pagina» + contenitore `#paginazione-miei` nella card «Elenco dei tuoi certificati» |
| `tests/frontend.test.js` | le asserzioni v2.2.3 «nessuna paginazione sui certificati» sono SOSTITUITE con le nuove (richiesta utente v2.3.5): selettori, contenitori e pager cablati su entrambe le UI |
| `tests-qa/15-v235-impaginazione-certificati.test.js` | NUOVO: 8 test (elenco completo storico; pagine 1/2 con perPagina=5; oreTotali+conteggi GLOBALI identici su ogni pagina; normalizzazione 999→50, 1→5, pagina 0→1, valori non numerici; pagina oltre l'ultima; admin pagina+filtro stato combinati; RBAC 401) |

## Esiti (suite intera rieseguita)

| Verifica | Esito |
|---|---|
| node --test (tests/) | 144/144 PASS |
| Jest (tests-qa/ + tests-audit/) | 257/257 PASS, 18/18 suite |
| **TOTALE** | **401/401 PASS** |
| Smoke live (dipendente 10001, 12 caricamenti): pag.1 = 10 righe, pag.2 = 3 righe, totale 13, pagine 2 | OK |
| Smoke live: oreTotali 3120′ e conteggi {13,1,12,0} IDENTICI sulle 2 pagine | OK |
| Smoke live (admin): totale 91 certificati → 10 pagine con perPagina=10 | OK |

## Note

- «Righe per pagina» è una preferenza di VISTA: «Azzera filtri» non la tocca,
  i filtri riportano invece sempre alla pagina 1.
- Export CSV e statistiche/monitoraggio restano SEMPRE globali (nessun effetto
  dalla pagina visualizzata).
- Compatibilità API: chiamate senza `perPagina` restituiscono l'elenco completo
  (tutti i client e i test preesistenti continuano a funzionare).

---

# ROUND v2.3.6 — Filtri dei certificati «a flusso» (una riga continua)

Richiesta: nella sezione Certificati i campi filtro («Esame finale», «Area
tematica», ecc.) devono disporsi UNO DOPO L'ALTRO su una riga unica, non più
a blocchi fissi di 3 per riga.

## Modifiche

| File | Cambiamento |
|---|---|
| `public/admin.html` | la barra filtri dei CERTIFICATI riceve la classe `filtro-flusso` (unica sezione toccata: Dipendenti resta a griglia) |
| `public/css/stile.css` | nuovo blocco `.filtro-flusso`: flex + wrap (ogni campo in sequenza, a capo solo a fine riga, allineati sul fondo), larghezze calibrate per campo (ricerca 250px, dipendente 200px, area 250px, date 150px, perPagina ≥105px, «Azzera» compatto) |
| `tests/frontend.test.js` | nuovo test v2.3.6: classe presente UNA sola volta, CSS flex+wrap, larghezze |
| `package.json` | versione → 2.3.6 |

## Esiti (suite intera rieseguita)

| Verifica | Esito |
|---|---|
| node --test (tests/) | 145/145 PASS |
| Jest (tests-qa/ + tests-audit/) | 257/257 PASS, 18/18 suite |
| **TOTALE** | **402/402 PASS** |
| Smoke live: /admin.html serve `filtro-barra filtro-flusso`; stile.css serve il blocco | OK |
| Comportamento: campi in riga unica; a capo naturale su schermi stretti; griglia Dipendenti invariata | OK |

---

# ROUND v2.3.7 — Filtri certificati in DUE righe

Richiesta (con schermata): la barra «a flusso» della v2.3.6 si impilava su
TRE righe alla larghezza utile tipica, per le larghezze troppo generose dei
campi. Richiesto: farli stare in DUE righe.

## Causa e correzione

| File | Cambiamento |
|---|---|
| `public/css/stile.css` | larghezze dei campi `.filtro-flusso` COMPRESESSE: ricerca 250→230px, dipendente 200→185px, area 250→210px, date 150→140px; nuove larghezze dedicate stato 120px ed esame 110px; «Righe per pagina» ≥100px. Bilancio: riga 1 ≈ 845px (ricerca+dipendente+stato+esame+dal), riga 2 ≈ 780px (area+al+durata+righe/pagina+Azzera) → DUE righe dalla larghezza utile ≈860px in su, quindi anche a 1024px |
| `tests/frontend.test.js` | asserzioni sulle nuove larghezze (230/185/120/110/210/140) |
| `package.json` | versione → 2.3.7 |

## Esiti (suite intera rieseguita)

| Verifica | Esito |
|---|---|
| node --test (tests/) | 145/145 PASS |
| Jest (tests-qa/ + tests-audit/) | 257/257 PASS, 18/18 suite |
| **TOTALE** | **402/402 PASS** |
| Smoke live: stile.css servito con le larghezze v2.3.7 | OK |

Nota: sotto ≈860px di larghezza utile la barra torna ad andare a capo in
modo naturale (flex-wrap): nessuno scroll orizzontale a nessuna larghezza.

---

# ROUND v2.3.8 — Filtri certificati: DUE righe GARANTITE (griglia 5+5)

Richiesta (terzo giro, con schermata): la v2.3.7 mostrava ancora 3 righe.
Causa: il layout flex «a flusso» dipende dallo spazio residuo (i pulsanti
Export/Storico/Carica condividono la riga dei filtri e la comprimono), quindi
il numero di righe non era deterministico.

## Correzione radicale: layout DETERMINISTICO

| File | Cambiamento |
|---|---|
| `public/css/stile.css` | `.filtro-flusso` diventa una GRIGLIA FISSA a 5 colonne: riga 1 = ricerca, dipendente, stato, esame, area · riga 2 = «dal», «al», durata, righe/pagina, Azzera → ESATTAMENTE 2 righe a qualunque larghezza utile ≥ ~900px (colonne larghe ~170-200px, mai in overflow); media query ≤900px → 2 colonne con a capo naturale; i pulsanti azione (Export CSV, Storico, Carica per dipendente) scendono su una riga propria SOTTO i filtri, allineati a destra (`.barra-certificati`) |
| `public/admin.html` | la barra della sezione Certificati riceve la classe `barra-certificati` |
| `tests/frontend.test.js` | asserzioni sul layout deterministico (griglia 5 colonne, barra dedicata, fallback ≤900px) |
| `package.json` | versione → 2.3.8 |

## Esiti (suite intera rieseguita)

| Verifica | Esito |
|---|---|
| node --test (tests/) | 145/145 PASS |
| Jest (tests-qa/ + tests-audit/) | 257/257 PASS, 18/18 suite |
| **TOTALE** | **402/402 PASS** |
| Smoke live: admin.html serve `barra-certificati`; stile.css serve la griglia 5 colonne | OK |

---

# ROUND v2.3.9 — Pager «Pagina undefined»: robustezza frontend

Segnalazione: nella pagina dipendente il pager mostrava «Pagina undefined di
undefined». Diagnosi: il frontend v2.3.5+ legge i metadati di impaginazione
dalla risposta API; se il SERVER risponde col formato vecchio (file
`src/routes/certificati.routes.js` non aggiornato oppure app NON riavviata
dopo la copia — Node carica i moduli in memoria all'avvio, mentre i file in
`public/` sono letti da disco a ogni richiesta), `pagineTotali` non esiste
→ «undefined».

## Correzione

| File | Cambiamento |
|---|---|
| `public/js/dipendente.js` | guardia: il pager viene renderizzato SOLO se la risposta contiene `pagineTotali` numerico; in caso contrario il contenitore viene svuotato (degradazione elegante, mai più «undefined») |
| `tests/frontend.test.js` | asserzione sulla guardia `Number.isFinite(dati.pagineTotali)` |
| `package.json` | versione → 2.3.9 |

## Esiti (suite intera rieseguita)

| Verifica | Esito |
|---|---|
| node --test (tests/) | 145/145 PASS |
| Jest (tests-qa/ + tests-audit/) | 257/257 PASS, 18/18 suite |
| **TOTALE** | **402/402 PASS** |
| Smoke live: GET /api/certificati?pagina=1&perPagina=50 → {totale, pagina, perPagina, pagineTotali, conteggi} completi | OK |

## NOTA OPERATIVA (per l'installazione)

Per ottenere la paginazione funzionante sul server occorre:
1. copiare `src/routes/certificati.routes.js` aggiornato (pacchetto delta v2.3.5 o zip completo ≥v2.3.5);
2. **RIAVVIARE l'applicazione** (Ctrl+C → `npm start`): a differenza dei file
   in `public/` (serviti da disco), le modifiche in `src/` richiedono il
   riavvio di Node;
3. ricaricare il browser con Ctrl+F5.
Verifica rapida: DevTools → Scheda Rete → risposta di `/api/certificati`
deve contenere `pagineTotali`.

---

# ROUND v2.3.10 — Pager sempre operativo (fallback locale)

Segnalazione: con la v2.3.9, su un server con backend non aggiornato, il pager
spariva (niente più frecce). Correzione: doppio binario nel frontend.

| File | Cambiamento |
|---|---|
| `public/js/dipendente.js` | `caricaCertificati()` a DUE ramì: (1) risposta CON `pagineTotali` → impaginazione server-side come da v2.3.5; (2) risposta SENZA metadati (= elenco completo da backend vecchio) → **impaginazione LOCALE**: la lista viene tagliata nel browser (`slice`), il pager mostra «Pagina X di Y — N risultati» con le frecce operative e i conteggi delle card sono calcolati sulla lista COMPLETA (nuovo helper `conteggiDaLista`) |
| `public/js/admin.js` | guardia: pager nascosto se la risposta non ha metadati (l'API admin li fornisce dalla v2.2.3, quindi il pager resta sempre visibile) |
| `tests/frontend.test.js` | asserzioni sul doppio binario (ramo server, fallback `listaCompleta.slice`, `conteggiDaLista`, guardia admin) |
| `package.json` | versione → 2.3.10 |

## Esiti (suite intera rieseguita)

| Verifica | Esito |
|---|---|
| node --test (tests/) | 145/145 PASS |
| Jest (tests-qa/ + tests-audit/) | 257/257 PASS, 18/18 suite |
| **TOTALE** | **402/402 PASS** |
| Ramo 1 (app vera, backend aggiornato): metadati completi nella risposta | OK |
| Ramo 2 (simulazione vecchio formato, codice reale): 13 corsi → «Pagina 2 di 2 — 13 risultati», card {13,1,12,0} corrette | OK |

---

# ROUND v2.3.11 — Scheda Profilo: nuova card «Siti di formazione»

Richiesta: aggiungere nella scheda Profilo (di dipendente e amministratore)
un blocco con i link alle piattaforme di formazione esterne, apribili in
NUOVA scheda, con nomi/URL facilmente personalizzabili.

## Modifiche

| File | Cambiamento |
|---|---|
| `public/js/common.js` | NUOVO array di configurazione `SITI_FORMAZIONE` (nome, url, descrizione, icona): Syllabus + 2 placeholder; funzione condivisa `renderSitiFormazione()` che rende le righe con `escapeHtml`, `target=_blank` e `rel=noopener noreferrer` |
| `public/dipendente.html` | card «🎓 Siti di formazione» nella sezione Profilo (tra «I tuoi dati» e «Cambio password») con contenitore `#siti-formazione` |
| `public/admin.html` | stessa card nella sezione Profilo dell'amministratore |
| `public/js/dipendente.js` · `public/js/admin.js` | chiamata `renderSitiFormazione('siti-formazione')` negli init |
| `public/css/stile.css` | blocchi `.siti-formazione`/`.sito-formazione`: righe cliccabili con icona, nome blu, descrizione, pulsante «Apri ↗»; hover tinta blu del tema; focus visibile per tastiera |
| `tests/frontend.test.js` | nuovo test v2.3.11 (array, Syllabus, placeholder 2/3, renderer, target/rel, escape, card in entrambe le pagine, init agganciati) |
| `package.json` | versione → 2.3.11 |

## Esiti (suite intera rieseguita)

| Verifica | Esito |
|---|---|
| node --test (tests/) | 146/146 PASS |
| Jest (tests-qa/ + tests-audit/) | 257/257 PASS, 18/18 suite |
| **TOTALE** | **403/403 PASS** |
| Rendering reale (DOM simulato): 3 voci, target=_blank, rel=noopener noreferrer | OK |
| Prova XSS: nome ostile `<script>` resta escapato nel markup | OK |
| Smoke live: card in dipendente.html e admin.html; common.js e stile.css serviti | OK |

## Personalizzazione

Per cambiare nomi/URL basta editare `SITI_FORMAZIONE` in `public/js/common.js`
(aggiungere/togliere voci: l'interfaccia si aggiorna da sola in entrambe le pagine).
